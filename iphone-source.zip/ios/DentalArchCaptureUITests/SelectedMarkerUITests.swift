import XCTest

final class SelectedMarkerUITests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }
    func testFourPhysicalIDsDrivePlanAndCaptureRings() {
        let app = XCUIApplication(); app.launchArguments = ["--ui-testing"]; app.launch()
        let plan = app.buttons["openDentalPlan"]
        for _ in 0..<5 {
            if plan.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(plan.isHittable); plan.tap()
        let count = app.segmentedControls["planMarkerCount"]
        XCTAssertTrue(count.waitForExistence(timeout: 5)); count.buttons["4"].tap()
        XCTAssertEqual(app.staticTexts["selectedMarkerSummary"].label, "4/4 seçili · ID 0, 1, 2, 3")
        let firstReplacement = app.buttons["physicalMarkerSlot_1"]
        XCTAssertTrue(firstReplacement.isHittable); firstReplacement.tap()
        let duplicate = app.buttons["physicalMarkerChoice_1_0"]
        XCTAssertTrue(duplicate.waitForExistence(timeout: 5)); XCTAssertFalse(duplicate.isEnabled)
        app.buttons["physicalMarkerChoice_1_4"].tap()
        app.buttons["physicalMarkerSlot_2"].tap()
        let secondReplacement = app.buttons["physicalMarkerChoice_2_5"]
        XCTAssertTrue(secondReplacement.waitForExistence(timeout: 5)); secondReplacement.tap()
        XCTAssertEqual(app.staticTexts["selectedMarkerSummary"].label, "4/4 seçili · ID 0, 3, 4, 5")
        let selection = XCTAttachment(screenshot: app.screenshot())
        selection.name = "Four actual physical IDs selected: 0, 3, 4, 5"
        selection.lifetime = .keepAlways; add(selection)
        app.tabBars.buttons["Çekim"].tap()
        XCTAssertTrue(app.otherElements["confirmedFlagIDs"].waitForExistence(timeout: 5))
        for id in [0, 3, 4, 5] {
            XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "flagProgress_\(id)").firstMatch.exists)
        }
        for id in [1, 2] {
            XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "flagProgress_\(id)").firstMatch.exists)
        }
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        let rings = XCTAttachment(screenshot: app.screenshot())
        rings.name = "Only selected physical IDs appear in capture progress"
        rings.lifetime = .keepAlways; add(rings)
    }
}
