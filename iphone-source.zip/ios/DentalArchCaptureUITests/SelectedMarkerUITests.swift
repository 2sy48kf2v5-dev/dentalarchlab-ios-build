import XCTest

// Capture the whole screen: app-bounds screenshots can crop a rotated landscape window.

final class SelectedMarkerUITests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }
    override func tearDownWithError() throws { XCUIDevice.shared.orientation = .portrait }
    func testFourPhysicalIDsDrivePlanAndCaptureRings() {
        let app = XCUIApplication(); app.launchArguments = ["--ui-testing"]; app.launch()
        let plan = app.buttons["openDentalPlan"]
        for _ in 0..<5 {
            if plan.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(plan.isHittable); plan.tap()
        let count = app.segmentedControls["planMarkerCount"]
        XCTAssertTrue(count.waitForExistence(timeout: 5))
        XCTAssertTrue(count.buttons["6"].isSelected)
        count.buttons["4"].tap()
        XCTAssertEqual(app.staticTexts["selectedMarkerSummary"].label, "4/4 seçili · ID 0, 1, 2, 3")
        XCTAssertTrue(app.buttons["physicalMarkerSlot_3"].exists)
        count.buttons["6"].tap()
        XCTAssertEqual(app.staticTexts["selectedMarkerSummary"].label, "6/6 seçili · ID 0, 1, 2, 3, 4, 5")
        XCTAssertFalse(app.buttons["physicalMarkerSlot_3"].exists)
        count.buttons["4"].tap()
        XCTAssertEqual(app.staticTexts["selectedMarkerSummary"].label, "4/4 seçili · ID 0, 1, 2, 3")
        let firstReplacement = app.buttons["physicalMarkerSlot_1"]
        XCTAssertTrue(firstReplacement.isHittable); firstReplacement.tap()
        let duplicate = app.buttons["physicalMarkerChoice_1_0"]
        XCTAssertTrue(duplicate.waitForExistence(timeout: 5)); XCTAssertFalse(duplicate.isEnabled)
        app.buttons["physicalMarkerChoice_1_4"].tap()
        app.buttons["physicalMarkerSlot_2"].tap()
        let secondReplacement = app.buttons["physicalMarkerChoice_2_5"]
        XCTAssertTrue(secondReplacement.waitForExistence(timeout: 5)); secondReplacement.tap()
        XCTAssertEqual(app.staticTexts["selectedMarkerSummary"].label, "4/4 seçili · ID 0, 3, 4, 5")
        let selection = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        selection.name = "Four actual physical IDs selected: 0, 3, 4, 5"
        selection.lifetime = .keepAlways; add(selection)
        app.tabBars.buttons["Çekim"].tap()
        XCTAssertTrue(app.otherElements["confirmedFlagIDs"].waitForExistence(timeout: 5))
        for id in [0, 3, 4, 5] {
            XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "flagProgress_\(id)").firstMatch.exists)
        }
        for id in [1, 2] {
            XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "flagProgress_\(id)").firstMatch.exists)
        }
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        let rings = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        rings.name = "Only selected physical IDs appear in capture progress"
        rings.lifetime = .keepAlways; add(rings)
        let exit = app.buttons["captureExit"]
        XCTAssertTrue(exit.waitForExistence(timeout: 8)); exit.tap()
        XCTAssertTrue(app.buttons["openDentalPlan"].waitForExistence(timeout: 8))
        app.buttons["openDentalPlan"].tap()
        XCTAssertTrue(app.staticTexts["selectedMarkerSummary"].waitForExistence(timeout: 5))
        XCTAssertEqual(app.staticTexts["selectedMarkerSummary"].label, "4/4 seçili · ID 0, 3, 4, 5")
        XCTAssertTrue(app.segmentedControls["planMarkerCount"].buttons["4"].isSelected)
        app.tabBars.buttons["Çekim"].tap()
        for id in [0, 3, 4, 5] {
            XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "flagProgress_\(id)").firstMatch.exists)
        }
        for id in [1, 2] {
            XCTAssertFalse(app.descendants(matching: .any).matching(identifier: "flagProgress_\(id)").firstMatch.exists)
        }
    }
}
