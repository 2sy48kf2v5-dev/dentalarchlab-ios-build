import XCTest

// Capture the whole screen: app-bounds screenshots can crop a rotated landscape window.

final class NavigationTests: XCTestCase {
    override func setUpWithError() throws { continueAfterFailure = false }
    func launch() -> XCUIApplication {
        XCUIDevice.shared.orientation = .portrait
        let app = XCUIApplication(); app.launchArguments = ["--ui-testing"]; app.launch()
        XCTAssertTrue(app.textFields["caseReferenceField"].waitForExistence(timeout: 5))
        return app
    }
    private func openSettings(_ app: XCUIApplication) {
        let settings = app.buttons["openHomeSettings"]
        XCTAssertTrue(settings.waitForExistence(timeout: 5)); settings.tap()
        XCTAssertTrue(app.navigationBars["Ayarlar ve araçlar"].waitForExistence(timeout: 5))
    }
    private func waitForCaptureLandscape(_ app: XCUIApplication) {
        XCTAssertTrue(app.buttons["captureExit"].waitForExistence(timeout: 5))
        let landscape = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            app.frame.width > app.frame.height
        }, object: app)
        XCTAssertEqual(XCTWaiter.wait(for: [landscape], timeout: 5), .completed)
    }
    private func returnHome(_ app: XCUIApplication) {
        if app.buttons["captureExit"].exists { app.buttons["captureExit"].tap() }
        else { app.tabBars.buttons["Başlangıç"].tap() }
        let portrait = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            app.frame.height > app.frame.width
        }, object: app)
        XCTAssertEqual(XCTWaiter.wait(for: [portrait], timeout: 5), .completed)
        XCTAssertTrue(app.textFields["caseReferenceField"].waitForExistence(timeout: 5))
    }
    private func revealRailDetail(_ app: XCUIApplication, identifier: String) -> XCUIElement {
        let item = app.staticTexts[identifier]
        let rail = app.scrollViews["captureRailDetails"]
        XCTAssertTrue(rail.waitForExistence(timeout: 5))
        for _ in 0..<12 {
            if item.isHittable { break }
            rail.swipeUp()
        }
        XCTAssertTrue(item.isHittable, "Yatay çekim ayrıntısı erişilebilir olmalı: \(identifier)")
        return item
    }
    func testMacroXYZShortcutRoutesMissingCalibrationWithoutOpeningCamera() {
        let app = launch()
        let shortcut = app.buttons["startResearchScan"]
        XCTAssertTrue(shortcut.isHittable); XCTAssertTrue(shortcut.isEnabled)
        XCTAssertEqual(shortcut.label, "Taramayı başlat")
        XCTAssertTrue(app.textFields["caseReferenceField"].isHittable)
        XCTAssertTrue(app.buttons["homeArchUpper"].isHittable, app.debugDescription)
        XCTAssertTrue(app.buttons["homeArchLower"].isHittable, app.debugDescription)
        XCTAssertTrue(app.buttons["openHomeSettings"].isHittable)
        XCTAssertFalse(app.buttons["runNativeValidation"].exists, "Vaka başlangıcı uzun ayar formunu göstermemeli.")
        let home = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        home.name = "DAL new case, native arch choices and primary scan action above the fold"
        home.lifetime = .keepAlways; add(home)
        shortcut.tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.buttons["autoCalibration"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        XCTAssertTrue(app.staticTexts["captureStatus"].label.contains("ultra geniş lensle fiziksel tahta"))
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Macro XYZ requires its physical lens calibration"
        screenshot.lifetime = .keepAlways; add(screenshot)
    }
    func testCompletedPhysicalCalibrationOpensThreeDScanWithoutStartingCamera() {
        XCUIDevice.shared.orientation = .portrait
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing", "--ui-calibration-handoff-test"]
        app.launch()
        XCTAssertTrue(app.staticTexts["calibrationHandoffSyntheticBanner"].waitForExistence(timeout: 5))
        let openResult = app.buttons["resumeCurrentCapture"]
        XCTAssertTrue(openResult.waitForExistence(timeout: 5), app.debugDescription)
        for _ in 0..<5 {
            if openResult.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(openResult.isHittable); openResult.tap()
        let resultOpened = app.staticTexts["Kamera kalibrasyonu"].waitForExistence(timeout: 5)
        if !resultOpened {
            let failure = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
            failure.name = "SYNTHETIC failed calibration result navigation after center tap"
            failure.lifetime = .keepAlways; add(failure)
        }
        XCTAssertTrue(resultOpened, app.debugDescription)
        XCTAssertFalse(app.staticTexts["calibrationScanIssue"].exists)
        let handoff = app.buttons["scanWithCurrentCalibration"]
        XCTAssertTrue(handoff.waitForExistence(timeout: 5), app.debugDescription)
        for _ in 0..<5 {
            if handoff.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(handoff.isHittable); XCTAssertTrue(handoff.isEnabled)
        XCTAssertEqual(handoff.label, "Bu kalibrasyonla 3B tara")
        XCTAssertEqual(app.staticTexts["calibrationHandoffCameraStarts"].value as? String, "0")
        let result = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        result.name = "SYNTHETIC eligible ultrawide calibration result with explicit 3B handoff"
        result.lifetime = .keepAlways; add(result)

        handoff.tap()
        waitForCaptureLandscape(app)
        let scan = app.buttons["autoScan"]
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            scan.isHittable && app.buttons["cameraControl"].isHittable
                && app.staticTexts["KAMERA KAPALI"].exists
        }, object: app)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 5), .completed, app.debugDescription)
        XCTAssertTrue(app.staticTexts["Bayrak taraması · 3B"].exists)
        XCTAssertFalse(app.buttons["autoCalibration"].exists)
        XCTAssertEqual(scan.label, "Taramayı başlat")
        XCTAssertEqual(app.buttons["cameraControl"].label, "Kamerayı aç")
        XCTAssertEqual(app.staticTexts["calibrationHandoffCameraStarts"].value as? String, "0",
                       "Sonuçtan 3B hazırlığına geçiş önizleme veya ölçüm kamerasını başlatmamalı.")
        XCTAssertTrue(app.staticTexts["calibrationHandoffSyntheticBanner"].exists)
        let capture = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        capture.name = "SYNTHETIC calibration handoff selects 3B scan with zero camera starts"
        capture.lifetime = .keepAlways; add(capture)
    }
    func testOfflineIllustrationHasNoPhysicalAccuracyClaim() {
        let app = launch()
        openSettings(app)
        for _ in 0..<5 {
            if app.buttons["openIllustration"].isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(app.buttons["openIllustration"].isHittable)
        app.buttons["openIllustration"].tap()
        XCTAssertTrue(app.staticTexts["Uygulamayı keşfet"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["ÖRNEK · FİZİKSEL ÖLÇÜM DEĞİL"].exists)
        XCTAssertTrue(app.buttons["Görünümü sıfırla"].exists)
        XCTAssertTrue(app.otherElements["muaPlacementScene"].exists)
        XCTAssertTrue(app.staticTexts["muaSpatialPlacement"].label.contains("Örnek"))
        XCTAssertFalse(app.staticTexts["Görüntü uyum hatası"].exists)
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Native iPhone offline illustration"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }
    func testCaseReferenceAndArchSurvivePlanAndCaptureNavigation() {
        let app = launch()
        let reference = app.textFields["caseReferenceField"]
        reference.tap(); reference.typeText("MODEL-015")
        XCTAssertTrue(app.buttons["homeArchUpper"].isHittable, app.debugDescription)
        app.buttons["homeArchUpper"].tap()
        let keyboardDismissed = XCTNSPredicateExpectation(predicate: NSPredicate { _, _ in
            app.keyboards.count == 0
        }, object: app)
        XCTAssertEqual(XCTWaiter.wait(for: [keyboardDismissed], timeout: 5), .completed,
                       "Çene seçimi vaka alanının klavyesini kapatmalı.")
        XCTAssertTrue(app.buttons["homeArchUpper"].isSelected)
        XCTAssertFalse(app.buttons["homeArchLower"].isSelected)
        app.buttons["openDentalPlan"].tap()
        XCTAssertTrue(app.navigationBars["FDI planı"].waitForExistence(timeout: 5))
        let upper = app.segmentedControls.buttons["Üst çene"]
        for _ in 0..<4 {
            if upper.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(upper.isSelected, "Yeni vakada seçilen çene FDI planına geçmeli.")
        app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        returnHome(app)
        XCTAssertEqual(reference.value as? String, "MODEL-015")
        XCTAssertTrue(app.buttons["homeArchUpper"].isSelected)
        XCTAssertTrue(app.buttons["startResearchScan"].isHittable)
        XCTAssertTrue(app.buttons["openHomeSettings"].isHittable)
    }
    func testCaptureTabDoesNotOpenCameraAutomatically() {
        let app = launch(); app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["Bu iPhone"].exists)
        XCTAssertFalse(app.staticTexts["Bağlantı yok"].exists)
        XCTAssertFalse(app.buttons["Görüntüyü kaydet"].isEnabled)
        XCTAssertTrue(app.buttons["autoScan"].exists)
        XCTAssertTrue(app.buttons["cameraControl"].isHittable)
        let camera = app.otherElements["fullScreenCamera"]
        XCTAssertTrue(camera.exists)
        XCTAssertGreaterThan(camera.frame.height, app.frame.height * 0.7)
        XCTAssertGreaterThan(camera.frame.width, app.frame.width * 0.8)
        XCTAssertTrue(app.buttons["captureDetails"].isHittable)
        XCTAssertFalse(app.staticTexts["acceptedFrameCue"].exists)
        XCTAssertFalse(app.staticTexts["Kamera durdu. Görüntüler korunuyor; kamerayı yeniden açın."].exists)
        XCTAssertTrue(app.buttons["autoScan"].isEnabled, "Tek düğme kamera hazırlığını ve taramayı başlatabilmeli.")
        XCTAssertTrue(app.descendants(matching: .any).matching(identifier: "coveragePanel").firstMatch.exists)
        XCTAssertTrue(app.staticTexts["captureGeometryScope"].label.contains("XYZ hesaplanmaz"))
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Native iPhone capture screen"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }
    func testResearchScanPickerRequiresMacroCalibrationBeforeCameraStarts() {
        let app = launch()
        openSettings(app)
        let mode = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Çalışma")).firstMatch
        for _ in 0..<6 {
            if mode.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(mode.isHittable)
        mode.tap()
        let scan = app.buttons["Araştırma taraması (3B)"]
        XCTAssertTrue(scan.waitForExistence(timeout: 5))
        scan.tap()
        app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.buttons["autoCalibration"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["captureStatus"].label.contains("ultra geniş lensle fiziksel tahta"))
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        XCTAssertTrue(app.buttons["autoCalibration"].isEnabled, "Çalışma seçicisi de aynı yakın çekim kalibrasyonu yolunu kullanmalı.")
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Work picker requires the same physical macro calibration as XYZ shortcut"
        screenshot.lifetime = .keepAlways; add(screenshot)
    }
    func testEmptyResultCanReturnHome() {
        let app = launch(); app.tabBars.buttons["Sonuç"].tap()
        XCTAssertTrue(app.staticTexts["Sonuç bekleniyor"].waitForExistence(timeout: 5))
        returnHome(app)
        XCTAssertTrue(app.textFields["caseReferenceField"].exists)
    }
    func testRecognitionReportCannotInventAFrameBeforeCapture() {
        let app = launch(); app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.otherElements["confirmedFlagIDs"].waitForExistence(timeout: 5))
        app.buttons["captureDetails"].tap()
        let report = app.buttons["prepareRecognitionReport"]
        for _ in 0..<5 {
            if report.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(report.exists)
        XCTAssertFalse(report.isEnabled)
        XCTAssertFalse(app.buttons["shareRecognitionReport"].exists)
        XCTAssertTrue(app.buttons["closeCaptureDetails"].isHittable)
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Recognition diagnostics require a real sampled frame"
        screenshot.lifetime = .keepAlways; add(screenshot)
    }
    func testCalibrationHasAutomaticStartAndSecondarySingleFrameBeforeCameraStarts() {
        let app = launch()
        openSettings(app)
        let mode = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Çalışma")).firstMatch
        for _ in 0..<5 {
            if mode.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(mode.isHittable)
        mode.tap()
        let calibration = app.buttons["Kamera kalibrasyonu"]
        XCTAssertTrue(calibration.waitForExistence(timeout: 5))
        calibration.tap()
        app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)

        let automatic = app.buttons["autoCalibration"]
        XCTAssertTrue(automatic.waitForExistence(timeout: 5))
        XCTAssertEqual(automatic.label, "Kalibrasyon taramasını başlat")
        XCTAssertTrue(automatic.isHittable)
        XCTAssertTrue(automatic.isEnabled, "Kalibrasyon tek düğmeyle kamerayı açabilmeli.")
        let capture = app.buttons["calibrationCapture"]
        XCTAssertTrue(capture.waitForExistence(timeout: 5))
        XCTAssertTrue(capture.isHittable)
        XCTAssertFalse(capture.isEnabled)
        XCTAssertEqual(app.buttons.matching(NSPredicate(format: "label == %@", "Görüntüyü kaydet")).count, 1)
        XCTAssertTrue(app.buttons["cameraControl"].isHittable)
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        XCTAssertTrue(app.staticTexts["calibrationGuidance"].exists)
        XCTAssertTrue(app.staticTexts["screenCalibrationNote"].exists)
        XCTAssertFalse(app.buttons["autoScan"].exists)
        XCTAssertGreaterThan(app.otherElements["fullScreenCamera"].frame.height, app.frame.height * 0.7)
        XCTAssertFalse(app.staticTexts["acceptedFrameCue"].exists)
        app.scrollViews["captureRailDetails"].swipeUp()
        XCTAssertTrue(automatic.isHittable)
        XCTAssertTrue(automatic.isEnabled)
        XCTAssertTrue(capture.isHittable)
        XCTAssertFalse(capture.isEnabled)
        XCTAssertFalse(app.buttons["Hesapla / deneyi tamamla"].exists)
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Automatic calibration start and secondary single-frame footer with camera closed"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }
    func testFocusAssistOnlyChangesPreviewControl() {
        let app = launch(); app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        let button = app.buttons["focusAssist"]
        XCTAssertTrue(button.waitForExistence(timeout: 5))
        XCTAssertEqual(button.label, "1× ekran büyütme")
        button.tap()
        XCTAssertEqual(app.buttons["focusAssist"].label, "2× ekran büyütme")
        XCTAssertTrue(app.buttons["autoScan"].isEnabled)
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
    }
    func testCameraOpticsPreferenceDoesNotOpenCameraAndExplainsCalibration() {
        let app = launch()
        openSettings(app)
        let picker = app.segmentedControls["cameraOpticsPicker"]
        for _ in 0..<7 {
            if picker.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(picker.isHittable)
        XCTAssertTrue(picker.buttons["Yakın çekim"].isSelected)
        picker.buttons["Standart"].tap()
        XCTAssertTrue(picker.buttons["Standart"].isSelected)
        XCTAssertTrue(app.staticTexts["homeOpticsCalibrationScope"].label.contains("yeni kalibrasyon gerekir"))
        app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].waitForExistence(timeout: 5))
        XCTAssertTrue(revealRailDetail(app, identifier: "captureOpticsSummary").label.contains("Standart çekim seçili"))
        XCTAssertTrue(revealRailDetail(app, identifier: "cameraTargetBeforeStart").label.contains("hedefi ortala"))
        XCTAssertEqual(app.buttons["focusAssist"].label, "1× ekran büyütme")
        app.buttons["captureDetails"].tap()
        let scope = app.staticTexts["previewMagnificationScope"]
        for _ in 0..<8 {
            if scope.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(scope.isHittable)
        XCTAssertTrue(scope.label.contains("Kaydedilen kareyi, çözünürlüğü ve fiziksel odak uzaklığını değiştirmez"))
        XCTAssertTrue(app.staticTexts["cameraOpticsCalibrationScope"].label.contains("yeni kalibrasyon yap"))
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Native lens preference and preview-only magnification guidance"
        screenshot.lifetime = .keepAlways; add(screenshot)
    }
    func testPreviewMagnificationResetsOnModeChangeAndResearchPickerUsesMacroRoute() {
        let app = launch(); app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        app.buttons["focusAssist"].tap()
        XCTAssertEqual(app.buttons["focusAssist"].label, "2× ekran büyütme")
        returnHome(app)
        let calibration = app.buttons["startCalibration"]
        for _ in 0..<5 {
            if calibration.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(calibration.isHittable); calibration.tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.buttons["autoCalibration"].waitForExistence(timeout: 5))
        XCTAssertEqual(app.buttons["focusAssist"].label, "1× ekran büyütme")
        XCTAssertFalse(app.buttons["refocusCamera"].isEnabled)
        returnHome(app)
        openSettings(app)
        let mode = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", "Çalışma")).firstMatch
        for _ in 0..<10 {
            if mode.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(mode.isHittable); mode.tap()
        app.buttons["Araştırma taraması (3B)"].tap()
        let picker = app.segmentedControls["cameraOpticsPicker"]
        for _ in 0..<10 {
            if picker.isHittable { break }
            app.swipeDown()
        }
        XCTAssertTrue(picker.isHittable)
        XCTAssertTrue(picker.buttons["Yakın çekim"].isSelected)
        app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.buttons["autoCalibration"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["captureOpticsSummary"].label.contains("Yakın çekim seçili"))
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
    }
    func testCalibrationOffersAutomaticFocusWithoutManualLensSlider() {
        let app = launch()
        let calibration = app.buttons["startCalibration"]
        for _ in 0..<4 {
            if calibration.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(calibration.isHittable)
        calibration.tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.buttons["autoCalibration"].waitForExistence(timeout: 5))
        let focusGuidance = revealRailDetail(app, identifier: "cameraFocusGuidance")
        XCTAssertFalse(focusGuidance.label.isEmpty)
        XCTAssertTrue(app.buttons["refocusCamera"].exists)
        XCTAssertFalse(app.buttons["refocusCamera"].isEnabled, "Kamera açılmadan yeniden netleme sunulmamalı.")
        XCTAssertFalse(app.staticTexts["Odak konumu"].exists)
        XCTAssertEqual(app.sliders.count, 0, "Kullanıcıdan lens konumu seçmesi istenmemeli.")
        XCTAssertTrue(app.buttons["autoCalibration"].isEnabled)
        XCTAssertTrue(app.buttons["captureDetails"].isHittable)
        app.buttons["captureDetails"].tap()
        let explanation = app.staticTexts["calibrationFocusExplanation"]
        for _ in 0..<5 {
            if explanation.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(explanation.isHittable)
        XCTAssertTrue(app.buttons["closeCaptureDetails"].isHittable)
        app.buttons["closeCaptureDetails"].tap()
        let calibrationButton = app.buttons["autoCalibration"]
        let calibrationReachable = NSPredicate { object, _ in
            guard let button = object as? XCUIElement else { return false }
            return button.exists && button.isHittable
        }
        let detailsDismissed = XCTNSPredicateExpectation(predicate: calibrationReachable, object: calibrationButton)
        XCTAssertEqual(XCTWaiter.wait(for: [detailsDismissed], timeout: 5), .completed,
                       "Kalibrasyon düğmesi ayrıntı sayfası kapandıktan sonra erişilebilir olmalı.")
        XCTAssertTrue(app.buttons["autoCalibration"].isHittable)
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Full screen calibration with automatic focus and reachable capture controls"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }
    func testFDIPlanExampleAndComponent() {
        let app = launch()
        let link = app.buttons["openDentalPlan"]
        for _ in 0..<5 {
            if link.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(link.isHittable)
        link.tap()
        XCTAssertTrue(app.buttons["sampleDentalPlan"].waitForExistence(timeout: 5))
        for _ in 0..<4 {
            if app.buttons["sampleDentalPlan"].isHittable { break }
            app.swipeUp()
        }
        app.buttons["sampleDentalPlan"].tap()
        XCTAssertTrue(app.staticTexts["FDI 46"].exists)
        XCTAssertTrue(app.staticTexts["FDI 36"].exists)
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "FDI plan and MG-MUASBU reference"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    func testOfflineHomeOffersLocalWorkflowWithoutPairing() {
        let app = launch()
        XCTAssertTrue(app.staticTexts["iPhone üzerinde · Çevrimdışı"].waitForExistence(timeout: 5))
        openSettings(app)
        for _ in 0..<5 {
            if app.buttons["runNativeValidation"].isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(app.buttons["runNativeValidation"].exists)
        XCTAssertFalse(app.buttons["Bilgisayara bağlan"].exists)
        XCTAssertFalse(app.buttons["Bilgisayarın QR kodunu okut"].exists)
        let calibration = app.buttons["startCalibration"]
        for _ in 0..<4 {
            if calibration.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(calibration.isHittable)
        calibration.tap()
        waitForCaptureLandscape(app)
        XCTAssertTrue(app.buttons["calibrationCapture"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["autoCalibration"].isEnabled)
        XCTAssertTrue(app.buttons["cameraControl"].isHittable)
        XCTAssertFalse(app.buttons["calibrationCapture"].isEnabled)
    }

    func testCalibrationIdleShowsCornerTargetAndMovementWithoutInventingDetection() {
        let app = launch()
        let calibration = app.buttons["startCalibration"]
        for _ in 0..<4 {
            if calibration.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(calibration.isHittable)
        calibration.tap()
        waitForCaptureLandscape(app)
        let frames = app.staticTexts["calibrationFrameCount"]
        XCTAssertTrue(frames.waitForExistence(timeout: 5))
        XCTAssertEqual(frames.label, "0/20 uygun kare")
        XCTAssertEqual(app.staticTexts["calibrationCornerCount"].label, "0/54 iç köşe")
        XCTAssertTrue(app.staticTexts["calibrationGuidance"].label.contains("otomatik kaydedilir"))
        XCTAssertTrue(app.staticTexts["calibrationMovementGuidance"].label.contains("hafifçe eğin"))
        XCTAssertTrue(app.staticTexts["screenCalibrationNote"].exists)
        XCTAssertFalse(app.otherElements["calibrationAnalyzedFrame"].exists)
        XCTAssertFalse(app.staticTexts["calibrationAdditionalViews"].exists)
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        XCTAssertTrue(app.buttons["autoCalibration"].isEnabled)
        returnHome(app)
        app.tabBars.buttons["Sonuç"].tap()
        XCTAssertTrue(app.staticTexts["Sonuç bekleniyor"].waitForExistence(timeout: 5))
        app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        XCTAssertEqual(frames.label, "0/20 uygun kare")
        XCTAssertTrue(app.buttons["autoCalibration"].isEnabled)
    }

    func testSoundAndLightPreferencesDoNotStartCamera() {
        let app = launch(); app.tabBars.buttons["Çekim"].tap()
        waitForCaptureLandscape(app)
        let sound = app.buttons["scanSoundToggle"]
        let torch = app.buttons["scanTorchToggle"]
        XCTAssertTrue(sound.waitForExistence(timeout: 5))
        XCTAssertTrue(sound.isHittable); XCTAssertTrue(torch.isHittable)
        XCTAssertEqual(sound.value as? String, "Açık")
        sound.tap()
        XCTAssertEqual(sound.value as? String, "Kapalı")
        XCTAssertEqual(torch.value as? String, "Başlangıçta açılacak")
        torch.tap()
        XCTAssertEqual(torch.value as? String, "Kapalı")
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        XCTAssertFalse(app.staticTexts["acceptedFrameCue"].exists)
        for id in 0..<6 {
            // SwiftUI exposes this labeled leaf with a platform-selected
            // element type. Its stable ID and actual coverage text are the contract.
            let progress = app.descendants(matching: .any).matching(identifier: "flagProgress_\(id)").firstMatch
            XCTAssertTrue(progress.exists, "Missing flag progress \(id): \(app.debugDescription)")
            XCTAssertTrue(progress.label.contains("0/1 görünüm"))
        }
        app.buttons["captureDetails"].tap()
        let test = app.buttons["testScanSound"]
        for _ in 0..<5 {
            if test.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(test.exists)
        XCTAssertFalse(test.isEnabled)
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "Sound and continuous light controls with camera closed"
        screenshot.lifetime = .keepAlways; add(screenshot)
    }

    func testNativeEngineValidationRunsFromHome() {
        let app = launch()
        openSettings(app)
        let test = app.buttons["runNativeValidation"]
        for _ in 0..<5 {
            if test.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(test.waitForExistence(timeout: 5))
        test.tap()
        let report = app.staticTexts["nativeValidationReport"]
        let success = NSPredicate(format: "exists == true AND label CONTAINS %@", "Motor testi başarılı")
        let completed = XCTNSPredicateExpectation(predicate: success, object: report)
        XCTAssertEqual(XCTWaiter.wait(for: [completed], timeout: 60), .completed,
                       "Gerçek yerel motor testi başarı raporu üretmedi: \(report.exists ? report.label : "rapor yok")")
        XCTAssertFalse(report.label.contains("Motor testi başarısız"))
        let screenshot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        screenshot.name = "On-device native engine synthetic validation report"
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    private func launchTissueFixture() -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing", "--ui-tissue-test"]
        app.launch()
        openSettings(app)
        let entry = app.buttons["openTissueTest"]
        for _ in 0..<5 {
            if entry.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(entry.waitForExistence(timeout: 5)); entry.tap()
        XCTAssertTrue(app.staticTexts["tissueSyntheticBanner"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.buttons["importTissueMesh"].waitForExistence(timeout: 15), app.debugDescription)
        return app
    }
    private func scrollTissue(_ app: XCUIApplication, to element: XCUIElement) {
        XCTAssertTrue(element.waitForExistence(timeout: 5), app.debugDescription)
        let scroll = app.scrollViews["tissueScroll"]
        XCTAssertTrue(scroll.exists)
        // A 370-point viewport can be skipped by a whole-screen swipe. Use
        // its actual geometry, small margin drags and either direction.
        for _ in 0..<18 {
            let scrollFrame = scroll.frame.intersection(app.frame)
            // SwiftUI's scroll frame extends beneath navigation/tab bars and
            // safeAreaInset content. Those occluded regions are not visible.
            let navigation = app.navigationBars.firstMatch
            let banner = app.staticTexts["tissueSyntheticBanner"]
            let tabs = app.tabBars.firstMatch
            let top = max(scrollFrame.minY, max(navigation.exists ? navigation.frame.maxY : scrollFrame.minY,
                          banner.exists ? banner.frame.maxY : scrollFrame.minY)) + 12
            let bottom = min(scrollFrame.maxY, tabs.exists ? tabs.frame.minY : scrollFrame.maxY) - 12
            let visible = CGRect(x: scrollFrame.minX, y: top, width: scrollFrame.width, height: bottom - top)
            let frame = element.frame
            let fullyVisible = frame.height > 0 && frame.minY >= visible.minY && frame.maxY <= visible.maxY
            if fullyVisible && element.isHittable { return }
            guard frame.height > 0 else { break }
            let delta: CGFloat
            if frame.minY < visible.minY { delta = frame.minY - visible.minY }
            else if frame.maxY > visible.maxY { delta = frame.maxY - visible.maxY }
            else { break } // Visible but not interactive is a real failure.
            let distance = min(180, max(40, abs(delta) + 20))
            let start = app.coordinate(withNormalizedOffset: .zero)
                .withOffset(CGVector(dx: scroll.frame.minX + 6, dy: visible.midY))
            start.press(forDuration: 0.05, thenDragTo: start.withOffset(CGVector(dx: 0, dy: delta > 0 ? -distance : distance)))
        }
        XCTFail("Doku kontrolü görünür ve etkileşimli değil: \(element)\n\(app.debugDescription)")
    }
    private func attachTissue(_ app: XCUIApplication, name: String) {
        let shot = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
        shot.name = name; shot.lifetime = .keepAlways; add(shot)
    }
    func testTissueScreenRequiresMillimeterConfirmationAndShowsActualTargetChoices() {
        let app = launchTissueFixture()
        let importer = app.buttons["importTissueMesh"]
        XCTAssertFalse(importer.isEnabled)
        app.switches["tissueMillimetersConfirmed"].tap()
        XCTAssertTrue(importer.isEnabled)
        let scene = app.descendants(matching: .any).matching(identifier: "tissueMeshScene").firstMatch
        XCTAssertTrue(scene.exists)
        let ready = XCTNSPredicateExpectation(predicate: NSPredicate(format: "value CONTAINS %@", "Renkli yüzey hazır"), object: scene)
        XCTAssertEqual(XCTWaiter.wait(for: [ready], timeout: 10), .completed, "Gerçek SceneKit geometrisi hazır olmadı.")
        scrollTissue(app, to: scene)
        XCTAssertTrue(scene.isHittable)
        XCTAssertGreaterThan(scene.frame.height, 300)
        attachTissue(app, name: "Synthetic native colored tissue mesh before alignment")
        let target = app.buttons["tissueTargetPicker"]
        scrollTissue(app, to: target); target.tap()
        let choice = app.buttons["Bayrak 1 · B"]
        XCTAssertTrue(choice.waitForExistence(timeout: 5)); choice.tap()
        let diagram = app.descendants(matching: .any).matching(identifier: "tissueTargetDiagram").firstMatch
        XCTAssertTrue(diagram.exists)
        XCTAssertTrue(diagram.label.contains("Bayrak 1 · B seçili"), diagram.label)
        scrollTissue(app, to: app.buttons["saveTissuePoint"])
        XCTAssertFalse(app.buttons["saveTissuePoint"].isEnabled, "Hedefi seçmek, yüzeyde bir nokta seçmek değildir.")
        scrollTissue(app, to: app.staticTexts["tissuePairCounts"])
        XCTAssertTrue(app.staticTexts["tissuePairCounts"].label.contains("6 uyum · 1 kontrol · 6 bayrak"))
    }
    func testTissueAlignmentExportsResearchSurfaceButBlocksUncalibratedImplantPositions() {
        let app = launchTissueFixture()
        let align = app.buttons["alignTissue"]
        scrollTissue(app, to: align)
        XCTAssertTrue(align.isEnabled); align.tap()
        let scope = app.staticTexts["tissueResidualScope"]
        XCTAssertTrue(scope.waitForExistence(timeout: 15), app.debugDescription)
        XCTAssertTrue(scope.label.contains("implant doğruluğu veya klinik kabul sınırı değildir"))
        let checkpoint = app.descendants(matching: .any).matching(identifier: "tissueCheckpointRMS").firstMatch
        XCTAssertTrue(checkpoint.exists)
        XCTAssertEqual(checkpoint.label, "Bağımsız kontrol RMS")
        XCTAssertEqual(checkpoint.value as? String, "0.000 mm", "Bilinen sentetik dönüşümün ayrı kontrolü sıfıra yakın olmalı.")
        scrollTissue(app, to: scope)
        attachTissue(app, name: "Synthetic native tissue rigid-fit residual and withheld checkpoint")
        let export = app.buttons["exportAlignedTissue"]
        scrollTissue(app, to: export)
        XCTAssertTrue(export.isEnabled); export.tap()
        let share = app.buttons["shareAlignedTissue"]
        XCTAssertTrue(share.waitForExistence(timeout: 15), app.debugDescription)
        XCTAssertTrue(app.staticTexts["tissueFile_DentalArchLab-tissue-aligned.stl"].exists)
        XCTAssertTrue(app.staticTexts["tissueFile_alignment-report.json"].exists)
        XCTAssertEqual(app.staticTexts.matching(NSPredicate(format: "identifier BEGINSWITH %@ AND label ENDSWITH %@", "tissueFile_", ".implantPosition")).count, 0)
        XCTAssertTrue(app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "Her bayrağın ölçülmüş MUA bağlantı kalibrasyonu gerekli")).firstMatch.exists)
        scrollTissue(app, to: share)
        attachTissue(app, name: "Synthetic native tissue export with missing MUA calibration blockers")
    }
}
