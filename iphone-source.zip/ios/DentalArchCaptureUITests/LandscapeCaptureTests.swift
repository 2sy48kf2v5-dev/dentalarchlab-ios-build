import XCTest
import UIKit

/// These fixtures intentionally leave the real camera closed. They verify
/// interface rotation, safe-area layout and actions, not device image quality.
final class LandscapeCaptureTests: XCTestCase {
    override func setUpWithError() throws {
        continueAfterFailure = false
        XCUIDevice.shared.orientation = .portrait
    }

    override func tearDownWithError() throws {
        XCUIDevice.shared.orientation = .portrait
    }

    private func launch() -> XCUIApplication {
        let app = XCUIApplication()
        app.launchArguments = ["--ui-testing"]
        app.launch()
        return app
    }

    private func open(_ identifier: String, in app: XCUIApplication) {
        let action = app.buttons[identifier]
        for _ in 0..<8 {
            if action.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(action.isHittable, app.debugDescription)
        action.tap()
    }

    private func element(_ identifier: String, in app: XCUIApplication) -> XCUIElement {
        app.descendants(matching: .any).matching(identifier: identifier).firstMatch
    }

    private func rotate(_ orientation: UIDeviceOrientation, in app: XCUIApplication) {
        XCUIDevice.shared.orientation = orientation
        let viewport = element("captureViewport", in: app)
        // Device/interface landscape names are opposite. This also checks the
        // scene observer after a 180-degree flip with no width/height change.
        let expected = orientation == .landscapeLeft ? "Yatay sağ" : "Yatay sol"
        let ready = NSPredicate { _, _ in
            viewport.exists && (viewport.value as? String) == expected && app.frame.width > app.frame.height
        }
        XCTAssertEqual(XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: ready, object: app)], timeout: 8), .completed,
                       "The preview must follow the actual window-scene orientation: \(app.debugDescription)")
    }

    private func assertLandscape(_ app: XCUIApplication, calibration: Bool) {
        let viewport = element("captureViewport", in: app)
        let rail = element("captureControlRail", in: app)
        XCTAssertTrue(viewport.exists)
        XCTAssertTrue(rail.exists)
        XCTAssertGreaterThan(viewport.frame.width, viewport.frame.height * 1.35)
        XCTAssertGreaterThan(viewport.frame.width, app.frame.width * 0.50)
        XCTAssertGreaterThan(viewport.frame.height, app.frame.height * 0.55)
        XCTAssertLessThanOrEqual(viewport.frame.maxX, rail.frame.minX)
        XCTAssertFalse(viewport.frame.intersects(rail.frame))
        XCTAssertFalse(app.tabBars.firstMatch.isHittable, "The capture tab bar must not use landscape height.")
        for identifier in ["captureExit", "scanSoundToggle", "scanTorchToggle", "captureDetails", "cameraControl",
                           "focusAssist", "refocusCamera", calibration ? "autoCalibration" : "autoScan",
                           calibration ? "calibrationCapture" : "scanSingleFrame"] {
            let control = app.buttons[identifier]
            XCTAssertTrue(control.isHittable, "Unreachable control: \(identifier)")
            XCTAssertGreaterThanOrEqual(control.frame.minX, app.frame.minX)
            XCTAssertGreaterThanOrEqual(control.frame.minY, app.frame.minY)
            XCTAssertLessThanOrEqual(control.frame.maxX, app.frame.maxX)
            XCTAssertLessThanOrEqual(control.frame.maxY, app.frame.maxY)
        }
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        XCTAssertFalse(app.buttons[calibration ? "calibrationCapture" : "scanSingleFrame"].isEnabled)
        XCTAssertFalse(app.buttons["refocusCamera"].isEnabled)
        XCTAssertFalse(element("recentSamplePoints", in: app).exists)
        XCTAssertFalse(app.staticTexts["acceptedFrameCue"].exists)
        XCTAssertFalse(app.buttons["analyzedSampleThumbnail"].exists)
    }

    private func attach(_ app: XCUIApplication, name: String) {
        let screenshot = XCTAttachment(screenshot: app.screenshot())
        screenshot.name = name
        screenshot.lifetime = .keepAlways
        add(screenshot)
    }

    func testTrialKeepsWideViewportAndReachableControlsAcrossBothLandscapeSides() {
        let app = launch()
        open("startTrialExperiment", in: app)
        for orientation in [UIDeviceOrientation.landscapeLeft, .landscapeRight] {
            rotate(orientation, in: app)
            assertLandscape(app, calibration: false)
            XCTAssertTrue(app.buttons["autoScan"].isEnabled)
            for id in 0..<6 {
                let progress = element("flagProgress_\(id)", in: app)
                XCTAssertTrue(progress.exists)
                XCTAssertTrue(progress.label.contains("0/1 görünüm"))
            }
            attach(app, name: "2B idle camera — \(orientation == .landscapeLeft ? "left" : "right") landscape")
        }
        app.buttons["focusAssist"].tap()
        XCTAssertEqual(app.buttons["focusAssist"].label, "2× ekran büyütme")
        app.buttons["scanSoundToggle"].tap()
        XCTAssertEqual(app.buttons["scanSoundToggle"].value as? String, "Kapalı")
        app.buttons["scanTorchToggle"].tap()
        XCTAssertEqual(app.buttons["scanTorchToggle"].value as? String, "Kapalı")
        XCTAssertTrue(app.staticTexts["KAMERA KAPALI"].exists)
        app.buttons["captureDetails"].tap()
        XCTAssertTrue(app.buttons["closeCaptureDetails"].waitForExistence(timeout: 5))
        app.buttons["closeCaptureDetails"].tap()
        XCTAssertTrue(app.buttons["captureExit"].waitForExistence(timeout: 5))
        app.buttons["captureExit"].tap()
        let home = NSPredicate { _, _ in app.frame.height > app.frame.width && app.textFields["caseReferenceField"].exists }
        let homeReturn = XCTWaiter.wait(for: [XCTNSPredicateExpectation(predicate: home, object: app)], timeout: 8)
        if homeReturn != .completed {
            attach(app, name: "Failed portrait home return after capture details dismissal")
        }
        XCTAssertEqual(homeReturn, .completed,
                       "Home return failed: app.frame=\(app.frame), caseReferenceField.exists=\(app.textFields["caseReferenceField"].exists)\n\(app.debugDescription)")
    }

    func testCalibrationKeepsRealZeroCountsAndBoardControlsInBothLandscapeSides() {
        let app = launch()
        open("startCalibration", in: app)
        for orientation in [UIDeviceOrientation.landscapeLeft, .landscapeRight] {
            rotate(orientation, in: app)
            assertLandscape(app, calibration: true)
            XCTAssertEqual(app.staticTexts["calibrationFrameCount"].label, "0/20 uygun kare")
            XCTAssertEqual(app.staticTexts["calibrationCornerCount"].label, "0/54 iç köşe")
            XCTAssertTrue(app.buttons["autoCalibration"].isEnabled)
            XCTAssertFalse(app.buttons["finishScan"].exists)
            attach(app, name: "Calibration idle camera — \(orientation == .landscapeLeft ? "left" : "right") landscape")
        }
        app.buttons["captureDetails"].tap()
        XCTAssertTrue(app.buttons["closeCaptureDetails"].waitForExistence(timeout: 5))
        XCTAssertTrue(app.staticTexts["calibrationFrameCount"].exists)
    }

    func test3DPreparationStillRequiresCalibrationInLandscapeWithoutOpeningCamera() {
        let app = launch()
        open("startResearchScan", in: app)
        rotate(.landscapeRight, in: app)
        assertLandscape(app, calibration: true)
        XCTAssertTrue(app.staticTexts["captureStatus"].label.contains("ultra geniş lensle fiziksel tahta"))
        XCTAssertFalse(app.buttons["autoScan"].exists)
        attach(app, name: "3B prerequisite — real physical calibration required, camera closed")
    }
}
