# DentalArchLab 0.8.1 — kamera açılışı ve kalibrasyon denemesi

Bu sürüm, “Odak ve ışık hazırlanıyor” mesajında süresiz kalabilen açılışı düzeltir.
Kameranın isteğe bağlı odak yanıtını beklemek yerine sabit odak, doğru çözünürlük
ve üç yeni sensör karesi kontrol edilir. Açılış en fazla 12 saniye beklenir;
başarısızlıkta açıklama ve yeniden deneme imkânı verilir. İptal her zaman erişilebilirdir.

## Kurulum

Mevcut DentalArchLab'ı silmeden, daha önce kullandığınız AltStore ve aynı Apple
hesabıyla yeni IPA'yı güncelleyin. Başlangıç ekranında **Sürüm 0.8.1** yazmalıdır.
Windows motoru 0.8 ile uyumludur; bu düzeltme için yeniden kurulum gerekmez.
İmzasız IPA, iPhone Dosyalar uygulamasından doğrudan kurulmaz; AltStore imzalar.

## Ekrandaki dama tahtasıyla ilk kontrol

1. Başlangıç → Deney ayarları → Çalışma → Kamera kalibrasyonu.
2. Ekrandan gösteriyorsanız **Fiziksel tahta boyutunu ölçtüm** kapalı kalsın.
3. Çekim → Kamerayı aç. Kamera izni istenirse izin verin. İlk izin sırasında
   süre dolarsa izin verdikten sonra Kamerayı aç'a tekrar basın.
4. “Kamera hazır” mesajını ve alttaki etkin **Tek kare** düğmesini bekleyin.
   Tahtanın tamamını, kenar boşluklarıyla gösterin; yansımayı azaltın ve sabit tutun.
5. Tek kare'ye basın. Bilgisayar bağlıysa tahta/keskinlik değerlendirmesi gelir.
   9 × 6 iç köşe = 54 köşe aranır. Sadece tahtaya tutmak otomatik kayıt başlatmaz.
6. En az 10 kabul edilmiş, farklı açı ve konumlardaki görüntüden sonra
   Hesapla / deneyi tamamla'yı kullanın.

Ekranın fiziksel boyutu bu işlemle doğrulanmaz. Sonuç ekran deneyi olarak saklanır;
fiziksel ölçüm ve doğrulanmış 3B tarama kalibrasyonu yerine geçmez.

## Telefonda kontrol edilecekler

- Açılışta İptal'e basınca kamera kapanmalı, tekrar açılabilmeli.
- Açılış sırasında uygulamayı arka plana alınca hazırlık iptal olmalı.
- Açıldıktan sonra arka plana alıp dönünce Kamerayı aç ile tekrar çalışmalı.
- Başarısız açılış süresiz beklememeli; en geç 12 saniyede hata görünmeli.
- Eski açılışın geç gelen yanıtı yeni denemeyi etkilememeli.
- Kalibrasyon Tek kare düğmesi ekran kaydırılırken altta kalmalı.

Apple otomatik testlerinin sonucu teslim klasöründeki verification.json ve Tests.log
dosyalarındadır. Simülatör testleri gerçek iPhone lensini/pozlamasını doğrulamaz;
yukarıdaki gerçek cihaz denemesi ayrıca gereklidir. Fiziksel mikron doğruluğu ölçülmedi.
