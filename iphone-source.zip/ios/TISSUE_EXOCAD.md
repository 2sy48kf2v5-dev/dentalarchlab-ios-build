# Doku birleştirme ve Exocad araştırma aktarımı · 0.12.0

Bu sürüm iPhone üzerinde ağız içi tarayıcıdan gelen **STL, PLY veya OBJ** yüzeyini açar, fotogrametri sonucuyla aynı koordinat sistemine taşır ve hizalanmış STL üretir. İnternet veya bilgisayar bağlantısı gerektirmez. Exocad'in kendisi laboratuvar bilgisayarında çalışır.

## Hangi veriler gerekli?

1. Tamamlanmış fiziksel **Bayrak taraması · 3B** kaydı; doğru FDI planı.
2. Aynı sabit modele ait, bayrakların ortak referans noktalarını da içeren IOS taraması. Renkli PLY, beyaz noktaları seçmek için uygundur. STL renk içermez; bizim beyaz noktalarımız yüzeyle aynı seviyedeyse STL'de görünmez. Görünmeyen noktayı tahmin ederek tıklamayın. OBJ dış doku/material dosyaları bu sürümde yüklenmez.
3. Dosya birimi **mm** olmalıdır; uygulama otomatik ölçek tahmini yapmaz. Desteklenen yüzeyler üçgenlerden oluşur. Çokgen yüzlü PLY/OBJ'yi tarayıcı yazılımında üçgenleştirin. Dosya sınırı 64 MiB, köşe/yüz sınırı birer milyondur.

Bayrakları çıkardıktan sonra yalnız diş etini taramak, fotogrametriye bağlanacak ortak referansı ortadan kaldırır. Gerekirse IOS yazılımının kendi koordinatında eşlenmiş referanslı taraması kullanılmalıdır. Hareket eden diş eti, rijit bağlantı referansı olarak kullanılmaz. iPhone videosundan yumuşak doku rekonstrüksiyonu bu sürümün parçası değildir.

## Telefonda işlem

1. **Sonuç → Doku birleştir · Exocad** ekranını açın.
2. Dosyanın mm olduğunu onaylayın, IOS dosyasını seçin. Yeni dosya eski nokta eşleştirmelerini sıfırlar; özgün tarama sonucu değişmez.
3. Modeli döndürün/yakınlaştırın. Bayrak ve A/B/C/D referansını seçin. Nokta şeması seçilen referansı gösterir. Nokta seçme moduna geçip IOS yüzeyindeki **aynı noktanın merkezini** seçin, eşleştirmeyi kaydedin.
4. En az iki farklı bayrağa dağılmış, aynı doğru üzerinde olmayan üç veya daha fazla nokta seçin. Tüm arka yay boyunca daha geniş dağılım tercih edin. Bu asgari sayı doğruluk garantisi değildir.
5. En az bir farklı noktayı **kontrol noktası** olarak ayırın. Bu nokta dönüşümü hesaplamakta kullanılmaz; bağımsız sapma gösterir.
6. Hizalamayı hesaplayın. Uyum RMS ve maksimum artığını, kontrol noktası sapmasını ve birleşmiş görünümü inceleyin. Elle seçimin hatası da bu değerlere dahildir. Sayılar mm'dir ve mikron doğruluk belgesi değildir.
7. Exocad projesinin `.dentalProject` uzantısı olmadan tam adını yazın, paketi oluşturup Dosyalar/AirDrop ile paylaşın.

## Üretilen dosyalar

- `<proje>-tissue-aligned.stl`: IOS yüzeyi fotogrametri dünya koordinatında, mm; renkler STL'de korunmaz.
- `photogrammetry-result.json`: özgün fotogrametri sonucu.
- `alignment-report.json`: kaynak SHA-256 özetleri, `T_world_tissue`, kullanılan/kontrol noktaları, artıklar ve eksik önkoşullar.
- `OKU.txt`: kurulum ve koordinat uyarıları.
- Önkoşullar sağlanırsa her FDI için `<proje>-<FDI>.implantPosition`: kütüphane geometrisinin aynı dünya sistemindeki dönüşümü.

Yüzey araştırma çıktısı, MUA dönüşümü eksikken de oluşturulabilir. **İmplant konumu XML'leri eksik veriyle üretilmez.** İmplant geometrileri yumuşak dokuya uydurulmak için kaydırılmaz veya ölçeklenmez. Eski çıktılar ayrı klasörde kalır; aktif paylaşım yalnız son geçerli paket içindir. Sonuç/nokta/dosya değiştiğinde eşleştirme veya paylaşım listesi geçersizleştirilir.

## Gerçek MegaGen/Vida Dental kaydı

Kullanıcının gönderdiği 13 dosya, MegaGen Türkiye'nin resmi arşivindeki aynı klasörle byte düzeyinde eşleşmiştir:

| Kimlik | Değer |
|---|---|
| Library | `MegaGen_N_Type_MUA_Direkt_9mm` |
| Type Keyword | `VidaTrkiye` |
| Subtype Keyword | `48Direkt` |
| Scanbody | `MG-MUASBU`, D4.85 / L9 |
| config.xml SHA-256 | `a5fc3b5a15a42bf19a93065856f792f90c036287cfc68911173be28b14762e22` |
| Kütüphanede oklüzal eksen | `+Y` |

`MG-MUASB9` önceki kullanıcı referansıdır; farklı kod olduğu için mevcut kayıtlar otomatik yeniden etiketlenmez. Yeni planın varsayılanı MG-MUASBU'dur. Eski kalibrasyon dosyasıyla farklı kodlu yeni plan karıştırılırsa tarama başlamadan hata gösterilir. Bu katalog eşleşmesi, her ST implant ve her MUA'nın birbirinin yerine geçtiği anlamına gelmez.

Üretici STL'leri açık kaynak derleme paketine veya uygulama içine eklenmez. Yerel inceleme kopyaları `integrations/megagen/n_type_mua9_review` altında tutulur.

## Eksik fiziksel referans verisi

Kütüphane kimliği hazırdır; uygulama içinde **ölçülmüş MUA–kütüphane dönüşümü yoktur**. Basılmış bayrakların `T_marker_mua` ölçümü de her fiziksel parça için gereklidir. CAD'nin nominal dönüşümü fiziksel ölçüm yerine konmaz. Kütüphanedeki `RegistrationClickCenter` MUA başlangıcı değildir. Kütüphane +Y eksenini uygulamanın MUA +Z eksenine eşitlemek için sadece eksen döndürmek, başlangıç ve dönüş referansını kanıtlamaz.

İçe aktarılan bağlantı JSON'unda `schema=1`, `manufacturer=MegaGen`, `implant_system`, `connection_level=mua`, `component_reference=MG-MUASBU`, gerçek `library/type/subtype`, `config_sha256`, `library_version`, `exocad_version`, izlenebilir `reference_report`, `source=reference_metrology` ve **ölçülmüş** `T_mua_library` 4×4 matrisi bulunmalıdır. Matris sütun vektörle kütüphane koordinatını MUA koordinatına taşır.

`max_alignment_rms_mm` ve `max_checkpoint_error_mm` referans raporunda tanımlanan **araştırma kabul sınırlarıdır**, klinik eşik değildir. Birlikte ölçülmüş dosya olmadan yerleşik katalog profilinin hiçbir kabul sınırı uygulanmaz veya implant XML'i yazılmaz. JSON yapısal doğrulaması ölçüm raporunu/üretici uyumluluğunu bağımsız onaylamaz.

İmplant XML önkoşulları: dört veya altı benzersiz, aynı çenede FDI; eksiksiz ölçülmüş MUA dönüşümü ve tutarlı özet; bayrak kalite uyarılarının giderilmesi; yakınsamış çoklu görüntü hesabı; en az bir kontrol noktası; kütüphane dönüşümü; tanımlı araştırma uyum sınırlarının aşılmaması. Yansıma/ölçek/dejenere matris kabul edilmez.

## Exocad'de doğrulama

Uygulama, resmi 05/2015 implant konumu tarifindeki per-FDI XML'i kullanır. Dahili sütun-vektör matrisleri dosyadaki satır-vektör alanlarına bir kez transpoze edilir. Yüzey ve implant dosyaları aynı koordinattadır; bunları orijinal hizalanmamış IOS yüzeyiyle karıştırmayın. Proje adı ve kütüphane klasörü Exocad kurulumunda aynı olmalıdır.

Gerçek Exocad sürümünde açma testi henüz yapılmadan `exocad_import_tested=false` kalır. İlk denemede asimetrik bilinen bir poz ve dört/altı FDI ile merkezler, eksenler ve mesafeler kontrol edilmelidir. Yalnız STL'nin açılması implant aktarımının doğrulanması değildir. Doğru MUA arayüzü ve fiziksel doğruluk ayrıca referans cihazla değerlendirilir.

Kaynaklar: [MegaGen Türkiye](https://www.megagen.com.tr/dijital-kutuphane/), [Exocad yüzey yükleme](https://wiki.exocad.com/wiki/index.php/Add/Remove_Mesh), [resmî implant konumu tarifi](https://content.exocad.com/secure_area/exocad_Specification_Document_Implant_Position_Import-en.pdf). Ayrıntılı araştırma `docs/EXOCAD_MEGAGEN_RESEARCH.md` içindedir.
