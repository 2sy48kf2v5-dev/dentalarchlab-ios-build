#pragma once
#include <opencv2/core.hpp>
#include <array>
#include <string>
#include <vector>

namespace dal {
using Transform = cv::Matx44d;
struct Camera {
    cv::Matx33d K = cv::Matx33d::eye();
    std::vector<double> distortion = {0, 0, 0, 0, 0};
    int width = 0, height = 0;
};
struct Marker {
    int id;
    std::array<cv::Point3d, 4> points;
    double radius = 0.55;
};
struct Observation {
    int marker;
    std::array<cv::Point2d, 4> corners;
    double span = 0, ambiguityRatio = 0;
    double blurLaplacian = 0;
};
struct PoseCandidate { Transform transform; double rms; };
std::vector<Marker> makeRig(int count);
void validateCamera(const Camera& camera);
Transform transform(const cv::Vec3d& rotation, const cv::Vec3d& translation);
Transform inverse(const Transform& value);
cv::Point3d apply(const Transform& value, const cv::Point3d& point);
std::vector<cv::Point2d> project(const Camera& camera, const Transform& value,
                               const std::vector<cv::Point3d>& points);
std::vector<PoseCandidate> poseCandidates(const Camera& camera, const Marker& marker,
                                        const std::array<cv::Point2d, 4>& corners);
}
