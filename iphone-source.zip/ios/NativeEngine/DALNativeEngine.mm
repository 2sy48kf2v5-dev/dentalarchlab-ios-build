// OpenCV headers precede Foundation: Objective-C's YES/NO macros otherwise
// collide with identifiers in C++ headers.
#include "DALVision.hpp"
#include "DALReconstruction.hpp"
#include <opencv2/calib3d.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include <cmath>
#include <random>
#include <stdexcept>
#import "DALNativeEngine.h"
#import <ImageIO/ImageIO.h>

namespace {
double number(id value) {
    if (![value isKindOfClass:[NSNumber class]] || CFGetTypeID((__bridge CFTypeRef)value)==CFBooleanGetTypeID()) throw std::invalid_argument("Sayısal değer bekleniyor.");
    double result=[value doubleValue];if(!std::isfinite(result))throw std::invalid_argument("Sayısal değer sonlu olmalı.");return result;
}
NSInteger integer(id value) {double result=number(value);if(result!=std::floor(result)||std::abs(result)>10000000)throw std::invalid_argument("Tam sayı bekleniyor.");return NSInteger(result);}
NSArray* array(id value,NSInteger length=-1) {if(![value isKindOfClass:[NSArray class]]||(length>=0&&[value count]!=NSUInteger(length)))throw std::invalid_argument("Dizi boyutu geçersiz.");return value;}
NSDictionary* dictionary(id value,const std::string& context="Veri") {if(![value isKindOfClass:[NSDictionary class]])throw std::invalid_argument(context+" sözlük biçiminde olmalı.");return value;}
NSString* text(const std::string& value) {return [NSString stringWithUTF8String:value.c_str()]?:@"Geçersiz metin";}
id diagnosticNumber(double value) {return value>=0&&std::isfinite(value)?(id)@(value):(id)[NSNull null];}
template<typename T> NSArray* numbers(const std::vector<T>& v) {NSMutableArray*a=[NSMutableArray arrayWithCapacity:v.size()];for(auto x:v)[a addObject:@(x)];return a;}
NSArray* strings(const std::vector<std::string>& v) {NSMutableArray*a=[NSMutableArray arrayWithCapacity:v.size()];for(const auto&x:v)[a addObject:text(x)];return a;}
template<typename T> NSArray* points2(const T& values) {NSMutableArray*a=[NSMutableArray array];for(auto p:values)[a addObject:@[@(p.x),@(p.y)]];return a;}
NSArray* point3(const cv::Point3d& p) {return @[@(p.x),@(p.y),@(p.z)];}
NSArray* matrix(const dal::Transform& value) {NSMutableArray*a=[NSMutableArray array];for(int y=0;y<4;++y){NSMutableArray*r=[NSMutableArray array];for(int x=0;x<4;++x)[r addObject:@(value(y,x))];[a addObject:r];}return a;}
std::vector<std::vector<cv::Point2f>> cornerSets(NSArray* input) {
    array(input);if(input.count>120)throw std::invalid_argument("En fazla 120 görünüm desteklenir.");std::vector<std::vector<cv::Point2f>> result;
    for(id view in input){auto points=array(view,54);std::vector<cv::Point2f> c;for(id point in points){auto p=array(point,2);c.emplace_back(float(number(p[0])),float(number(p[1])));}result.push_back(std::move(c));}return result;
}
cv::Mat imageFromData(NSData* data) {
    if(![data isKindOfClass:[NSData class]]||data.length==0||data.length>12*1024*1024)throw std::invalid_argument("Görüntü boş veya 12 MB sınırından büyük.");
    CGImageSourceRef source=CGImageSourceCreateWithData((__bridge CFDataRef)data,nullptr);
    if(!source)throw std::invalid_argument("Görüntü biçimi okunamadı.");
    NSDictionary* properties=CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(source,0,nullptr));CFRelease(source);
    double width=[properties[(NSString*)kCGImagePropertyPixelWidth] doubleValue],height=[properties[(NSString*)kCGImagePropertyPixelHeight] doubleValue];
    if(width<1||height<1||width>8192||height>8192||width*height>20000000)throw std::invalid_argument("Görüntü boyutu desteklenen sınırların dışında.");
    cv::Mat encoded(1,int(data.length),CV_8U,const_cast<void*>(data.bytes));auto image=cv::imdecode(encoded,cv::IMREAD_COLOR|cv::IMREAD_IGNORE_ORIENTATION);
    if(image.empty()||image.cols!=width||image.rows!=height)throw std::invalid_argument("Görüntü çözülemedi.");return image;
}
dal::Camera cameraFromDictionary(NSDictionary* value) {
    dictionary(value,"Kamera kalibrasyonu");if(integer(value[@"schema_version"])!=1||![value[@"model"] isEqual:@"opencv_pinhole"])throw std::invalid_argument("Kamera şeması desteklenmiyor.");
    auto K=array(value[@"K"],3),size=array(value[@"image_size"],2),dist=array(value[@"distortion"]);dal::Camera c;
    c.width=int(integer(size[0]));c.height=int(integer(size[1]));for(int y=0;y<3;++y){auto row=array(K[y],3);for(int x=0;x<3;++x)c.K(y,x)=number(row[x]);}c.distortion.clear();for(id v in dist)c.distortion.push_back(number(v));dal::validateCamera(c);return c;
}
NSDictionary* cameraDictionary(const dal::Camera&c,NSDictionary*metadata) {NSMutableArray*K=[NSMutableArray array];for(int y=0;y<3;++y)[K addObject:@[@(c.K(y,0)),@(c.K(y,1)),@(c.K(y,2))]];return @{@"schema_version":@1,@"model":@"opencv_pinhole",@"K":K,@"distortion":numbers(c.distortion),@"image_size":@[@(c.width),@(c.height)],@"metadata":metadata};}
bool controlledProfile(NSDictionary* p,int width,int height) {
    if(![p isKindOfClass:[NSDictionary class]])return false;
    return [p[@"pipeline"] isEqual:@"ios_avfoundation_v1"]&&[p[@"focus"] isEqual:@"locked"]&&[p[@"lens"] isEqual:@"wide"]&&[p[@"stabilization"] isEqual:@"off"]&&[p[@"orientation"] isEqual:@"sensor_native"]&&[p[@"zoom"] doubleValue]==1&&[p[@"width"] integerValue]==width&&[p[@"height"] integerValue]==height&&[p[@"device"] isKindOfClass:[NSString class]]&&[p[@"device"] length]>0&&[p[@"format"] isKindOfClass:[NSString class]]&&[p[@"format"] length]>0&&[p[@"lens_position"] isKindOfClass:[NSNumber class]]&&std::isfinite([p[@"lens_position"] doubleValue])&&[p[@"lens_position"] doubleValue]>=0&&[p[@"lens_position"] doubleValue]<=1;
}
void failure(NSError** error,const std::exception& exception) {if(error)*error=[NSError errorWithDomain:@"DentalArchLab.NativeEngine" code:1 userInfo:@{NSLocalizedDescriptionKey:text(exception.what())}];}
NSDictionary* reconstructionDictionary(const dal::Reconstruction&r,const dal::Camera&camera,NSDictionary*cameraSource,int count) {
    NSMutableArray*markers=[NSMutableArray array],*points=[NSMutableArray array],*rigMarkers=[NSMutableArray array];NSMutableDictionary*cameraPoses=[NSMutableDictionary dictionary];
    for(const auto&m:dal::makeRig(count)){NSMutableArray*objects=[NSMutableArray array];for(auto p:m.points)[objects addObject:point3(p)];[rigMarkers addObject:@{@"id":@(m.id),@"side_mm":@8,@"serial":[NSString stringWithFormat:@"DAL-D4-%02d",m.id],@"points_mm":objects,@"dot_radius_mm":@(.55),@"T_marker_mua":[NSNull null],@"calibration":@{@"status":@"missing"}}];}
    for(const auto&m:r.markers){[markers addObject:@{@"id":@(m.id),@"serial":[NSString stringWithFormat:@"DAL-D4-%02d",m.id],@"T_world_marker":matrix(m.pose),@"T_world_mua":[NSNull null],@"center_mm":[NSNull null],@"axis":[NSNull null],@"calibration_status":@"missing",@"views":@(m.views),@"reprojection_rms_px":@(m.rms),@"min_marker_side_px":@(m.minSpan),@"min_corner_max_ray_angle_deg":@(m.angle),@"triangulation_to_rigid_rms_mm":m.triangulated?@(m.triangulationRMS):[NSNull null],@"geometry_score":@(m.score),@"score_is_probability":@NO,@"ambiguous_single_view_count":@(m.ambiguousViews),@"issues":strings(m.issues)}];
        for(size_t j=0;j<m.rigidPoints.size();++j)[points addObject:@{@"marker":@(m.id),@"corner":@(j),@"point_mm":point3(m.rigidPoints[j]),@"source":@"rigid_bundle"}];if(m.triangulated)for(size_t j=0;j<m.triangulatedPoints.size();++j)[points addObject:@{@"marker":@(m.id),@"corner":@(j),@"point_mm":point3(m.triangulatedPoints[j]),@"source":@"dlt_triangulation"}];}
    for(const auto&c:r.cameraPoses)cameraPoses[text(c.first)]=matrix(c.second);
    return @{@"schema_version":@1,@"software":@"DentalArchLab native 0.9",@"research_only":@YES,@"units":@"mm",@"coordinate_convention":@"T_a_b maps b into a; +Z MUA axis requires measured calibration; right-handed",@"world_anchor_marker_id":@(r.anchor),@"scale_source":@"configured independent DAL landmark geometry in mm; nominal until physically measured",@"status":text(r.status),@"camera":cameraSource?:cameraDictionary(camera,@{}),@"rig":@{@"schema_version":@1,@"units":@"mm",@"dictionary":@"DAL_DOTS4_V1",@"markers":rigMarkers},@"frame_count":@(r.cameraPoses.size()),@"observations_used":@(r.observationsUsed),@"missing_markers":numbers(r.missing),@"warnings":strings(r.warnings),@"bundle_adjustment":@[@{@"initial_rms_px":@(r.bundle.initialRMS),@"final_rms_px":@(r.bundle.finalRMS),@"converged":@(r.bundle.converged),@"evaluations":@(r.bundle.iterations),@"cost":@(r.bundle.cost),@"message":@"Original bounded robust Schur Levenberg-Marquardt; 50 iterations maximum"}],@"reprojection_rms_px":@(r.rms),@"markers":markers,@"points":points,@"camera_poses":cameraPoses,@"rejected_observations":@[],@"physical_accuracy_um":[NSNull null]};
}
dal::Camera syntheticCamera() {
    dal::Camera c;c.width=1920;c.height=1080;c.K=cv::Matx33d(1600,0,960,0,1585,540,0,0,1);c.distortion={-.035,.008,.0002,-.0001,.001};return c;
}
cv::Mat renderFlags(const dal::Camera&camera) {
    constexpr int scale=4;cv::Mat image(camera.height*scale,camera.width*scale,CV_8UC3,cv::Scalar(228,228,228));auto c=camera;c.K(0,0)*=scale;c.K(1,1)*=scale;c.K(0,2)*=scale;c.K(1,2)*=scale;c.width*=scale;c.height*=scale;
    const double pi=3.14159265358979323846;auto rig=dal::makeRig(6);
    for(const auto&marker:rig){auto T=dal::transform(cv::Vec3d(.12,-.10,.025*(marker.id-2)),cv::Vec3d((marker.id%3-1)*18.,(marker.id/3-.5)*15.,150));T=T*dal::transform(cv::Vec3d(pi,0,0),cv::Vec3d(0,0,0));
        std::vector<cv::Point3d>outline={{-5,-4,0},{5,-4,0},{5,4,0},{-5,4,0}};auto projected=dal::project(c,T,outline);std::vector<cv::Point>polygon;for(auto p:projected)polygon.emplace_back(cvRound(p.x),cvRound(p.y));cv::fillConvexPoly(image,polygon,cv::Scalar(20,20,20),cv::LINE_AA);
        for(auto center:marker.points){std::vector<cv::Point3d>circle;for(int j=0;j<96;++j){double angle=2*pi*j/96;circle.push_back(center+cv::Point3d(marker.radius*std::cos(angle),marker.radius*std::sin(angle),0));}projected=dal::project(c,T,circle);polygon.clear();for(auto p:projected)polygon.emplace_back(cvRound(p.x),cvRound(p.y));cv::fillConvexPoly(image,polygon,cv::Scalar(244,244,244),cv::LINE_AA);}
    }
    cv::Mat small;cv::resize(image,small,cv::Size(camera.width,camera.height),0,0,cv::INTER_AREA);cv::GaussianBlur(small,small,cv::Size(3,3),.45);return small;
}
NSDictionary* validateSynthetic() {
    const double pi=3.14159265358979323846;auto camera=syntheticCamera();NSMutableArray*tests=[NSMutableArray array];bool passed=true;
    // Pixel fixture is rendered independently from the detector by projecting
    // dense circle outlines, then downsampling; it is never used in capture.
    auto image=renderFlags(camera);auto detection=dal::detect(image,camera,6);std::vector<int>ids;for(const auto&o:detection.observations)ids.push_back(o.marker);std::sort(ids.begin(),ids.end());bool detectionPassed=ids==std::vector<int>({0,1,2,3,4,5});passed&=detectionPassed;
    [tests addObject:@{@"name":@"six_flag_render_detection",@"passed":@(detectionPassed),@"detected_ids":numbers(ids),@"expected_ids":@[@0,@1,@2,@3,@4,@5],@"rejected":strings(detection.rejected)}];
    cv::Mat blank(camera.height,camera.width,CV_8UC3,cv::Scalar(128,128,128));auto negative=dal::detect(blank,camera,6);bool negativePassed=negative.observations.empty();passed&=negativePassed;[tests addObject:@{@"name":@"blank_image_rejection",@"passed":@(negativePassed),@"detected_count":@(negative.observations.size())}];
    for(int count:{4,6}){
        auto rig=dal::makeRig(count);std::vector<dal::Transform>truth;for(int i=0;i<count;++i){double a=pi*i/(count-1);truth.push_back(dal::transform(cv::Vec3d(.025*std::sin(a),.02*std::cos(a),.08*std::cos(a)),cv::Vec3d(25*std::cos(a),28*std::sin(a),1.5*std::sin(2*a))));}auto anchor=truth[0];for(auto&T:truth)T=dal::inverse(anchor)*T;
        std::mt19937 generator(7401+count);std::normal_distribution<double> noise(0,.035);std::vector<dal::FrameObservation>observations;
        for(int f=0;f<14;++f){double phase=2*pi*f/14;auto C=dal::transform(cv::Vec3d(.13*std::sin(phase),.16*std::cos(phase),.015*std::sin(2*phase)),cv::Vec3d(12*std::cos(phase),10+8*std::sin(phase),165+10*std::sin(2*phase)))*dal::transform(cv::Vec3d(pi,0,0),cv::Vec3d(0,0,0))*anchor;
            for(int i=0;i<count;++i){std::vector<cv::Point3d>points(rig[i].points.begin(),rig[i].points.end());auto uv=dal::project(camera,C*truth[i],points);dal::Observation observation;observation.marker=i;for(int j=0;j<4;++j)observation.corners[j]={uv[j].x+noise(generator),uv[j].y+noise(generator)};for(auto a:observation.corners)for(auto b:observation.corners)observation.span=std::max(observation.span,cv::norm(a-b));observations.push_back({"frame_"+std::to_string(f),observation});}
        }
        auto result=dal::reconstruct(camera,count,observations);double positionSS=0,axisSS=0,maxPosition=0;NSMutableArray*errors=[NSMutableArray array];
        for(int i=1;i<count;++i){const auto&actual=result.markerPoses.at(i);auto expected=truth[i];double position=std::sqrt(std::pow(actual(0,3)-expected(0,3),2)+std::pow(actual(1,3)-expected(1,3),2)+std::pow(actual(2,3)-expected(2,3),2));double dot=actual(0,2)*expected(0,2)+actual(1,2)*expected(1,2)+actual(2,2)*expected(2,2);double angle=std::acos(std::clamp(dot,-1.,1.))*180/pi;positionSS+=position*position;axisSS+=angle*angle;maxPosition=std::max(maxPosition,position);[errors addObject:@{@"id":@(i),@"position_error_mm":@(position),@"axis_error_deg":@(angle)}];}
        double positionRMS=std::sqrt(positionSS/(count-1)),axisRMS=std::sqrt(axisSS/(count-1));bool reconstructionPassed=result.bundle.converged&&positionRMS<.25&&axisRMS<1.0&&result.rms<.12&&result.markers.size()==size_t(count)&&result.status=="research_result";passed&=reconstructionPassed;
        [tests addObject:@{@"name":[NSString stringWithFormat:@"%d_flag_multiview_ground_truth",count],@"passed":@(reconstructionPassed),@"frames":@14,@"marker_count":@(count),@"noise_sigma_px":@(.035),@"non_anchor_position_rms_mm":@(positionRMS),@"non_anchor_max_position_error_mm":@(maxPosition),@"non_anchor_axis_rms_deg":@(axisRMS),@"reprojection_rms_px":@(result.rms),@"converged":@(result.bundle.converged),@"iterations":@(result.bundle.iterations),@"per_marker":errors}];
    }
    std::vector<std::vector<cv::Point2f>> views;std::vector<cv::Point3d>board;for(int y=0;y<6;++y)for(int x=0;x<9;++x)board.emplace_back(x*6.,y*6.,0);
    std::mt19937 generator(9081);std::normal_distribution<double>noise(0,.025);
    for(int i=0;i<20;++i){double phase=2*pi*i/20;auto T=dal::transform(cv::Vec3d(.32*std::sin(phase),.28*std::cos(phase),.04*std::sin(2*phase)),cv::Vec3d(-24+29*std::cos(phase),-15+17*std::sin(phase),165+12*std::sin(2*phase)));auto projected=dal::project(camera,T,board);std::vector<cv::Point2f>corners;for(auto p:projected)corners.emplace_back(float(p.x+noise(generator)),float(p.y+noise(generator)));views.push_back(std::move(corners));}
    auto calibration=dal::calibrate(views,camera.width,camera.height,6);double focalError=std::max(std::abs(calibration.camera.K(0,0)/camera.K(0,0)-1),std::abs(calibration.camera.K(1,1)/camera.K(1,1)-1));bool calibrationPassed=calibration.rms<.1&&focalError<.02&&calibration.kept.size()>=10&&calibration.warnings.empty();passed&=calibrationPassed;
    [tests addObject:@{@"name":@"camera_calibration_ground_truth",@"passed":@(calibrationPassed),@"input_views":@20,@"retained_views":@(calibration.kept.size()),@"rms_px":@(calibration.rms),@"maximum_relative_focal_error":@(focalError),@"tilt_spread_deg":@(calibration.tiltSpread),@"warnings":strings(calibration.warnings)}];
    // Degenerate requests must fail instead of inventing a pose/calibration.
    bool disconnectedRejected=false;try{std::vector<dal::FrameObservation>bad;auto rig=dal::makeRig(4);for(int f=0;f<4;++f){for(int i:(f<2?std::vector<int>{0,1}:std::vector<int>{2,3})){auto T=dal::transform(cv::Vec3d(pi,0,0),cv::Vec3d(i*9-13.5,0,170));std::vector<cv::Point3d>points(rig[i].points.begin(),rig[i].points.end());auto uv=dal::project(camera,T,points);dal::Observation o;o.marker=i;o.span=60;std::copy(uv.begin(),uv.end(),o.corners.begin());bad.push_back({"bad_"+std::to_string(f),o});}}dal::reconstruct(camera,4,bad);}catch(const std::invalid_argument&){disconnectedRejected=true;}passed&=disconnectedRejected;[tests addObject:@{@"name":@"disconnected_visibility_rejection",@"passed":@(disconnectedRejected)}];
    return @{@"passed":@(passed),@"synthetic_only":@YES,@"physical_accuracy_um":[NSNull null],@"computed_on_device":@YES,@"engine":@"original DAL native OpenCV core",@"message":@"Seeded synthetic ground-truth tests. These errors are not physical or clinical accuracy.",@"tests":tests};
}
}

@implementation DALNativeEngine
+ (NSDictionary<NSString*,id>*)validateSyntheticWithError:(NSError**)error {
    try{return validateSynthetic();}catch(const std::exception&e){failure(error,e);return nil;}
}
+ (NSDictionary<NSString*,id>*)detectImage:(NSData*)data camera:(NSDictionary<NSString*,id>*)camera markerCount:(NSInteger)count error:(NSError**)error {
    try{auto image=imageFromData(data);dal::Camera c;if(camera)c=cameraFromDictionary(camera);else{c.width=image.cols;c.height=image.rows;double f=std::max(c.width,c.height)*1.15;c.K=cv::Matx33d(f,0,c.width/2.,0,f,c.height/2.,0,0,1);}
        auto result=dal::detect(image,c,int(count));NSMutableArray*observations=[NSMutableArray array],*matches=[NSMutableArray array],*diagnostics=[NSMutableArray array];for(const auto&o:result.observations)[observations addObject:@{@"marker":@(o.marker),@"corners":points2(o.corners),@"min_side_px":@(o.span),@"ambiguity_ratio":@(o.ambiguityRatio),@"blur_laplacian":@(o.blurLaplacian)}];for(const auto&m:result.matches)[matches addObject:@{@"id":@(m.id),@"score":@(m.score),@"identity_ratio":@(m.ratio),@"identity_gap_px":@(m.gap)}];
        for(const auto&d:result.candidates)[diagnostics addObject:@{@"candidate_index":@(d.index),@"centers_px":points2(d.centers),@"span_px":@(d.span),@"reason":text(d.reason),@"accepted":@(d.accepted),@"best_id":d.bestID<0?(id)[NSNull null]:(id)@(d.bestID),@"best_score_px":diagnosticNumber(d.score),@"identity_ratio":diagnosticNumber(d.ratio),@"identity_gap_px":diagnosticNumber(d.gap)}];
        cv::Mat gray,bright;cv::cvtColor(image,gray,cv::COLOR_BGR2GRAY);cv::compare(gray,250,bright,cv::CMP_GE);double fraction=double(cv::countNonZero(bright))/gray.total();
        return @{@"observations":observations,@"quality":@{@"blur_laplacian":@(result.blur),@"frame_blur_laplacian":@(result.frameBlur),@"blur_region":@"accepted_dot_target_ROIs",@"rejected":strings(result.rejected),@"dot_groups":@(result.groups),@"identity_matches":matches,@"candidate_diagnostics":diagnostics,@"detector_mode":camera?@"calibrated_pose_3d":@"assumed_camera_pose_2d",@"diagnostics_truncated":@(result.groups>72),@"saturated_fraction":@(fraction),@"family":@"DAL_DOTS4_V1",@"commercial_pic_compatible":@NO},@"image_size":@[@(image.cols),@(image.rows)],@"metric_intrinsics":@(camera!=nil)};
    }catch(const std::exception&e){failure(error,e);return nil;}
}
+ (NSDictionary<NSString*,id>*)checkBoardImage:(NSData*)data previousCorners:(NSArray*)previous error:(NSError**)error {
    try{auto image=imageFromData(data);auto result=dal::checkBoard(image,cornerSets(previous));return @{@"accepted":@(result.accepted),@"message":text(result.message),@"reason":text(result.reason),@"corners":result.accepted?points2(result.corners):[NSNull null],@"detected_corners":points2(result.detectedCorners),@"detected_count":@(result.detectedCorners.size()),@"blur_laplacian":@(result.blur),@"image_size":@[@(image.cols),@(image.rows)]};}catch(const std::exception&e){failure(error,e);return nil;}
}
+ (NSDictionary<NSString*,id>*)calibrateCorners:(NSArray*)corners width:(NSInteger)width height:(NSInteger)height squareMM:(double)squareMM physicalMeasured:(BOOL)physicalMeasured profile:(NSDictionary<NSString*,id>*)profile error:(NSError**)error {
    try{dictionary(profile);auto input=cornerSets(corners);auto result=dal::calibrate(input,int(width),int(height),physicalMeasured?squareMM:1.);bool controlled=controlledProfile(profile,int(width),int(height));NSString*created=[[[NSISO8601DateFormatter alloc]init] stringFromDate:[NSDate date]];auto metadata=@{@"status":physicalMeasured&&controlled?@"measured_research":@"screen_experimental",@"capture_profile":profile,@"board_inner_corners":@[@9,@6],@"square_mm":physicalMeasured?@(squareMM):[NSNull null],@"physical_accuracy_validated":@NO,@"board_size_user_declared":@(physicalMeasured),@"created_utc":created,@"rms_px":@(result.rms),@"per_view_rms_px":numbers(result.perView),@"intrinsic_std_deviations":numbers(result.intrinsicStd),@"views":@(result.kept.size()),@"input_views":@(input.size()),@"kept_view_indices":numbers(result.kept),@"rejected_view_indices":numbers(result.rejected),@"tilt_spread_deg":@(result.tiltSpread),@"warnings":strings(result.warnings),@"calibration_model":@"5 coefficient Brown-Conrady",@"outlier_policy":@"up to 20%; at least 10 retained; robust per-view RMS",@"computed_on_device":@YES};return cameraDictionary(result.camera,metadata);}catch(const std::exception&e){failure(error,e);return nil;}
}
+ (NSDictionary<NSString*,id>*)reconstructObservations:(NSArray<NSDictionary<NSString*,id>*>*)input camera:(NSDictionary<NSString*,id>*)camera markerCount:(NSInteger)count error:(NSError**)error {
    try{auto c=cameraFromDictionary(camera);array(input);if(input.count>720)throw std::invalid_argument("En fazla 720 bayrak gözlemi desteklenir.");std::vector<dal::FrameObservation>observations;size_t index=0;for(id raw in input){auto row=dictionary(raw,"Bayrak gözlemi "+std::to_string(++index));NSString*frame=row[@"frame"];if(![frame isKindOfClass:[NSString class]])throw std::invalid_argument("Kare kimliği eksik.");dal::Observation observation;observation.marker=int(integer(row[@"marker"]));observation.span=number(row[@"min_side_px"]);observation.ambiguityRatio=row[@"ambiguity_ratio"]?number(row[@"ambiguity_ratio"]):0;auto corners=array(row[@"corners"],4);for(int j=0;j<4;++j){auto p=array(corners[j],2);observation.corners[j]={number(p[0]),number(p[1])};}observations.push_back({[frame UTF8String],observation});}auto result=dal::reconstruct(c,int(count),observations);return reconstructionDictionary(result,c,camera,int(count));}catch(const std::exception&e){failure(error,e);return nil;}
}
@end
