"""Collect pinned upstream license notices; no third-party code is executed."""
from pathlib import Path
import hashlib
import io
import json
import re
import tarfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[3] / 'work'
TAG = '4.12.0'
SOURCE_URL = f'https://codeload.github.com/opencv/opencv/tar.gz/refs/tags/{TAG}'
ARCHIVE_URL = f'https://github.com/opencv/opencv/releases/download/{TAG}/opencv-{TAG}-ios-framework.zip'
FRAMEWORK_SHA = '86b42c9f141cd9169b91be2fc380b0e556a88a95c98ccc8e7aef8349ab74cf70'

def sha(data): return hashlib.sha256(data).hexdigest()

def main():
    source = WORK / f'opencv-{TAG}-source-notices.tar.gz'
    if not source.exists():
        with urllib.request.urlopen(SOURCE_URL, timeout=60) as response:
            source.write_bytes(response.read())
    records = []
    source_sha = sha(source.read_bytes())
    sections = [
        'DENTALARCHLAB - THIRD PARTY NOTICES\n\n'
        'OpenCV 4.12.0 is linked from the official iOS static framework.\n'
        f'Archive: {ARCHIVE_URL}\nSHA-256: {FRAMEWORK_SHA}\n\n'
        'OpenCV Apache-2.0 license is supplied separately in OPENCV-LICENSE.txt.\n'
        'The following upstream notices are retained verbatim. Some libraries or\n'
        'source files may be removed by the static linker. Inclusion of a notice\n'
        'does not mean that every upstream module is enabled in this app.\n'
        'The original DentalArchLab algorithms are separate from these components.\n\n'
        f'Pinned OpenCV source: {SOURCE_URL}\nSource archive SHA-256: {source_sha}\n'
    ]
    prefix = f'opencv-{TAG}/'
    packages = {
        '3rdparty/libjpeg-turbo/LICENSE.md', '3rdparty/libjpeg-turbo/README.ijg',
        '3rdparty/libwebp/COPYING', '3rdparty/libwebp/PATENTS',
        '3rdparty/libpng/LICENSE', '3rdparty/zlib/LICENSE',
        '3rdparty/protobuf/LICENSE', '3rdparty/flatbuffers/LICENSE.txt',
    }
    source_modules = ('modules/core/', 'modules/imgproc/', 'modules/imgcodecs/',
                      'modules/calib3d/', 'modules/features2d/', 'modules/flann/')
    notices = {}
    with tarfile.open(source, 'r:gz') as archive:
        for item in archive:
            if not item.isfile() or not item.name.startswith(prefix): continue
            name = item.name[len(prefix):]
            if name == 'LICENSE' or name in packages:
                data = archive.extractfile(item).read()
                records.append({'path': name, 'sha256': sha(data), 'source_url': f'https://raw.githubusercontent.com/opencv/opencv/{TAG}/{name}'})
                if name == 'LICENSE':
                    (ROOT/'OPENCV-LICENSE.txt').write_bytes(data)
                else:
                    sections.append('\n' + '='*72 + '\n' + name + '\n' + records[-1]['source_url'] + '\n\n' + data.decode('utf-8', errors='replace'))
            elif name.startswith(source_modules) and name.endswith(('.hpp', '.h', '.cpp', '.c')):
                # Preserve leading license comments, not implementation bodies.
                text = archive.extractfile(item).read(32768).decode('utf-8', errors='replace')
                comments = []
                remaining = text.lstrip('\ufeff\r\n \t')
                while remaining.startswith(('/*', '//')):
                    if remaining.startswith('/*'):
                        end = remaining.find('*/')
                        if end < 0: break
                        comment = remaining[:end+2]
                        remaining = remaining[end+2:].lstrip()
                    else:
                        match = re.match(r'(?:(?://[^\n]*)(?:\n|$))+', remaining)
                        if not match: break
                        comment = match.group()
                        remaining = remaining[match.end():].lstrip()
                    if any(word in comment.lower() for word in ('copyright', 'license', 'redistribution', 'permission to use')):
                        comments.append(comment)
                for comment in comments:
                    normalized = re.sub(r'\s+', ' ', comment).strip()
                    if normalized not in notices: notices[normalized] = [comment, []]
                    notices[normalized][1].append(name)
    for _, (notice, paths) in sorted(notices.items(), key=lambda item: item[1][1][0]):
        sections.append('\n' + '='*72 + '\nRetained OpenCV source attribution\n' + '\n'.join(paths) + '\n\n' + notice + '\n')
    # G-API's optional ADE dependency is downloaded by OpenCV CMake and is not
    # stored inside the OpenCV source archive. Preserve its upstream license too.
    ade_url = 'https://raw.githubusercontent.com/opencv/ade/v0.1.2e/LICENSE'
    with urllib.request.urlopen(ade_url, timeout=30) as response: ade = response.read()
    records.append({'path': 'ade/LICENSE', 'source_url': ade_url, 'sha256': sha(ade)})
    sections.append('\n' + '='*72 + '\nADE v0.1.2e\n' + ade_url + '\n\n' + ade.decode('utf-8'))
    (ROOT/'THIRD-PARTY-NOTICES.txt').write_text('\n'.join(sections), encoding='utf-8')
    manifest = {'opencv_version': TAG, 'official_framework_sha256': FRAMEWORK_SHA,
                'source_archive_url': SOURCE_URL, 'source_archive_sha256': source_sha,
                'license_sources': records, 'retained_source_notice_blocks': len(notices)}
    (ROOT/'license-provenance.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'license_bytes': (ROOT/'OPENCV-LICENSE.txt').stat().st_size,
                      'notice_bytes': (ROOT/'THIRD-PARTY-NOTICES.txt').stat().st_size,
                      'source_notice_blocks': len(notices), 'package_licenses': len(records)}, indent=2))

if __name__ == '__main__': main()
