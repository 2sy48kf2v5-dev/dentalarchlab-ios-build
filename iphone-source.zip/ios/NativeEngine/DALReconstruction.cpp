#include "DALReconstruction.hpp"
#include <opencv2/calib3d.hpp>
#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <set>
#include <stdexcept>

namespace dal {
namespace {
constexpr double pi=3.14159265358979323846;
using Parameters=cv::Vec<double,6>;
Parameters pack(const Transform&t){cv::Matx33d R(t(0,0),t(0,1),t(0,2),t(1,0),t(1,1),t(1,2),t(2,0),t(2,1),t(2,2));cv::Vec3d r;cv::Rodrigues(R,r);return {r[0],r[1],r[2],t(0,3),t(1,3),t(2,3)};}
Transform unpack(const Parameters&p){return transform(cv::Vec3d(p[0],p[1],p[2]),cv::Vec3d(p[3],p[4],p[5]));}
cv::Mat residual(const Camera& camera,const Marker& marker,const Transform&M,const Transform&C,const Observation& observation){cv::Mat r(8,1,CV_64F);auto T=C*M;std::vector<cv::Point3d> points(marker.points.begin(),marker.points.end());for(auto p:points)if(apply(T,p).z<=1e-6){r.setTo(1e5);return r;}auto uv=project(camera,T,points);for(int j=0;j<4;++j){r.at<double>(j*2)=uv[j].x-observation.corners[j].x;r.at<double>(j*2+1)=uv[j].y-observation.corners[j].y;}return r;}
double robustCost(const cv::Mat&r){double cost=0;for(int i=0;i<r.rows;++i){double v=r.at<double>(i)/.8;cost+=.64*(std::sqrt(1+v*v)-1);}return cost;}
double totalCost(const Camera&camera,const std::vector<Marker>&rig,const std::vector<FrameObservation>&obs,const std::map<int,Transform>&M,const std::map<std::string,Transform>&C,double*rms=nullptr){double cost=0,ss=0;for(const auto&o:obs){auto r=residual(camera,rig[o.observation.marker],M.at(o.observation.marker),C.at(o.frame),o.observation);cost+=robustCost(r);ss+=r.dot(r);}if(rms)*rms=std::sqrt(ss/(obs.size()*4));return cost;}
double poseCost(const Camera& camera,const std::vector<Marker>&rig,const std::vector<const FrameObservation*>&known,const std::map<int,Transform>&M,const Transform&C){double cost=0;for(auto o:known){auto r=residual(camera,rig[o->observation.marker],M.at(o->observation.marker),C,o->observation);for(int j=0;j<4;++j)cost+=std::min(10.,std::hypot(r.at<double>(2*j),r.at<double>(2*j+1)));}return cost;}
void initialize(const Camera&camera,const std::vector<Marker>&rig,const std::vector<FrameObservation>&obs,int anchor,std::map<int,Transform>&M,std::map<std::string,Transform>&C){
    std::map<std::pair<std::string,int>,std::vector<PoseCandidate>> cache;std::map<std::string,std::vector<const FrameObservation*>> byFrame;
    for(const auto&o:obs){auto poses=poseCandidates(camera,rig[o.observation.marker],o.observation.corners);if(poses.empty())throw std::invalid_argument("Pozitif derinlikli bayrak konumu bulunamadı.");cache[{o.frame,o.observation.marker}]=std::move(poses);byFrame[o.frame].push_back(&o);}
    M[anchor]=Transform::eye();std::set<std::string> remaining;for(const auto&f:byFrame)remaining.insert(f.first);
    while(!remaining.empty()){
        std::string selected;int bestKnown=-1;double bestSpan=-1;
        for(const auto&frame:remaining){int known=0;double span=0;for(auto o:byFrame[frame]){known+=M.count(o->observation.marker)>0;span+=o->observation.span;}if(known>bestKnown||(known==bestKnown&&span>bestSpan)){selected=frame;bestKnown=known;bestSpan=span;}}
        if(bestKnown<=0)throw std::invalid_argument("Bayrak grupları bağlantısız. Kareler arasında ortak bayrak gösterin.");
        std::vector<const FrameObservation*>known;for(auto o:byFrame[selected])if(M.count(o->observation.marker))known.push_back(o);
        Transform T;double bestCost=std::numeric_limits<double>::infinity();
        for(auto o:known)for(const auto&p:cache[{selected,o->observation.marker}]){auto candidate=p.transform*inverse(M.at(o->observation.marker));double cost=poseCost(camera,rig,known,M,candidate);if(cost<bestCost){T=candidate;bestCost=cost;}}
        if(known.size()>=2){std::vector<cv::Point3d>objects;std::vector<cv::Point2d>images;for(auto o:known)for(int j=0;j<4;++j){objects.push_back(apply(M.at(o->observation.marker),rig[o->observation.marker].points[j]));images.push_back(o->observation.corners[j]);}auto p=pack(T);cv::Vec3d r(p[0],p[1],p[2]),t(p[3],p[4],p[5]);try{if(cv::solvePnP(objects,images,camera.K,camera.distortion,r,t,true,cv::SOLVEPNP_ITERATIVE)){auto candidate=transform(r,t);if(poseCost(camera,rig,known,M,candidate)<=bestCost)T=candidate;}}catch(const cv::Exception&){} }
        C[selected]=T;for(auto o:byFrame[selected])if(!M.count(o->observation.marker))M[o->observation.marker]=inverse(T)*cache[{selected,o->observation.marker}][0].transform;remaining.erase(selected);
    }
}
BundleReport bundle(const Camera&camera,const std::vector<Marker>&rig,const std::vector<FrameObservation>&obs,int anchor,std::map<int,Transform>&M,std::map<std::string,Transform>&C){
    std::vector<int> mids;std::vector<std::string> frames;std::map<int,int> mi;std::map<std::string,int> ci;
    for(const auto&m:M)if(m.first!=anchor){mi[m.first]=int(mids.size())*6;mids.push_back(m.first);}for(const auto&c:C){ci[c.first]=int(frames.size());frames.push_back(c.first);}
    int n=int(mids.size())*6;BundleReport report;double cost=totalCost(camera,rig,obs,M,C,&report.initialRMS),lambda=1e-3;report.finalRMS=report.initialRMS;
    // Schur complement eliminates independent camera blocks; only <=30 marker
    // variables remain in the dense solve. Finite differences touch one pose.
    for(int iteration=0;iteration<50;++iteration){
        cv::Mat A=cv::Mat::zeros(n,n,CV_64F),gM=cv::Mat::zeros(n,1,CV_64F);
        std::vector<cv::Mat>D(frames.size()),E(frames.size()),gC(frames.size());for(size_t k=0;k<frames.size();++k){D[k]=cv::Mat::zeros(6,6,CV_64F);E[k]=cv::Mat::zeros(n,6,CV_64F);gC[k]=cv::Mat::zeros(6,1,CV_64F);}
        for(const auto&o:obs){int mid=o.observation.marker,k=ci[o.frame];const auto&marker=rig[mid];auto mp=pack(M.at(mid)),cp=pack(C.at(o.frame));cv::Mat r=residual(camera,marker,M.at(mid),C.at(o.frame),o.observation),Jc(8,6,CV_64F),Jm=cv::Mat::zeros(8,6,CV_64F);
            for(int axis=0;axis<6;++axis){double step=axis<3?1e-6:1e-4;auto p=cp;p[axis]+=step;auto plus=residual(camera,marker,M.at(mid),unpack(p),o.observation);p=cp;p[axis]-=step;auto minus=residual(camera,marker,M.at(mid),unpack(p),o.observation);cv::Mat derivative=(plus-minus)/(2*step);derivative.copyTo(Jc.col(axis));if(mid!=anchor){p=mp;p[axis]+=step;plus=residual(camera,marker,unpack(p),C.at(o.frame),o.observation);p=mp;p[axis]-=step;minus=residual(camera,marker,unpack(p),C.at(o.frame),o.observation);derivative=(plus-minus)/(2*step);derivative.copyTo(Jm.col(axis));}}
            for(int j=0;j<8;++j){double value=r.at<double>(j)/.8;double w=std::pow(1+value*value,-.25);r.at<double>(j)*=w;Jc.row(j)*=w;Jm.row(j)*=w;}
            D[k]+=Jc.t()*Jc;gC[k]+=Jc.t()*r;if(mid!=anchor){int off=mi[mid];A(cv::Rect(off,off,6,6))+=Jm.t()*Jm;gM(cv::Rect(0,off,1,6))+=Jm.t()*r;E[k](cv::Rect(0,off,6,6))+=Jm.t()*Jc;}
        }
        double gradient=cv::norm(gM,cv::NORM_INF);for(const auto&g:gC)gradient=std::max(gradient,cv::norm(g,cv::NORM_INF));if(gradient<1e-7){report.converged=true;break;}
        for(int j=0;j<n;++j)A.at<double>(j,j)+=lambda*std::max(1.,A.at<double>(j,j));
        std::vector<cv::Mat>dinv(frames.size());bool solved=true;cv::Mat S=A.clone(),rhs=-gM;
        for(size_t k=0;k<frames.size();++k){for(int j=0;j<6;++j)D[k].at<double>(j,j)+=lambda*std::max(1.,D[k].at<double>(j,j));if(!cv::invert(D[k],dinv[k],cv::DECOMP_CHOLESKY)){solved=false;break;}S-=E[k]*dinv[k]*E[k].t();rhs+=E[k]*dinv[k]*gC[k];}
        cv::Mat dm;if(!solved||!cv::solve(S,rhs,dm,cv::DECOMP_CHOLESKY)){lambda*=10;if(lambda>1e12)break;continue;}
        auto proposedM=M;auto proposedC=C;double maxStep=0;
        for(size_t k=0;k<mids.size();++k){auto p=pack(M.at(mids[k]));for(int j=0;j<6;++j){double d=dm.at<double>(int(k)*6+j);p[j]+=d;maxStep=std::max(maxStep,std::abs(d));}proposedM[mids[k]]=unpack(p);}
        for(size_t k=0;k<frames.size();++k){cv::Mat dc=-dinv[k]*(gC[k]+E[k].t()*dm);auto p=pack(C.at(frames[k]));for(int j=0;j<6;++j){double d=dc.at<double>(j);p[j]+=d;maxStep=std::max(maxStep,std::abs(d));}proposedC[frames[k]]=unpack(p);}
        double next=totalCost(camera,rig,obs,proposedM,proposedC);report.iterations=iteration+1;
        if(std::isfinite(next)&&next<cost){double improvement=cost-next;M=std::move(proposedM);C=std::move(proposedC);cost=next;lambda=std::max(1e-9,lambda*.3);if(improvement<1e-9*(1+cost)||maxStep<1e-7){report.converged=true;break;}}
        else{lambda*=10;if(maxStep<1e-8&&std::abs(next-cost)<1e-8*(1+cost)){report.converged=true;break;}if(lambda>1e12)break;}
    }
    report.cost=totalCost(camera,rig,obs,M,C,&report.finalRMS);return report;
}
bool triangulate(const Camera&camera,const std::vector<std::pair<Transform,cv::Point2d>>&views,cv::Point3d&point,double&angle){
    if(views.size()<2)return false;cv::Mat rows(int(views.size())*2,4,CV_64F);std::vector<cv::Point3d> centers;int row=0;
    for(const auto&v:views){std::vector<cv::Point2d>uv={v.second},n;cv::undistortPoints(uv,n,camera.K,camera.distortion);for(int j=0;j<4;++j){rows.at<double>(row,j)=n[0].x*v.first(2,j)-v.first(0,j);rows.at<double>(row+1,j)=n[0].y*v.first(2,j)-v.first(1,j);}row+=2;auto inv=inverse(v.first);centers.emplace_back(inv(0,3),inv(1,3),inv(2,3));}
    cv::Mat w,u,vt;cv::SVD::compute(rows,w,u,vt,cv::SVD::FULL_UV);double homogeneous=vt.at<double>(3,3);if(std::abs(homogeneous)<1e-12)return false;point={vt.at<double>(3,0)/homogeneous,vt.at<double>(3,1)/homogeneous,vt.at<double>(3,2)/homogeneous};if(!std::isfinite(point.x)||!std::isfinite(point.y)||!std::isfinite(point.z))return false;
    std::vector<cv::Point3d>rays;for(auto c:centers){auto r=point-c;double n=cv::norm(r);if(n<1e-9)return false;rays.push_back(r*(1/n));}angle=0;for(auto a:rays)for(auto b:rays)angle=std::max(angle,std::acos(std::clamp(a.dot(b),-1.,1.))*180/pi);for(const auto&v:views)if(apply(v.first,point).z<=0)return false;return true;
}
}
Reconstruction reconstruct(const Camera&camera,int markerCount,const std::vector<FrameObservation>&obs){
    validateCamera(camera);auto rig=makeRig(markerCount);if(obs.size()>720)throw std::invalid_argument("Bir hesapta en fazla 120 kare desteklenir.");std::set<std::pair<std::string,int>>keys;std::set<std::string>frames;std::set<int>seen;std::map<int,int>counts;
    for(const auto&o:obs){if(o.frame.empty()||o.frame.size()>128||o.observation.marker<0||o.observation.marker>=markerCount||!keys.insert({o.frame,o.observation.marker}).second)throw std::invalid_argument("Yinelenen veya geçersiz kare/bayrak kimliği.");for(auto p:o.observation.corners)if(!std::isfinite(p.x)||!std::isfinite(p.y)||p.x<0||p.y<0||p.x>=camera.width||p.y>=camera.height)throw std::invalid_argument("Bayrak köşesi görüntü dışında veya geçersiz.");frames.insert(o.frame);seen.insert(o.observation.marker);++counts[o.observation.marker];}
    if(frames.size()<3||frames.size()>120||seen.size()<2)throw std::invalid_argument("En az 3 farklı kare ve bağlantılı 2 bayrak gerekli.");for(const auto&c:counts)if(c.second<2)throw std::invalid_argument("Her bayrak en az iki karede görünmeli.");
    Reconstruction result;result.anchor=*seen.begin();result.observationsUsed=int(obs.size());initialize(camera,rig,obs,result.anchor,result.markerPoses,result.cameraPoses);result.bundle=bundle(camera,rig,obs,result.anchor,result.markerPoses,result.cameraPoses);result.rms=result.bundle.finalRMS;
    for(int i=0;i<markerCount;++i)if(!seen.count(i))result.missing.push_back(i);
    if(!result.bundle.converged)result.warnings.push_back("Bundle adjustment iteration limit reached; inspect the residuals before further research use.");
    result.warnings.push_back("MUA transforms are unmeasured; only independent optical flag geometry is available.");
    bool poor=false;
    for(const auto&entry:result.markerPoses){int mid=entry.first;ReconstructedMarker m;m.id=mid;m.pose=entry.second;m.views=counts[mid];m.minSpan=std::numeric_limits<double>::infinity();double ss=0;
        std::vector<const FrameObservation*>selected;for(const auto&o:obs)if(o.observation.marker==mid){selected.push_back(&o);auto r=residual(camera,rig[mid],m.pose,result.cameraPoses.at(o.frame),o.observation);ss+=r.dot(r);m.minSpan=std::min(m.minSpan,o.observation.span);m.ambiguousViews+=o.observation.ambiguityRatio>.8;}
        m.rms=std::sqrt(ss/(selected.size()*4));m.angle=180;double triSS=0;bool triOK=true;
        for(int j=0;j<4;++j){auto rigid=apply(m.pose,rig[mid].points[j]);m.rigidPoints.push_back(rigid);std::vector<std::pair<Transform,cv::Point2d>>views;for(auto o:selected)views.push_back({result.cameraPoses.at(o->frame),o->observation.corners[j]});cv::Point3d p;double angle=0;if(triangulate(camera,views,p,angle)){m.triangulatedPoints.push_back(p);m.angle=std::min(m.angle,angle);auto d=p-rigid;triSS+=d.dot(d);}else triOK=false;}
        m.triangulated=triOK&&m.triangulatedPoints.size()==4;if(m.triangulated)m.triangulationRMS=std::sqrt(triSS/4);else m.angle=0;
        if(m.views<6)m.issues.push_back("few_views");if(m.angle<3)m.issues.push_back("insufficient_parallax");if(m.rms>1)m.issues.push_back("high_reprojection_error");if(m.minSpan<40)m.issues.push_back("small_marker_image");if(!m.triangulated)m.issues.push_back("triangulation_failed");m.issues.push_back("missing_mua_calibration");
        m.score=100*std::min(m.views/10.,1.)*std::min(m.angle/10.,1.)*std::exp(-m.rms)*std::min(m.minSpan/60.,1.);if(m.angle<3||!m.triangulated)poor=true;result.markers.push_back(std::move(m));
    }
    if(poor)result.warnings.push_back("Insufficient view diversity: geometry is not reliable.");result.status=poor?"inadequate_geometry":!result.missing.empty()?"incomplete":"research_result";return result;
}
}
