#include "DALVision.hpp"
#include <opencv2/calib3d.hpp>
#include <opencv2/imgproc.hpp>
#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <numeric>
#include <set>
#include <stdexcept>

namespace dal {
namespace {
constexpr double pi = 3.14159265358979323846;
bool finite(double x) { return std::isfinite(x); }
double median(std::vector<double> values) {
    if (values.empty()) return 0;
    std::sort(values.begin(), values.end());
    auto n = values.size();
    return n % 2 ? values[n/2] : (values[n/2-1]+values[n/2])*.5;
}
double blur(const cv::Mat& image) {
    if (image.empty()) return 0;
    cv::Mat lap; cv::Laplacian(image, lap, CV_64F);
    cv::Scalar mean, stddev; cv::meanStdDev(lap, mean, stddev);
    return stddev[0]*stddev[0];
}
cv::Mat grayscale(const cv::Mat& image) {
    if (image.empty() || image.depth() != CV_8U) throw std::invalid_argument("Görüntü boş veya desteklenmeyen biçimde.");
    cv::Mat gray;
    if (image.channels() == 1) gray = image;
    else if (image.channels() == 3) cv::cvtColor(image, gray, cv::COLOR_BGR2GRAY);
    else if (image.channels() == 4) cv::cvtColor(image, gray, cv::COLOR_BGRA2GRAY);
    else throw std::invalid_argument("Görüntü kanal sayısı desteklenmiyor.");
    return gray;
}
template<typename Point> cv::Rect roi(const std::vector<Point>& points, cv::Size size, int margin) {
    double x0 = size.width, y0 = size.height, x1 = 0, y1 = 0;
    for (auto p: points) { x0=std::min(x0,double(p.x));y0=std::min(y0,double(p.y));x1=std::max(x1,double(p.x));y1=std::max(y1,double(p.y)); }
    int left=std::max(0,int(std::floor(x0))-margin), top=std::max(0,int(std::floor(y0))-margin);
    int right=std::min(size.width,int(std::ceil(x1))+margin), bottom=std::min(size.height,int(std::ceil(y1))+margin);
    return cv::Rect(left,top,std::max(0,right-left),std::max(0,bottom-top));
}
struct Circle { cv::Point2d center; std::vector<cv::Point2f> boundary; };
using Group = std::array<Circle, 4>;
std::vector<Group> groups(const cv::Mat& gray) {
    cv::Mat binary; cv::threshold(gray,binary,0,255,cv::THRESH_BINARY_INV|cv::THRESH_OTSU);
    std::vector<std::vector<cv::Point>> contours; std::vector<cv::Vec4i> hierarchy;
    cv::findContours(binary,contours,hierarchy,cv::RETR_TREE,cv::CHAIN_APPROX_NONE);
    std::map<int,std::vector<int>> children;
    for (size_t i=0;i<hierarchy.size();++i) if (hierarchy[i][3]>=0) children[hierarchy[i][3]].push_back(int(i));
    std::vector<Group> result;
    for (const auto& entry:children) {
        std::vector<Circle> circles;
        for (int index:entry.second) {
            const auto& contour=contours[index]; double area=cv::contourArea(contour);
            if (contour.size()<12 || area<12) continue;
            cv::RotatedRect ellipse=cv::fitEllipseAMS(contour);
            double a=ellipse.size.width,b=ellipse.size.height, x=ellipse.center.x,y=ellipse.center.y;
            if (!finite(x)||!finite(y)||!finite(a)||!finite(b)||std::min(a,b)<4||std::min(a,b)/std::max(a,b)<.30) continue;
            if (std::abs(area/(pi*a*b/4)-1)>.25) continue;
            const double ca=std::cos(ellipse.angle*pi/180),sa=std::sin(ellipse.angle*pi/180);
            const double band=std::min(4.,std::max(1.8,std::min(a,b)*.35));
            cv::Mat mx(48,41,CV_32F),my(48,41,CV_32F);
            std::array<cv::Point2d,48> dirs; std::array<double,48> lengths;
            for (int r=0;r<48;++r) {
                double t=2*pi*r/48,xx=a*.5*std::cos(t),yy=b*.5*std::sin(t);
                cv::Point2d d(xx*ca-yy*sa,xx*sa+yy*ca);double len=cv::norm(d);d*=1/len;
                dirs[r]=d;lengths[r]=len;
                for(int j=0;j<41;++j) { double radius=len-band+2*band*j/40;mx.at<float>(r,j)=float(x+d.x*radius);my.at<float>(r,j)=float(y+d.y*radius); }
            }
            cv::Mat vals;cv::remap(gray,vals,mx,my,cv::INTER_LINEAR);
            std::vector<double> contrasts;std::vector<cv::Point2f> boundary;
            for(int r=0;r<48;++r) {
                double lo=255,hi=0;
                for(int j=0;j<41;++j){double value=vals.at<uchar>(r,j);lo=std::min(lo,value);hi=std::max(hi,value);}
                contrasts.push_back(hi-lo);double target=(lo+hi)/2;
                int selected=-1;double closest=std::numeric_limits<double>::infinity();
                for(int j=0;j<40;++j) if(vals.at<uchar>(r,j)>=target&&vals.at<uchar>(r,j+1)<target) {
                    double distance=std::abs(-band+2*band*j/40);
                    if(distance<closest){closest=distance;selected=j;}
                }
                if(selected<0)continue;
                double v0=double(vals.at<uchar>(r,selected))-target,v1=double(vals.at<uchar>(r,selected+1))-target;
                double offset=-band+2*band*selected/40+(2*band/40)*v0/(v0-v1);
                auto p=cv::Point2d(x,y)+dirs[r]*(lengths[r]+offset);boundary.emplace_back(float(p.x),float(p.y));
            }
            if(median(contrasts)<30||boundary.size()<36)continue;
            auto center=cv::fitEllipseAMS(boundary).center;
            circles.push_back({cv::Point2d(center.x,center.y),std::move(boundary)});
        }
        if(circles.size()==4)result.push_back({circles[0],circles[1],circles[2],circles[3]});
        else if(circles.size()>4&&circles.size()<=120) {
            std::set<std::array<int,4>> seen;
            for(int i=0;i<int(circles.size());++i) {
                std::vector<int> neighbors;
                for(int j=0;j<int(circles.size());++j)if(j!=i)neighbors.push_back(j);
                std::sort(neighbors.begin(),neighbors.end(),[&](int a,int b){return cv::norm(circles[a].center-circles[i].center)<cv::norm(circles[b].center-circles[i].center);});
                neighbors.resize(std::min(size_t(5),neighbors.size()));
                for(int a=0;a<int(neighbors.size());++a)for(int b=a+1;b<int(neighbors.size());++b)for(int c=b+1;c<int(neighbors.size());++c) {
                    std::array<int,4> ids={i,neighbors[a],neighbors[b],neighbors[c]};std::sort(ids.begin(),ids.end());if(!seen.insert(ids).second)continue;
                    std::vector<cv::Point2f> centers;std::vector<double> radii;double span=0;
                    for(int id:ids){centers.emplace_back(float(circles[id].center.x),float(circles[id].center.y));std::vector<double> r;for(auto p:circles[id].boundary)r.push_back(cv::norm(cv::Point2d(p.x,p.y)-circles[id].center));radii.push_back(median(r));}
                    std::vector<int> hull;cv::convexHull(centers,hull);if(hull.size()!=3)continue;
                    for(auto p:centers)for(auto q:centers)span=std::max(span,cv::norm(p-q));
                    if(span>17*median(radii)||*std::max_element(radii.begin(),radii.end())>*std::min_element(radii.begin(),radii.end())*1.8)continue;
                    result.push_back({circles[ids[0]],circles[ids[1]],circles[ids[2]],circles[ids[3]]});
                }
            }
        }
    }
    return result;
}
double circleScore(const Camera& camera,const Marker& marker,const Transform& t,const Group& group,const std::array<int,4>& order) {
    cv::Matx33d h(t(0,0),t(0,1),t(0,3),t(1,0),t(1,1),t(1,3),t(2,0),t(2,1),t(2,3));
    if(std::abs(cv::determinant(h))<1e-12)return std::numeric_limits<double>::infinity();
    auto inv=h.inv();double scale=camera.K(0,0)/t(2,3),error=0;int count=0;
    for(int j=0;j<4;++j){std::vector<cv::Point2f> normalized;cv::undistortPoints(group[order[j]].boundary,normalized,camera.K,camera.distortion);
        for(auto n:normalized){auto p=inv*cv::Vec3d(n.x,n.y,1);if(std::abs(p[2])<1e-9)return std::numeric_limits<double>::infinity();double radius=std::hypot(p[0]/p[2]-marker.points[j].x,p[1]/p[2]-marker.points[j].y);double e=(radius-marker.radius)*scale;error+=e*e;++count;}}
    return count?std::sqrt(error/count):std::numeric_limits<double>::infinity();
}
}

std::vector<Marker> makeRig(int count) {
    if(count!=4&&count!=6)throw std::invalid_argument("4 veya 6 bağımsız DAL bayrağı seçin.");
    const std::array<cv::Point3d,3> outer={cv::Point3d(-3,2.4,0),cv::Point3d(3.3,2,0),cv::Point3d(-1.7,-2.8,0)};
    const double weights[6][3]={{.60,.22,.18},{.20,.60,.20},{.20,.20,.60},{.43,.41,.16},{.43,.16,.41},{.16,.42,.42}};
    std::vector<Marker> result;for(int i=0;i<count;++i){cv::Point3d inner;for(int j=0;j<3;++j)inner+=outer[j]*weights[i][j];result.push_back({i,{outer[0],outer[1],outer[2],inner},.55});}return result;
}
void validateCamera(const Camera& c) {
    if(c.width<1||c.height<1||c.width>8192||c.height>8192)throw std::invalid_argument("Kamera boyutu geçersiz.");
    for(double v:c.K.val)if(!finite(v))throw std::invalid_argument("Kamera matrisi sonlu değil.");
    if(c.K(0,0)<=0||c.K(1,1)<=0||std::abs(c.K(2,2)-1)>1e-8||std::abs(c.K(2,0))>1e-8||std::abs(c.K(2,1))>1e-8||std::abs(c.K(0,1))>1e-8||std::abs(c.K(1,0))>1e-8)throw std::invalid_argument("Kamera iç parametreleri geçersiz.");
    if(c.distortion.size()!=4&&c.distortion.size()!=5&&c.distortion.size()!=8&&c.distortion.size()!=12&&c.distortion.size()!=14)throw std::invalid_argument("Distorsiyon katsayı sayısı geçersiz.");
    for(double v:c.distortion)if(!finite(v))throw std::invalid_argument("Distorsiyon sonlu değil.");
}
Transform transform(const cv::Vec3d& r,const cv::Vec3d& t) { cv::Matx33d R;cv::Rodrigues(r,R);auto result=Transform::eye();for(int y=0;y<3;++y){for(int x=0;x<3;++x)result(y,x)=R(y,x);result(y,3)=t[y];}return result; }
Transform inverse(const Transform& a) { auto b=Transform::eye();for(int i=0;i<3;++i){for(int j=0;j<3;++j)b(i,j)=a(j,i);for(int j=0;j<3;++j)b(i,3)-=b(i,j)*a(j,3);}return b; }
cv::Point3d apply(const Transform& t,const cv::Point3d& p) {auto q=t*cv::Vec4d(p.x,p.y,p.z,1);return {q[0],q[1],q[2]};}
std::vector<cv::Point2d> project(const Camera& c,const Transform& t,const std::vector<cv::Point3d>& p) {cv::Matx33d R(t(0,0),t(0,1),t(0,2),t(1,0),t(1,1),t(1,2),t(2,0),t(2,1),t(2,2));cv::Vec3d r;cv::Rodrigues(R,r);std::vector<cv::Point2d> result;cv::projectPoints(p,r,cv::Vec3d(t(0,3),t(1,3),t(2,3)),c.K,c.distortion,result);return result;}
std::vector<PoseCandidate> poseCandidates(const Camera& camera,const Marker& marker,const std::array<cv::Point2d,4>& corners) {
    std::vector<cv::Point3d> objects(marker.points.begin(),marker.points.end());std::vector<cv::Point2d> images(corners.begin(),corners.end());
    std::vector<cv::Mat> rotations,translations;cv::solvePnPGeneric(objects,images,camera.K,camera.distortion,rotations,translations,false,cv::SOLVEPNP_IPPE);
    std::vector<PoseCandidate> result;
    for(size_t i=0;i<rotations.size();++i){cv::Vec3d r,t;for(int j=0;j<3;++j){r[j]=rotations[i].at<double>(j);t[j]=translations[i].at<double>(j);}auto T=transform(r,t);bool ok=true;for(double x:T.val)if(!finite(x))ok=false;for(auto p:objects)if(apply(T,p).z<=0)ok=false;if(!ok)continue;std::vector<cv::Point2d> projected;cv::projectPoints(objects,r,t,camera.K,camera.distortion,projected);double ss=0;for(int j=0;j<4;++j){auto d=projected[j]-corners[j];ss+=d.dot(d);}result.push_back({T,std::sqrt(ss/4)});}
    std::sort(result.begin(),result.end(),[](const auto&a,const auto&b){return a.rms<b.rms;});return result;
}
Detection detect(const cv::Mat& image,const Camera& camera,int markerCount) {
    validateCamera(camera);if(image.cols!=camera.width||image.rows!=camera.height)throw std::invalid_argument("Görüntü ve kalibrasyon çözünürlükleri eşleşmedi.");
    auto gray=grayscale(image);auto rig=makeRig(markerCount);auto candidates=groups(gray);Detection result;result.groups=int(candidates.size());
    struct Match{double score;int id;std::array<int,4> order;Transform T;double rms,shape;};
    int candidateIndex=0;
    for(const auto& group:candidates){std::vector<cv::Point2f> centers;bool clipped=false;double span=0;
        CandidateDiagnostic diagnostic;diagnostic.index=candidateIndex++;
        const auto record=[&](const char* reason,bool accepted=false){diagnostic.reason=reason;diagnostic.accepted=accepted;if(result.candidates.size()<72)result.candidates.push_back(diagnostic);};
        for(const auto& circle:group){auto p=circle.center;centers.emplace_back(float(p.x),float(p.y));diagnostic.centers.push_back(p);if(p.x<4||p.y<4||p.x>camera.width-5||p.y>camera.height-5)clipped=true;}
        for(auto p:centers)for(auto q:centers)span=std::max(span,cv::norm(p-q));diagnostic.span=span;
        if(clipped){result.rejected.push_back("Bayrağın noktaları görüntü kenarında kesiliyor.");record("clipped");continue;}std::vector<int> hull;cv::convexHull(centers,hull);if(hull.size()!=3){result.rejected.push_back("Dört nokta düzeni geçersiz.");record("invalid_layout");continue;}
        int inner=0;while(std::find(hull.begin(),hull.end(),inner)!=hull.end())++inner;
        if(span<35){result.rejected.push_back("Bayrak görüntüsü küçük: 35 pikselden az.");record("too_small");continue;}
        std::sort(hull.begin(),hull.end());std::vector<Match> matches;
        for(const auto& marker:rig){auto perm=hull;do{std::array<int,4> order={perm[0],perm[1],perm[2],inner};std::array<cv::Point2d,4> points;for(int j=0;j<4;++j)points[j]=group[order[j]].center;
                try{for(const auto& pose:poseCandidates(camera,marker,points)){const auto&T=pose.transform;double norm=std::sqrt(T(0,3)*T(0,3)+T(1,3)*T(1,3)+T(2,3)*T(2,3));double facing=-(T(0,2)*T(0,3)+T(1,2)*T(1,3)+T(2,2)*T(2,3))/norm;if(facing<.40||pose.rms>1)continue;double shape=circleScore(camera,marker,T,group,order);matches.push_back({pose.rms+.8*shape,marker.id,order,T,pose.rms,shape});}}catch(const cv::Exception&){}
            }while(std::next_permutation(perm.begin(),perm.end()));}
        std::sort(matches.begin(),matches.end(),[](const Match&a,const Match&b){return a.score<b.score;});if(matches.empty()){result.rejected.push_back("Önden görülen geçerli bayrak bulunamadı.");record("no_valid_geometry");continue;}
        const auto& best=matches.front();auto alternate=std::find_if(matches.begin()+1,matches.end(),[&](const Match&m){return m.id!=best.id||m.order!=best.order;});double ratio=alternate==matches.end()?0:best.score/std::max(alternate->score,1e-9),gap=alternate==matches.end()?1e6:alternate->score-best.score;
        diagnostic.bestID=best.id;diagnostic.score=best.score;diagnostic.ratio=ratio;diagnostic.gap=gap;
        result.matches.push_back({best.id,best.score,ratio,gap});if(best.score>.85||best.rms>.65||ratio>.60||gap<.20){result.rejected.push_back("Bayrak kimliği belirsiz veya uyum zayıf; aday "+std::to_string(best.id)+" henüz tanınmadı.");record("ambiguous_identity");continue;}
        const auto& marker=rig[best.id];std::array<cv::Point2d,4> points;for(int j=0;j<4;++j){points[j]=group[best.order[j]].center;std::vector<cv::Point3d> circle;for(int k=0;k<96;++k){double t=2*pi*k/96;circle.push_back(marker.points[j]+cv::Point3d(std::cos(t)*marker.radius,std::sin(t)*marker.radius,0));}auto outline=project(camera,best.T,circle);std::vector<cv::Point2f> outlineF;for(auto p:outline)outlineF.emplace_back(float(p.x),float(p.y));auto ellipse=cv::fitEllipseAMS(outlineF);auto p=project(camera,best.T,{marker.points[j]})[0];points[j]+=p-cv::Point2d(ellipse.center.x,ellipse.center.y);}
        auto poses=poseCandidates(camera,marker,points);if(poses.empty()){record("no_valid_geometry");continue;}double poseRatio=poses.size()>1?poses[0].rms/std::max(poses[1].rms,1e-9):0;result.observations.push_back({best.id,points,span,poseRatio});record("accepted",true);
    }
    std::map<int,int> counts;for(const auto&o:result.observations)++counts[o.marker];for(const auto&count:counts)if(count.second>1)result.rejected.push_back("Yinelenen bayrak kimliği: "+std::to_string(count.first));
    for(auto& diagnostic:result.candidates)if(diagnostic.accepted&&counts[diagnostic.bestID]>1){diagnostic.accepted=false;diagnostic.reason="duplicate_identity";}
    result.observations.erase(std::remove_if(result.observations.begin(),result.observations.end(),[&](const Observation&o){return counts[o.marker]!=1;}),result.observations.end());
    if(candidates.empty())result.rejected.push_back("Dört beyaz noktalı bayrak adayı bulunamadı; noktaların tamamı, netlik ve yansımayı kontrol edin.");
    std::vector<double> sharpness;for(auto&o:result.observations){std::vector<cv::Point2d> p(o.corners.begin(),o.corners.end());o.blurLaplacian=blur(gray(roi(p,gray.size(),10)));sharpness.push_back(o.blurLaplacian);}result.blur=median(sharpness);result.frameBlur=blur(gray);return result;
}
BoardShot checkBoard(const cv::Mat& image,const std::vector<std::vector<cv::Point2f>>& previous) {
    auto gray=grayscale(image);BoardShot result;
    if(!cv::findChessboardCornersSB(gray,cv::Size(9,6),result.corners,cv::CALIB_CB_NORMALIZE_IMAGE)){result.message="Dama tahtasının 54 iç köşesi görünmüyor. Tahtanın tamamını gösterin.";result.corners.clear();return result;}
    result.detectedCorners=result.corners;
    result.blur=blur(gray(roi(result.corners,gray.size(),8)));
    if(result.blur<35){result.reason="blur";result.message="Dama tahtası bulanık. Odağı ve ışığı kontrol edin.";result.corners.clear();return result;}
    // A checkerboard can reverse its decoded origin without camera movement.
    // Compare both valid 180-degree corner orders before counting a new view.
    for(const auto& old:previous)if(old.size()==result.corners.size()){double e=0,reversed=0;for(size_t i=0;i<old.size();++i){auto d=old[i]-result.corners[i];auto r=old[old.size()-1-i]-result.corners[i];e+=d.dot(d);reversed+=r.dot(r);}if(std::sqrt(std::min(e,reversed)/old.size())<8){result.reason="duplicate";result.message="Bu tahta görünümü kaydedildi. Eğimi veya kadrajdaki yerini değiştirin.";result.corners.clear();return result;}}
    result.accepted=true;result.reason="accepted";result.message="Dama tahtası bulundu; keskin ve yeni görünüm.";return result;
}
Calibration calibrate(const std::vector<std::vector<cv::Point2f>>& corners,int width,int height,double squareMM) {
    if(corners.size()<10||corners.size()>120||width<1||height<1||width>8192||height>8192||!finite(squareMM)||squareMM<=0||squareMM>100)throw std::invalid_argument("Kalibrasyon için en az 10 farklı görünüm ve geçerli tahta ölçüsü gerekli.");
    for(const auto& view:corners){if(view.size()!=54)throw std::invalid_argument("Her kalibrasyon karesinde 54 iç köşe gerekli.");for(auto p:view)if(!finite(p.x)||!finite(p.y)||p.x<0||p.y<0||p.x>=width||p.y>=height)throw std::invalid_argument("Kalibrasyon köşeleri görüntü dışında veya geçersiz.");}
    std::vector<cv::Point3f> obj;for(int y=0;y<6;++y)for(int x=0;x<9;++x)obj.emplace_back(float(x*squareMM),float(y*squareMM),0);
    Calibration result;result.kept.resize(corners.size());std::iota(result.kept.begin(),result.kept.end(),0);cv::Mat K,dist,stdI,stdE,perView;std::vector<cv::Mat> rotations,translations;
    for(int attempt=0;attempt<3;++attempt){std::vector<std::vector<cv::Point3f>> objects(result.kept.size(),obj);std::vector<std::vector<cv::Point2f>> images;for(int i:result.kept)images.push_back(corners[i]);
        result.rms=cv::calibrateCamera(objects,images,cv::Size(width,height),K,dist,rotations,translations,stdI,stdE,perView,0,cv::TermCriteria(cv::TermCriteria::COUNT|cv::TermCriteria::EPS,100,1e-10));
        result.perView.clear();for(int i=0;i<int(perView.total());++i)result.perView.push_back(perView.at<double>(i));double med=median(result.perView);std::vector<double> deviations;for(double v:result.perView)deviations.push_back(std::abs(v-med));double cutoff=std::max(.5,med+3*1.4826*median(deviations));std::vector<int> bad,keep;for(size_t j=0;j<result.kept.size();++j)(result.perView[j]>cutoff?bad:keep).push_back(result.kept[j]);
        if(bad.empty()||attempt==2)break;if(keep.size()<10||result.rejected.size()+bad.size()>corners.size()*.20)throw std::invalid_argument("Çok fazla tutarsız kalibrasyon görüntüsü. Net ve farklı açılardan yeniden çekin.");result.kept=std::move(keep);result.rejected.insert(result.rejected.end(),bad.begin(),bad.end());
    }
    for(int y=0;y<3;++y)for(int x=0;x<3;++x)result.camera.K(y,x)=K.at<double>(y,x);result.camera.distortion.clear();for(int i=0;i<int(dist.total());++i)result.camera.distortion.push_back(dist.at<double>(i));result.camera.width=width;result.camera.height=height;validateCamera(result.camera);
    for(int i=0;i<int(stdI.total());++i)result.intrinsicStd.push_back(stdI.at<double>(i));
    std::vector<cv::Vec3d> normals;for(const auto&r:rotations){cv::Matx33d R;cv::Rodrigues(r,R);normals.emplace_back(R(0,2),R(1,2),R(2,2));}
    for(auto a:normals)for(auto b:normals)result.tiltSpread=std::max(result.tiltSpread,std::acos(std::clamp(a.dot(b),-1.,1.))*180/pi);
    double minX=1,minY=1,maxX=0,maxY=0;for(int i:result.kept){cv::Point2d centroid;for(auto p:corners[i])centroid+=cv::Point2d(p.x,p.y);centroid*=1./54;double x=centroid.x/width,y=centroid.y/height;minX=std::min(minX,x);maxX=std::max(maxX,x);minY=std::min(minY,y);maxY=std::max(maxY,y);}
    if(result.tiltSpread<8.6)result.warnings.push_back("Tahta eğim çeşitliliği yetersiz.");if(std::max(maxX-minX,maxY-minY)<.15)result.warnings.push_back("Tahtayı görüntünün farklı bölgelerinde gösterin.");if(result.rms>.6)result.warnings.push_back("Kalibrasyon görüntü uyum hatası yüksek.");
    if(!finite(result.rms))throw std::invalid_argument("Kalibrasyon sonlu bir sonuç üretmedi.");return result;
}
}
