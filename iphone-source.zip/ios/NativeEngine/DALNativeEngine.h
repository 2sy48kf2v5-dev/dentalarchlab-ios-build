#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
// All work is synchronous CPU work. Call from a dedicated serial worker, not UI.
// Images must be sensor-oriented JPEG/PNG, matching the supplied camera size.
@interface DALNativeEngine : NSObject
+ (nullable NSDictionary<NSString *, id> *)validateSyntheticWithError:(NSError **)error
    NS_SWIFT_NAME(validateSynthetic());
+ (nullable NSDictionary<NSString *, id> *)detectImage:(NSData *)image
    camera:(nullable NSDictionary<NSString *, id> *)camera markerCount:(NSInteger)count
    error:(NSError **)error NS_SWIFT_NAME(detect(image:camera:markerCount:));
+ (nullable NSDictionary<NSString *, id> *)checkBoardImage:(NSData *)image
    previousCorners:(NSArray *)previous error:(NSError **)error
    NS_SWIFT_NAME(checkBoard(image:previousCorners:));
+ (nullable NSDictionary<NSString *, id> *)calibrateCorners:(NSArray *)corners
    width:(NSInteger)width height:(NSInteger)height squareMM:(double)squareMM
    physicalMeasured:(BOOL)physicalMeasured profile:(NSDictionary<NSString *, id> *)profile
    error:(NSError **)error
    NS_SWIFT_NAME(calibrate(corners:width:height:squareMM:physicalMeasured:profile:));
+ (nullable NSDictionary<NSString *, id> *)reconstructObservations:(NSArray<NSDictionary<NSString *, id> *> *)observations
    camera:(NSDictionary<NSString *, id> *)camera markerCount:(NSInteger)count
    error:(NSError **)error NS_SWIFT_NAME(reconstruct(observations:camera:markerCount:));
@end
NS_ASSUME_NONNULL_END
