#pragma once
#include "DALNativeTypes.hpp"
#include <map>
namespace dal {
struct FrameObservation { std::string frame; Observation observation; };
struct BundleReport { double initialRMS=0, finalRMS=0, cost=0; int iterations=0; bool converged=false; };
struct ReconstructedMarker {
    int id, views;
    Transform pose;
    double rms=0, minSpan=0, angle=0, triangulationRMS=0, score=0;
    bool triangulated=false;
    int ambiguousViews=0;
    std::vector<std::string> issues;
    std::vector<cv::Point3d> rigidPoints, triangulatedPoints;
};
struct Reconstruction {
    int anchor=0, observationsUsed=0;
    std::map<int,Transform> markerPoses;
    std::map<std::string,Transform> cameraPoses;
    std::vector<ReconstructedMarker> markers;
    std::vector<int> missing;
    std::vector<std::string> warnings;
    std::string status;
    BundleReport bundle;
    double rms=0;
};
Reconstruction reconstruct(const Camera& camera,int markerCount,const std::vector<FrameObservation>& observations);
}
