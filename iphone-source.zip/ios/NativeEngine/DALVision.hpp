#pragma once
#include "DALNativeTypes.hpp"

namespace dal {
struct IdentityMatch { int id; double score, ratio, gap; };
// Candidate identities are hypotheses until accepted; these records let the
// caller explain rejection without treating a best-fit ID as a recognized ID.
struct CandidateDiagnostic {
    int index = 0, bestID = -1;
    std::vector<cv::Point2d> centers;
    double span = 0, score = -1, ratio = -1, gap = -1;
    std::string reason;
    bool accepted = false;
};
struct Detection {
    std::vector<Observation> observations;
    std::vector<std::string> rejected;
    std::vector<IdentityMatch> matches;
    std::vector<CandidateDiagnostic> candidates;
    int groups = 0;
    int proposalPasses = 0, proposalContours = 0, refinedCircles = 0;
    int globalGroups = 0, localGroups = 0, duplicateGroups = 0;
    bool proposalBudgetExceeded = false;
    std::string proposalBudgetReason;
    double blur = 0, frameBlur = 0;
};
Detection detect(const cv::Mat& image, const Camera& camera, int markerCount);
struct BoardShot {
    bool accepted = false;
    std::string message;
    std::string reason = "not_found";
    std::vector<cv::Point2f> corners;
    std::vector<cv::Point2f> detectedCorners;
    double blur = 0;
};
BoardShot checkBoard(const cv::Mat& image,
                    const std::vector<std::vector<cv::Point2f>>& previous = {});
struct Calibration {
    Camera camera;
    double rms = 0, tiltSpread = 0;
    std::vector<double> perView, intrinsicStd;
    std::vector<int> kept, rejected;
    std::vector<std::string> warnings;
};
Calibration calibrate(const std::vector<std::vector<cv::Point2f>>& corners,
                      int width, int height, double squareMM);
}
