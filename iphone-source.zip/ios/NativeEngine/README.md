# Native engine

This independent C++/Objective-C++ engine runs in the iPhone process. It contains
no network client, Python runtime, PIC/iMetric source, commercial marker geometry,
or proprietary calibration tables.

`DALNativeEngine.h` is the Foundation bridge. All methods are synchronous CPU
operations; call on one serial worker away from the main actor. Exceptions are
translated into NSError and imported as Swift `throws`.

## Input and output contracts

- `detect(image:camera:markerCount:)`: sensor-oriented JPEG/PNG bytes; a camera
  dictionary or nil for explicitly nonmetric preview; 4 or 6 original DAL dots.
  Returns observations (`marker`, four pixel `corners`, `min_side_px`,
  `ambiguity_ratio`, per-marker ROI `blur_laplacian`) and quality diagnostics. It does not accept/reject the whole
  scan or count persistent views; the Swift acquisition gate does this.
- `checkBoard(image:previousCorners:)`: 9 x 6 internal corners; returns accepted,
  message, corners or null, and Laplacian sharpness. Repeated views are rejected.
- `calibrate(corners:width:height:squareMM:physicalMeasured:profile:)`: at least ten
  diverse accepted views. Camera schema matches the Python engine: schema_version
  1, model opencv_pinhole, K, distortion, image_size, metadata. A screen remains
  screen_experimental and has no physical square size. Declaring a measured board
  still requires a controlled camera profile. Pixel RMS is not micrometre error.
- `reconstruct(observations:camera:markerCount:)`: every observation adds `frame`
  to the detector fields. Returns marker poses, calibrated camera poses, rigid
  landmarks, DLT cross-checks, residuals and geometry warnings. The minimum marker
  ID fixes the world-coordinate gauge. Disconnected visibility graphs fail.
- `validateSynthetic()`: generates and processes real synthetic pixels and known
  3D geometry. Reports measured detection IDs, camera calibration residuals, and
  non-anchor position/axis errors for four and six flags. No production image is
  replaced with a fixture. The report always says synthetic_only and exposes no
  physical accuracy value.

## Implementation and limits

`DALVision.cpp` ports the project's original DAL_DOTS4_V1 detector: dark-component
grouping, 48-ray half-intensity circle contours, subpixel ellipse fitting, IPPE
pose candidates, circle-shape correspondence scoring, duplicate/ambiguous-ID
rejection, and perspective ellipse-centre correction. The independent printed
N48 D4 flag geometry has the same four optical centres as the Python rig.

`quality.candidate_diagnostics` contains at most 72 candidate records. Each has
`candidate_index`, four `centers_px`, `span_px`, `reason`, `accepted`, and nullable
`best_id`, `best_score_px`, `identity_ratio`, `identity_gap_px`. A candidate's
`best_id` is only a hypothesis: clients must never count it as a recognized ID.
Only returned observations passed all recognition checks. Reasons are `clipped`,
`invalid_layout`, `too_small`, `no_valid_geometry`, `ambiguous_identity`,
`duplicate_identity`, and `accepted`. Duplicate records explicitly set
`accepted=false`, matching removal of all duplicate observations.
`diagnostics_truncated` identifies frames containing more than 72 groups.

`quality.detector_mode` is `calibrated_pose_3d` with supplied intrinsics and
`assumed_camera_pose_2d` when the nonmetric identity test uses approximate
intrinsics. No projective fallback or lower identity threshold was introduced
in the ID-4 audit: without a failing captured iPhone image its cause is unresolved.
The Swift trial gate can assess the new ID's ROI sharpness independently of
already accepted IDs, while retaining the existing quality thresholds.

`NativeScreenIdentityTests.swift` exercises the exact displayed mouth render,
an oblique screen/JPEG simulation, an occluded ID-4 dot, duplicate ID-4 images,
and an empty frame. `Fixtures/mouth_front.dat` and `mouth_oblique.dat` retain
their reviewed PNG/JPEG bytes in the test bundle. For public source distribution,
PNG text metadata was removed from `mouth_front.dat` and `vertical_arch.dat`
without changing any IDAT bytes, decoded pixels, or other PNG chunks. Their
fixture SHA-256 assertions identify these sanitized files. These tests need Apple execution;
Python fixture checks do not establish native/device success.

`DALReconstruction.cpp` initializes overlapping camera/marker poses and uses an
original bounded robust Schur Levenberg-Marquardt optimizer. It eliminates each
six-variable camera block, leaving at most 30 free marker variables. Brown-Conrady
projection and per-coordinate soft-L1 weights are used. The maximum is 50
iterations and 120 frames. This is a native implementation, not SciPy running in
an iOS app. Its convergence and errors must be checked against ground truth.
Unlike the Python implementation, this version does not remove whole outlier
observations and rerun optimization; robust weighting limits their influence.

MUA transforms are deliberately null until measured marker-to-MUA calibration is
supplied. An optical flag origin is not an implant/MUA centre. A geometry score is
not a probability and does not certify clinical accuracy. Printed geometry is
nominal until measured. Native and Python parity still require captured-device
fixtures and physical reference-device validation, not only synthetic tests.

## Build and third-party code

The app links the official OpenCV 4.12.0 iOS static framework. Required modules:
core, imgproc, calib3d, imgcodecs. The release archive SHA-256 is
`86b42c9f141cd9169b91be2fc380b0e556a88a95c98ccc8e7aef8349ab74cf70`.

- [Official release assets](https://github.com/opencv/opencv/releases/expanded_assets/4.12.0)
- [Official iOS archive](https://github.com/opencv/opencv/releases/download/4.12.0/opencv-4.12.0-ios-framework.zip)
- [OpenCV license](https://opencv.org/license/): OpenCV >= 4.5 is Apache-2.0;
  retain its license and applicable bundled third-party notices in distribution.
- [Official Apple XCFramework builder](https://github.com/opencv/opencv/blob/4.x/platforms/apple/build_xcframework.py)

The official 4.12.0 archive is a legacy fat framework. Its arm64 slice targets a
physical iOS device; its x86_64 slice targets the simulator. Build simulator tests
on an Intel Apple runner, or build an arm64 simulator XCFramework from official
source. Do not claim a device slice is a simulator slice. Do not embed the static
framework as a dynamic application Frameworks dependency.

`../DentalArchCaptureTests/NativeEngineTests.swift` belongs to the test target.
It exercises real algorithms and rejects malformed inputs and repeated
board views. Apple compilation/test results are the authority for build status.
