# Fiziksel bayraklar ve yeni vaka akışı · 0.14.0 (22)

Başlangıç ekranında isteğe bağlı model/vaka referansı, alt/üst çene ve 4/6 bayrak seçilir. “Takılı bayraklar ve FDI” ekranında dört fiziksel ID, DAL 0–5 ailesinden tekrar olmadan seçilir. Örneğin 0, 3, 4, 5; dört sayısı artık 0, 1, 2, 3 zorunluluğu değildir. Her fiziksel ID doğru FDI konumuna bağlanır. Altı bayrakta ailedeki tüm ID'ler kullanılır. Vaka referansı yerel kayda eklenir.

“3B taramaya hazırlan” uygun fiziksel ultra geniş lens kalibrasyonunu seçer. Yoksa yeni kalibrasyona yönlendirir. Deney ayarlarındaki 3B seçimi de aynı yolu izler; yakın çekim talebi açıkken eski geniş lens kalibrasyonuna sessiz dönüş olmaz. Kayıtlı eski çalışmalar kendi özgün lens profilleriyle açılabilir; bu kayıtlardan Yeni kayıt hazırla ile çıkıldığında yeni XYZ çalışması yakın çekim kurulumuna döner. Lens, sabit odak ve ölçüm çözünürlüğü kalibrasyonla eşleşmeden XYZ kabul edilmez.

Kamera alanı baskındır. İnce çene çizgisi yalnız kadraj yardımıdır; ölçülen konum veya AR takibi değildir. Kabul edilen görüntüdeki gerçek noktalar ve seçilmiş ID'lere ait ilerleme halkaları korunur. Kamera kapalıysa canlı görüntü varmış gibi gösterilmez. Ses/ışık kontrolleri tarama ekranındadır.

## Tanıma ve ölçüm farklı kontrollerdir

Algılayıcı altı kimliği birlikte karşılaştırır; sonra seçili fiziksel ID'leri kabul eder. Seçim dışında gördüğü ID'leri kullanıcıya bildirir; başka bir bayrağın numarasını bu ID'ye vermez. Belirsizlik, yinelenen ID ve geometri eşikleri gevşetilmedi. Dört beyaz noktanın sensör görüntüsündeki açıklığı 45 pikselden küçükse ölçüm karesi kabul edilmez; uygun yakınlaşma yönlendirmesi gösterilir. 2B kimlik tanıma 3B sonuç değildir; XYZ için en az iki bayrağın ortak göründüğü, farklı açılı kalibre görüntüler gerekir.

Eski kayıtlar marker_ids alanı yoksa eski 0..<adet anlamını korur. Yeni kayıtlarda marker_ids, expected_marker_ids ve FDI ataması aynı gerçek kimlikleri kullanır. 3B referans koordinat sistemi gözlenen en küçük gerçek ID'ye bağlanır. 0 numarası seçili değilse sahte bir 0 üretilmez. Her oturumun koordinat sistemi yereldir; ayrı taramalar karşılaştırılırken rijit hizalama gerekir.

Tanıma raporu özgün görüntü ve eşleşen analizle beraber gerçek ID seçimini, kullanılan kamera kalibrasyonunu ve kalibrasyon kimliğini saklar. Ekran videosu yalnız giriş/yerleşim referansı olarak incelendi; başka uygulamanın logosu, görselleri, kaynakları veya ölçüm verisi kullanılmadı.

## Cihazda kontrol

1. Uygulamayı silmeden 0.14.0 yapı 22 ile güncelle.
2. Yeni kayıtta fiziksel ID'leri ve FDI'leri eşleştir. ID bilinmiyorsa önce 6 bayrak seçili 2B deneyde tek tek göstererek görülen numarayı kaydet; bu deneyi XYZ sonucu sayma.
3. Yakın çekim için basılı düz tahta ile fiziksel ultra geniş lens kalibrasyonu yap. Kare kenarını mm olarak gir. Tahta ile bayrakları benzer çalışma uzaklığında tut; kalibre odak ölçüm boyunca sabittir.
4. Modeli sabit tut, kamera ile farklı yönlere küçük hareketler yap. Noktalar kapanmamalı; aynı anda en az iki bayrak net görünmeli. Yeşil veri kabulü fiziksel mikron doğruluğu değildir.
5. İlerlemeyen durumda Tanıma raporunu kaydet. Yeni rapor kullanılan kalibrasyonu da içerir. Fiziksel doğruluk için bağımsız ölçülmüş referans geometri ve marker–MUA dönüşümü gerekir.

Sentetik ve simülatör testleri gerçek iPhone lens netliğini, basılı parça ölçülerini veya klinik uygunluğu kanıtlamaz. Uygulama içi hata eşikleri fiziksel doğrulukla karıştırılmaz.
