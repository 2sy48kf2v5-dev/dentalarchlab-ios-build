# 0.8 — tarama hızı ve bayrak geri bildirimi

Telefon 1920×1080 sensör karesi üretmeye devam eder. Tanıma Windows motorunda
yapılır; telefon ve bilgisayar aynı yerel ağda olmalıdır. Dik N48 D4 ve yatay D4
bayrakları aynı DAL_DOTS4_V1 optik kimliklerini kullanır. Dört beyaz nokta da
görünmelidir. MUA dönüşümü ölçülmeden fiziksel merkez doğruluğu verilemez.

## Değişiklikler

- Tanıma motorunda aynı IPPE pozunun gereksiz dönüşümü kaldırıldı ve nokta kenarı
  interpolasyonu vektörleştirildi. Kimlik/poz/kalite eşikleri değiştirilmedi.
- Kabul edilen önizleme için aynı fotoğraf ikinci kez yüklenmez. Telefon özgün
  görüntüyü önce diske kaydeder, sonra kimlik + SHA256 + profil + zaman ile
  `/commit-preview` çağrısı yapar. Sunucu kendi analiz ettiği pikselleri kullanır.
- Sunucu tek görüntülük, 8 saniye geçerli önbellek tutar. Görüntü değişmişse,
  süre dolmuşsa veya eski motor kullanılıyorsa özgün görüntü `/frames` yolundan
  gönderilir. Ağ hatasında kuyruk korunur; aynı kimlikle tekrar sayım yapılmaz.
- Kayıt açma isteği her karede tekrarlanmaz; yeniden bağlantıda önbelleği temizlenir.
- İşlemden sonraki sabit 350 ms bekleme kaldırıldı. Toplam örnek periyodu en az
  350 ms; işlem uzarsa bittikten sonra 50 ms ara vardır. Tek örnek aynı anda işlenir.
- Analiz edilen kare gösterimi 700 ms'den 220 ms'ye indirildi. İşaretler yalnızca
  analiz edilen kare üzerinde gösterilir; yeni canlı pikseller üzerinde takip iddiası yoktur.
- Son karede bulunan/eksik FDI veya ID, motor tanıma süresi ve yanıt süresi görünür.
  Yeşil/ses yalnızca uygun karenin kalıcı kayıt onayından sonra oluşur.

`Tanıma` bilgisayardaki algılayıcı süresidir. `Yanıt` kamera örneği, aktarım ve
önizleme yanıtını kapsar. `Örnek döngüsü` kayda alma dahil, sonraki beklemeden
önceki süredir. Bunlar mikron doğruluğu veya kameranın video FPS değeri değildir.

## iPhone 16 Pro Max model deneyi

1. Uygulamayı silmeden 0.8.0 IPA'yı önceki Apple hesabıyla AltStore'dan güncelle.
2. Güncel Windows motorunu aç ve tekrar bağlan. `Hızlı aktarım` yazısı ilk analizden
   sonra görünür; görünmüyorsa telefon eski motora bağlı olabilir.
3. Yeni kayıt → Bayrak deneyi (2B) → 6 bayrak → FDI planını fiziksel ID'lere göre seç.
4. Dik bayrakların optik yüzünü kameraya çevir. Mat siyah zemindeki dört beyaz nokta
   net görünmeli; düz siyah, doldurulmamış baskı tanınacak tamamlanmış hedef değildir.
5. Kamerayı aç → Taramayı başlat. Küçük açı değişiklikleri yapıp kısa süre sabit tut.
   `Son kare: 6/6` ve her yeni uygun karede bir ses beklenir. Aynı görüntü tekrarları
   uygun kare sayısını artırmamalı.
6. Bir bayrağın tek noktasını ört: o ID kaybolmalı; diğer görünen bayraklar kalabilir.
   Sonra noktayı aç, farklı açıdan göster. Yanlış ID veya tüm bayraklara sahte yeşil olmamalı.
7. Duraklat/aç-kapat çalışmalı. Bağlantı kesilirse kaydedilmiş bekleyen kareler
   tekrar bağlanınca gönderilmeli. Uygun kare sayısı çift artmamalı.
8. Son karede bulunan ID'leri, tanıma/yanıt sürelerini ve eksik bayrakları kaydet.

Bilgisayar sentetik görüntü testleri ile Apple simülatör testleri fiziksel iPhone
çekimini doğrulamaz. Baskı, ışık, odak, görüş açısı ve marker-to-MUA kalibrasyonu
ayrı model deneyi gerektirir; fiziksel mikron ve klinik doğruluk henüz ölçülmedi.
