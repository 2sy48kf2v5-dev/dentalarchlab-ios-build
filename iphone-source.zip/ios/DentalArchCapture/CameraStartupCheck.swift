import AVFoundation
import Foundation

enum CameraFocusRequest: Equatable {
    case automatic
    case locked(Float)
}

protocol CameraControlling: AnyObject {
    var session: AVCaptureSession { get }
    var onInterruption: ((String) -> Void)? { get set }
    var onIlluminationChanged: ((TorchStatus) -> Void)? { get set }
    var onPerformanceChanged: ((CameraPerformance) -> Void)? { get set }
    var onOpticsChanged: ((CameraOpticsStatus) -> Void)? { get set }
    func configureOptics(_ request: CameraOpticsRequest)
    func configureIllumination(enabled: Bool)
    /// Continuous focusing while the user aims. This never authorizes a measurement frame.
    func startPreview(completion: @escaping (Result<Void, Error>) -> Void)
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void)
    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void)
    func captureFrame(compactTrial: Bool, completion: @escaping (Result<CapturedCameraFrame, Error>) -> Void)
    func stop()
}

extension CameraControlling {
    func startPreview(completion: @escaping (Result<Void, Error>) -> Void) {
        completion(.failure(LabError.message("Bu kamera önizleme sırasında otomatik odak takibini desteklemiyor.")))
    }
    func captureFrame(compactTrial: Bool, completion: @escaping (Result<CapturedCameraFrame, Error>) -> Void) {
        capture(compactTrial: compactTrial) { result in
            completion(result.map { CapturedCameraFrame(image: $0.0, profile: $0.1, timestamp: $0.2, intrinsics: nil) })
        }
    }
    // Older camera fixtures have no torch hardware and remain harmless.
    var onIlluminationChanged: ((TorchStatus) -> Void)? {
        get { nil }
        set { newValue?(.unavailable) }
    }
    func configureIllumination(enabled: Bool) {}
    func configureOptics(_ request: CameraOpticsRequest) {}
    var onOpticsChanged: ((CameraOpticsStatus) -> Void)? {
        get { nil }
        set {}
    }
    var onPerformanceChanged: ((CameraPerformance) -> Void)? {
        get { nil }
        set {}
    }
}

/// Preview readiness only means fresh sensor frames arrived. Autofocus is allowed
/// to keep moving; this gate is deliberately separate from measurement readiness.
struct CameraPreviewCheck {
    private var lastTimestamp: Double?
    private var consecutiveFrames = 0
    private(set) var lastIssue: CameraStartupIssue = .noFrames

    mutating func observe(running: Bool, interrupted: Bool, continuousFocus: Bool,
                          width: Int, height: Int, timestamp: Double) -> Bool {
        let fresh = timestamp.isFinite && timestamp >= 0 && (lastTimestamp.map { timestamp > $0 } ?? true)
        if fresh { lastTimestamp = timestamp }
        let issue: CameraStartupIssue?
        if !running { issue = .sessionStopped }
        else if interrupted { issue = .sessionInterrupted }
        else if width != 1920 || height != 1080 { issue = .resolution }
        else if !continuousFocus { issue = .focusMoving }
        else if !fresh { issue = .invalidTimestamp }
        else { issue = nil }
        if let issue { lastIssue = issue; consecutiveFrames = 0; return false }
        consecutiveFrames += 1
        lastIssue = consecutiveFrames >= 3 ? .ready : .collecting
        return consecutiveFrames >= 3
    }
}

struct CameraStartupFailure: LocalizedError {
    let message: String
    let details: String
    var errorDescription: String? { message }
}

enum CameraStartupIssue: String {
    case noFrames = "KAM-01", resolution = "KAM-02", focusUnlocked = "KAM-03"
    case focusMoving = "KAM-04", lensPosition = "KAM-05", invalidTimestamp = "KAM-06"
    case settling = "KAM-07", sessionStopped = "KAM-08", sessionInterrupted = "KAM-09"
    case collecting = "KAM-10", ready = "OK"

    var explanation: String {
        switch self {
        case .noFrames: return "Canlı önizleme olsa bile kayıt için kamera karesi gelmedi."
        case .resolution: return "Kayıt karesinin boyutu 1920 × 1080 ile eşleşmiyor."
        case .focusUnlocked: return "Kamera odak kilidini uygulamadı."
        case .focusMoving: return "Kamera odak ayarını tamamlamadı."
        case .lensPosition: return "Kameranın odak konumu seçilen değerle eşleşmiyor."
        case .invalidTimestamp: return "Kameradan yeni zaman damgalı kare gelmedi."
        case .settling: return "Kamera ayarlarının hazırlanması tamamlanmadı."
        case .sessionStopped: return "Kamera oturumu çalışmıyor."
        case .sessionInterrupted: return "iOS kamera oturumunu kesintiye uğrattı."
        case .collecting: return "Üç ardışık uygun kamera karesi alınamadı."
        case .ready: return "Kamera hazır."
        }
    }
}

// This is a readback tolerance, not an optical accuracy or distance guarantee.
// The same bound applies when opening and when exporting a captured frame.
enum CameraFocusGuard {
    static let tolerance: Float = 0.002
    static func issue(expectedLens: Float, focusLocked: Bool, adjustingFocus: Bool,
                      lensPosition: Float) -> CameraStartupIssue? {
        if !focusLocked { return .focusUnlocked }
        if adjustingFocus { return .focusMoving }
        if !expectedLens.isFinite || !(0...1).contains(expectedLens)
            || !lensPosition.isFinite || !(0...1).contains(lensPosition)
            || abs(lensPosition - expectedLens) > tolerance { return .lensPosition }
        return nil
    }
}

// One-shot autofocus returns to .locked. Observe that state and stable fresh
// sensor frames; never require an adjusting transition or optional callback,
// because an already-focused camera may complete before the first frame.
struct CameraFocusAcquisition {
    let earliestFrameTime: Double
    let deadline: Double
    private var lastTimestamp: Double?
    private var stableMinimum: Float?
    private var stableMaximum: Float?
    private var consecutiveFrames = 0
    private var cancelled = false
    private(set) var timedOut = false
    private(set) var lastIssue: CameraStartupIssue = .noFrames

    init(earliestFrameTime: Double, deadline: Double) {
        self.earliestFrameTime = earliestFrameTime
        self.deadline = deadline
    }

    mutating func cancel() { cancelled = true; consecutiveFrames = 0 }

    mutating func observe(now: Double, running: Bool, interrupted: Bool,
                          focusLocked: Bool, adjustingFocus: Bool, lensPosition: Float,
                          width: Int, height: Int, timestamp: Double) -> Float? {
        guard !cancelled, !timedOut else { return nil }
        if now.isFinite && now >= deadline { timedOut = true; return nil }
        let fresh = timestamp.isFinite && timestamp >= 0 && (lastTimestamp.map { timestamp > $0 } ?? true)
        if fresh { lastTimestamp = timestamp }
        let issue: CameraStartupIssue?
        if !running { issue = .sessionStopped }
        else if interrupted { issue = .sessionInterrupted }
        else if !now.isFinite || now < earliestFrameTime { issue = .settling }
        else if width != 1920 || height != 1080 { issue = .resolution }
        else if adjustingFocus || !focusLocked { issue = .focusMoving }
        else if !lensPosition.isFinite || !(0...1).contains(lensPosition) { issue = .lensPosition }
        else if !fresh { issue = .invalidTimestamp }
        else { issue = nil }
        if let issue {
            lastIssue = issue; consecutiveFrames = 0; stableMinimum = nil; stableMaximum = nil
            return nil
        }
        let low = min(stableMinimum ?? lensPosition, lensPosition)
        let high = max(stableMaximum ?? lensPosition, lensPosition)
        if high - low > CameraFocusGuard.tolerance {
            consecutiveFrames = 1; stableMinimum = lensPosition; stableMaximum = lensPosition
            lastIssue = .focusMoving
            return nil
        }
        stableMinimum = low; stableMaximum = high; consecutiveFrames += 1
        lastIssue = consecutiveFrames >= 3 ? .ready : .collecting
        return consecutiveFrames >= 3 ? lensPosition : nil
    }
}

// Readiness comes from observed camera state and fresh sensor frames, not a
// focus completion handler or simply the passage of a fixed delay.
struct CameraStartupCheck {
    let requestedLens: Float
    let earliestFrameTime: Double
    private var consecutiveFrames = 0
    private var lastTimestamp: Double?
    private(set) var lastIssue: CameraStartupIssue = .noFrames

    init(requestedLens: Float, earliestFrameTime: Double) {
        self.requestedLens = requestedLens
        self.earliestFrameTime = earliestFrameTime
    }

    mutating func observe(now: Double, running: Bool, interrupted: Bool,
                          focusLocked: Bool, adjustingFocus: Bool, lensPosition: Float,
                          width: Int, height: Int, timestamp: Double) -> Bool {
        let fresh = timestamp.isFinite && timestamp >= 0 && (lastTimestamp.map { timestamp > $0 } ?? true)
        if fresh { lastTimestamp = timestamp }
        let issue: CameraStartupIssue?
        if !running { issue = .sessionStopped }
        else if interrupted { issue = .sessionInterrupted }
        else if !now.isFinite || now < earliestFrameTime { issue = .settling }
        else if width != 1920 || height != 1080 { issue = .resolution }
        else if let focusIssue = CameraFocusGuard.issue(expectedLens: requestedLens, focusLocked: focusLocked,
                                                       adjustingFocus: adjustingFocus, lensPosition: lensPosition) { issue = focusIssue }
        else if !fresh { issue = .invalidTimestamp }
        else { issue = nil }
        if let issue {
            lastIssue = issue
            consecutiveFrames = 0
            return false
        }
        consecutiveFrames += 1
        lastIssue = consecutiveFrames >= 3 ? .ready : .collecting
        return consecutiveFrames >= 3
    }
}
