import CryptoKit
import Foundation

/// A user's reference-metrology report for individually identified physical flags.
/// Import validates structure and rigid geometry; it cannot verify the measurement.
struct MUACalibrationFlag: Codable, Equatable {
    var markerID: Int
    var physicalSerial: String
    var transform: [[Double]]
    var fitRMSMM: Double
    var uncertaintyMM: Double
    var uncertaintyDegrees: Double

    enum CodingKeys: String, CodingKey {
        case markerID = "marker_id", physicalSerial = "physical_serial", transform = "T_marker_mua"
        case fitRMSMM = "fit_rms_mm", uncertaintyMM = "uncertainty_mm", uncertaintyDegrees = "uncertainty_deg"
    }
}

struct MUACalibration: Codable, Equatable {
    static let expectedGeometryRevision = "DAL_N48_D4_VERTICAL_V1"
    var schema = 1
    var units = "mm"
    var dictionary = "DAL_DOTS4_V1"
    var componentReference = "MG-MUASB9"
    var geometryRevision = Self.expectedGeometryRevision
    var source = "reference_metrology"
    var referenceDevice: String
    var referenceReport: String
    var measuredAt: String
    var flags: [MUACalibrationFlag]

    enum CodingKeys: String, CodingKey {
        case schema, units, dictionary, source, flags
        case componentReference = "component_reference", geometryRevision = "geometry_revision"
        case referenceDevice = "reference_device", referenceReport = "reference_report", measuredAt = "measured_at"
    }

    static func load(_ data: Data) throws -> Self {
        guard !data.isEmpty, data.count <= 512 * 1024 else {
            throw LabError.message("MUA kalibrasyon dosyası boş veya 512 KB sınırından büyük.")
        }
        return try JSONDecoder().decode(Self.self, from: data).validated()
    }

    @discardableResult func validated() throws -> Self {
        guard schema == 1, units == "mm", dictionary == "DAL_DOTS4_V1",
              ["MG-MUASB9", "MG-MUASBU"].contains(componentReference), geometryRevision == Self.expectedGeometryRevision,
              source == "reference_metrology" else {
            throw LabError.message("MUA kalibrasyonu DAL N48 D4 dik v1, MG-MUASBU veya eski MG-MUASB9 referansı, mm ve referans ölçüm şemasına ait olmalı.")
        }
        guard Self.validText(referenceDevice), Self.validText(referenceReport), Self.validText(measuredAt),
              Self.date(measuredAt) != nil else {
            throw LabError.message("Referans cihaz, ölçüm raporu ve ISO 8601 ölçüm tarihi gerekli.")
        }
        guard (1...6).contains(flags.count), Set(flags.map(\.markerID)).count == flags.count,
              Set(flags.map(\.physicalSerial)).count == flags.count else {
            throw LabError.message("Her fiziksel bayrak için farklı kimlik ve seri numarası gerekli; en fazla altı bayrak yüklenebilir.")
        }
        for flag in flags {
            guard (0...5).contains(flag.markerID), Self.validText(flag.physicalSerial),
                  [flag.fitRMSMM, flag.uncertaintyMM, flag.uncertaintyDegrees].allSatisfy({ $0.isFinite && $0 >= 0 }) else {
                throw LabError.message("Bayrak kimliği, fiziksel seri veya ölçüm belirsizliği geçersiz.")
            }
            try Self.validateRigid(flag.transform)
        }
        return self
    }

    func canonicalData() throws -> Data {
        try validated()
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        return try encoder.encode(self)
    }

    func contentHash() throws -> String {
        SHA256.hash(data: try canonicalData()).map { String(format: "%02x", $0) }.joined()
    }

    /// Freeze this exact import into a scan's creation before acquisition. Call
    /// apply on the reconstruction dictionary (envelope["result"]), not its parent.
    /// T_a_b maps coordinates in b into a, so T_w_mua = T_w_marker * T_marker_mua.
    func apply(to result: [String: Any]) throws -> [String: Any] {
        try validated()
        guard result["units"] as? String == "mm",
              let rig = result["rig"] as? [String: Any], rig["dictionary"] as? String == dictionary,
              rig["units"] as? String == "mm",
              let rawMarkers = result["markers"] as? [[String: Any]], !rawMarkers.isEmpty else {
            throw LabError.message("MUA dönüşümü yalnız eşleşen DAL_DOTS4_V1 mm araştırma sonucuna uygulanabilir.")
        }
        var ids = Set<Int>(), applied = [Int](), missing = [Int](), markers = [[String: Any]]()
        let byID = Dictionary(uniqueKeysWithValues: flags.map { ($0.markerID, $0) })
        let hash = try contentHash()
        for var marker in rawMarkers {
            guard let id = marker["id"] as? Int, (0...5).contains(id), ids.insert(id).inserted,
                  let worldMarker = marker["T_world_marker"] as? [[Double]] else {
                throw LabError.message("Sonuçta bayrak kimliği veya dünya dönüşümü geçersiz.")
            }
            try Self.validateRigid(worldMarker)
            if let component = marker["component_reference"] as? String, component != componentReference {
                throw LabError.message("FDI planındaki bileşen kodu ölçüm dosyasıyla eşleşmiyor; eski kod otomatik değiştirilmez.")
            }
            marker["T_world_mua"] = NSNull(); marker["center_mm"] = NSNull(); marker["axis"] = NSNull()
            marker["T_marker_mua"] = NSNull(); marker["calibration_status"] = "missing"
            marker.removeValue(forKey: "mua_calibration_provenance")
            if let flag = byID[id] {
                let worldMUA = Self.multiply(worldMarker, flag.transform)
                try Self.validateRigid(worldMUA)
                marker["T_world_mua"] = worldMUA
                marker["T_marker_mua"] = flag.transform
                marker["center_mm"] = (0..<3).map { worldMUA[$0][3] }
                marker["axis"] = (0..<3).map { worldMUA[$0][2] }
                marker["calibration_status"] = "imported_reference_metrology_unverified"
                if let issues = marker["issues"] as? [String] {
                    marker["issues"] = issues.filter { $0 != "missing_mua_calibration" }
                }
                marker["mua_calibration_provenance"] = [
                    "physical_serial": flag.physicalSerial, "geometry_revision": geometryRevision,
                    "component_reference": componentReference, "source": source,
                    "reference_device": referenceDevice, "reference_report": referenceReport,
                    "measured_at": measuredAt, "import_sha256": hash,
                    "fit_rms_mm": flag.fitRMSMM, "uncertainty_mm": flag.uncertaintyMM,
                    "uncertainty_deg": flag.uncertaintyDegrees, "measurement_source_verified": false,
                    "physical_serial_binding": "operator_declared", "clinically_validated": false
                ] as [String: Any]
                applied.append(id)
            } else { missing.append(id) }
            marker["physical_accuracy_um"] = NSNull()
            markers.append(marker)
        }
        var output = result
        output["markers"] = markers
        output["mua_calibration_import"] = try JSONSerialization.jsonObject(with: canonicalData())
        output["mua_calibration_sha256"] = hash
        output["mua_calibrated_marker_ids"] = applied.sorted()
        output["mua_missing_marker_ids"] = missing.sorted()
        output["all_mua_calibrated"] = missing.isEmpty
        output["measurement_source_verified"] = false
        output["clinically_validated"] = false
        output["physical_accuracy_um"] = NSNull()
        output["research_only"] = true
        var warnings = result["warnings"] as? [String] ?? []
        if missing.isEmpty {
            warnings.removeAll { $0 == "MUA transforms are unmeasured; only independent optical flag geometry is available." }
        }
        let importWarning = "MUA dönüşümleri içe aktarılan referans ölçümünden uygulanmıştır. Fiziksel seri eşleşmesi kullanıcı beyanıdır; ölçüm kaynağı ve klinik doğruluk uygulama tarafından doğrulanmadı."
        if !warnings.contains(importWarning) { warnings.append(importWarning) }
        if !missing.isEmpty {
            warnings.append("MUA kalibrasyonu eksik bayrak kimlikleri: " + missing.sorted().map(String.init).joined(separator: ", "))
        }
        output["warnings"] = warnings
        return output
    }

    private static func validText(_ value: String) -> Bool {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return !trimmed.isEmpty && value == trimmed && value.count <= 1024
            && value.unicodeScalars.allSatisfy { !CharacterSet.controlCharacters.contains($0) }
    }
    private static func date(_ value: String) -> Date? {
        let parser = ISO8601DateFormatter()
        if let date = parser.date(from: value) { return date }
        parser.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return parser.date(from: value)
    }
    private static func validateRigid(_ matrix: [[Double]]) throws {
        guard matrix.count == 4, matrix.allSatisfy({ $0.count == 4 && $0.allSatisfy(\.isFinite) }),
              abs(matrix[3][0]) <= 1e-8, abs(matrix[3][1]) <= 1e-8,
              abs(matrix[3][2]) <= 1e-8, abs(matrix[3][3] - 1) <= 1e-8 else {
            throw LabError.message("MUA dönüşümü sonlu, homojen 4 × 4 matris olmalı.")
        }
        for a in 0..<3 {
            for b in 0..<3 {
                let dot = (0..<3).reduce(0.0) { $0 + matrix[$1][a] * matrix[$1][b] }
                guard abs(dot - (a == b ? 1 : 0)) <= 1e-4 else {
                    throw LabError.message("MUA dönüşümünde ölçek veya eğrilik var; rijit dönme matrisi gerekli.")
                }
            }
        }
        let r = matrix
        let determinant = r[0][0] * (r[1][1] * r[2][2] - r[1][2] * r[2][1])
            - r[0][1] * (r[1][0] * r[2][2] - r[1][2] * r[2][0])
            + r[0][2] * (r[1][0] * r[2][1] - r[1][1] * r[2][0])
        guard determinant.isFinite, abs(determinant - 1) <= 1e-4 else {
            throw LabError.message("MUA dönüşümü sağ elli dönme matrisi olmalı; yansıma kabul edilmez.")
        }
    }
    private static func multiply(_ left: [[Double]], _ right: [[Double]]) -> [[Double]] {
        (0..<4).map { row in (0..<4).map { column in
            (0..<4).reduce(0.0) { $0 + left[row][$1] * right[$1][column] }
        } }
    }
}
