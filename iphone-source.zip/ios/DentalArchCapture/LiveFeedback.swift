import Foundation

enum ScanCadence {
    // At most five analysis cycles per second when the device can keep up.
    // The reservation still covers capture, analysis and authoritative commit.
    static func delayNanoseconds(elapsed: Double) -> UInt64 {
        guard elapsed.isFinite, elapsed >= 0 else { return 200_000_000 }
        return UInt64(max(0.02, 0.20 - elapsed) * 1_000_000_000)
    }
}

// One reservation owns the camera -> preview -> persistent upload sequence.
// Stop invalidates its UI effects; outstanding work must finish before a restart.
struct SamplingGate {
    private(set) var active = false
    private(set) var epoch = 0
    private(set) var outstanding: Int?
    mutating func start() -> Bool {
        guard !active, outstanding == nil else { return false }
        epoch += 1; active = true; return true
    }
    mutating func reserve() -> Int? {
        guard active, outstanding == nil else { return nil }
        outstanding = epoch; return epoch
    }
    func owns(_ ticket: Int) -> Bool { active && outstanding == ticket && epoch == ticket }
    mutating func stop() { active = false }
    mutating func release(_ ticket: Int) { if outstanding == ticket { outstanding = nil } }
}

struct LiveFeedback {
    struct Marker: Identifiable {
        let id: Int
        let points: [[Double]]
    }
    struct Candidate: Identifiable {
        let id: Int
        let points: [[Double]]
        let reason: String
        let accepted: Bool
    }
    let sampleID: String
    let preview: Bool
    let usable: Bool
    let markers: [Marker]
    let views: [Int: Int]
    let frames: Int
    let targetFrames: Int
    let targetViews: Int
    let width: Int
    let height: Int
    let message: String
    var detectionMilliseconds: Double? = nil
    var hint: String? = nil
    var detectorMode: String? = nil
    var candidateCount = 0
    var candidates: [Candidate] = []
    var candidateReasons: [String] = []
    var unselectedIDs: [Int] = []
    var targetBlurAvailable: Bool? = nil
    var missingInSample: [Int] { views.keys.filter { id in !markers.contains { $0.id == id } }.sorted() }
    var completedIDs: [Int] { views.keys.filter { views[$0, default: 0] >= targetViews }.sorted() }
    var pendingIDs: [Int] { views.keys.filter { views[$0, default: 0] < targetViews }.sorted() }
    var minimumViews: Int { views.values.min() ?? 0 }
    var coverageReached: Bool { frames >= targetFrames && minimumViews >= targetViews }
    var fraction: Double {
        if targetViews == 1 { return Double(completedIDs.count) / Double(max(1, views.count)) }
        return min(1, min(Double(frames) / Double(targetFrames), Double(minimumViews) / Double(targetViews)))
    }
    static func decode(_ response: [String: Any], session: String, sample: String, count: Int, markerIDs: [Int]? = nil) throws -> LiveFeedback {
        let expected = try MarkerSelection.resolve(count: count, ids: markerIDs)
        guard response["id"] as? String == sample,
              let f = response["feedback"] as? [String: Any], f["schema"] as? Int == 1,
              f["session_id"] as? String == session, f["sample_id"] as? String == sample,
              f["coordinates"] as? String == "sensor_normalized",
              f["metric"] as? String == "accepted_image_coverage_not_accuracy",
              f["physical_accuracy_um"] is NSNull,
              let preview = f["preview"] as? Bool, let usable = f["sample_usable"] as? Bool,
              let size = f["image_size"] as? [Int], size.count == 2, size.allSatisfy({ $0 > 0 && $0 <= 8192 }),
              let frames = f["frames"] as? Int, (0...120).contains(frames),
              let targetFrames = f["target_frames"] as? Int, [1, 12, 24].contains(targetFrames),
              let targetViews = f["target_views"] as? Int, [1, 4, 8].contains(targetViews),
              let rawViews = f["views"] as? [String: Int], rawViews.count == count,
              let rawMarkers = f["markers"] as? [[String: Any]], rawMarkers.count <= count,
              let message = response["message"] as? String else { throw LabError.message("Canlı analiz yanıtı eşleşmedi.") }
        guard (targetFrames == 1 && targetViews == 1) || (targetFrames == 12 && targetViews == 4) || (targetFrames == 24 && targetViews == 8) else {
            throw LabError.message("Bayrak kapsam hedefleri eşleşmedi.")
        }
        if let declared = f["expected_marker_ids"] {
            guard try MarkerSelection.decode(count: count, raw: declared) == expected else {
                throw LabError.message("Canlı analiz farklı bayrak numaraları için hazırlanmış.")
            }
        } else if markerIDs != nil, expected != Array(0..<count) {
            throw LabError.message("Canlı analizde seçilmiş bayrak numaraları eksik.")
        }
        var views: [Int: Int] = [:]
        for id in expected {
            guard let value = rawViews[String(id)], (0...frames).contains(value) else { throw LabError.message("Bayrak kapsam sayacı geçersiz.") }
            views[id] = value
        }
        var markers: [Marker] = []
        for m in rawMarkers {
            guard let id = m["id"] as? Int, expected.contains(id), !markers.contains(where: { $0.id == id }),
                  let points = m["points"] as? [[Double]], points.count == 4,
                  points.allSatisfy({ $0.count == 2 && $0.allSatisfy { $0.isFinite && (0...1).contains($0) } }) else {
                throw LabError.message("Bayrak görüntü koordinatları geçersiz.")
            }
            markers.append(Marker(id: id, points: points))
        }
        var result = LiveFeedback(sampleID: sample, preview: preview, usable: usable, markers: markers, views: views,
            frames: frames, targetFrames: targetFrames, targetViews: targetViews, width: size[0], height: size[1], message: message)
        if let ms = (response["timing"] as? [String: Any])?["detection_ms"] as? Double, ms.isFinite, ms >= 0 {
            result.detectionMilliseconds = ms
        }
        if let diagnostics = f["diagnostics"] as? [String: Any] {
            if let raw = diagnostics["target_blur_available"] {
                guard let available = raw as? Bool, available == !markers.isEmpty else {
                    throw LabError.message("Bayrak netlik tanısı bulunan bayraklarla eşleşmedi.")
                }
                result.targetBlurAvailable = available
            }
            result.hint = diagnostics["hint"] as? String
            result.detectorMode = diagnostics["detector_mode"] as? String
            if let raw = diagnostics["unselected_marker_ids"] {
                guard let ids = raw as? [Int], Set(ids).count == ids.count,
                      ids.allSatisfy({ (0...5).contains($0) && !expected.contains($0) }) else {
                    throw LabError.message("Seçim dışındaki bayrak tanıları geçersiz.")
                }
                result.unselectedIDs = ids.sorted()
            }
            if let count = diagnostics["dot_groups"] as? Int, (0...10000).contains(count) { result.candidateCount = count }
            if let raw = diagnostics["candidate_diagnostics"] as? [[String: Any]] {
                let reasons: Set<String> = ["clipped", "invalid_layout", "too_small", "no_valid_geometry", "ambiguous_identity", "duplicate_identity", "unselected_identity", "accepted"]
                guard raw.count <= 128 else { throw LabError.message("Tanıma aday sayısı geçersiz.") }
                for candidate in raw {
                    guard let index = candidate["candidate_index"] as? Int, index >= 0,
                          !result.candidates.contains(where: { $0.id == index }),
                          let points = candidate["centers_px"] as? [[Double]], (1...16).contains(points.count),
                          points.allSatisfy({ $0.count == 2 && $0.allSatisfy(\.isFinite) && (0...Double(size[0])).contains($0[0]) && (0...Double(size[1])).contains($0[1]) }),
                          let accepted = candidate["accepted"] as? Bool,
                          let reason = candidate["reason"] as? String, reasons.contains(reason) else {
                        throw LabError.message("Tanıma ayrıntıları görüntüyle eşleşmiyor.")
                    }
                    result.candidates.append(Candidate(id: index,
                        points: points.map { [$0[0]/Double(size[0]), $0[1]/Double(size[1])] }, reason: reason, accepted: accepted))
                }
                result.candidateReasons = Array(Set(result.candidates.filter { !$0.accepted }.map(\.reason))).sorted()
            }
        }
        return result
    }
}

// Sensor PNGs remain unrotated. Overlay coordinates are drawn only on that exact
// analyzed image, never on a newer moving camera preview.
struct FeedbackViewport {
    let width: Double
    let height: Double
    let x: Double
    let y: Double
    init(imageWidth: Double, imageHeight: Double, viewWidth: Double, viewHeight: Double) {
        let scale = min(viewWidth / imageWidth, viewHeight / imageHeight)
        width = imageWidth * scale; height = imageHeight * scale
        x = (viewWidth - width) / 2; y = (viewHeight - height) / 2
    }
    func point(_ normalized: [Double]) -> (Double, Double) { (x + normalized[0] * width, y + normalized[1] * height) }
}
