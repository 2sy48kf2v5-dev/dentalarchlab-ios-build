import Foundation

// Serial CPU worker and durable state: no URLSession, socket or remote service.
// Original images remain in CaptureRepository; only observations live here.
actor OfflineEngine {
    let root: URL
    private struct Preview {
        let session: String; let id: String; let hash: String; let timestamp: Double
        let profile: [String: Any]; let assessment: [String: Any]; let created: TimeInterval
    }
    private var preview: Preview?
    private var recoveryCheckedSessions = Set<String>()
    init(root: URL) { self.root = root }

    private func file(_ id: String) throws -> URL {
        guard id.count == 32, id.utf8.allSatisfy({ (48...57).contains($0) || (97...102).contains($0) }) else {
            throw LabError.message("Yerel kayıt kimliği geçersiz.")
        }
        return root.appendingPathComponent(id + ".json")
    }
    private func load(_ id: String) throws -> [String: Any] {
        let url = try file(id)
        guard FileManager.default.fileExists(atPath: url.path),
              var state = try JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any] else {
            throw LabError.message("Bu iPhone'da hesap kaydı yok. Yeni bir kayıt başlatın.")
        }
        if !recoveryCheckedSessions.contains(id) {
            // Native fitting is synchronous inside this actor. A processing
            // calibration found on the first read belongs to a prior engine
            // lifetime interrupted before its result was committed.
            if state["engine"] as? String == "iphone_native_v1",
               state["mode"] as? String == "calibration", state["state"] as? String == "processing" {
                state["state"] = "collecting"
                state.removeValue(forKey: "calibration"); state.removeValue(forKey: "result")
                state["calibration_recovery"] = ["kind": "interrupted_native_fit", "previous_state": "processing",
                    "accepted_frames": accepted(state).count, "recovered_utc": ISO8601DateFormatter().string(from: Date())] as [String: Any]
                state["message"] = "Önceki kalibrasyon hesabı yarıda kesildi. Kaydedilen kareler korundu; hesap yeniden denenebilir."
                try save(state)
            }
            recoveryCheckedSessions.insert(id)
        }
        return state
    }
    private func save(_ state: [String: Any]) throws {
        guard let id = state["id"] as? String else { throw LabError.message("Kayıt kimliği eksik.") }
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let data = try JSONSerialization.data(withJSONObject: state, options: [.sortedKeys])
        try data.write(to: file(id), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
    private func same(_ a: [String: Any], _ b: [String: Any]) -> Bool { NSDictionary(dictionary: a).isEqual(to: b) }
    private func frameIntrinsics(_ data: [String: Any]) throws -> FrameCameraIntrinsics? {
        guard let value = data["intrinsics"], !(value is NSNull) else { return nil }
        return try JSONDecoder().decode(FrameCameraIntrinsics.self, from: JSONSerialization.data(withJSONObject: value))
    }
    private func matchesIntrinsics(_ intrinsics: FrameCameraIntrinsics?, binding: Any) -> Bool {
        if let intrinsics, let expected = binding as? [String: Any] { return same(intrinsics.nativeDictionary(), expected) }
        return intrinsics == nil && binding is NSNull
    }
    private func accepted(_ s: [String: Any]) -> [[String: Any]] { (s["accepted"] as? [[String: Any]]) ?? [] }
    private func selectedIDs(_ state: [String: Any]) throws -> [Int] {
        try MarkerSelection.decode(count: (state["marker_count"] as? Int) ?? 6, raw: state["marker_ids"])
    }
    private func views(_ s: [String: Any]) throws -> [String: Int] {
        let ids = try selectedIDs(s)
        var result = Dictionary(uniqueKeysWithValues: ids.map { (String($0), 0) })
        for frame in accepted(s) {
            for item in (frame["observations"] as? [[String: Any]]) ?? [] {
                guard let id = item["marker"] as? Int, ids.contains(id) else {
                    throw LabError.message("Kaydedilen bayrak kimliği seçilen bayraklarla eşleşmiyor; kayıt korundu.")
                }
                result[String(id), default: 0] += 1
            }
        }
        return result
    }

    func request(_ path: String, body: Data?) throws -> [String: Any] {
        let data: [String: Any]?
        if let body { data = try JSONSerialization.jsonObject(with: body) as? [String: Any] } else { data = nil }
        if path == "status" { return ["research_only": true, "engine": "iphone_native_v1", "capabilities": ["fdi_case_plan_v1", "transient_frame_preview_v1", "cached_frame_commit_v1", "automatic_calibration_preview_v1"]] }
        if path == "sessions", let data { return try create(data) }
        let parts = path.split(separator: "/").map(String.init)
        guard parts.count >= 2, parts[0] == "sessions" else { throw LabError.message("Yerel işlem yolu geçersiz.") }
        let id = parts[1]
        if parts.count == 2 { return try load(id) }
        guard parts.count == 3 else { throw LabError.message("Yerel işlem yolu geçersiz.") }
        if parts[2] == "process" { return try process(id, automatic: (data?["automatic"] as? Bool) ?? false) }
        guard let data else { throw LabError.message("İşlem verisi eksik.") }
        switch parts[2] {
        case "preview": return try frame(id, data: data, isPreview: true)
        case "frames": return try frame(id, data: data, isPreview: false)
        case "commit-preview": return try commit(id, data: data)
        default: throw LabError.message("Yerel işlem tanınmadı.")
        }
    }
    /// In-process camera transfer avoids a full-image base64/JSON round trip.
    /// Both APIs share validation, detector, preview cache and receipt behavior.
    func submitFrame(_ path: String, id: String, image: Data, profile: CaptureProfile, timestamp: Double, intrinsics: FrameCameraIntrinsics? = nil) throws -> [String: Any] {
        let parts = path.split(separator: "/").map(String.init)
        guard parts.count == 3, parts[0] == "sessions", ["preview", "frames"].contains(parts[2]) else {
            throw LabError.message("Yerel görüntü işlem yolu geçersiz.")
        }
        let profileData = try JSONEncoder().encode(profile)
        guard let metadataProfile = try JSONSerialization.jsonObject(with: profileData) as? [String: Any] else {
            throw LabError.message("Kamera profili okunamadı.")
        }
        var metadata: [String: Any] = ["id": id, "timestamp_s": timestamp, "profile": metadataProfile]
        if let intrinsics {
            guard intrinsics.matches(profile) else { throw LabError.message("Kare kamera matrisi boyutları eşleşmiyor.") }
            metadata["intrinsics"] = try JSONSerialization.jsonObject(with: JSONEncoder().encode(intrinsics))
        }
        return try frame(parts[1], data: metadata, rawImage: image, isPreview: parts[2] == "preview")
    }

    private func create(_ data: [String: Any]) throws -> [String: Any] {
        let creation = try JSONDecoder().decode(CaptureCreation.self, from: JSONSerialization.data(withJSONObject: data))
        let id = creation.id; let destination = try file(id)
        guard ["trial", "calibration", "scan"].contains(creation.mode), [4,6].contains(creation.markerCount),
              creation.profile.width == 1920, creation.profile.height == 1080,
              creation.profile.lensPosition.isFinite, (0...1).contains(creation.profile.lensPosition),
              creation.profile.pipeline == "ios_avfoundation_v1", creation.profile.focus == "locked",
              ["wide", "ultrawide"].contains(creation.profile.lens), creation.profile.zoom == 1,
              !creation.profile.device.isEmpty, !creation.profile.format.isEmpty,
              creation.profile.stabilization == "off", creation.profile.orientation == "sensor_native" else {
            throw LabError.message("Yerel kamera profili veya çalışma türü geçersiz.")
        }
        let markerIDs = try MarkerSelection.decode(count: creation.markerCount, raw: data["marker_ids"])
        try creation.validateCaseReference()
        if creation.mode != "calibration", let plan = creation.dentalPlan {
            try plan.validate(count: creation.markerCount)
            guard Set(plan.assignments.map(\.markerID)) == Set(markerIDs) else {
                throw LabError.message("FDI planındaki bayrak kimlikleri seçilen fiziksel bayraklarla eşleşmiyor.")
            }
        }
        if let calibration = creation.muaCalibration { _ = try calibration.validated() }
        let signature = PreviewCommit.digest(try JSONSerialization.data(withJSONObject: data, options: [.sortedKeys]))
        if FileManager.default.fileExists(atPath: destination.path) {
            let old = try load(id)
            guard old["creation_hash"] as? String == signature else { throw LabError.message("Aynı kayıt farklı ayarlarla açılamaz.") }
            return old
        }
        if creation.board.physicalMeasured {
            guard let size = creation.board.squareMM, size.isFinite, (0.5...100).contains(size) else { throw LabError.message("Ölçülen kare kenarı 0,5–100 mm arasında olmalı.") }
        }
        var state = data
        state["marker_ids"] = markerIDs
        state["engine"] = "iphone_native_v1"; state["creation_hash"] = signature
        state["state"] = "collecting"; state["count"] = 0; state["message"] = "iPhone hesap motoru hazır."
        state["accepted"] = [[String: Any]](); state["receipts"] = [String: Any]()
        state["research_only"] = true; state["physical_accuracy_um"] = NSNull()
        if creation.mode == "calibration" { state["next_calibration_target"] = 20 }
        if creation.mode == "scan" {
            guard let calID = creation.calibrationID else { throw LabError.message("Önce bu iPhone'da fiziksel tahta kalibrasyonu yapın.") }
            let calibration = try load(calID)
            guard calibration["state"] as? String == "complete", calibration["mode"] as? String == "calibration",
                  let camera = calibration["calibration"] as? [String: Any],
                  let meta = camera["metadata"] as? [String: Any], meta["status"] as? String == "measured_research",
                  let warning = meta["warnings"] as? [String], warning.isEmpty,
                  let rms = meta["rms_px"] as? Double, rms.isFinite, (0...0.6).contains(rms),
                  ((meta["views"] as? Int) ?? 0) >= 10,
                  // Physical lens, native format/FOV signature, output geometry
                  // and fixed focus remain exact. Macro does not inherit a wide calibration.
                  let oldProfile = meta["capture_profile"] as? [String: Any], let profile = data["profile"] as? [String: Any], same(oldProfile, profile) else {
                throw LabError.message("Aynı sabit odakta, en az 10 farklı görüntüyle uygun fiziksel tahta kalibrasyonu gerekli. Ekran deneyi 3B ölçüme aktarılamaz.")
            }
            state["camera"] = camera
        }
        try save(state); return state
    }
    private func validateFrame(_ state: [String: Any], _ data: [String: Any]) throws -> (String, Double, [String: Any]) {
        guard let id = data["id"] as? String, let timestamp = data["timestamp_s"] as? Double,
              timestamp.isFinite, timestamp >= 0, let profile = data["profile"] as? [String: Any],
              let expected = state["profile"] as? [String: Any] else { throw LabError.message("Kare kimliği, zamanı veya kamera profili değişmiş.") }
        let decoder = JSONDecoder()
        let expectedProfile = try decoder.decode(CaptureProfile.self, from: JSONSerialization.data(withJSONObject: expected))
        let actualProfile = try decoder.decode(CaptureProfile.self, from: JSONSerialization.data(withJSONObject: profile))
        guard expectedProfile.accepts(actualProfile, mode: (state["mode"] as? String) ?? "") else {
            throw LabError.message("Kamera profili bu kayıtla eşleşmiyor.")
        }
        _ = try file(id)
        return (id, timestamp, profile)
    }
    private func frame(_ session: String, data: [String: Any], rawImage: Data? = nil, isPreview: Bool) throws -> [String: Any] {
        let state = try load(session)
        let (id, timestamp, profile) = try validateFrame(state, data)
        let intrinsics = try frameIntrinsics(data)
        let image: Data
        if let rawImage {
            image = rawImage
        } else {
            guard let encoded = data["image"] as? String, encoded.count <= 12_000_000,
                  let decoded = Data(base64Encoded: encoded) else { throw LabError.message("Kamera görüntüsü geçersiz veya fazla büyük.") }
            image = decoded
        }
        guard !image.isEmpty, image.count <= 8*1024*1024 else { throw LabError.message("Kamera görüntüsü geçersiz veya fazla büyük.") }
        let hash = PreviewCommit.digest(image)
        if !isPreview, let old = (state["receipts"] as? [String: [String: Any]])?[id] {
            guard old["sha256"] as? String == hash else { throw LabError.message("Aynı kare kimliğinde farklı görüntü var.") }
            if let binding = old["frame_intrinsics"], !matchesIntrinsics(intrinsics, binding: binding) {
                throw LabError.message("Aynı kare kimliğinde kamera matrisi değiştirilmiş.")
            }
            return old
        }
        guard state["state"] as? String == "collecting", ((state["receipts"] as? [String: Any]) ?? [:]).count < 120 else { throw LabError.message("Kayıt çekime kapalı veya 120 kare sınırında. Yeni kayıt açın.") }
        let start = ProcessInfo.processInfo.systemUptime
        let markerIDs = try selectedIDs(state)
        let nativeIDs = markerIDs.map { NSNumber(value: $0) }
        var assessment: [String: Any]
        if state["mode"] as? String == "calibration" {
            assessment = try DALNativeEngine.checkBoard(image: image, previousCorners: accepted(state).compactMap { $0["corners"] })
        } else if state["mode"] as? String == "trial", state["trial_intrinsics_required"] as? Bool == true {
            // New identity trials use the K attached to this exact image. A
            // calibrated XYZ scan ALWAYS uses its saved physical calibration.
            assessment = try DALNativeEngine.detectTrial(image: image, intrinsics: intrinsics?.nativeDictionary(), markerIDs: nativeIDs)
        } else {
            if state["mode"] as? String == "scan", !(state["camera"] is [String: Any]) {
                throw LabError.message("3B kaydının ölçülmüş kamera kalibrasyonu eksik. Kayıt korunuyor; yeni fiziksel kalibrasyonla başlayın.")
            }
            assessment = try DALNativeEngine.detect(image: image, camera: state["camera"] as? [String: Any], markerIDs: nativeIDs)
        }
        assessment["frame_intrinsics"] = intrinsics.map { $0.nativeDictionary() as Any } ?? NSNull()
        // Keep the exact metric camera used for these pixels with the preview
        // cache. Export never substitutes a newer calibration or hardware K.
        assessment["used_camera_calibration"] = state["camera"] ?? NSNull()
        assessment["calibration_id"] = state["mode"] as? String == "scan" ? (state["calibration_id"] ?? NSNull()) : NSNull()
        let elapsed = (ProcessInfo.processInfo.systemUptime - start)*1000
        let receipt = try assessAndCommit(session, id: id, hash: hash, timestamp: timestamp, profile: profile, assessment: assessment, isPreview: isPreview, milliseconds: elapsed)
        if isPreview {
            preview = receipt["accepted"] as? Bool == true ? Preview(session: session, id: id, hash: hash, timestamp: timestamp, profile: profile, assessment: assessment, created: ProcessInfo.processInfo.systemUptime) : nil
        }
        return receipt
    }
    private func commit(_ session: String, data: [String: Any]) throws -> [String: Any] {
        let state = try load(session)
        let (id, timestamp, profile) = try validateFrame(state, data)
        let intrinsics = try frameIntrinsics(data)
        let hash = (data["sha256"] as? String) ?? ""
        if let old = (state["receipts"] as? [String: [String: Any]])?[id] {
            guard old["sha256"] as? String == hash else { throw LabError.message("Kare özeti eşleşmedi.") }
            if let binding = old["frame_intrinsics"], !matchesIntrinsics(intrinsics, binding: binding) {
                throw LabError.message("Kayıt onayındaki kamera matrisi eşleşmedi.")
            }
            return old
        }
        guard let p = preview, p.session == session, p.id == id, p.hash == hash, p.timestamp == timestamp,
              same(profile, p.profile), matchesIntrinsics(intrinsics, binding: p.assessment["frame_intrinsics"] ?? NSNull()),
              ProcessInfo.processInfo.systemUptime - p.created < 8 else {
            throw BridgeHTTPError(status: 409, message: "Yerel önizleme süresi doldu; özgün kare yeniden işlenecek.")
        }
        let receipt = try assessAndCommit(session, id: id, hash: hash, timestamp: timestamp, profile: profile, assessment: p.assessment, isPreview: false, milliseconds: 0)
        preview = nil; return receipt
    }
    private func assessAndCommit(_ session: String, id: String, hash: String, timestamp: Double, profile: [String: Any],
                                 assessment originalAssessment: [String: Any], isPreview: Bool, milliseconds: Double) throws -> [String: Any] {
        var s = try load(session)
        guard s["state"] as? String == "collecting" else { throw LabError.message("Kayıt çekime kapalı.") }
        guard ((s["receipts"] as? [String: Any]) ?? [:]).count < 120 else { throw LabError.message("120 kare sınırına ulaşıldı. Yeni kayıt açın.") }
        var assessment = originalAssessment
        guard let size = assessment["image_size"] as? [Int], size == [1920, 1080] else { throw LabError.message("İşlenen görüntü 1920 × 1080 sensör çözünürlüğünde olmalı.") }
        let calibration = s["mode"] as? String == "calibration"
        if calibration, assessment["accepted"] as? Bool == true,
           let corners = assessment["corners"] as? [[Double]],
           Self.repeatedBoard(corners, history: accepted(s)) {
            // A preview is only provisional. Another committed view must not
            // make the same pose count twice when that preview is later saved.
            assessment["accepted"] = false; assessment["reason"] = "duplicate"
            assessment["message"] = "Bu tahta görünümü kaydedildi. Eğimi veya kadrajdaki yerini değiştirin."
            assessment["corners"] = NSNull()
        }
        let observations = (assessment["observations"] as? [[String: Any]]) ?? []
        let quality = (assessment["quality"] as? [String: Any]) ?? [:]
        let markerIDs = try selectedIDs(s)
        let decision = calibration ? ((assessment["accepted"] as? Bool) ?? false, (assessment["message"] as? String) ?? "Tahta bulunamadı.")
            : try Self.assess(observations, quality: quality, history: accepted(s), markerCount: (s["marker_count"] as? Int) ?? 6, identityOnly: s["mode"] as? String == "trial", markerIDs: markerIDs)
        let usable = decision.0; let message = decision.1
        var history = accepted(s)
        if usable && !isPreview {
            let storedObservations = s["mode"] as? String == "trial"
                ? Self.eligibleTrialObservations(observations, quality: quality, history: history)
                : observations
            var frame: [String: Any] = ["id": id, "timestamp_s": timestamp, "capture_profile": profile, "observations": storedObservations.map { item -> [String: Any] in var o = item; o["frame"] = id; return o }]
            if let corners = assessment["corners"] { frame["corners"] = corners }
            frame["frame_intrinsics"] = assessment["frame_intrinsics"] ?? NSNull()
            frame["calibration_id"] = assessment["calibration_id"] ?? NSNull()
            history.append(frame); s["accepted"] = history
        }
        let counts = try views(s)
        var feedback: Any = NSNull()
        var calibrationFeedback: Any = NSNull()
        if calibration {
            guard let detected = assessment["detected_corners"] as? [[Double]],
                  [0,54].contains(detected.count),
                  detected.allSatisfy({ $0.count == 2 && $0[0].isFinite && $0[1].isFinite && (0..<1920).contains($0[0]) && (0..<1080).contains($0[1]) }),
                  let blur = assessment["blur_laplacian"] as? Double, blur.isFinite, blur >= 0,
                  let reason = assessment["reason"] as? String, ["accepted", "not_found", "blur", "duplicate"].contains(reason),
                  !usable || (detected.count == 54 && (assessment["corners"] as? [[Double]])?.count == 54) else {
                throw LabError.message("Kalibrasyon köşe yanıtı geçersiz.")
            }
            calibrationFeedback = ["schema": 1, "session_id": session, "sample_id": id,
                "image_size": size, "coordinates": "sensor_normalized", "preview": isPreview,
                "sample_usable": usable, "corners": detected.map { [$0[0]/1920, $0[1]/1080] },
                "detected_count": detected.count, "expected_corners": 54,
                "target_frames": Self.calibrationTarget(s), "accepted_frames": history.count,
                "blur_laplacian": blur, "reason": reason, "message": message,
                "metric": "accepted_calibration_views_not_accuracy", "physical_accuracy_um": NSNull()] as [String: Any]
        }
        if !calibration {
            var diagnostics = quality
            diagnostics["hint"] = message
            feedback = ["schema": 1, "session_id": session, "sample_id": id, "image_size": size,
                "coordinates": "sensor_normalized", "preview": isPreview, "sample_usable": usable,
                "physical_accuracy_um": NSNull(), "markers": observations.map { o -> [String: Any] in
                    let points = o["corners"] as? [[Double]] ?? []
                    return ["id": o["marker"] ?? -1, "points": points.map { [$0[0]/1920, $0[1]/1080] }]
                }, "views": counts, "frames": history.count, "minimum_views": counts.values.min() ?? 0,
                "expected_marker_ids": markerIDs,
                "missing_ids": markerIDs.filter { counts[String($0), default: 0] == 0 },
                "target_frames": s["mode"] as? String == "trial" ? 1 : 24,
                "target_views": s["mode"] as? String == "trial" ? 1 : 8,
                "metric": "accepted_image_coverage_not_accuracy", "diagnostics": diagnostics] as [String: Any]
        }
        let receipt: [String: Any] = ["id": id, "sha256": hash, "capture_profile": profile, "accepted": usable, "message": message,
            "session_id": session, "timestamp_s": timestamp,
            "frame_intrinsics": assessment["frame_intrinsics"] ?? NSNull(),
            "mode": s["mode"] ?? NSNull(), "marker_count": markerIDs.count, "expected_marker_ids": markerIDs,
            "used_camera_calibration": assessment["used_camera_calibration"] ?? NSNull(),
            "calibration_id": assessment["calibration_id"] ?? NSNull(),
            "count": history.count, "feedback": feedback, "calibration_feedback": calibrationFeedback, "views": counts,
            "timing": ["detection_ms": milliseconds], "marker_ids": observations.compactMap { $0["marker"] as? Int }]
        if !isPreview {
            var receipts = (s["receipts"] as? [String: Any]) ?? [:]; receipts[id] = receipt
            s["receipts"] = receipts; s["count"] = history.count; s["views"] = counts; s["message"] = message
            try save(s)
        }
        return receipt
    }
    private static func calibrationTarget(_ state: [String: Any]) -> Int {
        let value = (state["next_calibration_target"] as? Int) ?? 20
        return [20,25,30,35,40,45,50,55,60].contains(value) ? value : 20
    }
    private static func repeatedBoard(_ corners: [[Double]], history: [[String: Any]]) -> Bool {
        guard corners.count == 54, corners.allSatisfy({ $0.count == 2 && $0.allSatisfy(\.isFinite) }) else { return false }
        return history.contains { frame in
            guard let old = frame["corners"] as? [[Double]], old.count == 54,
                  old.allSatisfy({ $0.count == 2 && $0.allSatisfy(\.isFinite) }) else { return false }
            var forward = 0.0, reverse = 0.0
            for index in corners.indices {
                forward += pow(corners[index][0]-old[index][0],2) + pow(corners[index][1]-old[index][1],2)
                reverse += pow(corners[index][0]-old[53-index][0],2) + pow(corners[index][1]-old[53-index][1],2)
            }
            return sqrt(min(forward, reverse)/54) < 8
        }
    }
    static func assess(_ observations: [[String: Any]], quality: [String: Any], history: [[String: Any]], markerCount: Int, identityOnly: Bool = false, markerIDs: [Int]? = nil) throws -> (Bool, String) {
        let expected = try MarkerSelection.resolve(count: markerCount, ids: markerIDs)
        var now: [Int: [[Double]]] = [:]
        for o in observations {
            guard let id = o["marker"] as? Int, expected.contains(id), now[id] == nil,
                  let p = o["corners"] as? [[Double]], p.count == 4,
                  p.allSatisfy({ $0.count == 2 && $0[0].isFinite && $0[1].isFinite && (0...1920).contains($0[0]) && (0...1080).contains($0[1]) }) else { throw LabError.message("Bayrak kimliği veya köşe koordinatları geçersiz.") }
            now[id] = p
        }
        guard now.count >= (identityOnly ? 1 : 2) else {
            return (false, undersizedTargetMessage(observations, quality: quality)
                ?? unselectedIdentityMessage(quality)
                ?? (identityOnly ? "Bir bayrağın dört beyaz noktasını net gösterin." : "En az 2 bayrağın dört beyaz noktası birlikte görünmeli."))
        }
        let seen = Set(history.flatMap { (($0["observations"] as? [[String: Any]]) ?? []).compactMap { $0["marker"] as? Int } })
        if identityOnly {
            guard !Set(now.keys).subtracting(seen).isEmpty else { return (false, unselectedIdentityMessage(quality)
                ?? "Bu bayraklar zaten kaydedildi. Eksik bayrakları gösterin.") }
            let eligible = eligibleTrialObservations(observations, quality: quality, history: history)
            guard !eligible.isEmpty else { return (false, undersizedTargetMessage(observations, quality: quality)
                ?? "Yeni bayrak yeterince büyük ve net değil. Yeniden netle veya uzaklığını ayarla; önceki onaylar korunur.") }
            return (true, "Yeni bayrak kaydı: " + eligible.compactMap { $0["marker"] as? Int }.sorted().map(String.init).joined(separator: ", ") + ".")
        }
        guard ((quality["blur_laplacian"] as? Double) ?? 0) >= 35 else { return (false, "Görüntü bulanık. Telefonu sabit tutup odağı kontrol edin.") }
        guard observations.allSatisfy({ (($0["min_side_px"] as? Double) ?? 0) >= 45 }) else { return (false, "Bayraklar küçük görünüyor. Netliği koruyarak yaklaşın.") }
        if !history.isEmpty && seen.intersection(now.keys).count < 2 { return (false, "Önceki karelerle en az 2 ortak bayrak görünmeli.") }
        for frame in history {
            var old: [Int: [[Double]]] = [:]
            for o in (frame["observations"] as? [[String: Any]]) ?? [] { if let id = o["marker"] as? Int, let p = o["corners"] as? [[Double]] { old[id] = p } }
            let common = Set(now.keys).intersection(old.keys)
            if common.count >= 2 && Set(now.keys).subtracting(old.keys).isEmpty {
                let shifts = common.compactMap { id -> Double? in
                    guard let a = now[id], let b = old[id], b.count == 4, b.allSatisfy({ $0.count == 2 }) else { return nil }
                    return sqrt(zip(a, b).reduce(0) { value, pair in value + pow(pair.0[0]-pair.1[0],2) + pow(pair.0[1]-pair.1[1],2) }/4)
                }.sorted()
                if !shifts.isEmpty {
                    let mid = shifts.count/2
                    let median = shifts.count % 2 == 0 ? (shifts[mid-1]+shifts[mid])/2 : shifts[mid]
                    if median < 4 { return (false, "Bu açı zaten kaydedildi. Model sabitken telefonu yana ve hafif yukarı taşıyın.") }
                }
            }
        }
        return (true, "Uygun kare iPhone'da işlendi. Farklı açılardan devam edin.")
    }
    /// A credible but undersampled four-dot group is not an accepted identity.
    /// Explain its scale before a generic missing-ID message, without changing
    /// the 45 px acceptance threshold or relaxing any geometry gate.
    private static func undersizedTargetMessage(_ observations: [[String: Any]], quality: [String: Any]) -> String? {
        let knownSpans = observations.compactMap { $0["min_side_px"] as? Double }
        let candidates = (quality["candidate_diagnostics"] as? [[String: Any]]) ?? []
        let candidateSpans = candidates.compactMap { candidate -> Double? in
            guard let id = candidate["best_id"] as? Int, (0...5).contains(id),
                  let score = candidate["best_score_px"] as? Double, score.isFinite, score >= 0, score <= 1,
                  let reason = candidate["reason"] as? String, ["accepted", "ambiguous_identity"].contains(reason),
                  let points = candidate["centers_px"] as? [[Double]], points.count == 4,
                  points.allSatisfy({ $0.count == 2 && $0.allSatisfy(\.isFinite) }),
                  let span = candidate["span_px"] as? Double else { return nil }
            return span
        }
        guard let largest = (knownSpans + candidateSpans).filter({ $0.isFinite && $0 > 0 && $0 < 45 }).max() else { return nil }
        return String(format: "Bayrak noktaları görüntüde küçük (%.1f px; en az 45 px gerekli). Netliği koruyarak fiziksel olarak yaklaşın; ekran büyütmesi ölçüm ayrıntısını artırmaz.", largest)
    }
    private static func unselectedIdentityMessage(_ quality: [String: Any]) -> String? {
        guard let ids = quality["unselected_marker_ids"] as? [Int], !ids.isEmpty,
              ids.allSatisfy({ (0...5).contains($0) }) else { return nil }
        return "Görünen bayrak " + Array(Set(ids)).sorted().map(String.init).joined(separator: ", ")
            + " bu kayıtta seçili değil. Yeni kayıt planında modeldeki gerçek bayrak kimliklerini seçin."
    }
    // A previously confirmed flag must not veto a sharp new trial identity.
    // The physical multi-view scan still validates the entire observation set.
    static func eligibleTrialObservations(_ observations: [[String: Any]], quality: [String: Any], history: [[String: Any]]) -> [[String: Any]] {
        let seen = Set(history.flatMap { (($0["observations"] as? [[String: Any]]) ?? []).compactMap { $0["marker"] as? Int } })
        return observations.filter { item in
            guard let id = item["marker"] as? Int, !seen.contains(id),
                  let span = item["min_side_px"] as? Double, span.isFinite, span >= 45,
                  let blur = (item["blur_laplacian"] ?? quality["blur_laplacian"]) as? Double,
                  blur.isFinite, blur >= 35 else { return false }
            return true
        }
    }
    // Give the Foundation boundary an explicit element type. In an NSArray /
    // [Any] call context Swift can choose the deprecated optional flatMap
    // overload and retain one nested observation array per frame.
    static func reconstructionObservations(_ history: [[String: Any]]) throws -> [[String: Any]] {
        var observations: [[String: Any]] = []
        for (index, frame) in history.enumerated() {
            guard let frameID = frame["id"] as? String, !frameID.isEmpty, frameID.count <= 128 else {
                throw LabError.message("Kaydedilen \(index + 1). karenin kimliği geçersiz; görüntüler korunuyor.")
            }
            guard let rows = frame["observations"] as? [[String: Any]], !rows.isEmpty else {
                throw LabError.message("Kaydedilen \(index + 1). karenin bayrak verisi geçersiz; görüntüler korunuyor.")
            }
            for row in rows {
                guard row["frame"] as? String == frameID else {
                    throw LabError.message("Kaydedilen \(index + 1). karenin bayrak bağlantısı eşleşmiyor; görüntüler korunuyor.")
                }
            }
            observations.append(contentsOf: rows)
        }
        return observations
    }
    private func process(_ id: String, automatic: Bool = false) throws -> [String: Any] {
        var s = try load(id)
        if s["state"] as? String == "complete" { return s }
        let mode = (s["mode"] as? String) ?? ""
        guard !automatic || mode == "calibration" else { throw LabError.message("Otomatik hesap yalnız kamera kalibrasyonunda kullanılabilir.") }
        let history = accepted(s)
        let needed = automatic ? Self.calibrationTarget(s) : mode == "trial" ? 1 : mode == "calibration" ? 10 : 12
        guard history.count >= needed else { throw LabError.message("En az \(needed) uygun ve farklı görüntü gerekli.") }
        if mode == "scan", (try views(s).values.min() ?? 0) < 4 { throw LabError.message("Her bayrak en az 4 farklı karede görünmeli; 8 ve üzeri önerilir.") }
        s["state"] = "processing"; s["message"] = "iPhone hesaplıyor. Uygulamayı açık tutun."; try save(s)
        do {
            if mode == "calibration" {
                let board = (s["board"] as? [String: Any]) ?? [:]
                let physical = (board["physical_measured"] as? Bool) ?? false
                let result = try DALNativeEngine.calibrate(corners: history.compactMap { $0["corners"] }, width: 1920, height: 1080,
                    squareMM: physical ? ((board["square_mm"] as? Double) ?? 0) : 1, physicalMeasured: physical, profile: (s["profile"] as? [String: Any]) ?? [:])
                if automatic {
                    let metadata = (result["metadata"] as? [String: Any]) ?? [:]
                    let warnings = (metadata["warnings"] as? [String]) ?? ["Kalibrasyon tanı bilgisi eksik."]
                    let rms = (metadata["rms_px"] as? Double) ?? .infinity
                    let retained = (metadata["views"] as? Int) ?? 0
                    if !warnings.isEmpty || !rms.isFinite || !(0...0.6).contains(rms) || retained < 10 {
                        var diagnostic: [String: Any] = ["warnings": warnings, "retained_views": retained]
                        if rms.isFinite { diagnostic["rms_px"] = rms }
                        for key in ["tilt_spread_deg", "input_views", "kept_view_indices", "rejected_view_indices", "per_view_rms_px"] {
                            diagnostic[key] = metadata[key]
                        }
                        return try continueCalibration(s, diagnostic: diagnostic)
                    }
                }
                s["calibration"] = result
                s.removeValue(forKey: "calibration_guidance"); s.removeValue(forKey: "calibration_diagnostic")
                s["calibration_paused"] = false
                let rms = ((result["metadata"] as? [String: Any])?["rms_px"] as? Double) ?? 0
                s["message"] = String(format: "Kalibrasyon iPhone'da tamamlandı: %.3f px. Bu değer mikron doğruluğu değildir.", rms)
            } else if mode == "scan" {
                guard let camera = s["camera"] as? [String: Any] else { throw LabError.message("Kamera kalibrasyonu eksik.") }
                let observations: [[String: Any]] = try Self.reconstructionObservations(history)
                var result = try DALNativeEngine.reconstruct(observations: observations, camera: camera, markerIDs: selectedIDs(s).map { NSNumber(value: $0) })
                if let plan = s["dental_plan"] as? [String: Any], let assignments = plan["assignments"] as? [[String: Any]], var markers = result["markers"] as? [[String: Any]] {
                    for i in markers.indices { if let a = assignments.first(where: { $0["marker_id"] as? Int == markers[i]["id"] as? Int }) { markers[i]["fdi"] = a["fdi"]; markers[i]["component_reference"] = a["component_code"] } }
                    result["markers"] = markers
                }
                if let imported = s["mua_calibration"] as? [String: Any] {
                    let calibration = try MUACalibration.load(JSONSerialization.data(withJSONObject: imported))
                    result = try calibration.apply(to: result)
                }
                result["physical_accuracy_um"] = NSNull(); s["result"] = result
                s["message"] = "3B hesap iPhone'da tamamlandı. Sonuç uyarılarını kontrol edin."
            } else {
                let markerIDs = try selectedIDs(s), count = markerIDs.count
                let counts = try views(s)
                let recognized = markerIDs.filter { counts[String($0), default: 0] > 0 }
                s["trial_summary"] = ["recognized_ids": recognized, "expected_count": count, "expected_marker_ids": markerIDs,
                    "accepted_frames": history.count, "metric": "identity_only_no_3d", "physical_accuracy_um": NSNull()] as [String: Any]
                s["message"] = "2B deneyi tamamlandı: \(recognized.count)/\(count) bayrak kaydedildi. Ekran görüntüsünden uzaysal konum hesaplanmaz."
            }
            s["state"] = "complete"; try save(s); return s
        } catch {
            if automatic && mode == "calibration" {
                return try continueCalibration(s, diagnostic: ["warnings": [], "error": error.localizedDescription])
            }
            s["state"] = "error"; s["message"] = "Hesap tamamlanamadı: \(error.localizedDescription)"; try save(s); throw error
        }
    }
    /// Report the optimizer's actual rejection, including at the frame limit.
    /// A numerical/data failure must not be disguised as insufficient board tilt.
    static func calibrationFailureMessage(_ diagnostic: [String: Any], count: Int) -> String {
        var lines = [count >= 60
            ? "60 görüntüde kalibrasyon tamamlanamadı; otomatik çekim durdu."
            : "Kalibrasyon henüz uygun değil; \(count) görüntü korunuyor."]
        let warnings = (diagnostic["warnings"] as? [String] ?? []).filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        if let error = diagnostic["error"] as? String, !error.isEmpty { lines.append("Hesaplama nedeni: \(error)") }
        if !warnings.isEmpty { lines.append("Ret nedeni: " + warnings.joined(separator: " ")) }
        if let rms = diagnostic["rms_px"] as? Double, rms.isFinite {
            lines.append(String(format: "Görüntü uyum hatası: %.3f px; kabul sınırı 0,600 px.", locale: Locale(identifier: "tr_TR"), rms))
        }
        if let retained = diagnostic["retained_views"] as? Int, retained < 10 {
            lines.append("Hesapta kalan uygun görüntü: \(retained); en az 10 gerekli.")
        }
        if warnings.contains("Tahta eğim çeşitliliği yetersiz.") {
            lines.append("Tahtayı sağa/sola ve yukarı/aşağı eğik gösterin; her açıda kısa süre durun.")
        }
        if warnings.contains("Tahtayı görüntünün farklı bölgelerinde gösterin.") {
            lines.append("Tahtanın tüm köşeleri görünürken kadrajın sol, sağ, üst ve alt bölgelerini kullanın.")
        }
        if warnings.contains("Kalibrasyon görüntü uyum hatası yüksek.") || ((diagnostic["rms_px"] as? Double) ?? 0) > 0.6 {
            lines.append("Tahtanın düzlüğünü ve görüntülerin netliğini kontrol edin; telefonu her örnekte kısa süre sabit tutun.")
        }
        if warnings.isEmpty && diagnostic["error"] == nil && diagnostic["rms_px"] == nil && diagnostic["retained_views"] == nil {
            lines.append("Hesap motoru ayrıntılı ret nedeni bildirmedi.")
        }
        if count >= 60 { lines.append("Kaydedilen kareler korunuyor. Yeni çekimden önce yukarıdaki ret nedenini kontrol edin.") }
        return lines.joined(separator: "\n")
    }
    private func continueCalibration(_ original: [String: Any], diagnostic: [String: Any]) throws -> [String: Any] {
        var state = original
        let count = accepted(state).count
        let paused = count >= 60
        state["state"] = "collecting"; state["next_calibration_target"] = min(60, max(20, ((count+4)/5)*5+5))
        state["calibration_paused"] = paused
        let text = Self.calibrationFailureMessage(diagnostic, count: count)
        state["calibration_guidance"] = text; state["calibration_diagnostic"] = diagnostic; state["message"] = text
        state.removeValue(forKey: "calibration"); state.removeValue(forKey: "result")
        try save(state); return state
    }
    func validateSynthetic() throws -> [String: Any] { try DALNativeEngine.validateSynthetic() }
}
