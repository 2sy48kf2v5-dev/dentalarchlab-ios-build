import CoreImage
import CoreVideo
import Foundation
import ImageIO
import UniformTypeIdentifiers

struct CameraPerformance: Equatable {
    static let targetFramesPerSecond = 30
    let framesPerSecond: Double?
    let droppedFrames: Int
    let encodingMilliseconds: Double?
}

// Sensor delivery rate is distinct from accepted scan/analysis rate. Reporting
// uses a monotonic clock, and is limited to one update per second.
struct CameraPerformanceMeter {
    private var firstTimestamp: Double?
    private var lastTimestamp: Double?
    private var lastPublication: Double?
    private var intervals = 0
    private var drops = 0
    private var encodingMilliseconds: Double?

    mutating func recordDrop() { drops += 1 }
    mutating func recordEncoding(seconds: Double) {
        guard seconds.isFinite, seconds >= 0, (seconds * 1_000).isFinite else { return }
        encodingMilliseconds = seconds * 1_000
    }
    mutating func observe(timestamp: Double, now: Double) -> CameraPerformance? {
        guard timestamp.isFinite, timestamp >= 0, now.isFinite, now >= 0 else { return nil }
        if let previous = lastTimestamp {
            if timestamp > previous { intervals += 1; lastTimestamp = timestamp }
            else if timestamp < previous { firstTimestamp = timestamp; lastTimestamp = timestamp; intervals = 0 }
        } else { firstTimestamp = timestamp; lastTimestamp = timestamp }
        guard let published = lastPublication else { lastPublication = now; return nil }
        guard now - published >= 1 else { return nil }
        let elapsed = (lastTimestamp ?? timestamp) - (firstTimestamp ?? timestamp)
        let fps = elapsed > 0 && intervals > 0 ? Double(intervals) / elapsed : nil
        let value = CameraPerformance(framesPerSecond: fps?.isFinite == true ? fps : nil,
                                      droppedFrames: drops, encodingMilliseconds: encodingMilliseconds)
        lastPublication = now; firstTimestamp = lastTimestamp; intervals = 0
        return value
    }
}

struct CameraFrameTicket: Equatable {
    let generation: Int
    let request: Int
}

// Cancelled work retains its slot until the worker really returns. A stop or
// timeout must not allow an unbounded queue of retained full-resolution frames.
struct CameraFrameWorkGate {
    private var inFlight: CameraFrameTicket?
    private var deliverable = false
    var isIdle: Bool { inFlight == nil }
    mutating func begin(_ ticket: CameraFrameTicket) -> Bool {
        guard inFlight == nil else { return false }
        inFlight = ticket; deliverable = true; return true
    }
    mutating func cancel() { deliverable = false }
    mutating func finish(_ ticket: CameraFrameTicket) -> Bool {
        guard inFlight == ticket else { return false }
        let allowed = deliverable
        inFlight = nil; deliverable = false
        return allowed
    }
}

// Copy only the requested frame out of AVFoundation's pool, then compress on a
// separate serial worker. No resizing, cropping, pixel-format substitution or
// lossy measurement conversion is performed.
final class CameraFrameEncoder {
    private let context = CIContext()

    static func copyPixels(_ source: CVPixelBuffer) throws -> CVPixelBuffer {
        guard CVPixelBufferGetPixelFormatType(source) == kCVPixelFormatType_32BGRA,
              !CVPixelBufferIsPlanar(source) else {
            throw LabError.message("Kamera piksel biçimi BGRA ile eşleşmiyor.")
        }
        let width = CVPixelBufferGetWidth(source), height = CVPixelBufferGetHeight(source)
        guard width > 0, height > 0, width <= 1920, height <= 1080 else {
            throw LabError.message("Kamera karesinin boyutu desteklenmiyor.")
        }
        var copy: CVPixelBuffer?
        let attributes: [String: Any] = [kCVPixelBufferCGImageCompatibilityKey as String: true,
                                         kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
                                         kCVPixelBufferIOSurfacePropertiesKey as String: [:]]
        guard CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
                                  attributes as CFDictionary, &copy) == kCVReturnSuccess, let copy else {
            throw LabError.message("Kamera karesi için bellek ayrılamadı.")
        }
        guard CVPixelBufferLockBaseAddress(source, .readOnly) == kCVReturnSuccess else {
            throw LabError.message("Kamera piksel verisi okunamadı.")
        }
        defer { CVPixelBufferUnlockBaseAddress(source, .readOnly) }
        guard CVPixelBufferLockBaseAddress(copy, []) == kCVReturnSuccess else {
            throw LabError.message("Kamera kopyası hazırlanamadı.")
        }
        defer { CVPixelBufferUnlockBaseAddress(copy, []) }
        guard let sourceBase = CVPixelBufferGetBaseAddress(source),
              let copyBase = CVPixelBufferGetBaseAddress(copy) else {
            throw LabError.message("Kamera piksel belleği bulunamadı.")
        }
        let sourceStride = CVPixelBufferGetBytesPerRow(source), copyStride = CVPixelBufferGetBytesPerRow(copy)
        let rowBytes = width * 4
        guard sourceStride >= rowBytes, copyStride >= rowBytes else { throw LabError.message("Kamera piksel satırı geçersiz.") }
        for row in 0..<height {
            copyBase.advanced(by: row * copyStride).copyMemory(from: sourceBase.advanced(by: row * sourceStride), byteCount: rowBytes)
        }
        CVBufferPropagateAttachments(source, copy)
        return copy
    }

    func encode(_ pixels: CVPixelBuffer, compactTrial: Bool) throws -> Data {
        try autoreleasepool {
            let ci = CIImage(cvPixelBuffer: pixels)
            guard let cg = context.createCGImage(ci, from: ci.extent) else { throw LabError.message("Görüntü oluşturulamadı.") }
            let bytes = NSMutableData()
            guard let target = CGImageDestinationCreateWithData(bytes, (compactTrial ? UTType.jpeg : UTType.png).identifier as CFString, 1, nil) else {
                throw LabError.message("Görüntü kodlayıcı açılamadı.")
            }
            let properties: CFDictionary? = compactTrial ? [kCGImageDestinationLossyCompressionQuality: 0.94] as CFDictionary : nil
            CGImageDestinationAddImage(target, cg, properties)
            guard CGImageDestinationFinalize(target) else { throw LabError.message("Görüntü kodlama tamamlanamadı.") }
            return bytes as Data
        }
    }
}
