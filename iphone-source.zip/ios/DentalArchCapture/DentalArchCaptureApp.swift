import AVFoundation
import SwiftUI
import UIKit
import UniformTypeIdentifiers

@main struct DentalArchCaptureApp: App {
    @StateObject private var model = CaptureModel()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            CaptureHome().environmentObject(model).tint(Color(red: 0.03, green: 0.5, blue: 0.48))
                .onChange(of: phase) { _, value in
                    if value == .background { model.stopCamera() }
                    else if value == .active { Task { await model.sendPending() } }
                }
        }
    }
}

struct CaptureHome: View {
    @EnvironmentObject var model: CaptureModel
    @State private var tab = 0
    @State private var importingMUA = false
    @State private var importError: String?
    private var working: Bool { model.busy || model.computing || model.analyzing || model.uploading }
    var body: some View {
        TabView(selection: $tab) {
            NavigationStack {
                Form {
                    Section {
#if DEBUG
                        if ProcessInfo.processInfo.arguments.contains("--ui-testing"),
                           ProcessInfo.processInfo.arguments.contains("--ui-tissue-test") {
                            NavigationLink("Sentetik doku UI testi") { TissueAlignmentTestHost() }
                                .accessibilityIdentifier("openTissueTest")
                        }
#endif
                        Text("Modelini hazırla. Taramayı başlat.").font(.title2.bold())
                        Label("iPhone üzerinde · Çevrimdışı", systemImage: "cpu")
                            .font(.subheadline.bold()).foregroundStyle(.teal).accessibilityIdentifier("offlineEngineStatus")
                        Text("Kamera, bayrak tanıma ve 3B hesap bu telefonda çalışır.").font(.footnote).foregroundStyle(.secondary)
                        Button { model.showIllustration(); tab = 2 } label: {
                            Label("Bağlantısız 3B örneği aç", systemImage: "cube.transparent")
                        }.accessibilityIdentifier("openIllustration").disabled(working)
                        Button { Task { await model.runNativeValidation() } } label: {
                            Label("Hesap motorunu test et", systemImage: "checkmark.seal")
                        }.accessibilityIdentifier("runNativeValidation").disabled(working || model.ready || model.autoRunning)
                        if let report = model.validationText {
                            Text(report).font(.caption.monospaced()).textSelection(.enabled)
                                .accessibilityIdentifier("nativeValidationReport")
                        }
                        Text("Motor testi sentetik görüntülerle hesaplamayı sınar. Fiziksel ölçüm doğruluğunu belirlemez.").font(.caption).foregroundStyle(.secondary)
                    }
                    Section("Tarama adımları") {
                        Button { model.mode = "calibration"; tab = 1 } label: {
                            Label("1. Kamerayı kalibre et", systemImage: "checkerboard.rectangle")
                        }.accessibilityIdentifier("startCalibration").disabled(working || model.currentID != nil || model.ready)
                        NavigationLink { DentalPlanView() } label: {
                            Label("2. Diş seçimi · FDI planı", systemImage: "square.grid.3x3")
                        }.accessibilityIdentifier("openDentalPlan")
                        Button { model.mode = "scan"; tab = 1 } label: {
                            Label("3. Bayrakları tara", systemImage: "viewfinder")
                        }.accessibilityIdentifier("startResearchScan").disabled(working || model.currentID != nil || model.ready || model.calibrationID.isEmpty)
                        Text(model.calibrationID.isEmpty ? "3B tarama için aşağıdan ölçülmüş fiziksel kalibrasyon kaydını seç." : "Seçilen kalibrasyonla farklı açılardan tarama yap; sonucu telefonda incele.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Section("Yakın çekim ve kamera") {
                        if (model.mode == "trial" || model.mode == "calibration"), model.currentID == nil,
                           !model.ready, !model.cameraStarting {
                            Picker("Lens tercihi", selection: $model.cameraOpticsChoice) {
                                Text("Yakın çekim").tag("closeUp")
                                Text("Standart").tag("standard")
                            }.pickerStyle(.segmented).disabled(working)
                                .accessibilityIdentifier("cameraOpticsPicker")
                            Text("Yakın çekim, desteklenen ultra geniş lensi kullanır. Netlik ve kullanılabilir çözünürlük kamera açıldığında kontrol edilir. Hedefi ortala; sonra kamerayı aç.")
                                .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("cameraOpticsPreferenceHelp")
                        } else {
                            Text("Lens ve kayıt biçimi korunuyor. 3B tarama seçilen kalibrasyonun kamerasını kullanır.")
                                .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("cameraOpticsLocked")
                        }
                        Text("Lens değiştirince yeni kalibrasyon gerekir. Yakın çekim de her uzaklıkta netlik sağlamaz; tarama boyunca aynı odak korunur.")
                            .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("homeOpticsCalibrationScope")
                    }
                    Section("FDI ve parça planı") {
                        Text("MegaGen · \(model.plan.assignments.first?.componentCode ?? "MG-MUASBU")").font(.subheadline.bold())
                        Text("Vida Dental Multi 9 mm kütüphanesi tanımlandı. Doku birleştirme ve Exocad aktarımı, 3B sonuç ekranından açılır.").font(.caption).foregroundStyle(.secondary)
                    }
                    Section("Bayrak–MUA kalibrasyonu") {
                        Text(model.muaCalibration == nil ? "Ölçülmüş bağlantı dönüşümü yok" : "Ölçülmüş bağlantı dosyası hazır")
                        Button("Ölçüm JSON dosyasını içe aktar") { importingMUA = true }
                            .accessibilityIdentifier("importMUACalibration")
                        if model.muaCalibration != nil {
                            Button("Yeni taramada bağlantı dosyasını kullanma") { model.clearMUACalibration() }
                        }
                        Text("Referans cihazla ölçülen bayrak merkezinden MUA'ya dönüşümü kullanır. Seri numaraları fiziksel bayraklarla eşleşmeli. Dosya doğrulaması klinik doğruluk onayı değildir.").font(.caption).foregroundStyle(.secondary)
                        if let importError { Text(importError).font(.caption).foregroundStyle(.orange) }
                    }.disabled(working || model.currentID != nil || model.ready)
                    Section("Kamera kalibrasyonu") {
                        if model.availableCalibrations.isEmpty {
                            Label("Tamamlanmış fiziksel kalibrasyon yok", systemImage: "checkerboard.rectangle")
                                .font(.subheadline).accessibilityIdentifier("noLocalCalibration")
                            Text("Ölçülmüş düz tahta ile kalibrasyon çekimini tamamla. Ekrandaki tahta, görüntü alma denemesi içindir.")
                                .font(.caption).foregroundStyle(.secondary)
                        } else {
                            Menu {
                                ForEach(model.availableCalibrations) { capture in
                                    Button {
                                        model.chooseCalibration(capture)
                                    } label: {
                                        Text("\(capture.created.formatted(date: .abbreviated, time: .shortened)) · \(capture.acceptedCount) kare")
                                    }
                                }
                            } label: {
                                Label(model.calibrationID.isEmpty ? "Kalibrasyon seç" : "Kalibrasyon seçildi · değiştir", systemImage: "checkmark.circle")
                            }.accessibilityIdentifier("chooseLocalCalibration")
                            if let selected = model.availableCalibrations.first(where: { $0.id == model.calibrationID }) {
                                Text("\(selected.created.formatted(date: .abbreviated, time: .shortened)) · Odak \(String(format: "%.3f", selected.creation.profile.lensPosition))")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }.disabled(working || model.currentID != nil || model.ready)
                    Section("Deney ayarları") {
                        Picker("Çalışma", selection: $model.mode) {
                            Text("Bayrak deneyi (2B)").tag("trial")
                            Text("Kamera kalibrasyonu").tag("calibration")
                            Text("Araştırma taraması (3B)").tag("scan")
                        }
                        Picker("Bayrak sayısı", selection: $model.markerCount) { Text("4").tag(4); Text("6").tag(6) }.pickerStyle(.segmented)
                            .onChange(of: model.markerCount) { _, count in if model.currentID == nil { model.plan.reset(count: count) } }
                        if model.mode == "calibration" {
                            Text("Çekimde Kalibrasyon taramasını başlat'a basın. Farklı açılardan 20 uygun kare otomatik toplanır ve hesaplanır; gerekirse ek açılar istenir.")
                                .font(.caption).accessibilityIdentifier("automaticCalibrationHomeHint")
                            Toggle("Fiziksel tahta boyutunu ölçtüm", isOn: $model.physicalBoard)
                            if model.physicalBoard { TextField("Kare kenarı (mm)", text: $model.squareMM).keyboardType(.decimalPad) }
                            Text("9 × 6 iç köşe. Ekran veya iPhone Ölçüm uygulaması ölçüsü, doğrulanmış fiziksel tahta boyutu sayılmaz.").font(.caption)
                        }
                        if model.mode == "scan" {
                            Text("3B konum için gerçek, sabit bayrakları farklı açılardan tara. Bilgisayar ekranındaki sanal ağız için Bayrak deneyi (2B) seç; resimdeki derinlik fiziksel konum olarak ölçülemez.")
                                .font(.caption).accessibilityIdentifier("physicalScanSourceHint")
                            Text("Seçtiğin kalibrasyonun odak, kamera biçimi ve çözünürlüğü korunur. MUA bağlantısı ölçülmediyse MUA merkezi üretilmez.").font(.caption)
                        }
                    }.disabled(model.currentID != nil || model.ready || model.busy || model.computing)
                    Section {
                        Button("Çekime geç") { tab = 1 }.accessibilityIdentifier("openCapture")
                        Button("Yeni kayıt hazırla") { model.newSession() }.disabled(model.busy || model.computing || model.analyzing || model.uploading)
                    }
                    Section("Durum") { Text(model.status).font(.callout).accessibilityLabel("Durum: " + model.status) }
                    Section { Text("Fiziksel doğruluk henüz ölçülmedi. Klinik kullanım için doğrulanmadı.").font(.footnote).foregroundStyle(.secondary) }
                    Section("Bu uygulama ne yapıyor?") {
                        Text("Sabit odakta görüntü kaydeder; kalibrasyon, DAL bayrak tanıma ve fotogrametri hesabını iPhone üzerinde yapar. Kayıtlar ve sonuçlar telefonda saklanır. CSV, JSON ve araştırma amaçlı 3B dosyalar paylaşılabilir.")
                        Text("PIC/iMetric'in özel markerları veya kodu kullanılmaz. DAL bayrakları ve gerçek ölçülmüş kamera/bağlantı kalibrasyonu gerekir.")
                        Text("Sürüm \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—") · iPhone hesap motoru · Araştırma prototipi").foregroundStyle(.secondary)
                        NavigationLink("Açık kaynak bildirimleri") {
                            LicenseNoticesView()
                        }
                    }.font(.footnote)
                }.navigationTitle("DentalArchLab")
            }.tabItem { Label("Başlangıç", systemImage: "square.grid.2x2") }.tag(0)
            NavigationStack {
                LiveCaptureView { Task { await model.finish(); if model.current?.state != "collecting" { tab = 2 } } }
            }.tabItem { Label("Çekim", systemImage: "camera") }.tag(1)
            NavigationStack { NativeResultsView() }.tabItem { Label("Sonuç", systemImage: "cube.transparent") }.tag(2)
            NavigationStack {
                List {
                    if model.sessions.isEmpty { Text("Henüz kayıt yok.").foregroundStyle(.secondary) }
                    ForEach(model.sessions) { capture in
                        Button {
                            model.select(capture); tab = capture.state == "collecting" && capture.engine != nil ? 1 : 2
                            if capture.state != "collecting" || capture.engine == nil { Task { await model.refreshResult() } }
                        } label: {
                            VStack(alignment: .leading, spacing: 7) {
                                Text(capture.creation.mode == "calibration" ? "Kalibrasyon" : capture.creation.mode == "scan" ? "Araştırma taraması" : "Bayrak deneyi").font(.headline)
                                Text(capture.created.formatted(date: .abbreviated, time: .shortened)).font(.caption)
                                Text("\(capture.acceptedCount) uygun · \(capture.pending.count) işlenecek kare").font(.caption)
                                if capture.engine == nil {
                                    Text("Önceki sürüm kaydı").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }.disabled(model.busy || model.computing || model.analyzing || model.uploading)
                    }
                    Text("Orijinal PNG dosyaları Dosyalar > iPhone'umda > DentalArchLab > Captures içinde korunur.").font(.footnote).foregroundStyle(.secondary)
                }.navigationTitle("Kayıtlar")
            }.tabItem { Label("Kayıtlar", systemImage: "folder") }.tag(3)
        }.onChange(of: tab) { _, next in
            if next != 1 { model.leaveCaptureScreen(showingCompletedResult: next == 2) }
        }
            .onChange(of: model.current?.state) { _, state in
                if (state == "complete" || state == "error"), tab == 1 { tab = 2 }
            }
            .fileImporter(isPresented: $importingMUA, allowedContentTypes: [.json]) { result in
                do { let url = try result.get(); importError = nil; model.importMUACalibration(url) }
                catch { importError = error.localizedDescription }
            }
    }
}

/// Keep the large bundled notices out of the home form's body evaluation.
/// The file read and text layout start only when this destination appears.
struct LicenseNoticesView: View {
    @State private var licenseText: String?

    var body: some View {
        ScrollView {
            if let licenseText {
                Text(licenseText).font(.caption.monospaced()).textSelection(.enabled).padding()
            } else {
                ProgressView("Bildirimler yükleniyor…").padding()
            }
        }.navigationTitle("Lisanslar")
            .onAppear {
                guard licenseText == nil else { return }
                let notices = ["OPENCV-LICENSE", "THIRD-PARTY-NOTICES"].compactMap { name -> String? in
                    guard let url = Bundle.main.url(forResource: name, withExtension: "txt") else { return nil }
                    return try? String(contentsOf: url, encoding: .utf8)
                }.joined(separator: "\n\n")
                licenseText = notices.isEmpty ? "Lisans bildirimleri okunamadı." : notices
            }
    }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var preview: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView(); view.preview.session = session; view.preview.videoGravity = .resizeAspect
        return view
    }
    func updateUIView(_ uiView: PreviewView, context: Context) {
        // Preview orientation only; stored PNG pixels retain the sensor coordinate system.
        if let connection = uiView.preview.connection, connection.isVideoRotationAngleSupported(90) { connection.videoRotationAngle = 90 }
    }
}
