import AVFoundation
import SwiftUI
import UIKit
import UniformTypeIdentifiers

@main struct DentalArchCaptureApp: App {
    @UIApplicationDelegateAdaptor(DentalOrientationDelegate.self) private var appDelegate
    @StateObject private var model = CaptureModel()
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            CaptureHome().environmentObject(model).tint(Color(red: 0.03, green: 0.5, blue: 0.48))
                .onChange(of: phase) { _, value in
                    if value == .background { model.stopCamera() }
                    else if value == .active { Task { await model.sendPending() } }
                }
        }
    }
}

struct CaptureHome: View {
    @EnvironmentObject var model: CaptureModel
    @State private var tab = 0
    @State private var importingMUA = false
    @State private var importError: String?
    private var working: Bool { model.busy || model.computing || model.analyzing || model.uploading }
    private var appVersion: String {
        guard let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String else { return "bilinmiyor" }
        return version
    }
    private var setupLocked: Bool { working || model.currentID != nil || model.cameraVisible || model.cameraStarting }
    @State private var homePath: [HomeDestination] = []
    @FocusState private var referenceFocused: Bool
    private enum HomeDestination: Hashable { case settings, plan }
    private let ink = Color(red: 0.08, green: 0.11, blue: 0.13)
    private let accent = Color(red: 0.03, green: 0.5, blue: 0.48)

    private var homeHeader: some View {
        HStack(spacing: 10) {
            DALHomeMark().frame(width: 35, height: 35).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 3) {
                Text("DentalArchLab").font(.system(size: 19, weight: .bold, design: .rounded))
                Text("Sürüm \(appVersion)").font(.caption2).foregroundStyle(.secondary)
            }
            Spacer()
            NavigationLink(value: HomeDestination.settings) {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 19, weight: .medium))
                    .frame(width: 46, height: 46)
                    .background(ink.opacity(0.045), in: Circle())
            }.buttonStyle(.plain).accessibilityLabel("Ayarlar ve araçlar")
                .accessibilityIdentifier("openHomeSettings")
        }
    }

    private func selectArch(_ arch: String) {
        guard !setupLocked else { return }
        referenceFocused = false
        guard model.plan.arch != arch else { return }
        model.plan.arch = arch
        try? model.plan.reset(markerIDs: model.plan.markerIDs)
    }

    private func archChoice(_ arch: String, title: String) -> some View {
        let selected = model.plan.arch == arch
        return Button { selectArch(arch) } label: {
            HStack(spacing: 8) {
                HomeArchGlyph(upper: arch == "upper")
                    .frame(width: 30, height: 29).accessibilityHidden(true)
                Text(title).font(.system(size: 14, weight: .semibold)).lineLimit(1).minimumScaleFactor(0.8)
                Spacer(minLength: 0)
            }.padding(.horizontal, 13).frame(maxWidth: .infinity, minHeight: 65)
                .foregroundStyle(selected ? Color.white : ink)
                .background(selected ? ink : Color.white, in: RoundedRectangle(cornerRadius: 17))
                .overlay { RoundedRectangle(cornerRadius: 17).strokeBorder(selected ? ink : ink.opacity(0.13), lineWidth: 1) }
                .contentShape(RoundedRectangle(cornerRadius: 17))
        }.buttonStyle(.plain).disabled(setupLocked)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(title).accessibilityValue(selected ? "Seçili" : "Seçili değil")
            .accessibilityAddTraits(selected ? [.isButton, .isSelected] : [.isButton])
            .accessibilityAction { selectArch(arch) }
            .accessibilityIdentifier(arch == "upper" ? "homeArchUpper" : "homeArchLower")
    }

    private var caseSetup: some View {
        VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 7) {
                Text("Model / vaka referansı").font(.caption.weight(.semibold)).foregroundStyle(.secondary)
                TextField("Örnek: MODEL-04 · isteğe bağlı", text: Binding(
                    get: { model.caseReference }, set: { model.caseReference = String($0.prefix(80)) }))
                    .font(.body).textInputAutocapitalization(.characters).autocorrectionDisabled()
                    .focused($referenceFocused).submitLabel(.done).onSubmit { referenceFocused = false }
                    .padding(.vertical, 10)
                    .disabled(setupLocked).accessibilityIdentifier("caseReferenceField")
                Rectangle().fill(ink.opacity(0.18)).frame(height: 1)
            }
            HStack(spacing: 10) {
                archChoice("upper", title: "Üst çene")
                archChoice("lower", title: "Alt çene")
            // Give the group its own accessibility node so its identifier
            // cannot replace the identifiers of the two actionable choices.
            }.accessibilityElement(children: .contain).accessibilityIdentifier("homeArchPicker")
            HStack {
                Label("Bayrak sayısı", systemImage: "circle.grid.2x2")
                    .font(.subheadline.weight(.medium))
                Spacer()
                Picker("Bayrak sayısı", selection: $model.markerCount) {
                    Text("4").tag(4); Text("6").tag(6)
                }.pickerStyle(.segmented).frame(width: 118).disabled(setupLocked)
                    .accessibilityIdentifier("homeMarkerCount")
                    .onChange(of: model.markerCount) { _, count in
                        guard !setupLocked else { return }; model.plan.reset(count: count)
                    }
            }
            NavigationLink(value: HomeDestination.plan) {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Takılı bayraklar ve FDI").font(.subheadline.weight(.semibold))
                        Text("ID " + model.plan.markerIDs.map(String.init).joined(separator: " · "))
                            .font(.caption.monospaced()).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").font(.caption.weight(.semibold))
                }.padding(.vertical, 3).contentShape(Rectangle())
            }.buttonStyle(.plain).accessibilityIdentifier("openDentalPlan")
        }.padding(20).background(ink.opacity(0.035), in: RoundedRectangle(cornerRadius: 24))
    }

    private var primaryCaseAction: some View {
        VStack(spacing: 10) {
            if model.currentID == nil {
                Button {
                    referenceFocused = false
                    model.prepareMacroXYZ(); tab = 1
                } label: {
                    HStack {
                        Spacer()
                        Text("Taramayı başlat").font(.headline)
                        Spacer()
                        Image(systemName: "arrow.right").font(.headline)
                    }.padding(.horizontal, 22).frame(maxWidth: .infinity, minHeight: 58)
                }.buttonStyle(.plain).foregroundStyle(.white)
                    .background(ink, in: Capsule())
                    .accessibilityIdentifier("startResearchScan").disabled(setupLocked).opacity(setupLocked ? 0.45 : 1)
                Text("Yakın çekim kalibrasyonu yoksa önce kalibrasyon açılır.")
                    .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
            } else {
                Button { referenceFocused = false; tab = model.current?.state == "collecting" ? 1 : 2 } label: {
                    HStack {
                        Text(model.current?.state == "collecting" ? "Kayda devam et" : "Sonucu aç")
                        Spacer(); Image(systemName: "arrow.right")
                    }.font(.headline).padding(.horizontal, 22).frame(maxWidth: .infinity, minHeight: 58)
                }.buttonStyle(.plain).foregroundStyle(.white).background(ink, in: Capsule())
                    .disabled(working).accessibilityIdentifier("resumeCurrentCapture")
                Button { model.newSession() } label: {
                    Label("Yeni vaka başlat", systemImage: "plus").font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 44)
                }.buttonStyle(.plain).foregroundStyle(accent).disabled(working)
                    .accessibilityIdentifier("newCase")
            }
        }
    }

    private var homePage: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 21) {
                homeHeader
                VStack(alignment: .leading, spacing: 7) {
                    Text(model.currentID == nil ? "Yeni vaka" : "Mevcut vaka")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                    Text(model.currentID == nil ? "Çeneyi seç. Bayrakları hazırla." : "Kaydına devam et veya yeni bir vaka aç.")
                        .font(.subheadline).foregroundStyle(.secondary)
                }.padding(.top, 3)
                caseSetup
                primaryCaseAction
                HStack(spacing: 12) {
                    Button { referenceFocused = false; model.selectWorkMode("calibration"); tab = 1 } label: {
                        Label("Kalibrasyon", systemImage: "checkerboard.rectangle")
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }.accessibilityIdentifier("startCalibration").disabled(setupLocked)
                    Rectangle().fill(ink.opacity(0.12)).frame(width: 1, height: 22)
                    Button { referenceFocused = false; model.selectWorkMode("trial"); tab = 1 } label: {
                        Label("2B deneme", systemImage: "viewfinder")
                            .frame(maxWidth: .infinity, minHeight: 44)
                    }.accessibilityIdentifier("startTrialExperiment").disabled(setupLocked)
                }.font(.subheadline.weight(.medium)).buttonStyle(.plain)
                VStack(spacing: 6) {
                    Label("iPhone üzerinde · Çevrimdışı", systemImage: "iphone")
                        .font(.caption.weight(.medium)).accessibilityIdentifier("offlineEngineStatus")
                    Text("Araştırma prototipi · Klinik kullanım için doğrulanmadı.")
                        .font(.caption2).multilineTextAlignment(.center)
                }.foregroundStyle(.secondary).frame(maxWidth: .infinity)
            }.padding(.horizontal, 24).padding(.top, 12).padding(.bottom, 22)
                .frame(maxWidth: 560).frame(maxWidth: .infinity)
        }.scrollDismissesKeyboard(.interactively)
            .background(Color.white).foregroundStyle(ink).preferredColorScheme(.light)
            .toolbar(.hidden, for: .navigationBar)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer(); Button("Tamam") { referenceFocused = false }
                }
            }
            .accessibilityIdentifier("caseHome")
    }

    private var settingsPage: some View {
        Form {
            Section {
    #if DEBUG
                if ProcessInfo.processInfo.arguments.contains("--ui-testing"),
                   ProcessInfo.processInfo.arguments.contains("--ui-tissue-test") {
                    NavigationLink("Sentetik doku UI testi") { TissueAlignmentTestHost() }
                        .accessibilityIdentifier("openTissueTest")
                }
    #endif
                Text("Kamera, bayrak tanıma ve 3B hesap bu telefonda çalışır.").font(.footnote).foregroundStyle(.secondary)
                Button { model.showIllustration(); tab = 2 } label: {
                    Label("Bağlantısız 3B örneği aç", systemImage: "cube.transparent")
                }.accessibilityIdentifier("openIllustration").disabled(working)
                Button { Task { await model.runNativeValidation() } } label: {
                    Label("Hesap motorunu test et", systemImage: "checkmark.seal")
                }.accessibilityIdentifier("runNativeValidation").disabled(working || model.cameraVisible || model.autoRunning)
                if let report = model.validationText {
                    Text(report).font(.caption.monospaced()).textSelection(.enabled)
                        .accessibilityIdentifier("nativeValidationReport")
                }
                Text("Motor testi sentetik görüntülerle hesaplamayı sınar. Fiziksel ölçüm doğruluğunu belirlemez.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Kalibrasyon ve deneme") {
                Button { model.selectWorkMode("calibration"); tab = 1 } label: {
                    Label("Kamerayı kalibre et", systemImage: "checkerboard.rectangle")
                }.accessibilityIdentifier("startCalibration").disabled(working || model.currentID != nil || model.cameraVisible)
                Button { model.selectWorkMode("trial"); tab = 1 } label: {
                    Label("Bayrak tanımayı dene · 2B", systemImage: "circle.dotted")
                }.accessibilityIdentifier("startTrialExperiment").disabled(setupLocked)
                Text("XYZ taraması yakın çekim kalibrasyonunu kullanır. Uygun ultra geniş lens kalibrasyonu yoksa önce kalibrasyon adımı açılır.")
                    .font(.caption).foregroundStyle(.secondary)
                DisclosureGroup("Taramadan önce") {
                    Label("Dört beyaz nokta kameraya dönük ve açıkta olsun.", systemImage: "circle.grid.2x2")
                    Label("Model sabit kalsın; telefonu yavaşça farklı açılara taşı.", systemImage: "move.3d")
                    Label("3B taramada en az iki bayrak birlikte görünsün.", systemImage: "viewfinder")
                }.font(.caption).accessibilityIdentifier("scanPreparationTips")
            }
            Section("Yakın çekim ve kamera") {
                if (model.mode == "trial" || model.mode == "calibration"), model.currentID == nil,
                   !model.cameraVisible, !model.cameraStarting {
                    Picker("Lens tercihi", selection: $model.cameraOpticsChoice) {
                        Text("Yakın çekim").tag("closeUp")
                        Text("Standart").tag("standard")
                    }.pickerStyle(.segmented).disabled(working || model.macroXYZRequested)
                        .accessibilityIdentifier("cameraOpticsPicker")
                    if model.macroXYZRequested {
                        Text("XYZ için yakın çekim lensi seçildi.").font(.caption.bold())
                    }
                    Text("Yakın çekim, desteklenen ultra geniş lensi kullanır. Netlik ve kullanılabilir çözünürlük kamera açıldığında kontrol edilir. Kamerayı aç, hedefi netleştir; sonra taramayı başlat.")
                        .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("cameraOpticsPreferenceHelp")
                } else {
                    Text("Lens ve kayıt biçimi korunuyor. 3B tarama seçilen kalibrasyonun kamerasını kullanır.")
                        .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("cameraOpticsLocked")
                }
                Text("Lens değiştirince yeni kalibrasyon gerekir. Yakın çekim de her uzaklıkta netlik sağlamaz; tarama boyunca aynı odak korunur.")
                    .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("homeOpticsCalibrationScope")
            }
            Section("FDI ve parça planı") {
                Text("MegaGen · \(model.plan.assignments.first?.componentCode ?? "MG-MUASBU")").font(.subheadline.bold())
                Text("Vida Dental Multi 9 mm kütüphanesi tanımlandı. Doku birleştirme ve Exocad aktarımı, 3B sonuç ekranından açılır.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Bayrak–MUA kalibrasyonu") {
                Text(model.muaCalibration == nil ? "Ölçülmüş bağlantı dönüşümü yok" : "Ölçülmüş bağlantı dosyası hazır")
                Button("Ölçüm JSON dosyasını içe aktar") { importingMUA = true }
                    .accessibilityIdentifier("importMUACalibration")
                if model.muaCalibration != nil {
                    Button("Yeni taramada bağlantı dosyasını kullanma") { model.clearMUACalibration() }
                }
                Text("Referans cihazla ölçülen bayrak merkezinden MUA'ya dönüşümü kullanır. Seri numaraları fiziksel bayraklarla eşleşmeli. Dosya doğrulaması klinik doğruluk onayı değildir.").font(.caption).foregroundStyle(.secondary)
                if let importError { Text(importError).font(.caption).foregroundStyle(.orange) }
            }.disabled(working || model.currentID != nil || model.cameraVisible)
            Section("Kamera kalibrasyonu") {
                if model.availableCalibrations.isEmpty {
                    Label("Tamamlanmış fiziksel kalibrasyon yok", systemImage: "checkerboard.rectangle")
                        .font(.subheadline).accessibilityIdentifier("noLocalCalibration")
                    Text("Ölçülmüş düz tahta ile kalibrasyon çekimini tamamla. Ekrandaki tahta, görüntü alma denemesi içindir.")
                        .font(.caption).foregroundStyle(.secondary)
                } else {
                    Menu {
                        ForEach(model.availableCalibrations) { capture in
                            Button {
                                model.chooseCalibration(capture)
                            } label: {
                                Text("\(capture.creation.profile.lens == "ultrawide" ? "Yakın çekim" : "Geniş lens") · \(capture.created.formatted(date: .abbreviated, time: .shortened)) · \(capture.acceptedCount) kare")
                            }
                        }
                    } label: {
                        Label(model.calibrationID.isEmpty ? "Kalibrasyon seç" : "Kalibrasyon seçildi · değiştir", systemImage: "checkmark.circle")
                    }.accessibilityIdentifier("chooseLocalCalibration")
                    if let selected = model.availableCalibrations.first(where: { $0.id == model.calibrationID }) {
                        Text("\(selected.creation.profile.lens == "ultrawide" ? "Yakın çekim · ultra geniş" : "Geniş lens") · \(selected.created.formatted(date: .abbreviated, time: .shortened)) · Odak \(String(format: "%.3f", selected.creation.profile.lensPosition))")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
            }.disabled(working || model.currentID != nil || model.cameraVisible)
            Section("Deney ayarları") {
                Picker("Çalışma", selection: Binding(get: { model.mode }, set: { model.selectWorkMode($0) })) {
                    Text("Bayrak deneyi (2B)").tag("trial")
                    Text("Kamera kalibrasyonu").tag("calibration")
                    Text("Araştırma taraması (3B)").tag("scan")
                }
                Picker("Bayrak sayısı", selection: $model.markerCount) { Text("4").tag(4); Text("6").tag(6) }.pickerStyle(.segmented)
                    .onChange(of: model.markerCount) { _, count in if model.currentID == nil { model.plan.reset(count: count) } }
                Text("Seçili bayrak ID'leri: " + model.plan.markerIDs.map(String.init).joined(separator: ", "))
                    .font(.caption).accessibilityIdentifier("homeSelectedMarkerIDs")
                if model.markerCount == 4 {
                    NavigationLink("Takılı dört bayrağın ID'lerini seç") { DentalPlanView() }
                        .accessibilityIdentifier("editPhysicalMarkerIDs")
                }
                if model.mode == "calibration" {
                    Text("Çekimde Kalibrasyon taramasını başlat'a basın. Farklı açılardan 20 uygun kare otomatik toplanır ve hesaplanır; gerekirse ek açılar istenir.")
                        .font(.caption).accessibilityIdentifier("automaticCalibrationHomeHint")
                    Toggle("Fiziksel tahta boyutunu ölçtüm", isOn: $model.physicalBoard)
                    if model.physicalBoard { TextField("Kare kenarı (mm)", text: $model.squareMM).keyboardType(.decimalPad) }
                    Text("9 × 6 iç köşe. Ekran veya iPhone Ölçüm uygulaması ölçüsü, doğrulanmış fiziksel tahta boyutu sayılmaz.").font(.caption)
                }
                if model.mode == "scan" {
                    Text("3B konum için gerçek, sabit bayrakları farklı açılardan tara. Bilgisayar ekranındaki sanal ağız için Bayrak deneyi (2B) seç; resimdeki derinlik fiziksel konum olarak ölçülemez.")
                        .font(.caption).accessibilityIdentifier("physicalScanSourceHint")
                    Text("Seçtiğin kalibrasyonun odak, kamera biçimi ve çözünürlüğü korunur. MUA bağlantısı ölçülmediyse MUA merkezi üretilmez.").font(.caption)
                }
            }.disabled(model.currentID != nil || model.cameraVisible || model.busy || model.computing)
            Section {
                Button("Çekime geç") { tab = 1 }.accessibilityIdentifier("openCapture")
                Button("Yeni kayıt hazırla") { model.newSession() }.disabled(model.busy || model.computing || model.analyzing || model.uploading)
            }
            Section("Durum") { Text(model.status).font(.callout).accessibilityLabel("Durum: " + model.status) }
            Section { Text("Fiziksel doğruluk henüz ölçülmedi. Klinik kullanım için doğrulanmadı.").font(.footnote).foregroundStyle(.secondary) }
            Section("Bu uygulama ne yapıyor?") {
                Text("Sabit odakta görüntü kaydeder; kalibrasyon, DAL bayrak tanıma ve fotogrametri hesabını iPhone üzerinde yapar. Kayıtlar ve sonuçlar telefonda saklanır. CSV, JSON ve araştırma amaçlı 3B dosyalar paylaşılabilir.")
                Text("PIC/iMetric'in özel markerları veya kodu kullanılmaz. DAL bayrakları ve gerçek ölçülmüş kamera/bağlantı kalibrasyonu gerekir.")
                Text("Sürüm \(appVersion) · iPhone hesap motoru · Araştırma prototipi").foregroundStyle(.secondary)
                NavigationLink("Açık kaynak bildirimleri") {
                    LicenseNoticesView()
                }
            }.font(.footnote)
        }.navigationTitle("Ayarlar ve araçlar").navigationBarTitleDisplayMode(.inline)
            .toolbar(.visible, for: .navigationBar).preferredColorScheme(.light)
    }

    var body: some View {
        TabView(selection: $tab) {
            NavigationStack(path: $homePath) {
                homePage.navigationDestination(for: HomeDestination.self) { destination in
                    switch destination {
                    case .settings: settingsPage
                    case .plan: DentalPlanView().toolbar(.visible, for: .navigationBar)
                    }
                }
            }.tabItem { Label("Başlangıç", systemImage: "square.grid.2x2") }.tag(0)
            NavigationStack {
                LiveCaptureView(onExit: { homePath.removeAll(); tab = 0 }) { Task { await model.finish(); if model.current?.state != "collecting" { tab = 2 } } }
            }.tabItem { Label("Çekim", systemImage: "camera") }.tag(1)
            NavigationStack { NativeResultsView() }
                .id(model.currentID)
                .tabItem { Label("Sonuç", systemImage: "cube.transparent") }.tag(2)
            NavigationStack {
                List {
                    if model.sessions.isEmpty { Text("Henüz kayıt yok.").foregroundStyle(.secondary) }
                    ForEach(model.sessions) { capture in
                        Button {
                            model.select(capture); tab = capture.state == "collecting" && capture.engine != nil ? 1 : 2
                            if capture.state != "collecting" || capture.engine == nil { Task { await model.refreshResult() } }
                        } label: {
                            VStack(alignment: .leading, spacing: 7) {
                                Text(capture.creation.mode == "calibration" ? "Kalibrasyon" : capture.creation.mode == "scan" ? "Araştırma taraması" : "Bayrak deneyi").font(.headline)
                                Text(capture.created.formatted(date: .abbreviated, time: .shortened)).font(.caption)
                                Text("\(capture.acceptedCount) uygun · \(capture.pending.count) işlenecek kare").font(.caption)
                                if capture.engine == nil {
                                    Text("Önceki sürüm kaydı").font(.caption).foregroundStyle(.secondary)
                                }
                            }
                        }.disabled(model.busy || model.computing || model.analyzing || model.uploading)
                    }
                    Text("Orijinal PNG dosyaları Dosyalar > iPhone'umda > DentalArchLab > Captures içinde korunur.").font(.footnote).foregroundStyle(.secondary)
                }.navigationTitle("Kayıtlar")
            }.tabItem { Label("Kayıtlar", systemImage: "folder") }.tag(3)
        }.onAppear { ScanInterfaceOrientation.setScanning(tab == 1) }
            .onChange(of: tab) { _, next in
                ScanInterfaceOrientation.setScanning(next == 1)
                if next != 1 { model.leaveCaptureScreen(showingCompletedResult: next == 2) }
            }
            .onChange(of: model.current?.state) { _, state in
                if (state == "complete" || state == "error"), tab == 1 { tab = 2 }
            }
            .fileImporter(isPresented: $importingMUA, allowedContentTypes: [.json]) { result in
                do { let url = try result.get(); importError = nil; model.importMUACalibration(url) }
                catch { importError = error.localizedDescription }
            }
    }
}

/// Original DAL mark and arch illustrations are drawn locally; no reference-video assets are embedded.
private struct DALHomeMark: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 10).fill(Color(red: 0.03, green: 0.5, blue: 0.48))
            VStack(spacing: 5) {
                HStack(spacing: 5) { Circle(); Circle() }
                HStack(spacing: 5) { Circle(); Circle() }
            }.foregroundStyle(.white).padding(9)
        }
    }
}

private struct HomeArchGlyph: View {
    let upper: Bool
    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height
            Path { path in
                path.move(to: CGPoint(x: width * 0.13, y: height * 0.12))
                path.addLine(to: CGPoint(x: width * 0.13, y: height * 0.43))
                path.addCurve(to: CGPoint(x: width * 0.87, y: height * 0.43),
                              control1: CGPoint(x: width * 0.13, y: height * 1.03),
                              control2: CGPoint(x: width * 0.87, y: height * 1.03))
                path.addLine(to: CGPoint(x: width * 0.87, y: height * 0.12))
                path.move(to: CGPoint(x: width * 0.32, y: height * 0.16))
                path.addLine(to: CGPoint(x: width * 0.32, y: height * 0.43))
                path.addCurve(to: CGPoint(x: width * 0.68, y: height * 0.43),
                              control1: CGPoint(x: width * 0.32, y: height * 0.77),
                              control2: CGPoint(x: width * 0.68, y: height * 0.77))
                path.addLine(to: CGPoint(x: width * 0.68, y: height * 0.16))
            }.stroke(style: StrokeStyle(lineWidth: 2.1, lineCap: .round, lineJoin: .round))
        }.rotationEffect(.degrees(upper ? 180 : 0))
    }
}

/// Keep the large bundled notices out of the home form's body evaluation.
/// The file read and text layout start only when this destination appears.
struct LicenseNoticesView: View {
    @State private var licenseText: String?

    var body: some View {
        ScrollView {
            if let licenseText {
                Text(licenseText).font(.caption.monospaced()).textSelection(.enabled).padding()
            } else {
                ProgressView("Bildirimler yükleniyor…").padding()
            }
        }.navigationTitle("Lisanslar")
            .onAppear {
                guard licenseText == nil else { return }
                let notices = ["OPENCV-LICENSE", "THIRD-PARTY-NOTICES"].compactMap { name -> String? in
                    guard let url = Bundle.main.url(forResource: name, withExtension: "txt") else { return nil }
                    return try? String(contentsOf: url, encoding: .utf8)
                }.joined(separator: "\n\n")
                licenseText = notices.isEmpty ? "Lisans bildirimleri okunamadı." : notices
            }
    }
}

final class PreviewView: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var preview: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
}
struct CameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView(); view.preview.session = session; view.preview.videoGravity = .resizeAspect
        return view
    }
    func updateUIView(_ uiView: PreviewView, context: Context) {
        // Preview orientation only; stored PNG pixels retain the sensor coordinate system.
        if let connection = uiView.preview.connection, connection.isVideoRotationAngleSupported(90) { connection.videoRotationAngle = 90 }
    }
}
