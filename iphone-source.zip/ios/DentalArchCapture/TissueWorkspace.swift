import CryptoKit
import Foundation

struct TissueTarget: Identifiable {
    let id: String
    let label: String
    let markerID: Int
    let point: LabPoint
}

struct TissueSelection {
    let targetID: String
    let source: LabPoint
    let checkOnly: Bool
}

struct TissueWorkspaceState {
    let mesh: TissueMesh?
    let alignedMesh: TissueMesh?
    let meshFilename: String?
    let targets: [TissueTarget]
    let pairs: [TissueSelection]
    let registration: TissueRegistration?
    let checkRMSMM: Double?
    let checkpointErrors: [String: Double]
    let landmarks: [ResultLandmark]
    let libraryName: String?
    let blockers: [String]
    let files: [URL]
}

/// All mesh parsing, fitting and durable writes run outside the UI actor.
actor TissueWorkspace {
    private let repository: CaptureRepository
    private let session: String
    private var meshCache: (String, TissueMesh)?

    init(repository: CaptureRepository, session: String) { self.repository = repository; self.session = session }

    private struct SavedPair: Codable {
        let targetID: String
        let source: [Double]
        let checkOnly: Bool
    }
    private struct Saved: Codable {
        var schema = 1
        var resultSHA256: String
        var meshFilename: String?
        var meshExtension: String?
        var meshSHA256: String?
        var pairs: [SavedPair] = []
        var aligned = false
        var library: ExocadLibraryProfile?
        var exportDirectory: String?
    }
    private struct Context {
        let folder: URL
        let resultData: Data
        let envelope: [String: Any]
        let snapshot: ResultSnapshot
        let targets: [TissueTarget]
        let saved: Saved
    }

    private static func hash(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
    private static func read(_ url: URL, limit: Int) throws -> Data {
        let handle = try FileHandle(forReadingFrom: url); defer { try? handle.close() }
        let data = try handle.read(upToCount: limit + 1) ?? Data()
        guard data.count <= limit else { throw LabError.message("Kayıt dosyası izin verilen boyutu aşıyor.") }
        return data
    }

    private func context(ignoreSaved: Bool = false) throws -> Context {
        let resultURL = try repository.resultURL(session)
        let resultData = try Self.read(resultURL, limit: 32 * 1024 * 1024)
        guard resultData.count <= 32 * 1024 * 1024,
              let envelope = try JSONSerialization.jsonObject(with: resultData) as? [String: Any],
              envelope["id"] as? String == session, envelope["mode"] as? String == "scan" else {
            throw LabError.message("Doku eşleştirmesi için bu kayda ait tamamlanmış fiziksel 3B tarama gerekli.")
        }
        let snapshot = try ResultSnapshot.decode(envelope)
        guard !snapshot.isSynthetic, !snapshot.landmarks.isEmpty,
              let result = envelope["result"] as? [String: Any],
              let rig = result["rig"] as? [String: Any], rig["dictionary"] as? String == "DAL_DOTS4_V1",
              let rigMarkers = rig["markers"] as? [[String: Any]],
              let markers = result["markers"] as? [[String: Any]] else {
            throw LabError.message("Ölçülmüş bayrak konumları ve kullanılan nokta geometrisi bulunamadı.")
        }
        var targets: [TissueTarget] = []
        for marker in markers {
            guard let id = marker["id"] as? Int, (0...5).contains(id),
                  let transform = marker["T_world_marker"] as? [[Double]],
                  let points = rigMarkers.first(where: { $0["id"] as? Int == id })?["points_mm"] as? [[Double]],
                  points.count == 4, points.allSatisfy({ $0.count == 3 && $0.allSatisfy(\.isFinite) }) else {
                throw LabError.message("Bayrak referans noktaları okunamadı; tahmini nokta kullanılmadı.")
            }
            try TissueRegistration.validateRigid(transform)
            for (index, point) in points.enumerated() {
                targets.append(TissueTarget(id: "\(id):\(index)", label: "Bayrak \(id) · \(["A", "B", "C", "D"][index])",
                    markerID: id, point: ExocadHandoff.point(LabPoint(x: point[0], y: point[1], z: point[2]), by: transform)))
            }
        }
        let folder = resultURL.deletingLastPathComponent().appendingPathComponent("TissueAlignment", isDirectory: true)
        let stateURL = folder.appendingPathComponent("workspace.json")
        var saved = Saved(resultSHA256: Self.hash(resultData), library: .vidaMUA9)
        if !ignoreSaved && FileManager.default.fileExists(atPath: stateURL.path) {
            let data = try Self.read(stateURL, limit: 256_000)
            guard data.count <= 256_000 else { throw LabError.message("Doku çalışma kaydı boyutu geçersiz.") }
            saved = try JSONDecoder().decode(Saved.self, from: data)
            guard saved.schema == 1, saved.resultSHA256 == Self.hash(resultData) else {
                throw LabError.message("3B sonuç değişmiş. Eski eşleştirme kullanılmadı; doku dosyasını tekrar içe aktarın.")
            }
            guard saved.pairs.count <= 24, Set(saved.pairs.map(\.targetID)).count == saved.pairs.count,
                  saved.pairs.allSatisfy({ pair in targets.contains(where: { $0.id == pair.targetID }) && pair.source.count == 3 && pair.source.allSatisfy({ $0.isFinite && abs($0) <= 100_000 }) }) else {
                throw LabError.message("Kayıtlı eşleştirme noktaları geçersiz.")
            }
            if let library = saved.library { try library.validate() }
        }
        return Context(folder: folder, resultData: resultData, envelope: envelope, snapshot: snapshot, targets: targets, saved: saved)
    }

    private func save(_ saved: Saved, folder: URL) throws {
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(saved).write(to: folder.appendingPathComponent("workspace.json"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }

    private func mesh(_ context: Context) throws -> TissueMesh? {
        guard let ext = context.saved.meshExtension, let digest = context.saved.meshSHA256 else { return nil }
        guard ["stl", "ply", "obj"].contains(ext) else { throw LabError.message("Kayıtlı yüzey biçimi geçersiz.") }
        let bytes = try Self.read(context.folder.appendingPathComponent("source." + ext), limit: 64 * 1024 * 1024)
        guard Self.hash(bytes) == digest else { throw LabError.message("Doku dosyası değişmiş; eşleştirme için dosyayı yeniden içe aktarın.") }
        if let cached = meshCache, cached.0 == digest { return cached.1 }
        let value = try TissueMesh.parse(data: bytes, fileExtension: ext)
        meshCache = (digest, value); return value
    }

    private func fit(_ context: Context) throws -> TissueRegistration {
        let pairs = context.saved.pairs.filter { !$0.checkOnly }
        let identifiers = Set(pairs.compactMap { pair in context.targets.first { $0.id == pair.targetID }?.markerID })
        guard pairs.count >= 3, identifiers.count >= 2 else {
            throw LabError.message("En az iki farklı bayrağa dağılmış, aynı doğru üzerinde olmayan en az üç eşleştirme noktası seçin.")
        }
        return try TissueRegistration.fit(pairs.map { pair in
            let target = context.targets.first { $0.id == pair.targetID }!
            return TissuePair(source: LabPoint(x: pair.source[0], y: pair.source[1], z: pair.source[2]), target: target.point)
        })
    }

    private func checkpoints(_ context: Context, registration: TissueRegistration?) -> [String: Double] {
        guard let registration else { return [:] }
        var errors: [String: Double] = [:]
        for pair in context.saved.pairs where pair.checkOnly {
            guard let target = context.targets.first(where: { $0.id == pair.targetID }) else { continue }
            let p = LabPoint(x: pair.source[0], y: pair.source[1], z: pair.source[2])
            errors[pair.targetID] = (ExocadHandoff.point(p, by: registration.transform) - target.point).length
        }
        return errors
    }

    private func blockers(_ context: Context, registration: TissueRegistration?, errors: [String: Double]) -> [String] {
        var reasons: [String] = []
        if registration == nil { reasons.append("Doku eşleştirmesi henüz hesaplanmadı.") }
        if errors.isEmpty { reasons.append("Hesapta kullanılmamış en az bir kontrol noktası seçin.") }
        let result = (context.envelope["result"] as? [String: Any]) ?? [:]
        let markers = result["markers"] as? [[String: Any]] ?? []
        if context.snapshot.landmarks.contains(where: { !$0.isMUA }) { reasons.append("Her bayrağın ölçülmüş MUA bağlantı kalibrasyonu gerekli.") }
        if result["mua_calibration_import"] == nil || result["mua_calibration_sha256"] == nil {
            reasons.append("Bayrak–MUA referans ölçüm kaynağı eksik.")
        } else {
            do {
                let bytes = try JSONSerialization.data(withJSONObject: result["mua_calibration_import"]!)
                let calibration = try MUACalibration.load(bytes)
                guard try calibration.contentHash() == result["mua_calibration_sha256"] as? String else {
                    throw LabError.message("Kalibrasyon özeti uyuşmuyor.")
                }
                let recalculated = try calibration.apply(to: result)
                let expected = recalculated["markers"] as? [[String: Any]] ?? []
                for marker in markers {
                    guard let id = marker["id"] as? Int,
                          let actual = marker["T_world_mua"] as? [[Double]],
                          let calculated = expected.first(where: { $0["id"] as? Int == id })?["T_world_mua"] as? [[Double]],
                          actual.count == 4, actual.allSatisfy({ $0.count == 4 }),
                          (0..<4).allSatisfy({ row in (0..<4).allSatisfy({ abs(actual[row][$0] - calculated[row][$0]) < 1e-8 }) }),
                          marker["component_reference"] as? String == calibration.componentReference else {
                        throw LabError.message("Ölçüm kaydıyla MUA konumu veya bileşeni uyuşmuyor.")
                    }
                }
            } catch { reasons.append("MUA konumları referans ölçüm kaydından doğrulanamadı: " + error.localizedDescription) }
        }
        if result["status"] as? String != "research_result" || !(result["missing_markers"] as? [Int] ?? [-1]).isEmpty {
            reasons.append("3B hesapta eksik bayrak veya çözümlenmemiş geometri uyarısı var.")
        }
        if markers.contains(where: { ($0["issues"] as? [String])?.isEmpty != true }) ||
            ((result["bundle_adjustment"] as? [[String: Any]])?.last?["converged"] as? Bool) != true {
            reasons.append("3B kalite kontrolleri tamamlanmamış: bayrak uyarıları giderilmeli ve çoklu görüntü hesabı yakınsamalı.")
        }
        let fdis = markers.compactMap { $0["fdi"] as? Int }
        let upper = Set(DentalPlan.teeth(arch: "upper")), lower = Set(DentalPlan.teeth(arch: "lower"))
        if ![4, 6].contains(markers.count) || fdis.count != markers.count || Set(fdis).count != markers.count ||
            !(Set(fdis).isSubset(of: upper) || Set(fdis).isSubset(of: lower)) {
            reasons.append("Aynı çenede dört veya altı benzersiz FDI ataması gerekli.")
        }
        if let profile = context.saved.library {
            if profile.source != "reference_metrology" || profile.transform == nil {
                reasons.append("Vida Dental 9 mm kütüphanesi bulundu; ölçülmüş MUA–kütüphane dönüşümü henüz yok.")
            }
            if markers.contains(where: { $0["component_reference"] as? String != profile.componentReference }) {
                reasons.append("Tarama bileşeni kütüphane eşleştirme kaydıyla uyuşmuyor.")
            }
            if profile.source == "reference_metrology", let registration, registration.rmsMM > profile.maxAlignmentRMSMM {
                reasons.append("Eşleştirme artığı, kütüphane kaydında tanımlanan araştırma sınırını aşıyor.")
            }
            if profile.source == "reference_metrology", errors.values.contains(where: { $0 > profile.maxCheckpointErrorMM }) {
                reasons.append("Kontrol noktası sapması, tanımlanan araştırma sınırını aşıyor.")
            }
            if profile.source == "reference_metrology", let libraryTransform = profile.transform {
                do {
                    for marker in markers {
                        guard let matrix = marker["T_world_mua"] as? [[Double]] else { throw LabError.message("MUA dönüşümü yok.") }
                        try TissueRegistration.validateRigid(matrix)
                        try TissueRegistration.validateRigid(ExocadHandoff.multiply(matrix, libraryTransform))
                    }
                } catch { reasons.append("Exocad konum matrisi rijit dönüşüm kontrolünü geçemedi: " + error.localizedDescription) }
            }
        } else { reasons.append("MegaGen kütüphane kimliği ve ölçülmüş MUA–kütüphane dönüşümü gerekli.") }
        return reasons
    }

    private func state(_ context: Context) throws -> TissueWorkspaceState {
        let source = try mesh(context)
        let registration = context.saved.aligned ? try fit(context) : nil
        let errors = checkpoints(context, registration: registration)
        var files: [URL] = []
        if let directory = context.saved.exportDirectory, UUID(uuidString: directory) != nil {
            let folder = context.folder.appendingPathComponent("Exports").appendingPathComponent(directory)
            if FileManager.default.fileExists(atPath: folder.path) {
                files = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil).sorted { $0.lastPathComponent < $1.lastPathComponent }
            }
        }
        return TissueWorkspaceState(mesh: source, alignedMesh: try registration.flatMap { transform in try source?.transformed(transform.transform) },
            meshFilename: context.saved.meshFilename, targets: context.targets,
            pairs: context.saved.pairs.map { TissueSelection(targetID: $0.targetID, source: LabPoint(x: $0.source[0], y: $0.source[1], z: $0.source[2]), checkOnly: $0.checkOnly) },
            registration: registration, checkRMSMM: errors.isEmpty ? nil : sqrt(errors.values.reduce(0) { $0 + $1 * $1 } / Double(errors.count)),
            checkpointErrors: errors, landmarks: context.snapshot.landmarks,
            libraryName: context.saved.library.map { $0.library + " / " + $0.type + ($0.subtype.map { " / " + $0 } ?? "") },
            blockers: blockers(context, registration: registration, errors: errors), files: files)
    }

    func load() throws -> TissueWorkspaceState { try state(context()) }

    func importMesh(data: Data, name: String) throws -> TissueWorkspaceState {
        let context = try context(ignoreSaved: true)
        let ext = URL(fileURLWithPath: name).pathExtension.lowercased()
        let parsed = try TissueMesh.parse(data: data, fileExtension: ext)
        var saved = context.saved
        saved.meshFilename = String(URL(fileURLWithPath: name).lastPathComponent.prefix(180))
        saved.meshExtension = ext; saved.meshSHA256 = Self.hash(data)
        try FileManager.default.createDirectory(at: context.folder, withIntermediateDirectories: true)
        try data.write(to: context.folder.appendingPathComponent("source." + ext), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        try save(saved, folder: context.folder)
        meshCache = (Self.hash(data), parsed)
        return try load()
    }

    func setPair(targetID: String, source: LabPoint, checkOnly: Bool) throws -> TissueWorkspaceState {
        let context = try context()
        guard try mesh(context) != nil, context.targets.contains(where: { $0.id == targetID }),
              [source.x, source.y, source.z].allSatisfy({ $0.isFinite && abs($0) <= 100_000 }) else {
            throw LabError.message("Önce yüzeyi yükleyin ve geçerli bir ortak nokta seçin.")
        }
        var saved = context.saved
        saved.pairs.removeAll { $0.targetID == targetID }
        saved.pairs.append(SavedPair(targetID: targetID, source: [source.x, source.y, source.z], checkOnly: checkOnly))
        saved.aligned = false; saved.exportDirectory = nil
        try save(saved, folder: context.folder); return try load()
    }

    func removePair(targetID: String) throws -> TissueWorkspaceState {
        let context = try context(); var saved = context.saved
        saved.pairs.removeAll { $0.targetID == targetID }; saved.aligned = false; saved.exportDirectory = nil
        try save(saved, folder: context.folder); return try load()
    }

    func align() throws -> TissueWorkspaceState {
        let context = try context()
        guard try mesh(context) != nil else { throw LabError.message("Önce doku yüzeyi yükleyin.") }
        _ = try fit(context)
        var saved = context.saved; saved.aligned = true; saved.exportDirectory = nil
        try save(saved, folder: context.folder); return try load()
    }

    func importLibrary(data: Data) throws -> TissueWorkspaceState {
        let context = try context(); var saved = context.saved
        saved.library = try ExocadLibraryProfile.load(data); saved.exportDirectory = nil
        try save(saved, folder: context.folder); return try load()
    }

    func export(projectName: String) throws -> [URL] {
        let name = try ExocadHandoff.projectName(projectName)
        let context = try context()
        guard context.saved.aligned, let mesh = try mesh(context) else { throw LabError.message("Önce doku eşleştirmesini hesaplayın.") }
        let registration = try fit(context)
        let errors = checkpoints(context, registration: registration)
        let reasons = blockers(context, registration: registration, errors: errors)
        let directory = UUID().uuidString
        let folder = context.folder.appendingPathComponent("Exports").appendingPathComponent(directory)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        func put(_ file: String, _ data: Data) throws {
            try data.write(to: folder.appendingPathComponent(file), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        }
        let aligned = try mesh.transformed(registration.transform)
        try put(name + "-tissue-aligned.stl", aligned.stlData())
        try put("photogrammetry-result.json", context.resultData)
        var implantFiles: [String] = []
        if reasons.isEmpty, let profile = context.saved.library,
           let result = context.envelope["result"] as? [String: Any], let markers = result["markers"] as? [[String: Any]] {
            for marker in markers {
                guard let fdi = marker["fdi"] as? Int, let matrix = marker["T_world_mua"] as? [[Double]] else {
                    throw LabError.message("FDI veya MUA konumu eksik; eksik implant dosyası üretilmedi.")
                }
                let file = "\(name)-\(fdi).implantPosition"
                try put(file, ExocadHandoff.xml(worldMUA: matrix, profile: profile)); implantFiles.append(file)
            }
        }
        var report: [String: Any] = [
            "schema": 1, "units": "mm", "session": session, "project_name": name,
            "coordinate_frame": "photogrammetry_world", "T_world_tissue": registration.transform,
            "result_sha256": context.saved.resultSHA256, "source_mesh_sha256": context.saved.meshSHA256 ?? "",
            "source_mesh_filename": context.saved.meshFilename ?? "", "scale_fitted": false,
            "method": "operator_picked_shared_rigid_points_proper_rotation_least_squares",
            "alignment_rms_mm": registration.rmsMM, "alignment_max_mm": registration.maxMM,
            "alignment_residuals_mm": registration.residualsMM, "checkpoint_errors_mm": errors,
            "implant_position_files": implantFiles, "implant_export_blockers": reasons,
            "research_only": true, "clinically_validated": false, "physical_accuracy_um": NSNull(),
            "exocad_import_tested": false, "exocad_library_match_verified": false,
            "measurement_source_verified": false,
            "points": context.saved.pairs.map { pair in ["target_id": pair.targetID, "source_mm": pair.source, "check_only": pair.checkOnly] as [String: Any] }
        ]
        if let profile = context.saved.library { report["library_profile"] = try JSONSerialization.jsonObject(with: JSONEncoder().encode(profile)) }
        try put("alignment-report.json", JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys]))
        let instructions = """
        DentalArchLab · Doku ve MUA araştırma aktarımı
        Birim mm. Yüzey ve implantPosition dosyaları aynı photogrammetry_world koordinatındadır.
        Exocad'de mevcut projenizin uzantısız adı: \(name)
        \(name)-tissue-aligned.stl dosyasını bu projenin diş eti/optik model yüzeyi olarak açın.
        Üretilmişse aynı önekli FDI.implantPosition dosyalarını .dentalProject ile aynı klasöre koyun.
        Orijinal, hizalanmamış IOS yüzeyiyle bu implant dosyalarını karıştırmayın.
        Konum XML'i resmi Exocad 05/2015 tarifine göre yazıldı; kurulu sürümde gerçek içe aktarma testi henüz yapılmadı.
        MUA seviyesi ile implant gövdesinin seviyesi farklıdır. Kütüphane kimliğini ve bağlantı seviyesini kontrol edin.
        Nokta eşleştirmesi ve kontrol sapmaları mikron doğruluk belgesi değildir. Elle tıklama hatası da içerir.
        Üretim/klinik doğrulama yapılmadı. Sonuç yalnız araştırma içindir.
        İmplant dosyası sayısı: \(implantFiles.count)
        Eksikler: \(reasons.isEmpty ? "Yapısal önkoşullar sağlandı; uyumluluk yine de doğrulanmadı." : reasons.joined(separator: " | "))
        """
        try put("OKU.txt", Data(instructions.utf8))
        var saved = context.saved; saved.exportDirectory = directory
        try save(saved, folder: context.folder)
        return try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil).sorted { $0.lastPathComponent < $1.lastPathComponent }
    }
}
