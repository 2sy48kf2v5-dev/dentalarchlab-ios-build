import AVFoundation
import Foundation

struct TorchStatus: Equatable {
    let available: Bool
    let isOn: Bool
    let message: String

    static let unavailable = TorchStatus(available: false, isOn: false,
                                        message: "Flaş durumu kamera açılınca kontrol edilir.")
}

// Readback is independent of the requested preference: iOS may deny or switch
// off the torch, for example when the device is too hot. Never infer illumination
// from a successful configuration call or from the preference alone.
protocol CameraTorchDevice: AnyObject {
    var hasTorch: Bool { get }
    var isTorchAvailable: Bool { get }
    var isTorchActive: Bool { get }
    var supportsTorchOn: Bool { get }
    func setTorchLevel(_ level: Float) throws
    func switchTorchOff() throws
}

final class AVCameraTorchDevice: CameraTorchDevice {
    private let device: AVCaptureDevice
    init(_ device: AVCaptureDevice) { self.device = device }
    var hasTorch: Bool { device.hasTorch }
    var isTorchAvailable: Bool { device.isTorchAvailable }
    var isTorchActive: Bool { device.isTorchActive }
    var supportsTorchOn: Bool { device.isTorchModeSupported(.on) }

    func setTorchLevel(_ level: Float) throws {
        try device.lockForConfiguration()
        defer { device.unlockForConfiguration() }
        try device.setTorchModeOn(level: level)
    }

    func switchTorchOff() throws {
        try device.lockForConfiguration()
        defer { device.unlockForConfiguration() }
        device.torchMode = .off
    }
}

// Used only on CameraEngine's serial queue. Changing a preference never changes
// a running/stopped device; CameraEngine applies it during the next startup,
// before exposure settles and the canonical optical profile is locked.
struct CameraIllumination {
    static let torchLevel: Float = 0.25
    private(set) var requestedEnabled = true
    private(set) var sessionStarted = false
    private var failureMessage: String?

    mutating func configure(enabled: Bool) { requestedEnabled = enabled }

    mutating func start(device: CameraTorchDevice?, sessionRunning: Bool) {
        failureMessage = nil
        sessionStarted = sessionRunning
        guard sessionRunning else { stop(device: device); return }
        guard let device, device.hasTorch else { return }
        do {
            if requestedEnabled {
                guard device.isTorchAvailable, device.supportsTorchOn else { return }
                try device.setTorchLevel(Self.torchLevel)
            } else {
                try device.switchTorchOff()
            }
        } catch {
            failureMessage = "Flaş ayarı uygulanamadı: \(error.localizedDescription)"
            // A failing set operation must not leave a partially activated torch.
            try? device.switchTorchOff()
        }
    }

    mutating func stop(device: CameraTorchDevice?) {
        sessionStarted = false
        failureMessage = nil
        guard let device, device.hasTorch else { return }
        do { try device.switchTorchOff() }
        catch { failureMessage = "Flaş kapatılamadı: \(error.localizedDescription)" }
    }

    func status(device: CameraTorchDevice?) -> TorchStatus {
        guard let device else { return .unavailable }
        let available = device.hasTorch && device.supportsTorchOn && device.isTorchAvailable
        let actual = device.isTorchActive
        let message: String
        if let failureMessage { message = failureMessage }
        else if !device.hasTorch || !device.supportsTorchOn { message = "Bu kamerada sürekli flaş desteklenmiyor." }
        else if actual && !sessionStarted { message = "Flaşın kapanması bekleniyor." }
        else if actual { message = "Sürekli flaş açık." }
        else if !available && sessionStarted { message = "Flaş şu anda kullanılamıyor; iOS kamera veya sıcaklık nedeniyle kapatmış olabilir." }
        else if sessionStarted && requestedEnabled { message = "Flaş henüz ışık vermiyor; ortam ışığıyla devam edilebilir." }
        else { message = "Sürekli flaş kapalı." }
        return TorchStatus(available: available, isOn: actual, message: message)
    }
}
