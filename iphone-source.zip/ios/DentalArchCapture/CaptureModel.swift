import Combine
import Foundation
import UIKit
import AVFoundation

@MainActor final class CaptureModel: ObservableObject {
    let camera: CameraControlling
    private let cameraStartTimeoutNanoseconds: UInt64
    private var cameraStartID: UUID?
    private var cameraRunID: UUID?
    private var requiredCameraProfile: CaptureProfile?
    private var cameraStartIsTrialRefocus = false
    private var refocusRequestID: UUID?
    private var cameraStartWatchdog: Task<Void, Never>?
    @Published private(set) var cameraStarting = false
    @Published private(set) var cameraDiagnostic: String?
    let repository: CaptureRepository
    private let offlineEngine: OfflineEngine
    @Published private(set) var validationText: String?
    @Published private(set) var exportFiles: [URL] = []
    @Published private(set) var muaCalibration: MUACalibration?
    @Published var address = UserDefaults.standard.string(forKey: "dal.address") ?? ""
    @Published var token = ""
    @Published var mode = "trial"
    @Published var markerCount = 6
    @Published private(set) var focus: Float = 0.55
    @Published var plan = DentalPlan()
    @Published var soundEnabled = true
    @Published private(set) var soundStatus: String?
    @Published private(set) var torchEnabled = true
    @Published private(set) var torchStatus = TorchStatus.unavailable
    @Published private(set) var illuminationChanging = false
    private let scanAudio: ScanAudioFeedbackControlling
    private var scanFeedbackActive = false
    private var audioGeneration = 0
    private var illuminationRequestID: UUID?
    private var illuminationTask: Task<Void, Never>?
    @Published private(set) var analysisSeconds: Double?
    @Published private(set) var detectorMilliseconds: Double?
    @Published private(set) var cycleSeconds: Double?
    @Published private(set) var fastCommitSupported = true
    private var registeredSessions: Set<RegistrationKey> = []
    @Published private(set) var casePlanSupported = true
    private var cue = AcceptanceCue()
    private var flagCue = FlagConfirmationCue()
    @Published private(set) var newlyConfirmedIDs: [Int] = []
    @Published var physicalBoard = false
    @Published var squareMM = "6.0"
    @Published var calibrationID = ""
    @Published private(set) var status = "iPhone hesap motoru hazır. PC veya internet gerekmez."
    @Published private(set) var ready = false
    @Published private(set) var busy = false
    @Published private(set) var uploading = false
    @Published private(set) var connecting = false
    @Published private(set) var refreshing = false
    @Published private(set) var computing = false
    @Published private(set) var connected = true
    @Published private(set) var autoSupported = true
    @Published private(set) var autoRunning = false
    @Published private(set) var analyzing = false
    @Published private(set) var feedback: LiveFeedback?
    @Published private(set) var feedbackImage: UIImage?
    @Published private(set) var feedbackDate: Date?
    private var lastRecognitionSample: RecognitionSample?
    @Published private(set) var diagnosticFileURL: URL?
    var canPrepareRecognitionReport: Bool { lastRecognitionSample != nil }
    @Published private(set) var calibrationFeedback: CalibrationFeedback?
    @Published private(set) var calibrationFeedbackImage: UIImage?
    @Published private(set) var calibrationFeedbackDate: Date?
    @Published private(set) var calibrationTarget = 20
    @Published private(set) var calibrationGuidance: String?
    private var automaticStartRequested = false
    private var lastSampleID: String?
    private var sampling = SamplingGate()
    private var autoTask: Task<Void, Never>?
    @Published private(set) var resultSnapshot: ResultSnapshot?
    @Published private(set) var resultFile: URL?
    @Published private(set) var sessions: [LocalCapture] = []
    @Published private(set) var availableCalibrations: [LocalCapture] = []
    @Published private(set) var currentID: String?
    var pendingCount: Int { current?.engine == "iphone_native_v1" ? (current?.pending.count ?? 0) : 0 }
    var calibrationLimitReached: Bool { current?.creation.mode == "calibration" && current?.state == "collecting" && (current?.acceptedCount ?? 0) >= 60 }
    @Published private(set) var lastImage: UIImage?
    @Published private(set) var resultText = "Sonuç henüz yok."
    var current: LocalCapture? { sessions.first { $0.id == currentID } }

    var cameraFocusGuidance: String {
        if mode == "trial", current?.state == "collecting" {
            return "2B deneyinde netlik bozulursa Yeniden netle'ye basın. Kaydedilen bayraklar korunur; sonra taramaya devam edin."
        }
        if currentID != nil || mode == "scan" {
            return "Kayıtlı kalibrasyon odağı korunur. Netlik için telefonun uzaklığını ayarlayın; odağı değiştirmek için yeni kalibrasyon gerekir."
        }
        if ready { return "Otomatik netleme tamamlandı; odak bu kayıt boyunca sabit. Görüntü net değilse ilk kareden önce Yeniden netle'ye basın." }
        return mode == "calibration"
            ? "Tahtayı kameranın ortasında tutun. Kamera otomatik netleyip odağı sabitleyecek; sayı seçmeniz gerekmez."
            : "Bayrakları kameranın ortasında tutun. Kamera otomatik netleyip odağı sabitleyecek."
    }
    var canRefocus: Bool {
        guard ready, !busy, !cameraStarting, !computing, pendingCount == 0 else { return false }
        if mode == "trial", current?.creation.mode == "trial", current?.state == "collecting" { return true }
        return currentID == nil && mode != "scan" && !autoRunning && !analyzing && !uploading
    }
    func refocusCamera() {
        guard canRefocus else { return }
        let savedSession = currentID
        stopCamera()
        guard let savedSession else { openCamera(); return }
        let request = UUID(); refocusRequestID = request
        status = "Kaydedilen bayraklar korunuyor; mevcut kare tamamlanınca yeniden netlenecek."
        if !analyzing && !uploading {
            openCamera(reacquireTrialFocus: true)
            return
        }
        Task { [weak self] in
            guard let self else { return }
            while self.refocusRequestID == request && (self.analyzing || self.uploading) {
                do { try await Task.sleep(nanoseconds: 20_000_000) } catch { return }
            }
            guard self.refocusRequestID == request, self.currentID == savedSession,
                  self.mode == "trial", self.current?.state == "collecting" else { return }
            guard self.pendingCount == 0 else {
                self.status = "Önce bekleyen kareyi işleyin; sonra yeniden netleyin."
                return
            }
            self.openCamera(reacquireTrialFocus: true)
        }
    }
    func prepareRecognitionReport() {
        guard let sample = lastRecognitionSample else { status = "Önce taramayı başlatıp bir kare analiz edin."; return }
        pauseAutomatic()
        do {
            diagnosticFileURL = try sample.write(to: repository.root.appendingPathComponent("RecognitionReports"))
            status = "Tanıma raporu hazır. Son analiz edilen görüntü ve tanı bilgileri bu iPhone'da kaydedildi."
        } catch { status = "Tanıma raporu kaydedilemedi: \(error.localizedDescription)" }
    }

    init(repository: CaptureRepository = CaptureRepository(), camera: CameraControlling = CameraEngine(),
         cameraStartTimeoutNanoseconds: UInt64 = 12_000_000_000,
         scanAudio: ScanAudioFeedbackControlling? = nil) {
        self.repository = repository
        self.offlineEngine = OfflineEngine(root: repository.root.appendingPathComponent("EngineState"))
        self.camera = camera
        self.scanAudio = scanAudio ?? ScanAudioFeedback()
        self.cameraStartTimeoutNanoseconds = cameraStartTimeoutNanoseconds
        camera.onIlluminationChanged = { [weak self] value in
            Task { @MainActor in self?.torchStatus = value }
        }
        do { try reload() } catch { status = error.localizedDescription }
        let calibrationFile = repository.root.appendingPathComponent("MUA-calibration.json")
        if FileManager.default.fileExists(atPath: calibrationFile.path) {
            do { muaCalibration = try MUACalibration.load(Data(contentsOf: calibrationFile)) }
            catch { status = "Kaydedilen MUA kalibrasyonu geçersiz; yeniden içe aktarın." }
        }
        if !ProcessInfo.processInfo.arguments.contains("--ui-testing") { token = PairingKey.load() ?? "" }
    }
    private func client() throws -> OfflineClient { OfflineClient(engine: offlineEngine) }
    func toggleSound() {
        soundEnabled.toggle()
        if !soundEnabled { scanAudio.stop(); soundStatus = nil }
    }
    func testScanSound() {
        guard soundEnabled else { soundStatus = "Önce tarama sesini açın."; return }
        soundStatus = scanAudio.play(.test)
    }
    func toggleTorch() {
        guard !cameraStarting, !busy, !computing, !illuminationChanging else { return }
        torchEnabled.toggle()
        guard ready else { return }
        let resume = autoRunning
        // Re-establish exposure after changing light while retaining the saved
        // optical profile. In-flight frames finish under their original profile.
        stopCamera()
        let request = UUID()
        illuminationRequestID = request; illuminationChanging = true
        status = "Işık ayarlanıyor; kayıtlı bayraklar korunuyor…"
        illuminationTask = Task { [weak self] in
            guard let self else { return }
            while self.illuminationRequestID == request && (self.analyzing || self.uploading) {
                do { try await Task.sleep(nanoseconds: 20_000_000) } catch { return }
            }
            guard self.illuminationRequestID == request, !Task.isCancelled else { return }
            self.illuminationRequestID = nil; self.illuminationTask = nil
            self.illuminationChanging = false
            self.automaticStartRequested = resume
            self.openCamera()
        }
    }
    func startGuidedScan() {
        if mode == "calibration" { beginCalibrationScan(); return }
        guard ["trial", "scan"].contains(mode), !busy, !cameraStarting, !computing,
              !analyzing, !uploading, !illuminationChanging, pendingCount == 0 else { return }
        guard current == nil || (current?.engine == "iphone_native_v1" && current?.state == "collecting") else {
            status = "Bu kayıt kapalı. Başlangıç'tan yeni kayıt hazırlayın."; return
        }
        do { try plan.validate(count: markerCount) }
        catch { status = error.localizedDescription; return }
        if ready { startAutomatic() }
        else { automaticStartRequested = true; openCamera() }
    }
    func importMUACalibration(_ url: URL) {
        guard currentID == nil, !ready, !busy, !computing, !analyzing, !uploading else { return }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            guard (try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0) <= 256_000 else { throw LabError.message("MUA kalibrasyon dosyası fazla büyük.") }
            let calibration = try MUACalibration.load(Data(contentsOf: url))
            try FileManager.default.createDirectory(at: repository.root, withIntermediateDirectories: true)
            try calibration.canonicalData().write(to: repository.root.appendingPathComponent("MUA-calibration.json"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            muaCalibration = calibration
            status = "Ölçülmüş MUA dönüşümleri içe aktarıldı. Fiziksel seri numaralarının basılan bayraklarla eşleştiğini kontrol edin."
        } catch { status = error.localizedDescription }
    }
    func clearMUACalibration() {
        guard currentID == nil, !ready, !busy, !computing else { return }
        do {
            let file = repository.root.appendingPathComponent("MUA-calibration.json")
            if FileManager.default.fileExists(atPath: file.path) { try FileManager.default.removeItem(at: file) }
            muaCalibration = nil
            status = "Yeni taramalarda MUA dönüşümü kullanılmayacak. Önceki kayıtlar korunuyor."
        } catch { status = error.localizedDescription }
    }
    private func register(_ capture: LocalCapture, bridge: OfflineClient) async throws {
        guard capture.engine == "iphone_native_v1" else { throw LabError.message("Önceki PC kaydı salt okunur. Yeni bir iPhone kaydı başlatın.") }
        let key = RegistrationKey(base: bridge.base, token: bridge.token, session: capture.id)
        guard !registeredSessions.contains(key) else { return }
        let registered = try await bridge.send("sessions", value: capture.creation)
        guard registered["id"] as? String == capture.id else { throw LabError.message("Yerel hesap kaydı eşleşmedi.") }
        if capture.creation.dentalPlan != nil, registered["dental_plan"] == nil {
            throw LabError.message("Yerel motor FDI planını kaydedemedi.")
        }
        registeredSessions.insert(key)
    }
    private func reload() throws {
        sessions = try repository.list()
        availableCalibrations = eligibleCalibrations(sessions)
    }
    func importPairing(_ link: String) {
        guard !uploading, !connecting, !computing else { return }
        do {
            let details = try PairingDetails(link: link)
            address = details.address; token = details.token; connected = false; registeredSessions.removeAll()
            status = "QR okundu. Bilgisayara bağlan düğmesine bas."
        } catch { status = error.localizedDescription }
    }
    func showIllustration() {
        guard !busy, !computing, !analyzing, !uploading else { return }
        stopCamera(); currentID = nil; resultFile = nil; exportFiles = []
        resultSnapshot = .illustration(count: markerCount)
        status = "Örnek geometri gösteriliyor; kamera ölçümü yapılmadı."
    }
    func connect() async {
        connected = true; casePlanSupported = true; autoSupported = true; fastCommitSupported = true
        status = "iPhone hesap motoru hazır. PC veya internet gerekmez."
        await sendPending()
    }
    private func eligibleCalibrations(_ captures: [LocalCapture]) -> [LocalCapture] {
        captures.filter { capture in
            guard capture.engine == "iphone_native_v1", capture.creation.mode == "calibration", capture.state == "complete",
                  let url = try? repository.resultURL(capture.id), let bytes = try? Data(contentsOf: url),
                  let envelope = (try? JSONSerialization.jsonObject(with: bytes)) as? [String: Any],
                  let camera = envelope["calibration"] as? [String: Any], let meta = camera["metadata"] as? [String: Any],
                  meta["status"] as? String == "measured_research", let warnings = meta["warnings"] as? [String], warnings.isEmpty,
                  let rms = meta["rms_px"] as? Double, rms.isFinite, (0...0.6).contains(rms), ((meta["views"] as? Int) ?? 0) >= 10 else { return false }
            return true
        }
    }
    func chooseCalibration(_ capture: LocalCapture) {
        guard currentID == nil, !busy, !computing, !ready, availableCalibrations.contains(where: { $0.id == capture.id }) else { return }
        calibrationID = capture.id; focus = capture.creation.profile.lensPosition
        status = "Yerel kalibrasyon seçildi; aynı odak profili kullanılacak."
    }
    func runNativeValidation() async {
        guard !busy, !computing, !analyzing, !uploading else { return }
        stopCamera(); computing = true; validationText = "Sentetik referanslarla iPhone motoru sınanıyor…"
        defer { computing = false }
        do {
            let report = try await offlineEngine.validateSynthetic()
            guard report["passed"] as? Bool == true else { throw LabError.message("Sentetik referans kontrollerinden biri geçmedi.") }
            let bytes = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
            let folder = repository.root.deletingLastPathComponent().appendingPathComponent("Validation")
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try bytes.write(to: folder.appendingPathComponent("native-validation.json"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
            validationText = "Motor testi başarılı. Hesaplar bu iPhone'da çalıştı. Sentetik test fiziksel doğruluk değildir.\n" + (String(data: bytes, encoding: .utf8) ?? "")
            status = "Bağlantısız motor testi tamamlandı."
        } catch { validationText = "Motor testi başarısız: \(error.localizedDescription)"; status = "Motor testi tamamlanamadı." }
    }
    func openCamera() { openCamera(reacquireTrialFocus: false) }
    private func openCamera(reacquireTrialFocus: Bool) {
        guard !ready, !busy, !computing, !analyzing, !illuminationChanging else { return }
        if reacquireTrialFocus {
            guard mode == "trial", current?.creation.mode == "trial", current?.state == "collecting",
                  pendingCount == 0 else { return }
        }
        cameraDiagnostic = nil
        refocusRequestID = nil
        cameraStartIsTrialRefocus = reacquireTrialFocus
        requiredCameraProfile = current?.activeProfile
        if currentID == nil, mode == "scan" {
            guard let selected = availableCalibrations.first(where: { $0.id == calibrationID }) else {
                automaticStartRequested = false
                status = "Önce uygun fiziksel kalibrasyonu seçin."
                return
            }
            requiredCameraProfile = selected.creation.profile
        }
        let focusRequest: CameraFocusRequest = reacquireTrialFocus ? .automatic : (requiredCameraProfile.map { .locked($0.lensPosition) } ?? .automatic)
        let attempt = UUID()
        cameraRunID = attempt
        camera.onInterruption = { [weak self] message in
            Task { @MainActor in
                guard let self, self.cameraRunID == attempt else { return }
                self.stopCamera(); self.status = message
            }
        }
        cameraStartID = attempt; cameraStarting = true; busy = true; ready = false
        status = requiredCameraProfile == nil || reacquireTrialFocus
            ? "Tahtayı veya bayrakları ortada tutun; otomatik netleniyor… (en fazla 12 saniye)"
            : "Kayıtlı odak ve ışık hazırlanıyor… (en fazla 12 saniye)"
        cameraStartWatchdog?.cancel()
        let timeout = cameraStartTimeoutNanoseconds
        cameraStartWatchdog = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: timeout) } catch { return }
            guard let self, self.cameraStartID == attempt else { return }
            self.finishCameraStart(attempt, result: .failure(LabError.message("Kamera açılışı zaman aşımına uğradı. Kamerayı aç ile tekrar deneyin; başka bir uygulama kamerayı kullanıyorsa kapatın.")))
        }
        camera.configureIllumination(enabled: torchEnabled)
        camera.start(focus: focusRequest) { [weak self] result in
            Task { @MainActor in self?.finishCameraStart(attempt, result: result) }
        }
    }
    private func finishCameraStart(_ attempt: UUID, result: Result<CaptureProfile, Error>) {
        guard cameraStartID == attempt else { return }
        cameraStartID = nil; cameraStartWatchdog?.cancel(); cameraStartWatchdog = nil
        busy = false; cameraStarting = false
        switch result {
        case .success(let profile):
            guard profile.lensPosition.isFinite, (0...1).contains(profile.lensPosition),
                  requiredCameraProfile.map({ cameraStartIsTrialRefocus ? $0.accepts(profile, mode: "trial") : $0 == profile }) ?? true else {
                automaticStartRequested = false; cameraRunID = nil
                ready = false; camera.stop(); UIApplication.shared.isIdleTimerDisabled = false
                status = "Kamera kayıtlı kalibrasyon profiline dönmedi. Yeni kalibrasyon başlatın; önceki kayıt korunuyor."
                return
            }
            if cameraStartIsTrialRefocus {
                do {
                    guard let id = currentID, mode == "trial" else { throw LabError.message("2B deneyi değişti.") }
                    try repository.updateTrialProfile(session: id, profile: profile)
                    try reload()
                } catch {
                    cameraRunID = nil; ready = false; camera.stop(); UIApplication.shared.isIdleTimerDisabled = false
                    status = "Yeniden netleme kaydedilemedi: \(error.localizedDescription)"
                    return
                }
            }
            focus = profile.lensPosition
            ready = true; UIApplication.shared.isIdleTimerDisabled = true
            status = cameraStartIsTrialRefocus ? "Yeniden netlendi. Kaydedilen bayraklar korundu; Taramayı başlat ile devam edin." : mode == "calibration"
                ? "Kamera hazır. Kalibrasyon taramasını başlatıp tahtanın tamamını gösterin."
                : "Kamera hazır. Modeli sabit tutun, farklı açılardan çekin."
            if automaticStartRequested {
                automaticStartRequested = false
                startAutomatic()
            }
        case .failure(let error):
            automaticStartRequested = false
            cameraRunID = nil
            ready = false; camera.stop(); UIApplication.shared.isIdleTimerDisabled = false
            cameraDiagnostic = (error as? CameraStartupFailure)?.details
            status = error.localizedDescription
        }
    }
    func pauseAutomatic() {
        automaticStartRequested = false
        scanFeedbackActive = false
        audioGeneration += 1
        scanAudio.stop()
        if autoRunning && mode == "calibration" && !computing {
            status = "Kalibrasyon duraklatıldı. Alınan kareler korunuyor; Devam et ile sürdürebilirsiniz."
        }
        sampling.stop(); autoTask?.cancel(); autoRunning = false
    }
    func stopCamera() {
        illuminationRequestID = nil; illuminationTask?.cancel(); illuminationTask = nil
        illuminationChanging = false
        refocusRequestID = nil
        cameraStartIsTrialRefocus = false
        cameraRunID = nil
        cameraStartID = nil; cameraStartWatchdog?.cancel(); cameraStartWatchdog = nil
        if cameraStarting {
            cameraStarting = false; busy = false
            status = "Kamera açılışı iptal edildi. Kamerayı aç ile yeniden deneyebilirsiniz."
        }
        pauseAutomatic(); camera.stop(); ready = false; UIApplication.shared.isIdleTimerDisabled = false
    }
    func leaveCaptureScreen(showingCompletedResult: Bool) {
        // finish() already stopped the camera before producing this result.
        // Automatic navigation must not cut off its finite completion chime.
        if showingCompletedResult, current?.state == "complete", !ready,
           !cameraStarting, !autoRunning, !illuminationChanging { return }
        stopCamera()
    }
    private func clearFeedback() {
        lastRecognitionSample = nil; diagnosticFileURL = nil
        feedback = nil; feedbackImage = nil; feedbackDate = nil; lastSampleID = nil
        analysisSeconds = nil; detectorMilliseconds = nil; cycleSeconds = nil
        calibrationFeedback = nil; calibrationFeedbackImage = nil; calibrationFeedbackDate = nil
        calibrationTarget = 20; calibrationGuidance = nil
        flagCue = FlagConfirmationCue(); cue = AcceptanceCue(); newlyConfirmedIDs = []
    }
    func newSession() {
        guard !busy, !computing, !analyzing, !uploading else { status = "Önce çekimin bitmesini bekleyin."; return }
        stopCamera(); currentID = nil; lastImage = nil; resultSnapshot = nil; resultFile = nil; exportFiles = []
        clearFeedback()
        resultText = "Sonuç henüz yok."; status = "Yeni kayıt hazır. Kamerayı açın; netlik otomatik ayarlanacak."
    }
    func select(_ capture: LocalCapture) {
        guard !busy, !computing, !analyzing, !uploading else { return }; stopCamera(); clearFeedback(); currentID = capture.id; mode = capture.creation.mode
        plan = capture.creation.dentalPlan ?? DentalPlan()
        if capture.creation.dentalPlan == nil { plan.reset(count: capture.creation.markerCount) }
        markerCount = capture.creation.markerCount; focus = capture.activeProfile.lensPosition; status = capture.message
        physicalBoard = capture.creation.board.physicalMeasured
        if let square = capture.creation.board.squareMM { squareMM = String(square) }
        calibrationID = capture.creation.calibrationID ?? ""
        resultSnapshot = nil; resultFile = nil; lastImage = nil; exportFiles = []
        do {
            if capture.state == "complete", let snapshot = try repository.cachedResult(session: capture.id) {
                resultSnapshot = snapshot; resultFile = try repository.resultURL(capture.id)
                exportFiles = try ResearchExport.existing(repository: repository, session: capture.id)
            }
        } catch { status = error.localizedDescription }
    }
    private func captureCreation(profile: CaptureProfile) throws -> CaptureCreation {
        let physical = mode == "calibration" && physicalBoard
        let square = Double(squareMM.replacingOccurrences(of: ",", with: "."))
        if physical && (square == nil || !square!.isFinite || !(0.5...100).contains(square!)) {
            throw LabError.message("Kare boyutunu mm olarak kontrol edin.")
        }
        if mode == "scan" && calibrationID.count != 32 { throw LabError.message("Önce uygun fiziksel kalibrasyonu seçin.") }
        var creation = CaptureCreation(mode: mode, markerCount: markerCount, profile: profile,
            physical: physical, squareMM: physical ? square : nil, calibrationID: mode == "scan" ? calibrationID : nil)
        if mode != "calibration" { try plan.validate(count: markerCount); creation.dentalPlan = plan }
        if mode == "scan" { creation.muaCalibration = muaCalibration }
        return creation
    }
    /// One tap starts camera preparation, then automatic sampling after actual readiness.
    func beginCalibrationScan() {
        guard mode == "calibration", !autoRunning, !cameraStarting, !busy, !computing, !analyzing, !uploading else { return }
        guard !calibrationLimitReached else { status = "60 karede kalibrasyon tamamlanmadı. Açıları ve netliği kontrol edip Yeni kayıt hazırla ile yeniden başlayın."; return }
        guard current == nil || (current?.engine == "iphone_native_v1" && current?.state == "collecting") else {
            status = "Bu kalibrasyon kaydı kapalı. Yeni kayıt hazırla ile devam edin."; return
        }
        guard pendingCount == 0 else { status = "Önce kayıtlı kareleri işle düğmesiyle bekleyen analizi tamamlayın."; return }
        if physicalBoard {
            guard let square = Double(squareMM.replacingOccurrences(of: ",", with: ".")), square.isFinite,
                  (0.5...100).contains(square) else { status = "Kare boyutunu mm olarak kontrol edin."; return }
        }
        if ready { startAutomatic() }
        else { automaticStartRequested = true; openCamera() }
    }
    func takePhoto() {
        guard current?.engine != nil || current == nil else { status = "Önceki sürüm kaydı salt okunur. Yeni kayıt hazırla ile devam edin."; return }
        guard ready, !busy, !computing, !autoRunning, !analyzing, !uploading else { return }; busy = true
        scanFeedbackActive = true
        camera.capture(compactTrial: mode == "trial") { [weak self] outcome in
            Task { @MainActor in
                guard let self else { return }; defer { self.busy = false }
                do {
                    let (data, p, stamp) = try outcome.get()
                    if let active = self.current {
                        guard active.activeProfile == p, active.creation.mode == self.mode, active.state == "collecting" else {
                            throw LabError.message("Kamera profili/mod değişti veya kayıt kapalı. Yeni kayıt açın.")
                        }
                    } else {
                        let creation = try self.captureCreation(profile: p)
                        _ = try await self.client().send("sessions", value: creation)
                        try self.repository.create(creation); self.currentID = creation.id
                    }
                    guard let id = self.currentID else { return }
                    self.lastSampleID = try self.repository.append(id: id, image: data, timestamp: stamp, profile: p)
                    try self.reload(); self.lastImage = UIImage(data: data)
                    self.status = "Görüntü telefona kaydedildi. \(self.pendingCount) görüntü yerel analiz bekliyor."
                    Task { await self.sendPending() }
                } catch { self.status = error.localizedDescription }
            }
        }
    }
    func sendPending(cachedCommit: PreviewCommit? = nil) async {
        guard !uploading, pendingCount > 0 else { return }; uploading = true; defer { uploading = false }
        do {
            let bridge = try client()
            // Re-read after each batch: photos captured during an upload must not
            // wait indefinitely for another button press to enter the next batch.
            while let capture = try repository.list().first(where: { $0.id == currentID && $0.engine == "iphone_native_v1" && !$0.pending.isEmpty }) {
                try await register(capture, bridge: bridge)
                for frame in capture.pending {
                    let data = try repository.image(session: capture.id, frame: frame.id)
                    let digest = PreviewCommit.digest(data)
                    var cachedReceipt: [String: Any]?
                    if let commit = cachedCommit, commit.session == capture.id, commit.id == frame.id, commit.sha256 == digest {
                        do { cachedReceipt = try await bridge.send("sessions/\(capture.id)/commit-preview", value: commit) }
                        catch let error as BridgeHTTPError where error.retryWithOriginal { /* Expired cache/older server: send the original. */ }
                    }
                    let receipt: [String: Any]
                    if let cachedReceipt { receipt = cachedReceipt }
                    else {
                        receipt = try await bridge.send("sessions/\(capture.id)/frames",
                            value: FrameUpload(id: frame.id, image: data.base64EncodedString(), profile: frame.profile ?? capture.creation.profile, timestamp: frame.timestamp))
                    }
                    try PreviewCommit.verify(receipt, frame: frame.id, digest: digest)
                    if capture.creation.mode != "calibration", currentID == capture.id, frame.id == lastSampleID {
                        lastRecognitionSample = RecognitionSample(session: capture.id, sample: frame.id, image: data,
                            profile: frame.profile ?? capture.creation.profile, timestamp: frame.timestamp,
                            mode: capture.creation.mode, markerCount: capture.creation.markerCount, response: receipt)
                    }
                    let analysis: LiveFeedback?
                    let boardAnalysis: CalibrationFeedback?
                    if capture.creation.mode == "calibration" {
                        analysis = nil
                        // A previously committed 0.9 frame can return its old receipt
                        // after an interrupted acknowledgement during an app upgrade.
                        if receipt["calibration_feedback"] is [String: Any] {
                            boardAnalysis = try CalibrationFeedback.decode(receipt, session: capture.id, sample: frame.id)
                            guard boardAnalysis?.preview == false else { throw LabError.message("Kalibrasyon önizlemesi kayıt onayı değildir.") }
                        } else { boardAnalysis = nil }
                    }
                    else { analysis = try LiveFeedback.decode(receipt, session: capture.id, sample: frame.id, count: capture.creation.markerCount); boardAnalysis = nil }
                    guard analysis?.preview != true else { throw LabError.message("Kayıt onayı yerine önizleme geldi; görüntü korundu.") }
                    try repository.acknowledge(session: capture.id, frame: frame.id, receipt: receipt)
                    try reload()
                    if currentID == capture.id {
                        status = (receipt["message"] as? String) ?? "Görüntü iPhone’da işlendi."
                        if frame.id == lastSampleID, capture.creation.mode != "calibration", receipt["feedback"] is [String: Any] {
                            feedback = analysis
                            feedbackImage = UIImage(data: data); feedbackDate = Date()
                            if let feedback { acceptedCue(feedback) }
                        }
                        if frame.id == lastSampleID, let boardAnalysis {
                            calibrationFeedback = boardAnalysis; calibrationFeedbackImage = UIImage(data: data)
                            calibrationFeedbackDate = Date(); calibrationTarget = boardAnalysis.targetFrames
                            acceptedCue(sample: boardAnalysis.sampleID, preview: boardAnalysis.preview, usable: boardAnalysis.usable)
                        }
                    }
                }
            }
        } catch { registeredSessions.removeAll(); status = "Yerel analiz durdu; görüntüler telefonda korunuyor. \(error.localizedDescription)" }
    }
    func startAutomatic() {
        if mode == "calibration" && calibrationLimitReached { status = "Kalibrasyon için Yeni kayıt hazırla ile yeniden başlayın."; return }
        guard current?.engine != nil || current == nil else { status = "Önceki sürüm kaydı salt okunur. Yeni kayıt hazırlayın."; return }
        guard ready, autoSupported, !busy, !computing, !uploading,
              !analyzing, pendingCount == 0 else {
            status = "Otomatik tarama için kamerayı açın ve bekleyen yerel analizleri tamamlayın."
            return
        }
        do {
            if currentID == nil && mode != "calibration" {
                guard casePlanSupported else { throw LabError.message("Yerel FDI planı kullanılamadı.") }
                try plan.validate(count: markerCount)
            }
        } catch { status = error.localizedDescription; return }
        guard sampling.start() else { return }
        scanFeedbackActive = true
        autoRunning = true
        if mode == "calibration" { status = "Kalibrasyon taranıyor. Tahtanın tamamını gösterip farklı açılarda kısa süre sabit tutun." }
        let run = sampling.epoch
        autoTask = Task { [weak self] in
            guard let self else { return }
            defer {
                if self.sampling.epoch == run { self.autoRunning = false; self.autoTask = nil }
            }
            while !Task.isCancelled, let ticket = self.sampling.reserve() {
                let cycleStarted = ProcessInfo.processInfo.systemUptime
                self.analyzing = true
                do { try await self.sampleAutomatically(ticket: ticket) }
                catch {
                    if self.sampling.owns(ticket), !Task.isCancelled {
                        self.status = "Tarama duraklatıldı. \(error.localizedDescription)"
                    }
                    self.sampling.stop()
                    self.registeredSessions.removeAll()
                }
                self.sampling.release(ticket); self.analyzing = false
                if self.mode == "calibration", self.sampling.active, !Task.isCancelled,
                   (self.current?.acceptedCount ?? 0) >= self.calibrationTarget {
                    await self.finishAutomaticCalibration(run: run)
                } else if self.mode != "calibration", self.sampling.active, !Task.isCancelled,
                          self.feedback?.coverageReached == true, self.pendingCount == 0 {
                    self.sampling.stop(); self.autoRunning = false
                    // finish() stops the camera. Detach this task handle so that
                    // stopping capture cannot cancel the result being calculated.
                    self.autoTask = nil
                    self.status = self.mode == "trial" ? "Bayraklar tamamlandı; sonuç açılıyor…" : "Görüntüler tamamlandı; 3B konumlar hesaplanıyor…"
                    await self.finish()
                    return
                }
                guard self.sampling.active, !Task.isCancelled else { return }
                let elapsed = ProcessInfo.processInfo.systemUptime - cycleStarted
                self.cycleSeconds = elapsed
                let delay = self.mode == "calibration" ? CalibrationCadence.delayNanoseconds(elapsed: elapsed) : ScanCadence.delayNanoseconds(elapsed: elapsed)
                do { try await Task.sleep(nanoseconds: delay) } catch { return }
            }
        }
    }
    private func sampleAutomatically(ticket: Int) async throws {
        let started = ProcessInfo.processInfo.systemUptime
        let sample: (Data, CaptureProfile, Double) = try await withCheckedThrowingContinuation { continuation in
            camera.capture(compactTrial: mode == "trial") { continuation.resume(with: $0) }
        }
        guard sampling.owns(ticket), !Task.isCancelled else { return }
        let (data, profile, timestamp) = sample
        if let active = current {
            guard active.activeProfile == profile, active.creation.mode == mode, active.state == "collecting" else {
                throw LabError.message("Kamera profili/mod değişmiş veya kayıt tamamlanmış. Yeni kayıt hazırlayın.")
            }
        } else {
            let creation = try captureCreation(profile: profile)
            _ = try await client().send("sessions", value: creation)
            guard sampling.owns(ticket), !Task.isCancelled else { return }
            try repository.create(creation); currentID = creation.id; try reload()
        }
        guard let capture = current else { throw LabError.message("Çekim kaydı açılamadı.") }
        let bridge = try client()
        try await register(capture, bridge: bridge)
        guard sampling.owns(ticket), !Task.isCancelled, currentID == capture.id else { return }
        let fid = captureID()
        let receipt = try await bridge.send("sessions/\(capture.id)/preview",
            value: FrameUpload(id: fid, image: data.base64EncodedString(), profile: profile, timestamp: timestamp))
        guard sampling.owns(ticket), !Task.isCancelled, currentID == capture.id else { return }
        analysisSeconds = ProcessInfo.processInfo.systemUptime - started
        if capture.creation.mode != "calibration" {
            lastRecognitionSample = RecognitionSample(session: capture.id, sample: fid, image: data,
                profile: profile, timestamp: timestamp, mode: capture.creation.mode,
                markerCount: capture.creation.markerCount, response: receipt)
        }
        let usable: Bool
        if capture.creation.mode == "calibration" {
            let analysis = try CalibrationFeedback.decode(receipt, session: capture.id, sample: fid)
            calibrationFeedback = analysis; calibrationFeedbackImage = UIImage(data: data); calibrationFeedbackDate = Date()
            calibrationTarget = analysis.targetFrames; detectorMilliseconds = analysis.detectionMilliseconds
            status = analysis.message; usable = analysis.usable
        } else {
            let analysis = try LiveFeedback.decode(receipt, session: capture.id, sample: fid, count: capture.creation.markerCount)
            detectorMilliseconds = analysis.detectionMilliseconds
            flagCue.restore(analysis.completedIDs)
            newlyConfirmedIDs = []
            feedback = analysis; feedbackImage = UIImage(data: data); feedbackDate = Date(); status = analysis.message
            usable = analysis.usable
        }
        guard usable else { return }
        // Persist before the authoritative commit. If the connection fails, the
        // same frame ID is retried from disk; the server cannot double-count it.
        lastSampleID = try repository.append(id: capture.id, image: data, timestamp: timestamp, frameID: fid, profile: profile)
        lastImage = UIImage(data: data); try reload()
        let commit = fastCommitSupported ? PreviewCommit(session: capture.id, id: fid, sha256: PreviewCommit.digest(data), profile: profile, timestamp: timestamp) : nil
        await sendPending(cachedCommit: commit)
        guard current?.pending.isEmpty == true else { throw LabError.message("Yerel analiz tamamlanamadı. Görüntü telefonda korunuyor.") }
    }
    private func acceptedCue(_ feedback: LiveFeedback) {
        newlyConfirmedIDs = flagCue.consume(feedback)
        let newSample = cue.consume(sample: feedback.sampleID, preview: feedback.preview, usable: feedback.usable)
        if !newlyConfirmedIDs.isEmpty { playScanSound(.flagConfirmed) }
        else if newSample { playScanSound(.sampleAccepted) }
    }
    private func acceptedCue(sample: String, preview: Bool, usable: Bool) {
        guard cue.consume(sample: sample, preview: preview, usable: usable) else { return }
        playScanSound(.sampleAccepted)
    }
    private func playScanSound(_ event: ScanSoundEvent, allowStopped: Bool = false) {
        guard (ready && scanFeedbackActive) || allowStopped else { return }
        if event == .flagConfirmed || event == .completed {
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        }
        guard soundEnabled else { return }
        soundStatus = scanAudio.play(event)
    }
    private func finishAutomaticCalibration(run: Int) async {
        guard let id = currentID, mode == "calibration", sampling.active, sampling.epoch == run,
              !uploading, !busy, !computing, !analyzing, pendingCount == 0 else { return }
        computing = true; defer { computing = false }
        status = "Açı çeşitliliği kontrol ediliyor; kalibrasyon iPhone'da hesaplanıyor…"
        let startingAudioGeneration = audioGeneration
        do {
            let response = try await client().request("sessions/\(id)/process", body: ["automatic": true])
            guard currentID == id else { return }
            let state = (response["state"] as? String) ?? "collecting"
            let message = (response["message"] as? String) ?? "Kalibrasyon değerlendirildi."
            try repository.update(session: id, state: state, message: message)
            try reload()
            if state == "complete" {
                let audible = startingAudioGeneration == audioGeneration
                calibrationGuidance = nil; stopCamera()
                let completionAudioGeneration = audioGeneration
                await refreshResult()
                if audible, completionAudioGeneration == audioGeneration, resultSnapshot != nil {
                    playScanSound(.completed, allowStopped: true)
                }
            } else {
                calibrationTarget = (response["next_calibration_target"] as? Int) ?? min(60, (current?.acceptedCount ?? 20) + 5)
                calibrationGuidance = (response["calibration_guidance"] as? String) ?? message
                status = calibrationGuidance ?? message
                if response["calibration_paused"] as? Bool == true { pauseAutomatic() }
            }
        } catch {
            sampling.stop()
            status = "Kalibrasyon hesabı duraklatıldı. Kareler korunuyor. \(error.localizedDescription)"
        }
    }
    func finish() async {
        guard let currentID else { status = "Önce görüntü kaydedin."; return }
        guard current?.engine == "iphone_native_v1" else { status = "Önceki PC kaydının önbelleği korunuyor. Yeni iPhone kaydı başlatın."; return }
        guard !uploading, !busy, !computing, !analyzing else { status = "Önce çekim ve yerel analizin bitmesini bekleyin."; return }
        computing = true; defer { computing = false }
        stopCamera()
        let completionAudioGeneration = audioGeneration
        await sendPending()
        guard current?.pending.isEmpty == true else { status = "Bekleyen görüntüler işlenmeden hesap başlatılmaz."; return }
        do {
            let result = try await client().request("sessions/\(currentID)/process", body: [:])
            try repository.update(session: currentID, state: (result["state"] as? String) ?? "processing", message: (result["message"] as? String) ?? "Hesaplanıyor")
            try reload(); status = current?.message ?? "Hesaplanıyor"; await refreshResult()
            if completionAudioGeneration == audioGeneration, resultSnapshot != nil { playScanSound(.completed, allowStopped: true) }
        } catch {
            let failure = error.localizedDescription
            await refreshResult()
            status = failure
        }
    }
    func refreshResult() async {
        guard let currentID, !refreshing else { return }
        guard current?.engine == "iphone_native_v1" else { return }
        refreshing = true; defer { refreshing = false }
        do {
            let result = try await client().request("sessions/\(currentID)")
            guard result["id"] as? String == currentID else { throw LabError.message("Hesap motoru farklı kaydın sonucunu döndürdü.") }
            let message = (result["message"] as? String) ?? "Sonuç bekleniyor."
            try repository.update(session: currentID, state: (result["state"] as? String) ?? "collecting", message: message)
            var snapshot: ResultSnapshot?
            if result["state"] as? String == "complete" { snapshot = try repository.cacheResult(session: currentID, response: result) }
            try reload()
            guard self.currentID == currentID else { return }
            status = message; resultSnapshot = snapshot
            if snapshot != nil {
                resultFile = try repository.resultURL(currentID)
                exportFiles = try ResearchExport.write(response: result, repository: repository, session: currentID)
            } else { resultFile = nil; exportFiles = [] }
            if current?.creation.mode == "calibration", current?.state == "complete" {
                calibrationID = availableCalibrations.contains(where: { $0.id == currentID }) ? currentID : ""
            }
            var lines = [message, "Fiziksel doğruluk: ölçülmedi."]
            if let calibration = result["calibration"] as? [String: Any], let meta = calibration["metadata"] as? [String: Any] {
                if let rms = meta["rms_px"] as? Double { lines.append(String(format: "Görüntü uyum hatası: %.3f px (mikron değildir)", rms)) }
                lines.append("Kalibrasyon kimliği: \(currentID)")
                if let warnings = meta["warnings"] as? [String] { lines.append(contentsOf: warnings) }
            }
            if let r = result["result"] as? [String: Any], let rms = r["reprojection_rms_px"] as? Double {
                lines.append(String(format: "Görüntü uyum hatası: %.3f px", rms))
            }
            resultText = lines.joined(separator: "\n\n")
        } catch { if self.currentID == currentID { status = error.localizedDescription } }
    }
    func pollResult() async {
        guard let id = currentID else { return }
        for _ in 0..<60 {
            guard !Task.isCancelled, currentID == id, current?.state == "processing" else { return }
            await refreshResult()
            do { try await Task.sleep(nanoseconds: 2_000_000_000) } catch { return }
        }
    }
}
