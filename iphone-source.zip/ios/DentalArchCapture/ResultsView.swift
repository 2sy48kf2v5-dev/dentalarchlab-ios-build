import SwiftUI

struct NativeResultsView: View {
    @EnvironmentObject var model: CaptureModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                if let result = model.resultSnapshot {
                    Label(result.isSynthetic ? "ÖRNEK · FİZİKSEL ÖLÇÜM DEĞİL" : "ARAŞTIRMA SONUCU", systemImage: "viewfinder")
                        .font(.caption.bold()).foregroundStyle(.teal)
                    Text(result.title).font(.title2.bold())
                    Text(result.message).font(.callout)
                    if let trial = result.trial {
                        VStack(alignment: .leading, spacing: 12) {
                            Label("\(trial.recognizedIDs.count)/\(trial.expectedCount) bayrak kaydedildi",
                                  systemImage: trial.missingIDs.isEmpty ? "checkmark.circle.fill" : "circle.lefthalf.filled")
                                .font(.title2.bold()).foregroundStyle(trial.missingIDs.isEmpty ? Color.green : .orange)
                                .accessibilityIdentifier("trialRecognitionResult")
                            ForEach(0..<trial.expectedCount, id: \.self) { id in
                                let found = trial.recognizedIDs.contains(id)
                                Label("Bayrak \(id) · \(found ? "Kaydedildi" : "Bulunamadı")",
                                      systemImage: found ? "checkmark.circle.fill" : "minus.circle")
                                    .foregroundStyle(found ? Color.green : .orange)
                            }
                            Text("\(trial.acceptedFrames) uygun kare · her kimlik yalnız bir kez sayıldı.").font(.caption)
                            Text("Bu sonuç bayrak tanıma testidir. X/Y/Z ve eksen hesabı için fiziksel bayraklarla 3B araştırma modunda farklı açılardan tarayın.")
                                .font(.callout)
                        }.padding().background(Color.teal.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    if !result.landmarks.isEmpty {
                        LandmarkScene(landmarks: result.landmarks).frame(height: 340)
                        Text("Parmağınla döndür. − / + ile uzaklığı ayarla. Çizgiler +Z eksenlerini gösterir.").font(.caption).foregroundStyle(.secondary)
                        Text(result.hasMUA ? "MUA ve bayrak koordinatları" : "Bayrak merkezleri · MUA bağlantı kalibrasyonu yok").font(.subheadline.bold())
                        ForEach(result.landmarks) { point in
                            HStack {
                                Text("\(point.isMUA ? "MUA" : "Bayrak") \(point.id)").font(.subheadline.bold())
                                Spacer()
                                Text(String(format: "X %.2f  Y %.2f  Z %.2f", point.center.x, point.center.y, point.center.z))
                                    .font(.caption.monospacedDigit())
                            }.accessibilityElement(children: .combine)
                        }
                        Text(result.isIllustration ? "Örnek boyutlar mm cinsinden tanımlıdır." : "Birim: mm. Ölçek, kullanılan hedef geometrisine bağlıdır.").font(.caption).foregroundStyle(.secondary)
                    }
                    if let rms = result.rmsPX {
                        LabeledContent("Görüntü uyum hatası", value: String(format: "%.3f px", rms))
                    }
                    LabeledContent("Fiziksel doğruluk", value: "Henüz ölçülmedi")
                        .font(.subheadline.bold()).padding().background(Color.orange.opacity(0.10)).clipShape(RoundedRectangle(cornerRadius: 14))
                    Text("Piksel hatası mikron doğruluğu değildir. Klinik kullanım için doğrulanmadı.").font(.caption).foregroundStyle(.secondary)
                    ForEach(Array(result.warnings.enumerated()), id: \.offset) { _, warning in
                        Label(warning, systemImage: "exclamationmark.triangle").font(.caption)
                    }
                } else {
                    ContentUnavailableView(model.current?.state == "error" ? "Hesap tamamlanamadı" : "Sonuç bekleniyor",
                        systemImage: model.current?.state == "error" ? "exclamationmark.triangle" : "cube.transparent",
                        description: Text(model.current?.state == "error" ? model.status : model.resultText))
                }
                if model.currentID != nil {
                    if let capture = model.current, capture.state == "error", capture.engine == "iphone_native_v1", capture.acceptedCount > 0 {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("\(capture.acceptedCount) uygun kare korunuyor", systemImage: "photo.stack")
                                .font(.subheadline.bold()).accessibilityIdentifier("preservedResultFrames")
                            Text("Aynı kayıtlı karelerle hesabı yeniden deneyebilirsiniz. Kamerayı açmanız veya yeniden taramanız gerekmez.")
                                .font(.caption).foregroundStyle(.secondary)
                            Button(model.computing ? "Kaydedilen kareler hesaplanıyor…" : "Kaydedilen karelerle yeniden hesapla") {
                                Task { await model.finish() }
                            }.buttonStyle(.borderedProminent).accessibilityIdentifier("retrySavedResult")
                                .disabled(model.busy || model.computing || model.analyzing || model.uploading || model.refreshing || model.pendingCount > 0)
                        }.padding().background(Color.orange.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    Button("Sonucu yenile") { Task { await model.refreshResult() } }.buttonStyle(.bordered).disabled(model.refreshing || model.computing)
                    if !model.exportFiles.isEmpty {
                        ShareLink(items: model.exportFiles) {
                            Label(model.resultSnapshot?.trial != nil ? "2B deney özetini paylaş · JSON" : "Araştırma dosyalarını paylaş · CSV / JSON / PLY", systemImage: "square.and.arrow.up")
                        }.buttonStyle(.bordered).accessibilityIdentifier("shareResearchFiles")
                        Text(model.resultSnapshot?.trial != nil ? "2B deney özeti uzaysal koordinat içermez."
                             : "Paylaşılan geometri araştırma içindir. Exocad implant kütüphanesi ve MUA eşleşmesi ayrıca doğrulanmalıdır.")
                            .font(.caption).foregroundStyle(.secondary)
                    } else if let file = model.resultFile {
                        ShareLink(item: file) { Label("Sonuç JSON dosyasını paylaş", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered)
                    }
                    Text(model.status).font(.caption).foregroundStyle(.secondary)
                }
            }.padding()
        }.navigationTitle("Sonuç")
            .task(id: model.currentID) { await model.pollResult() }
    }
}

struct LandmarkScene: View {
    let landmarks: [ResultLandmark]
    @State private var yaw = -0.2
    @State private var pitch = 0.7
    @State private var zoom = 1.0
    @GestureState private var drag = CGSize.zero
    private var center: LabPoint { landmarks.reduce(.zero) { $0 + $1.center } * (1 / Double(max(landmarks.count, 1))) }
    private var radius: Double { max(landmarks.map { ($0.center-center).length }.max() ?? 1, 5) }
    private func rotated(_ point: LabPoint) -> LabPoint {
        let a = yaw + Double(drag.width)*0.008, b = min(1.5, max(-1.5, pitch + Double(drag.height)*0.008))
        let x = cos(a)*point.x - sin(a)*point.y, y = sin(a)*point.x + cos(a)*point.y
        return LabPoint(x: x, y: cos(b)*y - sin(b)*point.z, z: sin(b)*y + cos(b)*point.z)
    }
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Canvas { context, size in
                let scale = Double(min(size.width, size.height)) * 0.34 / radius * zoom
                func screen(_ p: LabPoint) -> CGPoint {
                    let r = rotated(p-center)
                    return CGPoint(x: Double(size.width)/2 + r.x*scale, y: Double(size.height)/2 - r.y*scale)
                }
                let axisLength = max(radius*0.32, 4)
                let sorted = landmarks.sorted { rotated($0.center-center).z < rotated($1.center-center).z }
                for item in sorted {
                    let p = screen(item.center), end = screen(item.center + item.axis*axisLength)
                    var stem = Path(); stem.move(to: p); stem.addLine(to: end)
                    context.stroke(stem, with: .color(.teal), style: StrokeStyle(lineWidth: 4, lineCap: .round))
                    context.fill(Path(ellipseIn: CGRect(x: p.x-8, y: p.y-8, width: 16, height: 16)), with: .color(.teal))
                    context.fill(Path(ellipseIn: CGRect(x: end.x-3, y: end.y-3, width: 6, height: 6)), with: .color(.orange))
                    context.draw(Text("\(item.id)").font(.caption.bold()).foregroundColor(.primary), at: CGPoint(x: p.x, y: p.y+22))
                }
            }.accessibilityLabel("\(landmarks.count) bayrağın döndürülebilir üç boyutlu görünümü. Koordinatlar aşağıdaki listede.")
                .gesture(DragGesture().updating($drag) { value, state, _ in state = value.translation }
                    .onEnded { value in yaw += Double(value.translation.width)*0.008; pitch = min(1.5, max(-1.5, pitch+Double(value.translation.height)*0.008)) })
            HStack {
                Button { zoom = max(0.5, zoom-0.2) } label: { Image(systemName: "minus.magnifyingglass") }.accessibilityLabel("Uzaklaştır")
                Button { zoom = min(2, zoom+0.2) } label: { Image(systemName: "plus.magnifyingglass") }.accessibilityLabel("Yakınlaştır")
                Button { yaw = -0.2; pitch = 0.7; zoom = 1 } label: { Image(systemName: "arrow.counterclockwise") }.accessibilityLabel("Görünümü sıfırla")
            }.buttonStyle(.bordered).padding(10)
        }.background(Color.teal.opacity(0.06)).clipShape(RoundedRectangle(cornerRadius: 20))
    }
}
