import SwiftUI

struct NativeResultsView: View {
    @EnvironmentObject var model: CaptureModel
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                if let result = model.resultSnapshot {
                    Label(result.isSynthetic ? "ÖRNEK · FİZİKSEL ÖLÇÜM DEĞİL" : "ARAŞTIRMA SONUCU", systemImage: "viewfinder")
                        .font(.caption.bold()).foregroundStyle(.teal)
                    Text(result.title).font(.title2.bold())
                    Text(result.message).font(.callout)
                    if let session = model.currentID, model.current?.creation.mode == "scan",
                       model.current?.state == "complete", !result.isSynthetic, !result.isIllustration,
                       result.trial == nil, !result.landmarks.isEmpty {
                        NavigationLink {
                            TissueAlignmentView(session: session, repository: model.repository)
                        } label: {
                            Label("Ağız içi yüzeyi eşleştir · STL / PLY", systemImage: "square.3.layers.3d")
                        }.buttonStyle(.borderedProminent).accessibilityIdentifier("openTissueAlignment")
                    }
                    if let trial = result.trial {
                        VStack(alignment: .leading, spacing: 12) {
                            Label("\(trial.recognizedIDs.count)/\(trial.expectedCount) bayrak kaydedildi",
                                  systemImage: trial.missingIDs.isEmpty ? "checkmark.circle.fill" : "circle.lefthalf.filled")
                                .font(.title2.bold()).foregroundStyle(trial.missingIDs.isEmpty ? Color.green : .orange)
                                .accessibilityIdentifier("trialRecognitionResult")
                            ForEach(trial.selectedIDs ?? Array(0..<trial.expectedCount), id: \.self) { id in
                                let found = trial.recognizedIDs.contains(id)
                                Label("Bayrak \(id) · \(found ? "Kaydedildi" : "Bulunamadı")",
                                      systemImage: found ? "checkmark.circle.fill" : "minus.circle")
                                    .foregroundStyle(found ? Color.green : .orange)
                            }
                            Text("\(trial.acceptedFrames) uygun kare · her kimlik yalnız bir kez sayıldı.").font(.caption)
                            Text("Bu sonuç bayrak tanıma testidir. X/Y/Z ve eksen hesabı için fiziksel bayraklarla 3B araştırma modunda farklı açılardan tarayın.")
                                .font(.callout)
                        }.padding().background(Color.teal.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    if !result.landmarks.isEmpty {
                        LandmarkScene(landmarks: result.landmarks, illustration: result.isIllustration).frame(height: 390)
                        Text(result.hasMUA || result.isIllustration
                            ? "Parmağınla döndür. − / + ile yakınlaştır. Gövdenin delikli üst yüzü +Z yönünü gösterir."
                            : "Parmağınla döndür. − / + ile yakınlaştır. Turuncu işaretler ölçülen bayrak merkezleridir.")
                            .font(.caption).foregroundStyle(.secondary)
                        if result.isIllustration || result.hasMUA {
                            Text(result.isIllustration ? "Örnek MUA yerleşimi" : "MUA uzaysal yerleşimi")
                                .font(.subheadline.bold()).accessibilityIdentifier("muaSpatialPlacement")
                            Text("MegaGen/Vida Dental bağlantı referansı. Gövdeler şematiktir; üretici parça ölçüleri veya Exocad üretim geometrisi değildir.")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        if !result.isIllustration {
                            let missing = result.landmarks.filter { !$0.isMUA }.count
                            if missing > 0 {
                                Label("\(missing) bayrağın MUA bağlantı kalibrasyonu eksik", systemImage: "exclamationmark.triangle")
                                    .font(.subheadline.bold()).foregroundStyle(.orange)
                                    .accessibilityIdentifier("missingMUACalibration")
                                Text("Turuncu işaretler bayrak merkezidir. Bu noktalara MUA gövdesi yerleştirmek için ölçülmüş bayrak–MUA dönüşümü gerekir.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        ForEach(result.landmarks) { point in
                            HStack {
                                Text("\(result.isIllustration ? "Örnek" : point.isMUA ? "MUA" : "Bayrak") \(point.id)").font(.subheadline.bold())
                                Spacer()
                                Text(String(format: "X %.2f  Y %.2f  Z %.2f", point.center.x, point.center.y, point.center.z))
                                    .font(.caption.monospacedDigit())
                            }.accessibilityElement(children: .combine)
                        }
                        Text(result.isIllustration ? "Örnek boyutlar mm cinsinden tanımlıdır." : "Birim: mm. Ölçek, kullanılan hedef geometrisine bağlıdır.").font(.caption).foregroundStyle(.secondary)
                    }
                    if let rms = result.rmsPX {
                        LabeledContent("Görüntü uyum hatası", value: String(format: "%.3f px", rms))
                    }
                    LabeledContent("Fiziksel doğruluk", value: "Henüz ölçülmedi")
                        .font(.subheadline.bold()).padding().background(Color.orange.opacity(0.10)).clipShape(RoundedRectangle(cornerRadius: 14))
                    Text("Piksel hatası mikron doğruluğu değildir. Klinik kullanım için doğrulanmadı.").font(.caption).foregroundStyle(.secondary)
                    ForEach(Array(result.warnings.enumerated()), id: \.offset) { _, warning in
                        Label(warning, systemImage: "exclamationmark.triangle").font(.caption)
                    }
                } else {
                    ContentUnavailableView(model.current?.state == "error" ? "Hesap tamamlanamadı" : "Sonuç bekleniyor",
                        systemImage: model.current?.state == "error" ? "exclamationmark.triangle" : "cube.transparent",
                        description: Text(model.current?.state == "error" ? model.status : model.resultText))
                }
                if model.currentID != nil {
                    if let capture = model.current, capture.state == "error", capture.engine == "iphone_native_v1", capture.acceptedCount > 0 {
                        VStack(alignment: .leading, spacing: 10) {
                            Label("\(capture.acceptedCount) uygun kare korunuyor", systemImage: "photo.stack")
                                .font(.subheadline.bold()).accessibilityIdentifier("preservedResultFrames")
                            Text("Aynı kayıtlı karelerle hesabı yeniden deneyebilirsiniz. Kamerayı açmanız veya yeniden taramanız gerekmez.")
                                .font(.caption).foregroundStyle(.secondary)
                            Button(model.computing ? "Kaydedilen kareler hesaplanıyor…" : "Kaydedilen karelerle yeniden hesapla") {
                                Task { await model.finish() }
                            }.buttonStyle(.borderedProminent).accessibilityIdentifier("retrySavedResult")
                                .disabled(model.busy || model.computing || model.analyzing || model.uploading || model.refreshing || model.pendingCount > 0)
                        }.padding().background(Color.orange.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    Button("Sonucu yenile") { Task { await model.refreshResult() } }.buttonStyle(.bordered).disabled(model.refreshing || model.computing)
                    if !model.exportFiles.isEmpty {
                        ShareLink(items: model.exportFiles) {
                            Label(model.resultSnapshot?.trial != nil ? "2B deney özetini paylaş · JSON" : "Araştırma dosyalarını paylaş · CSV / JSON / PLY", systemImage: "square.and.arrow.up")
                        }.buttonStyle(.bordered).accessibilityIdentifier("shareResearchFiles")
                        Text(model.resultSnapshot?.trial != nil ? "2B deney özeti uzaysal koordinat içermez."
                             : "Paylaşılan geometri araştırma içindir. Exocad implant kütüphanesi ve MUA eşleşmesi ayrıca doğrulanmalıdır.")
                            .font(.caption).foregroundStyle(.secondary)
                    } else if let file = model.resultFile {
                        ShareLink(item: file) { Label("Sonuç JSON dosyasını paylaş", systemImage: "square.and.arrow.up") }.buttonStyle(.bordered)
                    }
                    Text(model.status).font(.caption).foregroundStyle(.secondary)
                }
            }.padding()
        }.navigationTitle("Sonuç")
            .task(id: model.currentID) { await model.pollResult() }
    }
}

struct LandmarkScene: View {
    let landmarks: [ResultLandmark]
    var illustration = false
    @State private var yaw = -0.2
    @State private var pitch = 0.7
    @State private var zoom = 1.0
    @GestureState private var drag = CGSize.zero
    private var center: LabPoint { landmarks.reduce(.zero) { $0 + $1.center } * (1 / Double(max(landmarks.count, 1))) }
    private var radius: Double { max((landmarks.map { ($0.center-center).length }.max() ?? 1) + 4, 7) }
    private var objects: [MUADisplayGeometry] { landmarks.map { MUADisplayGeometry(landmark: $0, illustration: illustration) } }
    private func rotated(_ point: LabPoint) -> LabPoint {
        let a = yaw + Double(drag.width)*0.008, b = min(1.5, max(-1.5, pitch + Double(drag.height)*0.008))
        let x = cos(a)*point.x - sin(a)*point.y, y = sin(a)*point.x + cos(a)*point.y
        return LabPoint(x: x, y: cos(b)*y - sin(b)*point.z, z: sin(b)*y + cos(b)*point.z)
    }
    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            Canvas { context, size in
                let scale = Double(min(size.width, size.height)) * 0.34 / radius * zoom
                func screen(_ p: LabPoint) -> CGPoint {
                    let r = rotated(p-center)
                    return CGPoint(x: Double(size.width)/2 + r.x*scale, y: Double(size.height)/2 - r.y*scale)
                }
                let surfaces = objects.flatMap { $0.surfaces }.sorted {
                    rotated($0.center-center).z < rotated($1.center-center).z
                }
                for surface in surfaces {
                    guard let first = surface.vertices.first else { continue }
                    var path = Path(); path.move(to: screen(first))
                    for point in surface.vertices.dropFirst() { path.addLine(to: screen(point)) }
                    path.closeSubpath()
                    let light = 0.5 + 0.45 * abs(rotated(surface.normal).z)
                    let color: Color
                    switch surface.material {
                    case .titanium: color = Color(red: light * 0.83, green: light * 0.90, blue: light)
                    case .shoulder: color = Color(red: light * 0.54, green: light * 0.68, blue: light * 0.78)
                    case .bore: color = Color(red: 0.025, green: 0.035, blue: 0.05)
                    case .marker: color = Color(red: light, green: light * 0.57, blue: 0.08)
                    }
                    context.fill(path, with: .color(color))
                    context.stroke(path, with: .color(color.opacity(0.9)), lineWidth: 0.45)
                }
                for object in objects {
                    let p = screen(object.origin)
                    let prefix = object.kind == .uncalibratedMarker ? "Bayrak" : illustration ? "Örnek" : "MUA"
                    let tint: Color = object.kind == .uncalibratedMarker ? .orange : .mint
                    // This dot is the actual decoded reference origin, not an
                    // origin inferred from the illustrative body's dimensions.
                    context.fill(Path(ellipseIn: CGRect(x: p.x-2, y: p.y-2, width: 4, height: 4)), with: .color(tint))
                    context.draw(Text("\(prefix) \(object.landmark.id)").font(.caption2.bold()).foregroundColor(tint),
                        at: CGPoint(x: p.x, y: p.y+max(22, CGFloat(scale*4))))
                }
            }.accessibilityLabel("\(landmarks.count) konumun döndürülebilir üç boyutlu görünümü. Metal renkli MUA gövdeleri şematik, turuncu işaretler kalibrasyonsuz bayraktır. Koordinatlar aşağıdaki listede.")
                .accessibilityIdentifier("muaPlacementScene")
                .gesture(DragGesture().updating($drag) { value, state, _ in state = value.translation }
                    .onEnded { value in yaw += Double(value.translation.width)*0.008; pitch = min(1.5, max(-1.5, pitch+Double(value.translation.height)*0.008)) })
            HStack {
                Button { zoom = max(0.5, zoom-0.2) } label: { Image(systemName: "minus.magnifyingglass") }.accessibilityLabel("Uzaklaştır")
                Button { zoom = min(3.5, zoom+0.2) } label: { Image(systemName: "plus.magnifyingglass") }.accessibilityLabel("Yakınlaştır")
                Button { yaw = -0.2; pitch = 0.7; zoom = 1 } label: { Image(systemName: "arrow.counterclockwise") }.accessibilityLabel("Görünümü sıfırla")
            }.buttonStyle(.bordered).tint(.mint).padding(10)
        }.background(Color(red: 0.035, green: 0.065, blue: 0.095)).clipShape(RoundedRectangle(cornerRadius: 20))
    }
}
