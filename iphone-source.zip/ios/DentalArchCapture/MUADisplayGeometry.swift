import Foundation

enum LandmarkDisplayKind: Equatable {
    case calibratedMUA
    case exampleMUA
    case uncalibratedMarker
}

enum LandmarkSurfaceMaterial: Equatable {
    case titanium
    case shoulder
    case bore
    case marker
}

struct LandmarkSurface {
    let vertices: [LabPoint]
    let material: LandmarkSurfaceMaterial
    var center: LabPoint { vertices.reduce(.zero, +) * (1 / Double(max(1, vertices.count))) }
    var normal: LabPoint {
        guard vertices.count >= 3 else { return .zero }
        return MUADisplayGeometry.normalized(MUADisplayGeometry.cross(vertices[1] - vertices[0], vertices[2] - vertices[0]))
    }
}

/// Display-only geometry. These arbitrary illustrative dimensions are not
/// MegaGen/MG-MUASB9 manufacturer CAD and must never enter research exports.
/// The origin and orientation come from the result; no marker-to-MUA offset is
/// estimated or applied here. MUACalibration owns that measured transformation.
struct MUADisplayGeometry {
    let landmark: ResultLandmark
    let kind: LandmarkDisplayKind
    let surfaces: [LandmarkSurface]
    var origin: LabPoint { landmark.center }
    var axis: LabPoint { landmark.axis }
    var isSchematicMUA: Bool { kind != .uncalibratedMarker }

    init(landmark: ResultLandmark, illustration: Bool = false) {
        self.landmark = landmark
        self.kind = illustration ? .exampleMUA : landmark.isMUA ? .calibratedMUA : .uncalibratedMarker
        let local = kind == .uncalibratedMarker ? Self.markerSurfaces() : Self.muaSurfaces()
        self.surfaces = local.map { surface in
            LandmarkSurface(vertices: surface.vertices.map { Self.worldPoint($0, landmark: landmark) }, material: surface.material)
        }
    }

    static func worldPoint(_ local: LabPoint, landmark: ResultLandmark) -> LabPoint {
        if let t = landmark.worldTransform, t.count == 4, t.allSatisfy({ $0.count == 4 }) {
            let x = t[0][0] * local.x + t[0][1] * local.y + t[0][2] * local.z
            let y = t[1][0] * local.x + t[1][1] * local.y + t[1][2] * local.z
            let z = t[2][0] * local.x + t[2][1] * local.y + t[2][2] * local.z
            return landmark.center + LabPoint(x: x, y: y, z: z)
        }
        // Backwards-compatible axis-only landmarks use an axisymmetric body.
        // This display basis does not claim a measured roll.
        let z = normalized(landmark.axis)
        let reference = abs(z.z) < 0.9 ? LabPoint(x: 0, y: 0, z: 1) : LabPoint(x: 0, y: 1, z: 0)
        let x = normalized(cross(reference, z))
        let y = cross(z, x)
        return landmark.center + x * local.x + y * local.y + z * local.z
    }

    static func normalized(_ point: LabPoint) -> LabPoint {
        let length = point.length
        return length > 1e-12 ? point * (1 / length) : .zero
    }

    static func cross(_ a: LabPoint, _ b: LabPoint) -> LabPoint {
        LabPoint(x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x)
    }

    private static func muaSurfaces() -> [LandmarkSurface] {
        // The shoulder's reference plane passes through z=0. A short shank,
        // cone and recessed open bore make orientation visible without a rod.
        let profile: [(radius: Double, z: Double)] = [
            (1.15, -2.8), (1.35, -2.6), (1.35, -0.5), (2.6, -0.5),
            (2.6, 0), (2.2, 0.4), (1.6, 2.5), (1.6, 2.9),
            (0.65, 2.9), (0.65, 1.6)
        ]
        let segments = 24
        var rings: [[LabPoint]] = []
        for level in profile {
            var ring: [LabPoint] = []
            for segment in 0..<segments {
                let angle = Double(segment) * 2 * Double.pi / Double(segments)
                ring.append(LabPoint(x: level.radius * cos(angle), y: level.radius * sin(angle), z: level.z))
            }
            rings.append(ring)
        }
        var surfaces: [LandmarkSurface] = []
        for level in 0..<(rings.count - 1) {
            let material: LandmarkSurfaceMaterial = level >= 8 ? .bore : (3...4).contains(level) ? .shoulder : .titanium
            for segment in 0..<segments {
                let next = (segment + 1) % segments
                surfaces.append(LandmarkSurface(vertices: [rings[level][segment], rings[level][next],
                    rings[level + 1][next], rings[level + 1][segment]], material: material))
            }
        }
        surfaces.append(LandmarkSurface(vertices: Array(rings[0].reversed()), material: .titanium))
        surfaces.append(LandmarkSurface(vertices: rings[rings.count - 1], material: .bore))
        return surfaces
    }

    private static func markerSurfaces() -> [LandmarkSurface] {
        // A compact amber diamond at the optical origin: not an abutment body.
        let points = [LabPoint(x: 1.3, y: 0, z: 0), LabPoint(x: 0, y: 1.3, z: 0),
            LabPoint(x: -1.3, y: 0, z: 0), LabPoint(x: 0, y: -1.3, z: 0)]
        let top = LabPoint(x: 0, y: 0, z: 0.7), bottom = LabPoint(x: 0, y: 0, z: -0.7)
        var surfaces: [LandmarkSurface] = []
        for index in 0..<4 {
            let next = (index + 1) % 4
            surfaces.append(LandmarkSurface(vertices: [points[index], points[next], top], material: .marker))
            surfaces.append(LandmarkSurface(vertices: [points[next], points[index], bottom], material: .marker))
        }
        return surfaces
    }
}
