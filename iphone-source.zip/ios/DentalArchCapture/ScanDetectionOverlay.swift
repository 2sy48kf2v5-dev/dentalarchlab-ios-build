import CoreGraphics
import Foundation

/// Geometry for sampled-image thumbnails and bounded last-sample point hints.
/// No function estimates motion or attaches an AR anchor to the live scene.
enum ScanDetectionOverlay {
    static let maximumAge: TimeInterval = 0.35
    static let maximumLiveAge: TimeInterval = 0.25

    struct MarkerOutline {
        let id: Int
        let centers: [CGPoint]
        let bounds: CGRect
        let accepted: Bool
    }

    static func isVisible(ready: Bool, feedback: LiveFeedback?, sampledAt: Date?, now: Date,
                          imageWidth: Int?, imageHeight: Int?) -> Bool {
        guard ready, let feedback, let sampledAt,
              matchesImage(feedback: feedback, imageWidth: imageWidth, imageHeight: imageHeight) else { return false }
        let age = now.timeIntervalSince(sampledAt)
        return age.isFinite && age >= 0 && age < maximumAge
    }

    static func matchesImage(feedback: LiveFeedback, imageWidth: Int?, imageHeight: Int?) -> Bool {
        guard feedback.width > 0, feedback.height > 0,
              imageWidth == feedback.width, imageHeight == feedback.height else { return false }
        let hasMarker = feedback.markers.contains { $0.points.count == 4 && $0.points.allSatisfy(validPoint) }
        let hasCandidate = feedback.candidates.contains { !$0.accepted && $0.points.contains(where: validPoint) }
        return hasMarker || hasCandidate
    }

    /// Capture-request uptime must travel with its feedback. Receipt/commit time
    /// cannot be used: a slow analysis must never make an old image look current.
    static func remainingLiveTime(ready: Bool, feedback: LiveFeedback?, captureUptime: TimeInterval?,
                                  nowUptime: TimeInterval, imageWidth: Int?, imageHeight: Int?) -> TimeInterval {
        guard ready, let feedback, let captureUptime,
              captureUptime.isFinite, captureUptime >= 0, nowUptime.isFinite,
              matchesImage(feedback: feedback, imageWidth: imageWidth, imageHeight: imageHeight),
              feedback.markers.contains(where: { $0.points.count == 4 && $0.points.allSatisfy(validPoint) }) else { return 0 }
        let age = nowUptime - captureUptime
        guard age >= 0, age < maximumLiveAge else { return 0 }
        return maximumLiveAge - age
    }

    /// Maps the native landscape sensor to the same oriented aspect-fill crop
    /// and centered preview-only zoom used by AVCaptureVideoPreviewLayer.
    /// Only visible centers are returned; clipped markers do not get a fake box.
    static func liveCenters(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                            previewZoom: Double, orientation: CameraDisplayOrientation = .portrait) -> [CGPoint] {
        guard feedback.width > 0, feedback.height > 0,
              viewWidth.isFinite, viewHeight.isFinite, viewWidth > 0, viewHeight > 0,
              previewZoom.isFinite, (1...2).contains(previewZoom) else { return [] }
        let imageWidth = Double(orientation.swapsDimensions ? feedback.height : feedback.width)
        let imageHeight = Double(orientation.swapsDimensions ? feedback.width : feedback.height)
        let scale = max(viewWidth / imageWidth, viewHeight / imageHeight)
        let scaledWidth = imageWidth * scale
        let scaledHeight = imageHeight * scale
        let left = (viewWidth - scaledWidth) / 2
        let top = (viewHeight - scaledHeight) / 2
        var result: [CGPoint] = []
        for marker in feedback.markers where marker.points.count == 4 && marker.points.allSatisfy(validPoint) {
            for point in marker.points {
                let normalized = orientation.normalizedPoint(point)
                let unzoomedX = left + normalized[0] * scaledWidth
                let unzoomedY = top + normalized[1] * scaledHeight
                let x = viewWidth / 2 + (unzoomedX - viewWidth / 2) * previewZoom
                let y = viewHeight / 2 + (unzoomedY - viewHeight / 2) * previewZoom
                if (0...viewWidth).contains(x), (0...viewHeight).contains(y) {
                    result.append(CGPoint(x: x, y: y))
                }
            }
        }
        return result
    }

    static func outlines(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                         orientation: CameraDisplayOrientation = .portrait) -> [MarkerOutline] {
        guard feedback.width > 0, feedback.height > 0,
              viewWidth.isFinite, viewHeight.isFinite, viewWidth > 0, viewHeight > 0 else { return [] }
        let viewport = orientation.viewport(imageWidth: feedback.width, imageHeight: feedback.height,
                                            viewWidth: viewWidth, viewHeight: viewHeight)
        var result: [MarkerOutline] = []
        for marker in feedback.markers {
            guard marker.points.count == 4, marker.points.allSatisfy(validPoint) else { continue }
            let centers = marker.points.map { map($0, viewport: viewport, orientation: orientation) }
            guard let minX = centers.map(\.x).min(), let maxX = centers.map(\.x).max(),
                  let minY = centers.map(\.y).min(), let maxY = centers.map(\.y).max() else { continue }
            // Our marker has three outer dots and one inner dot. A rectangle is
            // only a group outline; joining the four centers would invent a corner.
            let bounds = CGRect(x: minX - 9, y: minY - 9, width: maxX - minX + 18, height: maxY - minY + 18)
            result.append(MarkerOutline(id: marker.id, centers: centers, bounds: bounds,
                accepted: feedback.usable && !feedback.preview))
        }
        return result
    }

    static func rejectedCenters(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                                orientation: CameraDisplayOrientation = .portrait) -> [CGPoint] {
        guard feedback.width > 0, feedback.height > 0,
              viewWidth.isFinite, viewHeight.isFinite, viewWidth > 0, viewHeight > 0 else { return [] }
        let viewport = orientation.viewport(imageWidth: feedback.width, imageHeight: feedback.height,
                                            viewWidth: viewWidth, viewHeight: viewHeight)
        var result: [CGPoint] = []
        for candidate in feedback.candidates where !candidate.accepted {
            for point in candidate.points where validPoint(point) {
                result.append(map(point, viewport: viewport, orientation: orientation))
            }
        }
        return result
    }

    /// Compatibility for fixed sensor-image cards; false means the raw image.
    static func outlines(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                         rotatedClockwise: Bool) -> [MarkerOutline] {
        outlines(feedback: feedback, viewWidth: viewWidth, viewHeight: viewHeight,
                 orientation: rotatedClockwise ? .portrait : .landscapeRight)
    }
    static func rejectedCenters(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                                rotatedClockwise: Bool) -> [CGPoint] {
        rejectedCenters(feedback: feedback, viewWidth: viewWidth, viewHeight: viewHeight,
                        orientation: rotatedClockwise ? .portrait : .landscapeRight)
    }
    private static func validPoint(_ point: [Double]) -> Bool {
        point.count == 2 && point.allSatisfy { $0.isFinite && (0...1).contains($0) }
    }
    private static func map(_ point: [Double], viewport: FeedbackViewport,
                            orientation: CameraDisplayOrientation) -> CGPoint {
        let normalized = orientation.normalizedPoint(point)
        let position = viewport.point(normalized)
        return CGPoint(x: position.0, y: position.1)
    }
}
