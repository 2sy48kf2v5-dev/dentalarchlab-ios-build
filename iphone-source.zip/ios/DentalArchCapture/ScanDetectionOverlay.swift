import CoreGraphics
import Foundation

/// Geometry for sampled-image thumbnails and bounded last-sample point hints.
/// No function estimates motion or attaches an AR anchor to the live scene.
enum ScanDetectionOverlay {
    static let maximumAge: TimeInterval = 0.35
    static let maximumLiveAge: TimeInterval = 0.25

    struct MarkerOutline {
        let id: Int
        let centers: [CGPoint]
        let bounds: CGRect
        let accepted: Bool
    }

    static func isVisible(ready: Bool, feedback: LiveFeedback?, sampledAt: Date?, now: Date,
                          imageWidth: Int?, imageHeight: Int?) -> Bool {
        guard ready, let feedback, let sampledAt,
              matchesImage(feedback: feedback, imageWidth: imageWidth, imageHeight: imageHeight) else { return false }
        let age = now.timeIntervalSince(sampledAt)
        return age.isFinite && age >= 0 && age < maximumAge
    }

    static func matchesImage(feedback: LiveFeedback, imageWidth: Int?, imageHeight: Int?) -> Bool {
        guard feedback.width > 0, feedback.height > 0,
              imageWidth == feedback.width, imageHeight == feedback.height else { return false }
        let hasMarker = feedback.markers.contains { $0.points.count == 4 && $0.points.allSatisfy(validPoint) }
        let hasCandidate = feedback.candidates.contains { !$0.accepted && $0.points.contains(where: validPoint) }
        return hasMarker || hasCandidate
    }

    /// Capture-request uptime must travel with its feedback. Receipt/commit time
    /// cannot be used: a slow analysis must never make an old image look current.
    static func remainingLiveTime(ready: Bool, feedback: LiveFeedback?, captureUptime: TimeInterval?,
                                  nowUptime: TimeInterval, imageWidth: Int?, imageHeight: Int?) -> TimeInterval {
        guard ready, let feedback, let captureUptime,
              captureUptime.isFinite, captureUptime >= 0, nowUptime.isFinite,
              matchesImage(feedback: feedback, imageWidth: imageWidth, imageHeight: imageHeight),
              feedback.markers.contains(where: { $0.points.count == 4 && $0.points.allSatisfy(validPoint) }) else { return 0 }
        let age = nowUptime - captureUptime
        guard age >= 0, age < maximumLiveAge else { return 0 }
        return maximumLiveAge - age
    }

    /// Maps the native landscape sensor to the same portrait aspect-fill crop
    /// and centered preview-only zoom used by AVCaptureVideoPreviewLayer.
    /// Only visible centers are returned; clipped markers do not get a fake box.
    static func liveCenters(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                            previewZoom: Double) -> [CGPoint] {
        guard feedback.width > 0, feedback.height > 0,
              viewWidth.isFinite, viewHeight.isFinite, viewWidth > 0, viewHeight > 0,
              previewZoom.isFinite, (1...2).contains(previewZoom) else { return [] }
        let scale = max(viewWidth / Double(feedback.height), viewHeight / Double(feedback.width))
        let scaledWidth = Double(feedback.height) * scale
        let scaledHeight = Double(feedback.width) * scale
        let left = (viewWidth - scaledWidth) / 2
        let top = (viewHeight - scaledHeight) / 2
        var result: [CGPoint] = []
        for marker in feedback.markers where marker.points.count == 4 && marker.points.allSatisfy(validPoint) {
            for point in marker.points {
                let unzoomedX = left + (1 - point[1]) * scaledWidth
                let unzoomedY = top + point[0] * scaledHeight
                let x = viewWidth / 2 + (unzoomedX - viewWidth / 2) * previewZoom
                let y = viewHeight / 2 + (unzoomedY - viewHeight / 2) * previewZoom
                if (0...viewWidth).contains(x), (0...viewHeight).contains(y) {
                    result.append(CGPoint(x: x, y: y))
                }
            }
        }
        return result
    }

    static func outlines(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                         rotatedClockwise: Bool) -> [MarkerOutline] {
        guard feedback.width > 0, feedback.height > 0,
              viewWidth.isFinite, viewHeight.isFinite, viewWidth > 0, viewHeight > 0 else { return [] }
        let viewport = viewport(feedback: feedback, viewWidth: viewWidth, viewHeight: viewHeight,
                                rotatedClockwise: rotatedClockwise)
        var result: [MarkerOutline] = []
        for marker in feedback.markers {
            guard marker.points.count == 4, marker.points.allSatisfy(validPoint) else { continue }
            let centers = marker.points.map { map($0, viewport: viewport, rotatedClockwise: rotatedClockwise) }
            guard let minX = centers.map(\.x).min(), let maxX = centers.map(\.x).max(),
                  let minY = centers.map(\.y).min(), let maxY = centers.map(\.y).max() else { continue }
            // Our marker has three outer dots and one inner dot. A rectangle is
            // only a group outline; joining the four centers would invent a corner.
            let bounds = CGRect(x: minX - 9, y: minY - 9, width: maxX - minX + 18, height: maxY - minY + 18)
            result.append(MarkerOutline(id: marker.id, centers: centers, bounds: bounds,
                accepted: feedback.usable && !feedback.preview))
        }
        return result
    }

    static func rejectedCenters(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                                rotatedClockwise: Bool) -> [CGPoint] {
        guard feedback.width > 0, feedback.height > 0,
              viewWidth.isFinite, viewHeight.isFinite, viewWidth > 0, viewHeight > 0 else { return [] }
        let viewport = viewport(feedback: feedback, viewWidth: viewWidth, viewHeight: viewHeight,
                                rotatedClockwise: rotatedClockwise)
        var result: [CGPoint] = []
        for candidate in feedback.candidates where !candidate.accepted {
            for point in candidate.points where validPoint(point) {
                result.append(map(point, viewport: viewport, rotatedClockwise: rotatedClockwise))
            }
        }
        return result
    }

    private static func viewport(feedback: LiveFeedback, viewWidth: Double, viewHeight: Double,
                                 rotatedClockwise: Bool) -> FeedbackViewport {
        FeedbackViewport(imageWidth: Double(rotatedClockwise ? feedback.height : feedback.width),
                         imageHeight: Double(rotatedClockwise ? feedback.width : feedback.height),
                         viewWidth: viewWidth, viewHeight: viewHeight)
    }
    private static func validPoint(_ point: [Double]) -> Bool {
        point.count == 2 && point.allSatisfy { $0.isFinite && (0...1).contains($0) }
    }
    private static func map(_ point: [Double], viewport: FeedbackViewport, rotatedClockwise: Bool) -> CGPoint {
        let normalized = rotatedClockwise ? [1 - point[1], point[0]] : point
        let position = viewport.point(normalized)
        return CGPoint(x: position.0, y: position.1)
    }
}
