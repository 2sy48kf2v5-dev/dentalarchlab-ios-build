import Foundation

/// Serial durable frame I/O stays off the UI actor; acknowledgement still
/// happens only after the engine verifies the exact frame ID and byte hash.
actor FramePersistence {
    private let repository: CaptureRepository
    init(repository: CaptureRepository) { self.repository = repository }

    func append(session: String, image: Data, timestamp: Double, frame: String,
                profile: CaptureProfile, intrinsics: FrameCameraIntrinsics? = nil) throws -> String {
        try repository.append(id: session, image: image, timestamp: timestamp, frameID: frame, profile: profile, intrinsics: intrinsics)
    }
    func image(session: String, frame: String) throws -> Data {
        try repository.image(session: session, frame: frame)
    }
    func acknowledge(session: String, frame: String, receipt: [String: Any]) throws {
        try repository.acknowledge(session: session, frame: frame, receipt: receipt)
    }
    func update(session: String, state: String, message: String) throws {
        try repository.update(session: session, state: state, message: message)
    }
}
