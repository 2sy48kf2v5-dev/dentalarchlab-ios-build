import Foundation
import CoreFoundation

/// Count is a case size, never a replacement for a manufactured flag identity.
/// Missing IDs retain the prefix dictionary used by older saved captures.
enum MarkerSelection {
    static func decode(count: Int, raw: Any?) throws -> [Int] {
        guard let raw else { return try resolve(count: count, ids: nil) }
        guard let values = raw as? [Any] else {
            throw LabError.message("Bayrak kimlikleri dizisi geçersiz.")
        }
        let ids = try values.map { value -> Int in
            guard let number = value as? NSNumber,
                  CFGetTypeID(number) != CFBooleanGetTypeID(),
                  number.doubleValue.isFinite, (0...5).contains(number.doubleValue),
                  number.doubleValue.rounded(.towardZero) == number.doubleValue else {
                throw LabError.message("Bayrak kimliği 0–5 arasında bir tam sayı olmalı.")
            }
            return number.intValue
        }
        return try resolve(count: count, ids: ids)
    }

    static func resolve(count: Int, ids: [Int]?) throws -> [Int] {
        guard [4, 6].contains(count) else {
            throw LabError.message("Bayrak sayısı 4 veya 6 olmalı.")
        }
        let selected = ids ?? Array(0..<count)
        guard selected.count == count, Set(selected).count == count,
              selected.allSatisfy({ (0...5).contains($0) }) else {
            throw LabError.message("Seçilen bayrak kimlikleri 0–5 arasında, farklı ve bayrak sayısıyla eşit olmalı.")
        }
        return selected.sorted()
    }
}
