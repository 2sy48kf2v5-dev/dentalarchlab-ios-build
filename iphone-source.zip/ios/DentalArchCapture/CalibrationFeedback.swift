import Foundation

/// Corners refer to the exact sampled sensor image, never to a newer preview.
struct CalibrationFeedback {
    let sampleID: String
    let preview: Bool
    let usable: Bool
    let acceptedFrames: Int
    let targetFrames: Int
    let cornerCount: Int
    let corners: [[Double]]
    let width: Int
    let height: Int
    let blur: Double
    let reason: String
    let message: String
    let detectionMilliseconds: Double?

    var fraction: Double { min(1, Double(acceptedFrames) / Double(targetFrames)) }

    static func decode(_ response: [String: Any], session: String, sample: String) throws -> Self {
        guard response["id"] as? String == sample,
              let f = response["calibration_feedback"] as? [String: Any],
              f["schema"] as? Int == 1, f["session_id"] as? String == session,
              f["sample_id"] as? String == sample,
              f["coordinates"] as? String == "sensor_normalized",
              f["metric"] as? String == "accepted_calibration_views_not_accuracy",
              f["physical_accuracy_um"] is NSNull,
              let preview = f["preview"] as? Bool, let usable = f["sample_usable"] as? Bool,
              response["accepted"] as? Bool == usable,
              let size = f["image_size"] as? [Int], size == [1920, 1080],
              let frames = f["accepted_frames"] as? Int, (0...120).contains(frames),
              response["count"] as? Int == frames,
              let target = f["target_frames"] as? Int, (20...60).contains(target), target % 5 == 0,
              let count = f["detected_count"] as? Int, [0, 54].contains(count),
              f["expected_corners"] as? Int == 54,
              let corners = f["corners"] as? [[Double]], corners.count == count,
              corners.allSatisfy({ $0.count == 2 && $0.allSatisfy { $0.isFinite && (0...1).contains($0) } }),
              let blur = f["blur_laplacian"] as? Double, blur.isFinite, blur >= 0,
              let reason = f["reason"] as? String, ["accepted", "not_found", "blur", "duplicate"].contains(reason),
              usable == (reason == "accepted"), !usable || count == 54,
              let message = f["message"] as? String, !message.isEmpty else {
            throw LabError.message("Canlı kalibrasyon yanıtı veya köşe koordinatları eşleşmedi.")
        }
        let elapsed = (response["timing"] as? [String: Any])?["detection_ms"] as? Double
        return Self(sampleID: sample, preview: preview, usable: usable, acceptedFrames: frames,
                    targetFrames: target, cornerCount: count, corners: corners, width: size[0], height: size[1],
                    blur: blur, reason: reason, message: message,
                    detectionMilliseconds: elapsed.flatMap { $0.isFinite && $0 >= 0 ? $0 : nil })
    }
}

enum CalibrationCadence {
    // Keep the camera live while running at most one full-resolution analysis.
    // Slow analysis never causes a queue of stale frames to build up.
    static func delayNanoseconds(elapsed: Double) -> UInt64 {
        guard elapsed.isFinite, elapsed >= 0 else { return 650_000_000 }
        return UInt64(max(0.1, 0.65 - elapsed) * 1_000_000_000)
    }
}
