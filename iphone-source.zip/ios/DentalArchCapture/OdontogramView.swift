import SwiftUI

struct OdontogramView: View {
    let plan: DentalPlan
    var views: [Int: Int] = [:]
    var target = 4
    var selectedMarker: Int? = nil
    var select: ((Int) -> Void)? = nil
    private func color(_ tooth: Int) -> Color {
        guard let a = plan.assignments.first(where: { $0.fdi == tooth }) else { return .secondary.opacity(0.22) }
        if selectedMarker == a.markerID { return .cyan }
        let n = views[a.markerID] ?? 0
        return n >= target ? .green : n > 0 ? .orange : .red.opacity(0.85)
    }
    var body: some View {
        VStack(spacing: 7) {
            HStack { Text("Hastanın sağı"); Spacer(); Text(plan.arch == "upper" ? "ÜST ÇENE" : "ALT ÇENE").bold(); Spacer(); Text("Hastanın solu") }
                .font(.system(size: 10)).foregroundStyle(.secondary)
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 5), count: 8), spacing: 8) {
                ForEach(DentalPlan.teeth(arch: plan.arch), id: \.self) { tooth in
                    Button { select?(tooth) } label: {
                        VStack(spacing: 3) {
                            RoundedRectangle(cornerRadius: 8).fill(color(tooth)).frame(height: 25)
                                .overlay(Image(systemName: "circle.fill").font(.system(size: 5)).foregroundStyle(.white.opacity(0.8)))
                            Text(String(tooth)).font(.system(size: 12, weight: .semibold, design: .rounded))
                            if let a = plan.assignments.first(where: { $0.fdi == tooth }) {
                                Text("ID \(a.markerID)").font(.system(size: 8, weight: .bold))
                            } else { Text("—").font(.system(size: 8)) }
                        }.foregroundStyle(.primary)
                    }.buttonStyle(.plain).accessibilityIdentifier("fdi-\(tooth)")
                        .accessibilityLabel("FDI \(tooth)")
                }
            }
        }
    }
}

struct DentalPlanView: View {
    @EnvironmentObject var model: CaptureModel
    @State private var marker = 0
    var locked: Bool { model.currentID != nil || model.ready || model.busy || model.analyzing || model.uploading }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Text("Dişleri ve bayrakları eşleştir").font(.title2.bold())
                Text("Önce bayrak ID'sini, sonra o bayrağın bulunduğu FDI dişini seç.").foregroundStyle(.secondary)
                Picker("Çene", selection: $model.plan.arch) { Text("Üst çene").tag("upper"); Text("Alt çene").tag("lower") }
                    .pickerStyle(.segmented).disabled(locked)
                    .onChange(of: model.plan.arch) { _, _ in model.plan.reset(count: model.markerCount) }
                Picker("Bayrak", selection: $marker) { ForEach(0..<model.markerCount, id: \.self) { Text("ID \($0)").tag($0) } }
                    .pickerStyle(.segmented).disabled(locked)
                OdontogramView(plan: model.plan, selectedMarker: marker, select: { tooth in
                    guard !locked else { return }; model.plan.assign(tooth, to: marker)
                    if marker + 1 < model.markerCount { marker += 1 }
                })
                Button("Örnek plan · sanal ağız") { model.plan.useExample(count: model.markerCount) }
                    .buttonStyle(.bordered).disabled(locked).accessibilityIdentifier("sampleDentalPlan")
                VStack(spacing: 10) {
                    ForEach(model.plan.assignments) { a in
                        HStack {
                            Text("ID \(a.markerID)").font(.headline)
                            Image(systemName: "arrow.right").foregroundStyle(.secondary)
                            Text(a.fdi.map { "FDI \($0)" } ?? "Diş seçilmedi")
                            Spacer(); Text(a.componentCode).font(.caption.monospaced())
                        }
                    }
                }.padding().background(Color.teal.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 16))
                Picker("Bağlantı referansı", selection: Binding(get: { model.plan.assignments.first?.componentCode ?? "MG-MUASBU" }, set: { model.plan.useComponent($0) })) {
                    Text("Vida Dental Multi 9 mm · MG-MUASBU").tag("MG-MUASBU")
                    Text("Eski kullanıcı referansı · MG-MUASB9").tag("MG-MUASB9")
                }.disabled(locked).accessibilityIdentifier("componentReferencePicker")
                Text("MegaGen_N_Type_MUA_Direkt_9mm kütüphanesi dosya eşleşmesiyle tanımlandı. Basılan bayrak–MUA ölçümü ve Exocad sürümünde aktarım testi ayrıca gerekli. Eski kayıtlar yeniden etiketlenmez.")
                    .font(.callout).foregroundStyle(.secondary)
                if locked { Text("Başlayan kaydın diş eşleştirmesi korunur. Değiştirmek için Yeni kayıt hazırla.").font(.caption).foregroundStyle(.orange) }
            }.padding(20)
        }.navigationTitle("FDI planı").navigationBarTitleDisplayMode(.inline)
    }
}
