import AVFoundation
import SwiftUI
import VisionKit

struct PairingScannerSheet: View {
    let receive: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var allowed = false
    @State private var problem: String?
    var body: some View {
        NavigationStack {
            Group {
                if let problem {
                    ContentUnavailableView("QR kamera açılamadı", systemImage: "qrcode", description: Text(problem))
                } else if allowed {
                    PairingScanner(receive: { value in receive(value); dismiss() }, fail: { problem = $0 })
                } else { ProgressView("Kamera izni kontrol ediliyor…") }
            }.navigationTitle("Bilgisayarın QR kodu")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Kapat") { dismiss() } } }
                .task {
                    guard DataScannerViewController.isSupported else { problem = "Bu cihazda QR taraması desteklenmiyor. Bağlantıyı elle girebilirsin."; return }
                    let granted = await AVCaptureDevice.requestAccess(for: .video)
                    guard granted, DataScannerViewController.isAvailable else { problem = "Ayarlar > DentalArchLab bölümünde kamera iznini aç veya bağlantıyı elle gir."; return }
                    allowed = true
                }
        }
    }
}

struct PairingScanner: UIViewControllerRepresentable {
    let receive: (String) -> Void
    let fail: (String) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(receive: receive, fail: fail) }
    func makeUIViewController(context: Context) -> DataScannerViewController {
        let scanner = DataScannerViewController(recognizedDataTypes: [.barcode(symbologies: [.qr])], qualityLevel: .balanced,
            recognizesMultipleItems: false, isHighFrameRateTrackingEnabled: false, isPinchToZoomEnabled: true,
            isGuidanceEnabled: true, isHighlightingEnabled: true)
        scanner.delegate = context.coordinator
        context.coordinator.start(scanner)
        return scanner
    }
    func updateUIViewController(_ scanner: DataScannerViewController, context: Context) {}
    static func dismantleUIViewController(_ scanner: DataScannerViewController, coordinator: Coordinator) {
        coordinator.cancelled = true; scanner.stopScanning()
    }
    @MainActor final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let receive: (String) -> Void
        let fail: (String) -> Void
        var cancelled = false
        var delivered = false
        init(receive: @escaping (String) -> Void, fail: @escaping (String) -> Void) { self.receive = receive; self.fail = fail }
        func start(_ scanner: DataScannerViewController) {
            DispatchQueue.main.async { [weak self, weak scanner] in
                guard let self, let scanner, !self.cancelled else { return }
                do { try scanner.startScanning() } catch { self.fail(error.localizedDescription) }
            }
        }
        func dataScanner(_ dataScanner: DataScannerViewController, didAdd addedItems: [RecognizedItem], allItems: [RecognizedItem]) {
            guard !delivered, !cancelled else { return }
            for item in addedItems {
                if case .barcode(let code) = item, let text = code.payloadStringValue {
                    delivered = true; dataScanner.stopScanning(); receive(text); return
                }
            }
        }
        func dataScanner(_ dataScanner: DataScannerViewController, becameUnavailableWithError error: DataScannerViewController.ScanningUnavailable) {
            guard !cancelled else { return }; fail("QR taraması durdu. Kamerayı yeniden aç veya bağlantıyı elle gir.")
        }
    }
}
