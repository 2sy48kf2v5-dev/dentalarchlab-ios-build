import Foundation

/// A supplied, traceable mapping to an INSTALLED Exocad library entry.
/// The operator's report is preserved; importing it never verifies compatibility.
struct ExocadLibraryProfile: Codable {
    var schema: Int
    var manufacturer: String
    var implantSystem: String
    var connectionLevel: String
    var componentReference: String
    var library: String
    var type: String
    var subtype: String?
    var configSHA256: String
    var libraryVersion: String
    var exocadVersion: String
    var referenceReport: String
    var source: String
    var transform: [[Double]]?
    var maxAlignmentRMSMM: Double
    var maxCheckpointErrorMM: Double

    enum CodingKeys: String, CodingKey {
        case schema, manufacturer, library, type, subtype, source
        case implantSystem = "implant_system", connectionLevel = "connection_level"
        case componentReference = "component_reference", configSHA256 = "config_sha256"
        case libraryVersion = "library_version", exocadVersion = "exocad_version"
        case referenceReport = "reference_report", transform = "T_mua_library"
        case maxAlignmentRMSMM = "max_alignment_rms_mm", maxCheckpointErrorMM = "max_checkpoint_error_mm"
    }

    static func load(_ data: Data) throws -> Self {
        guard !data.isEmpty, data.count <= 256_000 else { throw LabError.message("Kütüphane eşleştirme JSON dosyası boş veya 256 KB sınırını aşıyor.") }
        let profile = try JSONDecoder().decode(Self.self, from: data)
        try profile.validate(); return profile
    }

    func validate() throws {
        guard schema == 1, manufacturer == "MegaGen", connectionLevel == "mua",
              ["MG-MUASB9", "MG-MUASBU"].contains(componentReference),
              ["reference_metrology", "library_metadata_only"].contains(source),
              [implantSystem, library, type, libraryVersion, exocadVersion].allSatisfy(Self.validText),
              subtype.map(Self.validText) ?? true,
              !library.contains("/"), !library.contains("\\"), library != ".", library != "..",
              configSHA256.count == 64, configSHA256.allSatisfy({ "0123456789abcdef".contains($0) }),
              [maxAlignmentRMSMM, maxCheckpointErrorMM].allSatisfy({ $0.isFinite && $0 > 0 && $0 <= 5 }) else {
            throw LabError.message("MegaGen MUA kütüphane kaydında kimlikler, config SHA-256, referans ölçüm raporu ve araştırma eşleştirme sınırları gerekli. 9 mm boy bilgisi tek başına yeterli değil.")
        }
        if source == "reference_metrology" {
            guard let transform, Self.validText(referenceReport) else { throw LabError.message("MUA–kütüphane dönüşümü için ölçüm matrisi ve referans raporu gerekli.") }
            try TissueRegistration.validateRigid(transform)
        } else if transform != nil {
            throw LabError.message("Kütüphane kimliği kaydı ölçülmüş bağlantı dönüşümü içeremez.")
        }
    }

    /// Names and digest verified against the user folder and the official archive.
    /// No manufacturer mesh or unmeasured physical transform is bundled.
    static var vidaMUA9: Self {
        Self(schema: 1, manufacturer: "MegaGen", implantSystem: "N-Type MUA; ST implant compatibility to be checked separately",
            connectionLevel: "mua", componentReference: "MG-MUASBU", library: "MegaGen_N_Type_MUA_Direkt_9mm",
            type: "VidaTrkiye", subtype: "48Direkt",
            configSHA256: "a5fc3b5a15a42bf19a93065856f792f90c036287cfc68911173be28b14762e22",
            libraryVersion: "User folder and official archive byte match 2026-09-29",
            exocadVersion: "Target installation not yet tested", referenceReport: "", source: "library_metadata_only",
            transform: nil, maxAlignmentRMSMM: 0.1, maxCheckpointErrorMM: 0.2)
    }

    private static func validText(_ text: String) -> Bool {
        !text.isEmpty && text.count <= 512 && text == text.trimmingCharacters(in: .whitespacesAndNewlines)
            && !text.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) })
    }
}

enum ExocadHandoff {
    static func projectName(_ value: String) throws -> String {
        let forbidden = CharacterSet(charactersIn: "<>:\"/\\|?*").union(.controlCharacters)
        guard !value.isEmpty, value.count <= 80, value == value.trimmingCharacters(in: .whitespacesAndNewlines),
              value != ".", value != "..", !value.hasSuffix("."), !value.hasSuffix(".dentalProject"),
              !value.unicodeScalars.contains(where: { forbidden.contains($0) }),
              !["CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"].contains(value.components(separatedBy: ".")[0].uppercased()) else {
            throw LabError.message("Exocad proje adını uzantısız yazın; dosya yolu ve özel dosya karakterleri kullanmayın.")
        }
        return value
    }

    static func multiply(_ a: [[Double]], _ b: [[Double]]) -> [[Double]] {
        (0..<4).map { row in (0..<4).map { column in
            (0..<4).reduce(0.0) { $0 + a[row][$1] * b[$1][column] }
        } }
    }

    static func point(_ p: LabPoint, by t: [[Double]]) -> LabPoint {
        let v = [p.x, p.y, p.z, 1]
        let q = (0..<3).map { row in (0..<4).reduce(0.0) { $0 + t[row][$1] * v[$1] } }
        return LabPoint(x: q[0], y: q[1], z: q[2])
    }

    static func xml(worldMUA: [[Double]], profile: ExocadLibraryProfile) throws -> Data {
        try profile.validate(); try TissueRegistration.validateRigid(worldMUA)
        guard profile.source == "reference_metrology", let transform = profile.transform else {
            throw LabError.message("Kütüphane bulundu; ölçülmüş MUA–kütüphane dönüşümü olmadan implant konumu XML'i üretilemez.")
        }
        let worldLibrary = multiply(worldMUA, transform)
        try TissueRegistration.validateRigid(worldLibrary)
        func escape(_ s: String) -> String {
            s.replacingOccurrences(of: "&", with: "&amp;").replacingOccurrences(of: "<", with: "&lt;")
                .replacingOccurrences(of: ">", with: "&gt;").replacingOccurrences(of: "\"", with: "&quot;")
                .replacingOccurrences(of: "'", with: "&apos;")
        }
        var lines = ["<?xml version=\"1.0\" encoding=\"utf-8\"?>",
                     "<!-- Research export. Physical accuracy and target-version import are unvalidated. -->",
                     "<ImplantPosition>", "  <CoordinateSystem>OpticalModelScan</CoordinateSystem>",
                     "  <Library>\(escape(profile.library))</Library>", "  <Type>\(escape(profile.type))</Type>"]
        if let subtype = profile.subtype { lines.append("  <Subtype>\(escape(subtype))</Subtype>") }
        lines.append("  <MatrixImplantGeometry>")
        // Official Exocad 05/2015 convention is row-vector: translation is _30.._32.
        // Our internal matrices use column vectors. Transpose ONCE at serialization.
        for row in 0..<4 {
            for column in 0..<4 {
                let value = String(format: "%.12f", locale: Locale(identifier: "en_US_POSIX"), worldLibrary[column][row])
                lines.append("    <_\(row)\(column)>\(value)</_\(row)\(column)>")
            }
        }
        lines += ["  </MatrixImplantGeometry>", "</ImplantPosition>"]
        return Data((lines.joined(separator: "\n") + "\n").utf8)
    }
}
