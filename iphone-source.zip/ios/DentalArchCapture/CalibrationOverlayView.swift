import SwiftUI
import UIKit

/// This image and its corners are published together from one analyzed sample.
/// A separate thumbnail avoids implying that old detections track the live camera.
struct CalibrationAnalyzedFrameView: View {
    let feedback: CalibrationFeedback
    let image: UIImage
    let date: Date
    var orientation: CameraDisplayOrientation = .portrait

    private var displayImage: UIImage {
        guard let cg = image.cgImage else { return image }
        return UIImage(cgImage: cg, scale: 1, orientation: orientation.imageOrientation)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Label("Son işlenen tahta karesi", systemImage: "photo.badge.checkmark")
                Spacer()
                Text(date.formatted(date: .omitted, time: .standard)).monospacedDigit()
            }.font(.caption.bold())
            GeometryReader { geometry in
                ZStack {
                    Image(uiImage: displayImage).resizable().scaledToFit()
                    Canvas { context, size in
                        let viewport = orientation.viewport(imageWidth: feedback.width, imageHeight: feedback.height,
                                                            viewWidth: size.width, viewHeight: size.height)
                        let color: Color = feedback.usable && !feedback.preview ? .green : .orange
                        for corner in feedback.corners where corner.count == 2 {
                            let (x, y) = viewport.point(orientation.normalizedPoint(corner))
                            let circle = Path(ellipseIn: CGRect(x: x - 3, y: y - 3, width: 6, height: 6))
                            context.stroke(circle, with: .color(color), lineWidth: 1.5)
                        }
                    }
                }.frame(width: geometry.size.width, height: geometry.size.height)
            }.frame(height: 180).background(.black).clipShape(RoundedRectangle(cornerRadius: 12))
                .accessibilityLabel("Son işlenen sabit görüntü; \(feedback.cornerCount) iç köşe")
            Text(feedback.message).font(.caption).foregroundStyle(feedback.usable ? Color.mint : Color.orange)
            Text("Noktalar yalnız bu sabit kareye aittir; canlı görüntünün üzerine taşınmaz.")
                .font(.caption2).foregroundStyle(.secondary)
        }.accessibilityElement(children: .contain).accessibilityIdentifier("calibrationAnalyzedFrame")
    }
}
