import Foundation

enum ResearchExport {
    static func existing(repository: CaptureRepository, session: String) throws -> [URL] {
        let result = try repository.resultURL(session)
        var files = FileManager.default.fileExists(atPath: result.path) ? [result] : []
        let folder = result.deletingLastPathComponent().appendingPathComponent("Exports")
        if FileManager.default.fileExists(atPath: folder.path) {
            files += try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil)
                .filter { ["csv", "ply", "json", "txt"].contains($0.pathExtension) }.sorted { $0.lastPathComponent < $1.lastPathComponent }
        }
        return files
    }
    static func write(response: [String: Any], repository: CaptureRepository, session: String) throws -> [URL] {
        let snapshot = try ResultSnapshot.decode(response)
        let resultURL = try repository.resultURL(session)
        // A screen identity experiment has no spatial coordinates or CAD handoff.
        if snapshot.trial != nil { return [resultURL] }
        let folder = resultURL.deletingLastPathComponent().appendingPathComponent("Exports")
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        func put(_ name: String, _ text: String) throws {
            try Data(text.utf8).write(to: folder.appendingPathComponent(name), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        }
        let markers = (response["result"] as? [String: Any])?["markers"] as? [[String: Any]] ?? []
        func quoted(_ value: String) -> String { "\"" + value.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
        var rows = ["marker_id,fdi,component_reference,coordinate_type,x_mm,y_mm,z_mm,axis_x,axis_y,axis_z,physical_accuracy_um"]
        for point in snapshot.landmarks {
            let marker = markers.first { $0["id"] as? Int == point.id }
            let fdi = (marker?["fdi"] as? Int).map(String.init) ?? ""
            let component = (marker?["component_reference"] as? String) ?? ""
            let numbers = [point.center.x, point.center.y, point.center.z, point.axis.x, point.axis.y, point.axis.z]
                .map { String(format: "%.9f", locale: Locale(identifier: "en_US_POSIX"), $0) }
            rows.append(([String(point.id), fdi, quoted(component), point.isMUA ? "MUA" : "MARKER"] + numbers + [""]).joined(separator: ","))
        }
        try put("research_coordinates.csv", rows.joined(separator: "\n") + "\n")
        if !snapshot.landmarks.isEmpty {
            var ply = ["ply", "format ascii 1.0", "comment Research marker centres and +Z axes only; units mm; physical accuracy unvalidated",
                "element vertex \(snapshot.landmarks.count*2)", "property float x", "property float y", "property float z",
                "property uchar red", "property uchar green", "property uchar blue",
                "element edge \(snapshot.landmarks.count)", "property int vertex1", "property int vertex2", "end_header"]
            for marker in snapshot.landmarks {
                for (point, color) in [(marker.center, "0 170 150"), (marker.center + marker.axis * 5, "255 170 0")] {
                    ply.append(String(format: "%.9f %.9f %.9f ", locale: Locale(identifier: "en_US_POSIX"), point.x, point.y, point.z) + color)
                }
            }
            for i in snapshot.landmarks.indices { ply.append("\(2*i) \(2*i+1)") }
            try put("research_marker_axes.ply", ply.joined(separator: "\n") + "\n")
        }
        let references = Set(markers.compactMap { $0["component_reference"] as? String })
        let handoff: [String: Any] = ["schema": 1, "engine": "iphone_native_v1", "units": "mm", "research_only": true,
            "physical_accuracy_um": NSNull(), "component_reference": references.count == 1 ? references.first! as Any : NSNull(), "exocad_library_match_verified": false,
            "mua_calibration_available": snapshot.hasMUA,
            "mua_calibrated_marker_ids": snapshot.landmarks.filter { $0.isMUA }.map { $0.id },
            "all_mua_calibrated": !snapshot.landmarks.isEmpty && snapshot.landmarks.allSatisfy { $0.isMUA },
            "dental_plan": response["dental_plan"] ?? NSNull(),
            "purpose": "Research coordinates; not a validated prosthesis manufacturing handoff"]
        let bytes = try JSONSerialization.data(withJSONObject: handoff, options: [.prettyPrinted, .sortedKeys])
        try bytes.write(to: folder.appendingPathComponent("cad_handoff.json"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        try put("OKU.txt", """
        Bu dosyalar iPhone içinde hesaplanan araştırma sonucudur. Birim mm.
        CSV: bayrak/MUA merkez ve eksenleri. PLY: merkezler ve 5 mm eksen çizgileri.
        PLY bir diş/abutment yüzey taraması değildir. result.json dönüşüm matrislerini korur.
        MG-MUASBU, Vida Dental N-Type MUA Direkt 9 mm dosya referansıdır; eski MG-MUASB9 kayıtları ayrı tutulur.
        Exocad kütüphanesi ve fiziksel marker–MUA dönüşümü doğrulanmadan üretim sonucu sayılmaz.
        Fiziksel doğruluk ölçülmedi; piksel artık hatası mikron doğruluğu değildir.
        """)
        return try existing(repository: repository, session: session)
    }
}
