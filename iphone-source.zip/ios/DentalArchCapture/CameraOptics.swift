import Foundation

enum CameraOpticsRequest: Equatable {
    case closeUp
    case standard
    case restoring(CaptureProfile)
}

struct CameraOpticsStatus: Equatable {
    let lens: String
    let minimumFocusDistanceMM: Int?
    let sensorWidth: Int
    let sensorHeight: Int
    let outputWidth: Int
    let outputHeight: Int
    var focusTracking: Bool? = nil
    var focusLocked: Bool? = nil
    var lensPosition: Float? = nil
}

/// Lens readback changes during continuous AF. Limit UI notifications to 5 Hz.
struct CameraOpticsPublicationGate {
    private var lastPublication: Double?
    mutating func shouldPublish(now: Double) -> Bool {
        guard now.isFinite, now >= 0 else { return false }
        if let previous = lastPublication, now - previous < 0.2 { return false }
        lastPublication = now
        return true
    }
}

/// Hardware-independent format description used to test selection without opening a camera.
struct CameraOpticsFormat: Equatable {
    let index: Int
    let mediaSubtype: UInt32
    let width: Int
    let height: Int
    let fieldOfView: Float
    let binned: Bool
    let phaseDetection: Bool
    let supports30FPS: Bool

    var supported: Bool {
        supports30FPS && index >= 0 && mediaSubtype != 0 && fieldOfView.isFinite && fieldOfView > 0 && fieldOfView < 180
            && ((width == 3840 && height == 2160) || (width == 1920 && height == 1080))
    }
    func signature(correction: Bool) -> String {
        "dal-optics-v2|subtype=\(mediaSubtype)|sensor=\(width)x\(height)|fov=\(fieldOfView.bitPattern)|binned=\(binned ? 1 : 0)|index=\(index)|gdc=\(correction ? 1 : 0)"
    }
}

struct CameraOpticsChoice {
    let lens: String
    let format: CameraOpticsFormat
    let signature: String
    /// nil preserves the original legacy camera behavior.
    let distortionCorrection: Bool?
}

enum CameraOpticsPolicy {
    static func lens(for request: CameraOpticsRequest) throws -> String {
        switch request {
        case .closeUp: return "ultrawide"
        case .standard: return "wide"
        case .restoring(let profile):
            guard ["wide", "ultrawide"].contains(profile.lens) else {
                throw LabError.message("Kalibrasyonun fiziksel kamerası desteklenmiyor.")
            }
            return profile.lens
        }
    }

    static func choose(_ request: CameraOpticsRequest, deviceID: String, lens: String,
                       supportsDistortionCorrection: Bool, formats: [CameraOpticsFormat]) throws -> CameraOpticsChoice {
        guard lens == (try self.lens(for: request)) else {
            throw LabError.message("İstenen fiziksel kamera bulunamadı; başka lensle devam edilmedi.")
        }
        let supported=formats.filter(\.supported)
        if case .restoring(let profile)=request {
            guard profile.device == deviceID, profile.width == 1920, profile.height == 1080,
                  profile.pipeline == "ios_avfoundation_v1", profile.zoom == 1,
                  profile.focus == "locked", profile.stabilization == "off", profile.orientation == "sensor_native" else {
                throw LabError.message("Kayıtlı kamera profili bu cihazda aynen uygulanamıyor; yeni kalibrasyon gerekli.")
            }
            if let subtype=UInt32(profile.format), String(subtype) == profile.format {
                // Old builds selected the first 1080p30 format, regardless of
                // binning/FOV. Restore that choice rather than upgrading it.
                guard lens == "wide", let old=formats.first(where: { $0.width == 1920 && $0.height == 1080 && $0.supports30FPS }),
                      old.supported, old.mediaSubtype == subtype else {
                    throw LabError.message("Eski 1080p kamera biçimi bulunamadı; yeni kalibrasyon gerekli.")
                }
                return CameraOpticsChoice(lens:lens,format:old,signature:profile.format,distortionCorrection:nil)
            }
            let correction: Bool
            if profile.format.hasSuffix("|gdc=1") { correction=true }
            else if profile.format.hasSuffix("|gdc=0") { correction=false }
            else { throw LabError.message("Kayıtlı optik biçim imzası geçersiz; yeni kalibrasyon gerekli.") }
            guard !correction || supportsDistortionCorrection,
                  let exact=supported.first(where: { $0.signature(correction: correction) == profile.format }) else {
                throw LabError.message("Kalibrasyonun sensör biçimi/görüş açısı aynen bulunamadı; yeni kalibrasyon gerekli.")
            }
            return CameraOpticsChoice(lens:lens,format:exact,signature:profile.format,distortionCorrection:correction)
        }
        // Prefer genuine UHD sensor/preview detail, then phase AF and unbinned
        // sampling. Measurement output stays exactly 1920×1080 at the same FOV.
        let ranked=supported.sorted { a,b in
            if a.width != b.width { return a.width > b.width }
            if a.phaseDetection != b.phaseDetection { return a.phaseDetection }
            if a.binned != b.binned { return !a.binned }
            return a.index < b.index
        }
        guard let selected=ranked.first else { throw LabError.message("Bu fiziksel kamera 1080p/4K 30 fps biçimini desteklemiyor.") }
        return CameraOpticsChoice(lens:lens,format:selected,
                                  signature:selected.signature(correction:supportsDistortionCorrection),
                                  distortionCorrection:supportsDistortionCorrection)
    }
}
