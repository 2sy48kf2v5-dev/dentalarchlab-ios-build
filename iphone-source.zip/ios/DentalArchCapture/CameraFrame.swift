import CoreMedia
import CoreVideo
import Foundation
import simd

/// Metadata copied from the SAME accepted sensor sample as the image, before
/// asynchronous encoding. Hardware K helps 2D recognition; it is not a substitute
/// for physical lens/distortion calibration or a claim of metric accuracy.
struct CapturedCameraFrame {
    let image: Data
    let profile: CaptureProfile
    let timestamp: Double
    let intrinsics: FrameCameraIntrinsics?
}

struct FrameCameraIntrinsics: Codable, Equatable {
    let width: Int
    let height: Int
    let fx: Double
    let fy: Double
    let cx: Double
    let cy: Double
    let source: String
    static let hardwareSource = "avfoundation_sample_buffer"

    init(width: Int, height: Int, fx: Double, fy: Double, cx: Double, cy: Double) throws {
        // The current encoder accepts only the unrotated, uncropped 1080p
        // measurement stream. Do not scale sensor K by a guessed ratio.
        guard width == 1920, height == 1080,
              [fx, fy, cx, cy].allSatisfy(\.isFinite), fx > 0, fy > 0,
              cx >= 0, cx <= Double(width), cy >= 0, cy <= Double(height) else {
            throw LabError.message("Kareye ait donanım kamera matrisi geçersiz.")
        }
        self.width = width; self.height = height
        self.fx = fx; self.fy = fy; self.cx = cx; self.cy = cy
        self.source = Self.hardwareSource
    }

    private enum CodingKeys: String, CodingKey { case width, height, fx, fy, cx, cy, source }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        guard try values.decode(String.self, forKey: .source) == Self.hardwareSource else {
            throw DecodingError.dataCorruptedError(forKey: .source, in: values, debugDescription: "Hardware intrinsic source required.")
        }
        try self.init(width: values.decode(Int.self, forKey: .width), height: values.decode(Int.self, forKey: .height),
                      fx: values.decode(Double.self, forKey: .fx), fy: values.decode(Double.self, forKey: .fy),
                      cx: values.decode(Double.self, forKey: .cx), cy: values.decode(Double.self, forKey: .cy))
    }

    func nativeDictionary() -> [String: Any] {
        ["K": [[fx, 0, cx], [0, fy, cy], [0, 0, 1]], "width": width, "height": height, "source": source]
    }
    func matches(_ profile: CaptureProfile) -> Bool { profile.width == width && profile.height == height }

    static func fromHardwareAttachment(_ data: Data, width: Int, height: Int) -> FrameCameraIntrinsics? {
        // CoreMedia defines CFData(matrix_float3x3), column-major with SIMD
        // padding. Copy into aligned storage; never load unaligned Data memory.
        guard data.count == MemoryLayout<simd_float3x3>.size else { return nil }
        var matrix = matrix_identity_float3x3
        _ = withUnsafeMutableBytes(of: &matrix) { data.copyBytes(to: $0) }
        let c = matrix.columns
        let entries = [c.0.x,c.0.y,c.0.z,c.1.x,c.1.y,c.1.z,c.2.x,c.2.y,c.2.z]
        guard entries.allSatisfy(\.isFinite), abs(c.0.y) < 0.00001, abs(c.0.z) < 0.00001,
              abs(c.1.x) < 0.00001, abs(c.1.z) < 0.00001, abs(c.2.z - 1) < 0.00001 else { return nil }
        return try? FrameCameraIntrinsics(width: width, height: height, fx: Double(c.0.x), fy: Double(c.1.y),
                                         cx: Double(c.2.x), cy: Double(c.2.y))
    }

    static func read(from sample: CMSampleBuffer, width: Int, height: Int) -> FrameCameraIntrinsics? {
        guard let pixels = CMSampleBufferGetImageBuffer(sample),
              CVPixelBufferGetWidth(pixels) == width, CVPixelBufferGetHeight(pixels) == height,
              let attachment = CMGetAttachment(sample, key: kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix,
                                               attachmentModeOut: nil),
              CFGetTypeID(attachment) == CFDataGetTypeID(), let data = attachment as? Data else { return nil }
        return fromHardwareAttachment(data, width: width, height: height)
    }
}
