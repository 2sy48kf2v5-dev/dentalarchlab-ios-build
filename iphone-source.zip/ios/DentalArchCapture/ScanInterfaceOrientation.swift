import UIKit

/// Changes only the interface. Measurement buffers retain their native sensor axes.
@MainActor
enum ScanInterfaceOrientation {
    private(set) static var supported: UIInterfaceOrientationMask = .portrait
    private static var generation = 0
    // A dismissed sheet or tab transition can temporarily refuse a geometry
    // request. Recheck the actual scene rather than leaving that refusal final.
    private static let retryDelays: [TimeInterval] = [0.15, 0.3, 0.6, 1.0]

    static func setScanning(_ scanning: Bool) {
        supported = scanning ? .landscape : .portrait
        generation += 1
        let requestGeneration = generation
        // Let SwiftUI install the destination hierarchy before asking UIKit to rotate it.
        DispatchQueue.main.async {
            guard generation == requestGeneration else { return }
            for case let scene as UIWindowScene in UIApplication.shared.connectedScenes
                where scene.activationState == .foregroundActive || scene.activationState == .foregroundInactive {
                applyOrientation(to: scene, requestGeneration: requestGeneration, attempt: 0)
            }
        }
    }

    private static func applyOrientation(to scene: UIWindowScene, requestGeneration: Int, attempt: Int) {
        guard generation == requestGeneration,
              scene.activationState == .foregroundActive || scene.activationState == .foregroundInactive else { return }
        let target = supported
        let alreadyOriented = matches(scene.interfaceOrientation, mask: target)
        // Always invalidate once when the allowed mask changes, even if the
        // current orientation already matches. Later checks stop on success.
        guard attempt == 0 || !alreadyOriented else { return }
        let controllers = hierarchy(in: scene)
        for controller in controllers {
            controller.setNeedsUpdateOfSupportedInterfaceOrientations()
        }
        guard !alreadyOriented else { return }

        // SwiftUI's presented sheet, navigation stack, or tab controller may
        // still be transitioning. Wait for the deepest active transition so
        // UIKit evaluates the destination hierarchy's supported orientations.
        if attempt < retryDelays.count,
           let transition = controllers.reversed().compactMap({ $0.transitionCoordinator }).first(where: { $0.isAnimated }) {
            let scheduled = transition.animate(alongsideTransition: nil) { _ in
                DispatchQueue.main.async { [weak scene] in
                    guard let scene else { return }
                    applyOrientation(to: scene, requestGeneration: requestGeneration, attempt: attempt + 1)
                }
            }
            if scheduled { return }
        }

        scene.requestGeometryUpdate(.iOS(interfaceOrientations: target)) { error in
            // A later bounded check retries only while the scene still differs.
            NSLog("DentalArchLab interface rotation: %@", error.localizedDescription)
        }
        guard attempt < retryDelays.count else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + retryDelays[attempt]) { [weak scene] in
            guard let scene else { return }
            applyOrientation(to: scene, requestGeneration: requestGeneration, attempt: attempt + 1)
        }
    }

    private static func matches(_ orientation: UIInterfaceOrientation, mask: UIInterfaceOrientationMask) -> Bool {
        switch orientation {
        case .portrait: return mask.contains(.portrait)
        case .portraitUpsideDown: return mask.contains(.portraitUpsideDown)
        case .landscapeLeft: return mask.contains(.landscapeLeft)
        case .landscapeRight: return mask.contains(.landscapeRight)
        default: return false
        }
    }

    /// SwiftUI embeds the active content inside child tab/navigation hosting
    /// controllers, so walking only root and presented controllers is incomplete.
    private static func hierarchy(in scene: UIWindowScene) -> [UIViewController] {
        var result: [UIViewController] = []
        var visited = Set<ObjectIdentifier>()
        func visit(_ controller: UIViewController) {
            guard visited.insert(ObjectIdentifier(controller)).inserted else { return }
            result.append(controller)
            for child in controller.children { visit(child) }
            if let presented = controller.presentedViewController { visit(presented) }
        }
        for window in scene.windows {
            if let root = window.rootViewController { visit(root) }
        }
        return result
    }
}

@MainActor
final class DentalOrientationDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        ScanInterfaceOrientation.supported
    }
}
