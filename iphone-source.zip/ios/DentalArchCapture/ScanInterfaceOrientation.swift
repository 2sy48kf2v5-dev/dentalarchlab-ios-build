import UIKit

/// Changes only the interface. Measurement buffers retain their native sensor axes.
@MainActor
enum ScanInterfaceOrientation {
    private(set) static var supported: UIInterfaceOrientationMask = .portrait
    private static var generation = 0

    static func setScanning(_ scanning: Bool) {
        supported = scanning ? .landscape : .portrait
        generation += 1
        let requestGeneration = generation
        // Let SwiftUI install the destination hierarchy before asking UIKit to rotate it.
        DispatchQueue.main.async {
            guard generation == requestGeneration else { return }
            for case let scene as UIWindowScene in UIApplication.shared.connectedScenes
                where scene.activationState == .foregroundActive || scene.activationState == .foregroundInactive {
                for window in scene.windows {
                    var controller = window.rootViewController
                    while let current = controller {
                        current.setNeedsUpdateOfSupportedInterfaceOrientations()
                        controller = current.presentedViewController
                    }
                }
                scene.requestGeometryUpdate(.iOS(interfaceOrientations: supported)) { error in
                    // The responsive portrait fallback remains usable if the system refuses.
                    NSLog("DentalArchLab interface rotation: %@", error.localizedDescription)
                }
            }
        }
    }
}

@MainActor
final class DentalOrientationDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication,
                     supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        ScanInterfaceOrientation.supported
    }
}
