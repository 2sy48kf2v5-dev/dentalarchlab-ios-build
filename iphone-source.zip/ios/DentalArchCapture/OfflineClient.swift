import Foundation

struct OfflineClient {
    let engine: OfflineEngine
    let base = URL(string: "dentalarchlab://iphone-native")!
    let token = "local"

    /// Camera bytes stay Data across the actor boundary. The actor retains all
    /// session/frame/profile/hash validation; no full-image JSON is created.
    func frame(_ path: String, id: String, image: Data, profile: CaptureProfile, timestamp: Double) async throws -> [String: Any] {
        try await engine.submitFrame(path, id: id, image: image, profile: profile, timestamp: timestamp)
    }

    func send<T: Encodable>(_ path: String, value: T) async throws -> [String: Any] {
        try await engine.request(path, body: JSONEncoder().encode(value))
    }
    func request(_ path: String, body: [String: Any]? = nil) async throws -> [String: Any] {
        try await engine.request(path, body: body.map { try JSONSerialization.data(withJSONObject: $0) })
    }
}
