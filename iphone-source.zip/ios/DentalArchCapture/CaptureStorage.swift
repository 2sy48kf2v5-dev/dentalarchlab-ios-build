import Foundation
import Security
import CryptoKit

enum LabError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}
func captureID() -> String { UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased() }

struct CaptureProfile: Codable, Equatable {
    var pipeline = "ios_avfoundation_v1"
    var device: String
    var lensPosition: Float
    var width: Int
    var height: Int
    var format: String
    var lens = "wide"
    var focus = "locked"
    var stabilization = "off"
    var zoom = 1
    var orientation = "sensor_native"
    // A nonmetric identity trial may refocus. Every other optical property is
    // still exact, and calibrated scanning never inherits this exception.
    func accepts(_ actual: CaptureProfile, mode: String) -> Bool {
        guard actual.lensPosition.isFinite, (0...1).contains(actual.lensPosition) else { return false }
        guard mode == "trial" else { return self == actual }
        var comparable = actual
        comparable.lensPosition = lensPosition
        return self == comparable
    }
    enum CodingKeys: String, CodingKey {
        case pipeline, device, width, height, format, lens, focus, stabilization, zoom, orientation
        case lensPosition = "lens_position"
    }
}
struct CaptureCreation: Codable {
    struct Board: Codable {
        var physicalMeasured: Bool
        var squareMM: Double?
        enum CodingKeys: String, CodingKey { case physicalMeasured = "physical_measured", squareMM = "square_mm" }
    }
    var id: String
    var mode: String
    var markerCount: Int
    var profile: CaptureProfile
    var board: Board
    var calibrationID: String?
    var dentalPlan: DentalPlan? = nil
    var muaCalibration: MUACalibration? = nil
    // Absent only in records created before the per-frame hardware-K pipeline.
    var trialIntrinsicsRequired: Bool? = nil
    init(mode: String, markerCount: Int, profile: CaptureProfile, physical: Bool, squareMM: Double?, calibrationID: String?) {
        self.id = captureID(); self.mode = mode; self.markerCount = markerCount; self.profile = profile
        self.board = Board(physicalMeasured: physical, squareMM: squareMM); self.calibrationID = calibrationID
    }
    enum CodingKeys: String, CodingKey { case id, mode, profile, board; case markerCount = "marker_count", calibrationID = "calibration_id", dentalPlan = "dental_plan", muaCalibration = "mua_calibration", trialIntrinsicsRequired = "trial_intrinsics_required" }
}
struct PendingFrame: Codable, Identifiable {
    var id: String
    var timestamp: Double
    // Older records omit this; they were all captured with creation.profile.
    var profile: CaptureProfile? = nil
    var intrinsics: FrameCameraIntrinsics? = nil
}
struct LocalCapture: Codable, Identifiable {
    var id: String { creation.id }
    var creation: CaptureCreation
    var created: Date
    var state = "collecting"
    var engine: String? = nil
    var pending: [PendingFrame] = []
    var frameCount = 0
    var acceptedCount = 0
    var message = "İlk görüntü bekleniyor."
    var trialProfile: CaptureProfile? = nil
    var activeProfile: CaptureProfile { creation.mode == "trial" ? (trialProfile ?? creation.profile) : creation.profile }
}
struct FrameUpload: Encodable {
    var id: String; var image: String; var profile: CaptureProfile; var timestamp: Double
    var intrinsics: FrameCameraIntrinsics? = nil
    enum CodingKeys: String, CodingKey { case id, image, profile, intrinsics; case timestamp = "timestamp_s" }
}

struct PreviewCommit: Encodable {
    let session: String
    let id: String
    let sha256: String
    let profile: CaptureProfile
    let timestamp: Double
    var intrinsics: FrameCameraIntrinsics? = nil
    enum CodingKeys: String, CodingKey { case id, sha256, profile, intrinsics; case timestamp = "timestamp_s" }
    static func digest(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
    static func verify(_ receipt: [String: Any], frame: String, digest: String) throws {
        guard receipt["id"] as? String == frame, receipt["sha256"] as? String == digest,
              receipt["accepted"] is Bool, let count = receipt["count"] as? Int, (0...120).contains(count) else {
            throw LabError.message("Sunucu görüntü onayı eşleşmedi; özgün görüntü telefonda korundu.")
        }
    }
}

struct BridgeHTTPError: LocalizedError {
    let status: Int
    let message: String
    var errorDescription: String? { message }
    var retryWithOriginal: Bool { status == 409 || status == 404 }
}

struct RegistrationKey: Hashable {
    let base: URL
    let token: String
    let session: String
}

final class CaptureRepository {
    let root: URL
    init(root: URL? = nil) {
        self.root = root ?? FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("Captures", isDirectory: true)
    }
    private func folder(_ id: String) throws -> URL {
        guard id.count == 32, id.allSatisfy({ "0123456789abcdef".contains($0) }) else { throw LabError.message("Geçersiz kayıt kimliği.") }
        return root.appendingPathComponent(id, isDirectory: true)
    }
    func list() throws -> [LocalCapture] {
        guard FileManager.default.fileExists(atPath: root.path) else { return [] }
        return try FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil)
            .filter { FileManager.default.fileExists(atPath: $0.appendingPathComponent("capture.json").path) }
            .map { try JSONDecoder().decode(LocalCapture.self, from: Data(contentsOf: $0.appendingPathComponent("capture.json"))) }
            .sorted { $0.created > $1.created }
    }
    func get(_ id: String) throws -> LocalCapture {
        try JSONDecoder().decode(LocalCapture.self, from: Data(contentsOf: folder(id).appendingPathComponent("capture.json")))
    }
    private func save(_ capture: LocalCapture) throws {
        let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(capture).write(to: folder(capture.id).appendingPathComponent("capture.json"), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
    func create(_ creation: CaptureCreation) throws {
        let destination = try folder(creation.id)
        guard !FileManager.default.fileExists(atPath: destination.path) else { throw LabError.message("Kayıt zaten var.") }
        try FileManager.default.createDirectory(at: destination, withIntermediateDirectories: true)
        var local = LocalCapture(creation: creation, created: Date())
        local.engine = "iphone_native_v1"
        try save(local)
    }
    func updateTrialProfile(session: String, profile: CaptureProfile) throws {
        var capture = try get(session)
        guard capture.creation.mode == "trial", capture.engine == "iphone_native_v1",
              capture.state == "collecting", capture.pending.isEmpty,
              capture.creation.profile.accepts(profile, mode: "trial") else {
            throw LabError.message("Yeniden netleme yalnız bekleyen karesi olmayan 2B deneyinde kullanılabilir.")
        }
        capture.trialProfile = profile
        try save(capture)
    }
    @discardableResult func append(id: String, image: Data, timestamp: Double, frameID: String = captureID(), profile: CaptureProfile? = nil, intrinsics: FrameCameraIntrinsics? = nil) throws -> String {
        var capture = try get(id)
        let actual = profile ?? capture.activeProfile
        guard intrinsics?.matches(actual) ?? true else { throw LabError.message("Kare kamera matrisi görüntü boyutuyla eşleşmiyor.") }
        guard capture.state == "collecting", capture.frameCount < 120, image.count <= 8*1024*1024,
              timestamp.isFinite, timestamp >= 0,
              capture.creation.profile.accepts(actual, mode: capture.creation.mode) else { throw LabError.message("Kayıt kapalı, kamera profili değişmiş veya 120 görüntü / 8 MB sınırı aşıldı.") }
        let fid = frameID
        _ = try folder(fid)
        guard !FileManager.default.fileExists(atPath: try folder(id).appendingPathComponent(fid + ".png").path),
              !FileManager.default.fileExists(atPath: try folder(id).appendingPathComponent(fid + ".jpg").path) else {
            throw LabError.message("Kare zaten kaydedilmiş; üzerine yazılmadı.")
        }
        let suffix = image.starts(with: [0xff, 0xd8]) ? ".jpg" : ".png"
        try image.write(to: folder(id).appendingPathComponent(fid + suffix), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        capture.pending.append(PendingFrame(id: fid, timestamp: timestamp, profile: actual, intrinsics: intrinsics)); capture.frameCount += 1
        try save(capture)
        return fid
    }
    func image(session: String, frame: String) throws -> Data {
        _ = try folder(frame) // Validate frame ID before it becomes a path component.
        let png = try folder(session).appendingPathComponent(frame + ".png")
        let jpg = try folder(session).appendingPathComponent(frame + ".jpg")
        return try Data(contentsOf: FileManager.default.fileExists(atPath: png.path) ? png : jpg)
    }
    func acknowledge(session: String, frame: String, receipt: [String: Any]) throws {
        var capture = try get(session)
        guard receipt["id"] as? String == frame else { throw LabError.message("Sunucu kare kimliği eşleşmedi; görüntü korundu.") }
        capture.pending.removeAll { $0.id == frame }
        capture.acceptedCount = (receipt["count"] as? Int) ?? capture.acceptedCount
        capture.message = receipt["message"] as? String ?? "Görüntü gönderildi."
        try save(capture)
        // PNG originals are deliberately retained even when a quality gate rejects them.
    }
    func update(session: String, state: String, message: String) throws {
        var capture = try get(session); capture.state = state; capture.message = message; try save(capture)
    }
    func resultURL(_ id: String) throws -> URL { try folder(id).appendingPathComponent("result.json") }
    func cacheResult(session: String, response: [String: Any]) throws -> ResultSnapshot {
        guard response["id"] as? String == session else { throw LabError.message("Sonuç kayıt kimliği eşleşmedi.") }
        let snapshot = try ResultSnapshot.decode(response)
        let bytes = try JSONSerialization.data(withJSONObject: response, options: [.prettyPrinted, .sortedKeys])
        try bytes.write(to: resultURL(session), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return snapshot
    }
    func cachedResult(session: String) throws -> ResultSnapshot? {
        guard try get(session).state == "complete" else { return nil }
        let file = try resultURL(session)
        guard FileManager.default.fileExists(atPath: file.path) else { return nil }
        guard let response = try JSONSerialization.jsonObject(with: Data(contentsOf: file)) as? [String: Any],
              response["id"] as? String == session else { throw LabError.message("Kayıtlı sonuç geçersiz.") }
        return try ResultSnapshot.decode(response)
    }
}

final class NoRedirects: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
struct BridgeClient {
    let base: URL
    let token: String
    private static let network = URLSession(configuration: .ephemeral, delegate: NoRedirects(), delegateQueue: nil)
    init(address: String, token: String) throws {
        guard let components = URLComponents(string: address.trimmingCharacters(in: .whitespacesAndNewlines)),
              let host = components.host?.lowercased(), let url = components.url, let scheme = components.scheme,
              ["http", "https"].contains(scheme), components.user == nil, components.password == nil,
              components.query == nil, components.fragment == nil, components.path.isEmpty || components.path == "/" else {
            throw LabError.message("Bilgisayar adresini http://192.168.x.x:8765 biçiminde girin.")
        }
        let rawParts = host.split(separator: ".", omittingEmptySubsequences: false)
        let parts = rawParts.compactMap { Int($0) }
        let ipv4 = rawParts.count == 4 && parts.count == 4 && parts.allSatisfy { (0...255).contains($0) }
            && rawParts.allSatisfy { part in !part.isEmpty && part.utf8.allSatisfy { (48...57).contains($0) } && (part.count == 1 || !part.hasPrefix("0")) }
        let localIP = ipv4 && (parts[0] == 10 || parts[0] == 127 || (parts[0] == 192 && parts[1] == 168) || (parts[0] == 172 && (16...31).contains(parts[1])))
        guard localIP || host == "localhost" || host.hasSuffix(".local") else { throw LabError.message("Yalnız yerel bilgisayar adresleri desteklenir.") }
        guard !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw LabError.message("Bilgisayardaki bağlantı anahtarını girin.") }
        base = url; self.token = token.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    func send<T: Encodable>(_ path: String, value: T) async throws -> [String: Any] {
        try await requestData(path, body: JSONEncoder().encode(value))
    }
    func request(_ path: String, body: [String: Any]? = nil) async throws -> [String: Any] {
        try await requestData(path, body: body.map { try JSONSerialization.data(withJSONObject: $0) })
    }
    private func requestData(_ path: String, body: Data?) async throws -> [String: Any] {
        var request = URLRequest(url: base.appendingPathComponent("api/" + path))
        request.timeoutInterval = 30; request.httpMethod = body == nil ? "GET" : "POST"
        request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        if let body { request.setValue("application/json", forHTTPHeaderField: "Content-Type"); request.httpBody = body }
        let (bytes, response) = try await Self.network.data(for: request)
        guard let response = response as? HTTPURLResponse,
              let object = try JSONSerialization.jsonObject(with: bytes) as? [String: Any] else { throw LabError.message("Sunucu yanıtı okunamadı.") }
        guard (200..<300).contains(response.statusCode) else { throw BridgeHTTPError(status: response.statusCode, message: object["error"] as? String ?? "Sunucu işlemi kabul etmedi.") }
        return object
    }
}

enum PairingKey {
    private static let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: "DentalArchLab.localbridge", kSecAttrAccount as String: "pairing"]
    static func load() -> String? {
        var q = query; q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?; guard SecItemCopyMatching(q as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }; return String(data: data, encoding: .utf8)
    }
    static func save(_ token: String) throws {
        let update = [kSecValueData as String: Data(token.utf8)]
        var status = SecItemUpdate(query as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var item = query; item[kSecValueData as String] = Data(token.utf8)
            item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            status = SecItemAdd(item as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw LabError.message("Bağlantı anahtarı güvenli alana kaydedilemedi.") }
    }
}
