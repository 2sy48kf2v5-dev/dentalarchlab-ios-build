import Foundation
import ImageIO
import UIKit

/// Decode sampled images away from the main actor before SwiftUI draws them.
/// The input bytes and full pixel dimensions remain unchanged for metrology.
enum FramePresentation {
    static func decode(_ data: Data) async -> UIImage? {
        await Task.detached(priority: .userInitiated) { () -> UIImage? in
            autoreleasepool { () -> UIImage? in
                guard let source = CGImageSourceCreateWithData(data as CFData, nil),
                      let image = CGImageSourceCreateImageAtIndex(source, 0,
                        [kCGImageSourceShouldCacheImmediately: true] as CFDictionary) else { return nil }
                return UIImage(cgImage: image)
            }
        }.value
    }

    static func digest(_ data: Data) async -> String {
        await Task.detached(priority: .userInitiated) { PreviewCommit.digest(data) }.value
    }
}
