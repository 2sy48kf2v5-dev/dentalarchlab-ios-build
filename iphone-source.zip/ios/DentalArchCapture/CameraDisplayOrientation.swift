import UIKit

/// Display rotation for this app's unmirrored back-camera sensor images.
/// The video-data output stays at 0 degrees and 1920 x 1080 in every orientation.
/// Apply this angle only to the preview connection; rotate still-image metadata
/// and normalized overlay points together without changing measurement pixels.
enum CameraDisplayOrientation: CaseIterable, Equatable {
    case portrait
    case landscapeLeft
    case landscapeRight
    case portraitUpsideDown

    /// Use the preview's windowScene.interfaceOrientation, not UIDeviceOrientation:
    /// UIKit's two landscape interface names are opposite the device names.
    /// Unknown orientation must retain the previous display orientation.
    init?(interfaceOrientation: UIInterfaceOrientation) {
        switch interfaceOrientation {
        case .portrait: self = .portrait
        case .landscapeLeft: self = .landscapeLeft
        case .landscapeRight: self = .landscapeRight
        case .portraitUpsideDown: self = .portraitUpsideDown
        default: return nil
        }
    }

    var previewRotationAngle: CGFloat {
        switch self {
        case .landscapeRight: return 0
        case .portrait: return 90
        case .landscapeLeft: return 180
        case .portraitUpsideDown: return 270
        }
    }

    var imageOrientation: UIImage.Orientation {
        switch self {
        case .landscapeRight: return .up
        case .portrait: return .right
        case .landscapeLeft: return .down
        case .portraitUpsideDown: return .left
        }
    }

    var swapsDimensions: Bool { self == .portrait || self == .portraitUpsideDown }

    /// The input is a validated, unrotated sensor-normalized [x, y] point.
    func normalizedPoint(_ point: [Double]) -> [Double] {
        switch self {
        case .landscapeRight: return point
        case .portrait: return [1 - point[1], point[0]]
        case .landscapeLeft: return [1 - point[0], 1 - point[1]]
        case .portraitUpsideDown: return [point[1], 1 - point[0]]
        }
    }

    /// Aspect-fit viewport for an analyzed still; live preview uses aspect-fill.
    func viewport(imageWidth: Int, imageHeight: Int,
                  viewWidth: Double, viewHeight: Double) -> FeedbackViewport {
        FeedbackViewport(imageWidth: Double(swapsDimensions ? imageHeight : imageWidth),
                         imageHeight: Double(swapsDimensions ? imageWidth : imageHeight),
                         viewWidth: viewWidth, viewHeight: viewHeight)
    }
}
