import Foundation

struct LabPoint: Equatable {
    let x: Double
    let y: Double
    let z: Double
    static let zero = LabPoint(x: 0, y: 0, z: 0)
    static func + (a: Self, b: Self) -> Self { Self(x: a.x+b.x, y: a.y+b.y, z: a.z+b.z) }
    static func - (a: Self, b: Self) -> Self { Self(x: a.x-b.x, y: a.y-b.y, z: a.z-b.z) }
    static func * (a: Self, scale: Double) -> Self { Self(x: a.x*scale, y: a.y*scale, z: a.z*scale) }
    var length: Double { sqrt(x*x + y*y + z*z) }
}

struct ResultLandmark: Identifiable {
    let id: Int
    let center: LabPoint
    let axis: LabPoint
    let isMUA: Bool
    /// The measured pose selected during decoding. Its translation is center;
    /// preserve all rotation columns so the viewer never invents a measured roll.
    let worldTransform: [[Double]]?

    init(id: Int, center: LabPoint, axis: LabPoint, isMUA: Bool, worldTransform: [[Double]]? = nil) {
        self.id = id; self.center = center; self.axis = axis; self.isMUA = isMUA
        self.worldTransform = worldTransform
    }
}

struct ResultSnapshot {
    let title: String
    let message: String
    let landmarks: [ResultLandmark]
    let rmsPX: Double?
    let warnings: [String]
    let isIllustration: Bool
    let isSynthetic: Bool
    var trial: TrialSummary? = nil
    var hasMUA: Bool { landmarks.contains { $0.isMUA } }

    static func decode(_ envelope: [String: Any]) throws -> Self {
        guard envelope["state"] as? String == "complete" else {
            throw LabError.message("Hesap tamamlanmadan 3B sonuç gösterilmez.")
        }
        let result = envelope["result"] as? [String: Any]
        let calibration = envelope["calibration"] as? [String: Any]
        let mode = (envelope["mode"] as? String) ?? ""
        // A trial has no spatial result, including when loading an old or
        // inconsistent cache. Never display coordinates under a 2B trial title.
        if mode == "trial", let spatial = envelope["result"], !(spatial is NSNull) {
            throw LabError.message("2B bayrak deneyi 3B sonuç içeremez. Kayıt türü ve sonuç verisi eşleşmiyor.")
        }
        let meta = calibration?["metadata"] as? [String: Any]
        let rms = (result?["reprojection_rms_px"] ?? meta?["rms_px"]) as? Double
        if let rms, (!rms.isFinite || rms < 0) { throw LabError.message("Görüntü uyum hatası geçersiz.") }
        var landmarks: [ResultLandmark] = []
        if let result {
            guard result["units"] as? String == "mm", let markers = result["markers"] as? [[String: Any]],
                  !markers.isEmpty, markers.count <= 50 else {
                throw LabError.message("3B sonucun birimi veya bayrak listesi geçersiz.")
            }
            var ids = Set<Int>()
            for marker in markers {
                guard let id = marker["id"] as? Int, ids.insert(id).inserted else {
                    throw LabError.message("Bayrak kimliği eksik veya yinelenmiş.")
                }
                // T_world_mua may be JSON null. Never infer an MUA from a flag center.
                let mua = marker["T_world_mua"] as? [[Double]]
                if let raw = marker["T_world_mua"], !(raw is NSNull), mua == nil {
                    throw LabError.message("MUA dönüşüm matrisi okunamadı.")
                }
                let transform = mua ?? (marker["T_world_marker"] as? [[Double]])
                guard let t = transform, t.count == 4, t.allSatisfy({ $0.count == 4 && $0.allSatisfy(\.isFinite) }),
                      abs(t[3][0]) < 1e-8, abs(t[3][1]) < 1e-8, abs(t[3][2]) < 1e-8, abs(t[3][3]-1) < 1e-8 else {
                    throw LabError.message("3B dönüşüm matrisi geçersiz.")
                }
                let axis = LabPoint(x: t[0][2], y: t[1][2], z: t[2][2])
                guard abs(axis.length-1) < 0.01 else { throw LabError.message("3B eksen birim uzunlukta değil.") }
                guard isRigidRotation(t) else { throw LabError.message("3B dönüşümün dönme eksenleri rijit değil.") }
                landmarks.append(ResultLandmark(id: id, center: LabPoint(x: t[0][3], y: t[1][3], z: t[2][3]),
                    axis: axis, isMUA: mua != nil, worldTransform: t))
            }
        }
        return Self(title: mode == "calibration" ? "Kamera kalibrasyonu" : mode == "trial" ? "Bayrak deneyi" : "3B araştırma sonucu",
                    message: envelope["message"] as? String ?? "Hesap tamamlandı.", landmarks: landmarks,
                    rmsPX: rms, warnings: (result?["warnings"] ?? meta?["warnings"]) as? [String] ?? [],
                    isIllustration: false, isSynthetic: mode == "demo",
                    trial: mode == "trial" ? try TrialSummary.decode(envelope) : nil)
    }

    private static func isRigidRotation(_ t: [[Double]]) -> Bool {
        for a in 0..<3 {
            for b in 0..<3 {
                var dot = 0.0
                for row in 0..<3 { dot += t[row][a] * t[row][b] }
                if abs(dot - (a == b ? 1 : 0)) > 0.01 { return false }
            }
        }
        let first = t[0][0] * (t[1][1] * t[2][2] - t[1][2] * t[2][1])
        let second = t[0][1] * (t[1][0] * t[2][2] - t[1][2] * t[2][0])
        let third = t[0][2] * (t[1][0] * t[2][1] - t[1][1] * t[2][0])
        return abs(first - second + third - 1) <= 0.01
    }

    static func illustration(count: Int) -> Self {
        let n = count == 4 ? 4 : 6
        let points = (0..<n).map { index -> ResultLandmark in
            let angle = Double(index) / Double(n-1) * .pi
            return ResultLandmark(id: index, center: LabPoint(x: cos(angle)*27, y: sin(angle)*32, z: 0),
                                  axis: LabPoint(x: 0, y: 0, z: 1), isMUA: false)
        }
        return Self(title: "Uygulamayı keşfet", message: "Bu şekil uygulama içi tanıtım için çizildi. Kamera ölçümü veya doğruluk testi değildir.",
                    landmarks: points, rmsPX: nil, warnings: [], isIllustration: true, isSynthetic: true)
    }
}

struct TrialSummary {
    let expectedCount: Int
    let recognizedIDs: [Int]
    let acceptedFrames: Int
    var selectedIDs: [Int]? = nil
    var missingIDs: [Int] { (selectedIDs ?? Array(0..<expectedCount)).filter { !recognizedIDs.contains($0) } }
    static func decode(_ envelope: [String: Any]) throws -> Self {
        guard let count = envelope["marker_count"] as? Int, [4, 6].contains(count) else {
            throw LabError.message("2B deneyinin bayrak sayısı eksik.")
        }
        let expected = try MarkerSelection.decode(count: count, raw: envelope["marker_ids"])
        let frames = envelope["accepted"] as? [[String: Any]] ?? []
        let summary = envelope["trial_summary"] as? [String: Any]
        let ids: [Int]
        let accepted: Int
        if let summary {
            if let raw = summary["expected_marker_ids"] {
                guard try MarkerSelection.decode(count: count, raw: raw) == expected else {
                    throw LabError.message("2B sonuçtaki bayrak seçimi kayıtla eşleşmiyor.")
                }
            }
            guard summary["expected_count"] as? Int == count,
                  summary["metric"] as? String == "identity_only_no_3d",
                  summary["physical_accuracy_um"] is NSNull,
                  let values = summary["recognized_ids"] as? [Int],
                  let n = summary["accepted_frames"] as? Int else {
                throw LabError.message("2B deney özeti geçersiz.")
            }
            ids = values; accepted = n
        } else {
            // Recover an older locally saved trial without inventing 3D positions.
            ids = Array(Set(frames.flatMap { ($0["observations"] as? [[String: Any]] ?? []).compactMap { $0["marker"] as? Int } })).sorted()
            accepted = frames.count
        }
        guard Set(ids).count == ids.count, ids.allSatisfy({ expected.contains($0) }),
              (0...120).contains(accepted), accepted > 0 || ids.isEmpty else {
            throw LabError.message("2B deney bayrak kimlikleri geçersiz.")
        }
        return Self(expectedCount: count, recognizedIDs: ids.sorted(), acceptedFrames: accepted, selectedIDs: expected)
    }
}

struct PairingDetails {
    let address: String
    let token: String
    init(link: String) throws {
        guard var parts = URLComponents(string: link.trimmingCharacters(in: .whitespacesAndNewlines)),
              let fragment = parts.fragment, fragment.hasPrefix("key=") else {
            throw LabError.message("Bilgisayardaki DentalArchLab bağlantı QR kodunu kullanın.")
        }
        let key = String(fragment.dropFirst(4))
        guard (24...128).contains(key.count), key.utf8.allSatisfy({ (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0) || $0 == 45 || $0 == 95 }) else {
            throw LabError.message("QR bağlantı anahtarı geçersiz.")
        }
        parts.fragment = nil
        guard let address = parts.url?.absoluteString else { throw LabError.message("Bağlantı adresi geçersiz.") }
        let client = try BridgeClient(address: address, token: key)
        self.address = client.base.absoluteString; self.token = client.token
    }
}
