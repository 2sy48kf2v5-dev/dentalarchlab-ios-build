import Foundation

struct ToothAssignment: Codable, Equatable, Identifiable {
    var markerID: Int
    var fdi: Int?
    var componentCode = "MG-MUASB9"
    var id: Int { markerID }
    enum CodingKeys: String, CodingKey { case markerID = "marker_id", fdi, componentCode = "component_code" }
}

struct DentalPlan: Codable, Equatable {
    var arch = "lower"
    var assignments: [ToothAssignment] = (0..<6).map { ToothAssignment(markerID: $0) }
    /// Physical IDs are identities, not positions in the assignments array.
    var markerIDs: [Int] { assignments.map(\.markerID).sorted() }
    static func teeth(arch: String) -> [Int] {
        arch == "upper" ? Array(stride(from: 18, through: 11, by: -1)) + Array(21...28)
                        : Array(stride(from: 48, through: 41, by: -1)) + Array(31...38)
    }
    mutating func reset(count: Int, arch: String? = nil) {
        guard [4, 6].contains(count) else { return }
        try? reset(markerIDs: Array(0..<count), arch: arch)
    }
    mutating func reset(markerIDs: [Int], arch: String? = nil) throws {
        try Self.validateMarkerIDs(markerIDs, count: markerIDs.count)
        if let arch, !["upper", "lower"].contains(arch) {
            throw LabError.message("Üst veya alt çeneyi seçin.")
        }
        let code = assignments.first?.componentCode ?? "MG-MUASB9"
        if let arch { self.arch = arch }
        assignments = markerIDs.map { ToothAssignment(markerID: $0, componentCode: code) }
    }
    /// Preserve each retained physical flag's FDI; a replacement starts unassigned.
    mutating func setMarkerIDs(_ ids: [Int]) throws {
        try Self.validateMarkerIDs(ids, count: ids.count)
        let code = assignments.first?.componentCode ?? "MG-MUASB9"
        assignments = ids.map { id in
            assignments.first(where: { $0.markerID == id }) ?? ToothAssignment(markerID: id, componentCode: code)
        }
    }
    static func validateMarkerIDs(_ ids: [Int], count: Int) throws {
        guard [4, 6].contains(count), ids.count == count, Set(ids).count == count,
              ids.allSatisfy({ (0...5).contains($0) }) else {
            throw LabError.message("0–5 arasından modeldeki dört veya altı farklı bayrak ID'sini seçin.")
        }
    }
    func validateMarkerSelection(count: Int) throws {
        try Self.validateMarkerIDs(markerIDs, count: count)
    }
    mutating func useComponent(_ code: String) {
        guard ["MG-MUASB9", "MG-MUASBU"].contains(code) else { return }
        for index in assignments.indices { assignments[index].componentCode = code }
    }
    static var vidaMUA9: Self { var plan = Self(); plan.useComponent("MG-MUASBU"); return plan }
    mutating func assign(_ tooth: Int, to marker: Int) {
        guard Self.teeth(arch: arch).contains(tooth),
              let selectedIndex = assignments.firstIndex(where: { $0.markerID == marker }) else { return }
        for index in assignments.indices where assignments[index].fdi == tooth { assignments[index].fdi = nil }
        assignments[selectedIndex].fdi = tooth
    }
    mutating func useExample(count: Int) {
        if (try? validateMarkerSelection(count: count)) != nil { try? reset(markerIDs: markerIDs) }
        else { reset(count: count) }
        guard [4, 6].contains(count), assignments.count == count else { return }
        let positions = count == 4 ? [46, 43, 33, 36] : [46, 44, 42, 32, 34, 36]
        for index in assignments.indices { assignments[index].fdi = arch == "lower" ? positions[index] : (positions[index] >= 40 ? positions[index] - 30 : positions[index] - 10) }
    }
    func validate(count: Int) throws {
        try validateMarkerSelection(count: count)
        guard ["upper", "lower"].contains(arch), assignments.count == count,
              assignments.allSatisfy({ $0.fdi != nil && Self.teeth(arch: arch).contains($0.fdi!) && ["MG-MUASB9", "MG-MUASBU"].contains($0.componentCode) }),
              Set(assignments.compactMap(\.fdi)).count == count else {
            throw LabError.message("FDI planında her bayrağı farklı bir dişe atayın. Model deneyi için Örnek plan düğmesini kullanabilirsiniz.")
        }
    }
    func tooth(for marker: Int) -> Int? { assignments.first { $0.markerID == marker }?.fdi }
}

/// A preview is advisory. Only a new, committed, accepted frame produces a cue.
struct AcceptanceCue {
    private var played = Set<String>()
    mutating func consume(sample: String, preview: Bool, usable: Bool) -> Bool {
        guard !preview, usable else { return false }
        return played.insert(sample).inserted
    }
}

/// Completion is tied to unique IDs in this session, not the number of frames.
struct FlagConfirmationCue {
    private var confirmed = Set<Int>()
    mutating func restore(_ ids: [Int]) { confirmed.formUnion(ids) }
    mutating func consume(_ feedback: LiveFeedback) -> [Int] {
        guard !feedback.preview, feedback.usable else { return [] }
        let added = Set(feedback.completedIDs).subtracting(confirmed)
        confirmed.formUnion(added)
        return added.sorted()
    }
}
