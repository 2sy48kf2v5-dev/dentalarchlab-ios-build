import Foundation

struct ToothAssignment: Codable, Equatable, Identifiable {
    var markerID: Int
    var fdi: Int?
    var componentCode = "MG-MUASB9"
    var id: Int { markerID }
    enum CodingKeys: String, CodingKey { case markerID = "marker_id", fdi, componentCode = "component_code" }
}

struct DentalPlan: Codable, Equatable {
    var arch = "lower"
    var assignments: [ToothAssignment] = (0..<6).map { ToothAssignment(markerID: $0) }
    static func teeth(arch: String) -> [Int] {
        arch == "upper" ? Array(stride(from: 18, through: 11, by: -1)) + Array(21...28)
                        : Array(stride(from: 48, through: 41, by: -1)) + Array(31...38)
    }
    mutating func reset(count: Int, arch: String? = nil) {
        if let arch { self.arch = arch }
        assignments = (0..<count).map { ToothAssignment(markerID: $0) }
    }
    mutating func assign(_ tooth: Int, to marker: Int) {
        guard Self.teeth(arch: arch).contains(tooth), assignments.indices.contains(marker) else { return }
        for index in assignments.indices where assignments[index].fdi == tooth { assignments[index].fdi = nil }
        assignments[marker].fdi = tooth
    }
    mutating func useExample(count: Int) {
        reset(count: count)
        let positions = count == 4 ? [46, 43, 33, 36] : [46, 44, 42, 32, 34, 36]
        for index in assignments.indices { assignments[index].fdi = arch == "lower" ? positions[index] : (positions[index] >= 40 ? positions[index] - 30 : positions[index] - 10) }
    }
    func validate(count: Int) throws {
        guard ["upper", "lower"].contains(arch), assignments.count == count,
              Set(assignments.map(\.markerID)) == Set(0..<count),
              assignments.allSatisfy({ $0.fdi != nil && Self.teeth(arch: arch).contains($0.fdi!) && $0.componentCode == "MG-MUASB9" }),
              Set(assignments.compactMap(\.fdi)).count == count else {
            throw LabError.message("FDI planında her bayrağı farklı bir dişe atayın. Model deneyi için Örnek plan düğmesini kullanabilirsiniz.")
        }
    }
    func tooth(for marker: Int) -> Int? { assignments.first { $0.markerID == marker }?.fdi }
}

/// A preview is advisory. Only a new, committed, accepted frame produces a cue.
struct AcceptanceCue {
    private var played = Set<String>()
    mutating func consume(sample: String, preview: Bool, usable: Bool) -> Bool {
        guard !preview, usable else { return false }
        return played.insert(sample).inserted
    }
}

/// Completion is tied to unique IDs in this session, not the number of frames.
struct FlagConfirmationCue {
    private var confirmed = Set<Int>()
    mutating func restore(_ ids: [Int]) { confirmed.formUnion(ids) }
    mutating func consume(_ feedback: LiveFeedback) -> [Int] {
        guard !feedback.preview, feedback.usable else { return [] }
        let added = Set(feedback.completedIDs).subtracting(confirmed)
        confirmed.formUnion(added)
        return added.sorted()
    }
}
