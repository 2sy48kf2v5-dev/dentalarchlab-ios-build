import AVFoundation
import Foundation

enum ScanSoundEvent: Equatable {
    case sampleAccepted
    case flagConfirmed
    case completed
    case test
}

@MainActor protocol ScanAudioFeedbackControlling: AnyObject {
    /// Returns an actionable warning if sound cannot play. A cadence-suppressed
    /// sample is normal, so it returns nil. This does not confirm measurement accuracy.
    func play(_ event: ScanSoundEvent) -> String?
    func stop()
}

struct ScanSoundStyle: Equatable {
    let volume: Float
    let rate: Float
    let repetitions: Int

    static func forEvent(_ event: ScanSoundEvent) -> Self {
        switch event {
        case .sampleAccepted: return Self(volume: 0.35, rate: 1.25, repetitions: 0)
        case .flagConfirmed, .test: return Self(volume: 0.9, rate: 1, repetitions: 0)
        case .completed: return Self(volume: 1, rate: 1.15, repetitions: 1)
        }
    }
}

/// A narrow hardware boundary keeps cadence, failures and cleanup testable
/// without activating a simulator/device audio session in unit tests.
@MainActor protocol ScanAudioOutput: AnyObject {
    var outputVolume: Float { get }
    func activate() throws
    func prepare(style: ScanSoundStyle) throws -> Bool
    func play() -> Bool
    func stop()
    func deactivate() throws
}

@MainActor final class ScanAudioFeedback: ScanAudioFeedbackControlling {
    private let output: any ScanAudioOutput
    private let now: () -> TimeInterval
    private var active = false
    private var nextSampleTime: TimeInterval?
    private(set) var lastWarning: String?
    static let sampleInterval: TimeInterval = 0.75

    convenience init() {
        self.init(output: AppleScanAudioOutput())
    }

    init(output: any ScanAudioOutput, now: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime }) {
        self.output = output
        self.now = now
    }

    func play(_ event: ScanSoundEvent) -> String? {
        let time = now()
        // Confirmations always take priority over an immediately preceding tick.
        // Conversely a following sample cannot cut off the confirmation chime.
        if event == .sampleAccepted, let deadline = nextSampleTime, time < deadline {
            return lastWarning
        }
        do {
            if !active {
                try output.activate()
                active = true
            }
            guard output.outputVolume > 0 else {
                return fail("Telefonun medya sesi kapalı. Ses açma düğmesiyle sesi yükseltip Ses dene'ye dokunun.")
            }
            guard try output.prepare(style: ScanSoundStyle.forEvent(event)) else {
                return fail("Tarama sesi hazırlanamadı. Ses dene'ye dokunarak yeniden deneyin.")
            }
            guard output.play() else {
                return fail("Tarama sesi başlatılamadı. Ses çıkışını kontrol edip Ses dene'ye dokunun.")
            }
            nextSampleTime = time + Self.sampleInterval
            lastWarning = nil
            return nil
        } catch {
            return fail("Tarama sesi açılamadı: \(error.localizedDescription)")
        }
    }

    func stop() {
        output.stop()
        nextSampleTime = nil
        guard active else { return }
        do {
            try output.deactivate()
            active = false
        } catch {
            // The player is already stopped. Retain the failure and retry
            // deactivation on the next stop instead of pretending it succeeded.
            lastWarning = "Ses oturumu kapatılamadı: \(error.localizedDescription)"
        }
    }

    private func fail(_ message: String) -> String {
        stop()
        lastWarning = message
        return message
    }
}

@MainActor private final class AppleScanAudioOutput: ScanAudioOutput {
    private let session = AVAudioSession.sharedInstance()
    private var player: AVAudioPlayer?
    var outputVolume: Float { session.outputVolume }

    func activate() throws {
        // Explicit user-enabled scan feedback also works with the Silent switch.
        // Other audio keeps playing; no microphone or system-volume change is used.
        try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try session.setActive(true)
    }

    func prepare(style: ScanSoundStyle) throws -> Bool {
        if player == nil {
            guard let url = Bundle.main.url(forResource: "ScanAccepted", withExtension: "wav") else {
                throw NSError(domain: "DentalArchLab.ScanAudio", code: 1,
                    userInfo: [NSLocalizedDescriptionKey: "Tarama ses dosyası uygulamada bulunamadı."])
            }
            player = try AVAudioPlayer(contentsOf: url)
        }
        guard let player else { return false }
        player.stop()
        player.currentTime = 0
        player.enableRate = true
        player.rate = style.rate
        player.volume = style.volume
        player.numberOfLoops = style.repetitions
        return player.prepareToPlay()
    }

    func play() -> Bool { player?.play() ?? false }
    func stop() { player?.stop() }
    func deactivate() throws {
        try session.setActive(false, options: [.notifyOthersOnDeactivation])
    }
}
