import SwiftUI
import SceneKit
import UniformTypeIdentifiers

@MainActor final class TissueAlignmentModel: ObservableObject {
    @Published private(set) var state: TissueWorkspaceState?
    @Published private(set) var busy = false
    @Published private(set) var message = "Tarama dosyasını içe aktarın."
    @Published private(set) var error: String?
    @Published var selectedTargetID = ""
    @Published var pendingPoint: LabPoint?
    @Published var checkOnly = false
    @Published var selecting = false
    @Published var showAligned = false
    @Published var millimetersConfirmed = false
    @Published var projectName = "DentalArchLab"
    @Published private(set) var sceneRevision = UUID()
    private let workspace: TissueWorkspace

    init(session: String, repository: CaptureRepository) {
        workspace = TissueWorkspace(repository: repository, session: session)
    }
    var selectedTarget: TissueTarget? { state?.targets.first { $0.id == selectedTargetID } }
    var fitCount: Int { state?.pairs.filter { !$0.checkOnly }.count ?? 0 }
    var checkCount: Int { state?.pairs.filter(\.checkOnly).count ?? 0 }
    var fitMarkerCount: Int {
        guard let state else { return 0 }
        let ids = Set(state.pairs.filter { !$0.checkOnly }.map(\.targetID))
        return Set(state.targets.filter { ids.contains($0.id) }.map(\.markerID)).count
    }
    var canAlign: Bool { !busy && fitCount >= 3 && fitMarkerCount >= 2 }
    var displayMesh: TissueMesh? { showAligned ? state?.alignedMesh : state?.mesh }
    var sceneKey: String { "\(sceneRevision.uuidString)-\(showAligned)" }

    func load() {
        perform {
            self.apply(try await self.workspace.load(), geometryChanged: true)
            self.message = self.state?.mesh == nil ? "Önce STL veya renkli PLY dosyasını seçin." : "Kaydedilmiş eşleştirmeler yüklendi."
        }
    }
    func importMesh(_ url: URL) {
        guard millimetersConfirmed else { error = "İçe aktarılan dosyanın birimi mm olmalı."; return }
        perform {
            let data = try await Task.detached(priority: .userInitiated) { try Self.readFile(url) }.value
            self.apply(try await self.workspace.importMesh(data: data, name: url.lastPathComponent), geometryChanged: true)
            self.showAligned = false; self.selecting = false; self.pendingPoint = nil
            self.message = "Dosya yüklendi. Aynı rijit bayrak noktalarını eşleştirin."
        }
    }
    func importLibrary(_ url: URL) {
        perform {
            let data = try await Task.detached(priority: .userInitiated) { try Self.readFile(url) }.value
            self.apply(try await self.workspace.importLibrary(data: data))
            self.message = "Kütüphane bağlantı tanımı kontrol edildi."
        }
    }
    func chooseTarget() {
        pendingPoint = nil
        checkOnly = state?.pairs.first { $0.targetID == selectedTargetID }?.checkOnly ?? false
    }
    func choosePoint(_ point: LabPoint) {
        guard !busy, selecting, !showAligned, selectedTarget != nil else { return }
        pendingPoint = point
        message = "Seçilen yüzey noktasını kontrol edip eşleştirmeyi kaydedin."
    }
    func savePoint() {
        guard let point = pendingPoint, let target = selectedTarget else { return }
        let checkpoint = checkOnly
        perform {
            self.apply(try await self.workspace.setPair(targetID: target.id, source: point, checkOnly: checkpoint))
            self.pendingPoint = nil
            self.message = checkpoint ? "Bağımsız kontrol noktası kaydedildi; uyum hesabına katılmaz." : "Rijit nokta eşleştirmesi kaydedildi."
        }
    }
    func remove(_ selection: TissueSelection) {
        perform {
            self.apply(try await self.workspace.removePair(targetID: selection.targetID))
            self.showAligned = false; self.message = "Eşleştirme kaldırıldı; uyumu yeniden hesaplayın."
        }
    }
    func changeRole(_ selection: TissueSelection) {
        perform {
            self.apply(try await self.workspace.setPair(targetID: selection.targetID, source: selection.source,
                                                       checkOnly: !selection.checkOnly))
            self.showAligned = false; self.message = "Noktanın görevi değişti; uyumu yeniden hesaplayın."
        }
    }
    func align() {
        guard canAlign else { return }
        perform {
            self.apply(try await self.workspace.align(), geometryChanged: true)
            self.selecting = false; self.showAligned = true; self.pendingPoint = nil
            self.message = "Rijit hizalama hesaplandı. Bağımsız kontrol noktasını ve yüzeyleri inceleyin."
        }
    }
    func export() {
        let name = projectName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { error = "Exocad proje adını yazın."; return }
        perform {
            _ = try await self.workspace.export(projectName: name)
            self.apply(try await self.workspace.load())
            self.message = "Hazırlanan dosyalar aşağıdan paylaşılabilir."
        }
    }
    func reportImport(_ failure: Error) { error = failure.localizedDescription }
    private func apply(_ updated: TissueWorkspaceState, geometryChanged: Bool = false) {
        state = updated
        if !updated.targets.contains(where: { $0.id == selectedTargetID }) { selectedTargetID = updated.targets.first?.id ?? "" }
        if updated.registration == nil { showAligned = false }
        if geometryChanged { sceneRevision = UUID() }
    }
    private func perform(_ operation: @escaping @MainActor () async throws -> Void) {
        guard !busy else { return }
        busy = true; error = nil
        Task {
            defer { busy = false }
            do { try await operation() }
            catch { self.error = error.localizedDescription }
        }
    }
    private nonisolated static func readFile(_ url: URL) throws -> Data {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
        guard values.isRegularFile == true, let size = values.fileSize, size > 0, size <= 64 * 1024 * 1024 else {
            throw LabError.message("En fazla 64 MB boyutunda tek bir dosya seçin.")
        }
        return try Data(contentsOf: url)
    }
}

struct TissueAlignmentView: View {
    @StateObject private var model: TissueAlignmentModel
    @State private var importingMesh = false
    @State private var importingLibrary = false
    @State private var resetView = 0

    init(session: String, repository: CaptureRepository) {
        _model = StateObject(wrappedValue: TissueAlignmentModel(session: session, repository: repository))
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Ağız içi yüzeyi 3B bayrak kaydına hizala").font(.title2.bold())
                Text("Aynı taramada görülen rijit noktaları eşleştir. Diş eti gibi hareketli yüzeyleri referans seçme.")
                    .font(.callout).foregroundStyle(.secondary)
                importPanel
                if let mesh = model.displayMesh, let state = model.state {
                    scenePanel(mesh: mesh, state: state)
                    selectionPanel(state: state)
                    pairsPanel(state: state)
                    alignmentPanel(state: state)
                    exportPanel(state: state)
                }
                if model.busy { ProgressView("Dosya ve geometri işleniyor…").accessibilityIdentifier("tissueBusy") }
                Text(model.message).font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("tissueStatus")
                if let error = model.error {
                    Label(error, systemImage: "exclamationmark.triangle").font(.callout).foregroundStyle(.orange)
                        .accessibilityIdentifier("tissueError")
                }
            }.padding(18)
        }.accessibilityIdentifier("tissueScroll")
            .navigationTitle("Yüzey eşleştirme").navigationBarTitleDisplayMode(.inline)
            .task { model.load() }
    }
    private var importPanel: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("1 · Yüzey dosyası").font(.headline)
            Toggle("Dosya biriminin mm olduğunu doğruladım", isOn: $model.millimetersConfirmed)
                .font(.caption).accessibilityIdentifier("tissueMillimetersConfirmed")
            Button { importingMesh = true } label: { Label("STL / renkli PLY / OBJ seç", systemImage: "square.and.arrow.down") }
                .buttonStyle(.borderedProminent).disabled(model.busy || !model.millimetersConfirmed)
                .accessibilityIdentifier("importTissueMesh")
                .fileImporter(isPresented: $importingMesh,
                              allowedContentTypes: [UTType(filenameExtension: "stl") ?? .data,
                                                    UTType(filenameExtension: "ply") ?? .data,
                                                    UTType(filenameExtension: "obj") ?? .data]) { result in
                    switch result {
                    case .success(let url): model.importMesh(url)
                    case .failure(let error): model.reportImport(error)
                    }
                }
            if let name = model.state?.meshFilename {
                Text(name).font(.caption).textSelection(.enabled)
                Text("Yeni yüzey seçmek bu yüzeyin nokta eşleştirmelerini sıfırlar.").font(.caption).foregroundStyle(.secondary)
            }
            Text("Renkli PLY, bayrağın beyaz noktalarını seçmeyi kolaylaştırır. STL renk içermez; aynı nokta merkezini geometride açıkça göremiyorsan eşleştirme yapma.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func scenePanel(mesh: TissueMesh, state: TissueWorkspaceState) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("Görünüm", selection: $model.showAligned) {
                Text("Özgün yüzey").tag(false)
                Text("Hizalanmış").tag(true)
            }.pickerStyle(.segmented).disabled(model.busy || state.alignedMesh == nil)
                .onChange(of: model.showAligned) { _, aligned in if aligned { model.selecting = false; model.pendingPoint = nil } }
                .accessibilityIdentifier("tissueCoordinateView")
            TissueMeshScene(mesh: mesh, revision: model.sceneKey, resetToken: resetView,
                selecting: model.selecting && !model.showAligned && !model.busy,
                selected: model.pendingPoint, pairs: state.pairs,
                transform: model.showAligned ? state.registration?.transform : nil,
                targets: model.showAligned ? state.targets : [],
                landmarks: model.showAligned ? state.landmarks : [], onPick: model.choosePoint)
                .frame(height: 370).clipShape(RoundedRectangle(cornerRadius: 16))
            HStack {
                Picker("Etkileşim", selection: $model.selecting) {
                    Text("Döndür / yakınlaştır").tag(false)
                    Text("Nokta seç").tag(true)
                }.pickerStyle(.segmented).disabled(model.busy || model.showAligned)
                    .accessibilityIdentifier("tissueInteractionMode")
                Button { resetView += 1 } label: { Image(systemName: "arrow.counterclockwise") }
                    .accessibilityLabel("Yüzey görünümünü sıfırla")
            }
            Text(model.showAligned ? "Yüzey fotogrametri koordinatında. Küçük mavi işaretler gerçek bayrak noktalarıdır; gövdeler üretici CAD'i değildir."
                 : model.selecting ? "Önce hedefi seç; sonra özgün yüzeyde aynı rijit noktaya dokun. Döndürmek için inceleme moduna geç."
                 : "Tek parmakla döndür, iki parmakla yakınlaştır. Nokta seçmek için modu değiştir.")
                .font(.caption).foregroundStyle(.secondary)
        }
    }
    private func selectionPanel(state: TissueWorkspaceState) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("2 · Aynı noktayı eşleştir").font(.headline)
            Picker("Fotogrametri hedefi", selection: $model.selectedTargetID) {
                ForEach(state.targets, id: \.id) { target in Text(target.label).tag(target.id) }
            }.pickerStyle(.menu).accessibilityIdentifier("tissueTargetPicker")
                .onChange(of: model.selectedTargetID) { _, _ in model.chooseTarget() }
            if let target = model.selectedTarget {
                TissueTargetDiagram(targets: state.targets.filter { $0.markerID == target.markerID }, selectedID: target.id)
                    .frame(height: 155).background(Color.secondary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12))
                    .accessibilityElement(children: .ignore)
                    .accessibilityLabel("\(target.label) seçili. Diyagram, bu bayrağın ölçülen dört noktasını kendi düzleminde gösterir.")
                    .accessibilityIdentifier("tissueTargetDiagram")
            }
            Toggle("Bağımsız kontrol noktası · uyuma katma", isOn: $model.checkOnly).font(.caption)
                .accessibilityIdentifier("tissueCheckpointToggle")
            if let point = model.pendingPoint {
                Text(String(format: "Seçilen yüzey: X %.3f  Y %.3f  Z %.3f mm", point.x, point.y, point.z))
                    .font(.caption.monospacedDigit()).accessibilityIdentifier("tissueSelectedPoint")
            }
            Button(action: model.savePoint) {
                Label(state.pairs.contains(where: { $0.targetID == model.selectedTargetID }) ? "Eşleştirmeyi güncelle" : "Eşleştirmeyi kaydet",
                      systemImage: "pin")
            }.buttonStyle(.bordered).disabled(model.busy || model.pendingPoint == nil || model.showAligned)
                .accessibilityIdentifier("saveTissuePoint")
            Text("A–D, her bayrağın gerçek nokta sırasıdır. Aynı bayraktaki noktaları karıştırma. En az iki ayrı bayraktan birbirinden uzak üç nokta ve ayrıca bir bağımsız kontrol noktası seç.")
                .font(.caption).foregroundStyle(.secondary)
        }.disabled(model.busy)
    }
    private func pairsPanel(state: TissueWorkspaceState) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("\(model.fitCount) uyum · \(model.checkCount) kontrol · \(model.fitMarkerCount) bayrak")
                .font(.subheadline.bold()).accessibilityIdentifier("tissuePairCounts")
            ForEach(state.pairs, id: \.targetID) { pair in
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(state.targets.first(where: { $0.id == pair.targetID })?.label ?? pair.targetID).font(.caption.bold())
                        Text(pair.checkOnly ? "Bağımsız kontrol" : "Uyum noktası").font(.caption2).foregroundStyle(.secondary)
                        if let error = state.checkpointErrors[pair.targetID] {
                            Text(String(format: "Kontrol farkı %.3f mm", error)).font(.caption.monospacedDigit())
                        }
                    }
                    Spacer()
                    Menu {
                        Button(pair.checkOnly ? "Uyum hesabına kat" : "Bağımsız kontrol yap") { model.changeRole(pair) }
                        Button("Eşleştirmeyi kaldır", role: .destructive) { model.remove(pair) }
                    } label: { Image(systemName: "ellipsis.circle").frame(width: 44, height: 38) }
                        .disabled(model.busy).accessibilityLabel("\(pair.targetID) eşleştirmesini düzenle")
                }
            }
        }
    }
    private func alignmentPanel(state: TissueWorkspaceState) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Button(action: model.align) { Label("Rijit hizalamayı hesapla", systemImage: "move.3d") }
                .buttonStyle(.borderedProminent).disabled(!model.canAlign).accessibilityIdentifier("alignTissue")
            Text("Ölçek değiştirilmez; yalnız dönme ve öteleme hesaplanır. Kontrol noktaları hesaba katılmaz.")
                .font(.caption).foregroundStyle(.secondary)
            if let registration = state.registration {
                metric("Eşleştirme RMS", value: registration.rmsMM, identifier: "tissueAlignmentRMS")
                metric("En büyük eşleştirme farkı", value: registration.maxMM, identifier: "tissueAlignmentMax")
                if let check = state.checkRMSMM {
                    metric("Bağımsız kontrol RMS", value: check, identifier: "tissueCheckpointRMS")
                } else { Label("Bağımsız kontrol noktası henüz yok", systemImage: "exclamationmark.circle").foregroundStyle(.orange) }
                Text("Bu değerler seçtiğin noktaların uyum farkıdır; implant doğruluğu veya klinik kabul sınırı değildir.")
                    .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("tissueResidualScope")
            }
        }
    }
    private func metric(_ title: String, value: Double, identifier: String) -> some View {
        let formatted = String(format: "%.3f mm", value)
        return LabeledContent(title, value: formatted)
            .accessibilityElement(children: .ignore).accessibilityLabel(title)
            .accessibilityValue(formatted).accessibilityIdentifier(identifier)
    }
    private func exportPanel(state: TissueWorkspaceState) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("3 · Exocad aktarım dosyaları").font(.headline)
            TextField("Exocad proje dosyasının adı", text: $model.projectName)
                .textFieldStyle(.roundedBorder).textInputAutocapitalization(.never).autocorrectionDisabled()
                .accessibilityIdentifier("tissueProjectName")
            Text("Exocad'deki proje adıyla aynı kök adı kullan. Hazırlanan yüzey STL'si ve koordinat raporu ayrı dosyalardır.")
                .font(.caption).foregroundStyle(.secondary)
            Button { importingLibrary = true } label: { Label("Kütüphane bağlantı JSON'unu seç", systemImage: "shippingbox") }
                .buttonStyle(.bordered).disabled(model.busy).accessibilityIdentifier("importTissueLibrary")
                .fileImporter(isPresented: $importingLibrary, allowedContentTypes: [.json]) { result in
                    switch result {
                    case .success(let url): model.importLibrary(url)
                    case .failure(let error): model.reportImport(error)
                    }
                }
            if let name = state.libraryName { Text(name).font(.caption.bold()) }
            ForEach(Array(state.blockers.enumerated()), id: \.offset) { _, blocker in
                Label(blocker, systemImage: "exclamationmark.circle").font(.caption).foregroundStyle(.orange)
            }
            Text("MegaGen ST adı tek başına kütüphane eşleşmesi değildir. İmplant konum dosyası için doğru resmî kütüphane kimlikleri, ölçülmüş bağlantı dönüşümü ve bağımsız kontrol gerekir. Yüzey aktarımı ayrı hazırlanabilir.")
                .font(.caption).foregroundStyle(.secondary)
            Button(action: model.export) { Label("Hazır dosyaları oluştur", systemImage: "doc.badge.gearshape") }
                .buttonStyle(.borderedProminent).disabled(model.busy || state.registration == nil)
                .accessibilityIdentifier("exportAlignedTissue")
            if !state.files.isEmpty {
                ShareLink(items: state.files) { Label("Dosyaları paylaş", systemImage: "square.and.arrow.up") }
                    .buttonStyle(.bordered).accessibilityIdentifier("shareAlignedTissue")
                ForEach(state.files, id: \.self) { Text($0.lastPathComponent).font(.caption.monospaced()).accessibilityIdentifier("tissueFile_" + $0.lastPathComponent) }
            }
        }
    }
}

/// The reference uses measured target positions projected into their own plane.
/// It labels the inner dot as D; it does not turn four dots into four corners.
private struct TissueTargetDiagram: View {
    let targets: [TissueTarget]
    let selectedID: String
    var body: some View {
        Canvas { context, size in
            guard targets.count == 4 else { return }
            let origin = targets[0].point
            let ab = targets[1].point - origin, ac = targets[2].point - origin
            guard ab.length > 0 else { return }
            let xAxis = ab * (1 / ab.length)
            let normal = LabPoint(x: ab.y*ac.z-ab.z*ac.y, y: ab.z*ac.x-ab.x*ac.z, z: ab.x*ac.y-ab.y*ac.x)
            guard normal.length > 0 else { return }
            let n = normal * (1 / normal.length)
            let yAxis = LabPoint(x: n.y*xAxis.z-n.z*xAxis.y, y: n.z*xAxis.x-n.x*xAxis.z, z: n.x*xAxis.y-n.y*xAxis.x)
            var planar: [(Double, Double)] = []
            for target in targets {
                let delta = target.point - origin
                planar.append((delta.x*xAxis.x + delta.y*xAxis.y + delta.z*xAxis.z,
                               delta.x*yAxis.x + delta.y*yAxis.y + delta.z*yAxis.z))
            }
            let lowX = planar.map { $0.0 }.min() ?? 0, highX = planar.map { $0.0 }.max() ?? 1
            let lowY = planar.map { $0.1 }.min() ?? 0, highY = planar.map { $0.1 }.max() ?? 1
            let scale = min((Double(size.width)-72)/max(highX-lowX, 0.001), (Double(size.height)-58)/max(highY-lowY, 0.001))
            for index in targets.indices {
                let x = Double(size.width)/2 + (planar[index].0-(lowX+highX)/2)*scale
                let y = Double(size.height)/2 - (planar[index].1-(lowY+highY)/2)*scale
                let selected = targets[index].id == selectedID
                let color: Color = selected ? .pink : .primary
                let dot = Path(ellipseIn: CGRect(x: x-5, y: y-5, width: 10, height: 10))
                context.fill(dot, with: .color(color))
                if selected {
                    context.stroke(Path(ellipseIn: CGRect(x: x-9, y: y-9, width: 18, height: 18)), with: .color(color), lineWidth: 2)
                }
                context.draw(Text(["A", "B", "C", "D"][index]).font(.caption.bold()).foregroundStyle(color),
                             at: CGPoint(x: x+15, y: y-12))
            }
        }
    }
}

private struct TissueMeshScene: UIViewRepresentable {
    let mesh: TissueMesh
    let revision: String
    let resetToken: Int
    let selecting: Bool
    let selected: LabPoint?
    let pairs: [TissueSelection]
    let transform: [[Double]]?
    let targets: [TissueTarget]
    let landmarks: [ResultLandmark]
    let onPick: (LabPoint) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.backgroundColor = UIColor(red: 0.025, green: 0.045, blue: 0.065, alpha: 1)
        view.scene = SCNScene(); view.autoenablesDefaultLighting = true
        view.antialiasingMode = .multisampling2X
        view.preferredFramesPerSecond = 30
        view.isPlaying = false
        // Expose the actual interactive UIKit surface, not a non-hittable
        // SwiftUI wrapper. VoiceOver announces readiness and direct interaction.
        view.isUserInteractionEnabled = true
        view.isAccessibilityElement = true
        view.accessibilityIdentifier = "tissueMeshScene"
        view.accessibilityLabel = "Ağız içi 3B yüzey"
        view.accessibilityTraits = [.allowsDirectInteraction]
        view.accessibilityValue = "Geometri hazırlanıyor"
        let tap = UITapGestureRecognizer(target: context.coordinator, action: #selector(Coordinator.pick(_:)))
        tap.cancelsTouchesInView = true; view.addGestureRecognizer(tap)
        context.coordinator.tap = tap
        context.coordinator.view = view
        return view
    }
    func updateUIView(_ view: SCNView, context: Context) {
        context.coordinator.parent = self
        view.allowsCameraControl = !selecting
        view.accessibilityHint = selecting ? "Aynı rijit yüzey noktasını seçmek için dokun."
            : "Yüzeyi döndürmek için sürükle; yakınlaştırmak için iki parmağını kullan."
        context.coordinator.tap?.isEnabled = selecting
        context.coordinator.update()
    }
    final class Coordinator: NSObject {
        var parent: TissueMeshScene
        weak var view: SCNView?
        weak var tap: UITapGestureRecognizer?
        private var meshNode: SCNNode?
        private let indicators = SCNNode()
        private var requestedRevision = ""
        private var appliedRevision = ""
        private var appliedReset = -1
        private var center = SCNVector3Zero
        private var radius: Float = 30
        init(_ parent: TissueMeshScene) { self.parent = parent }
        func update() {
            guard let view else { return }
            if requestedRevision != parent.revision {
                requestedRevision = parent.revision
                view.accessibilityValue = "Geometri hazırlanıyor"
                let revision = parent.revision, mesh = parent.mesh
                DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                    let built = Self.geometry(mesh)
                    DispatchQueue.main.async {
                        guard let self, self.requestedRevision == revision, let view = self.view else { return }
                        self.meshNode?.removeFromParentNode()
                        let node = SCNNode(geometry: built.geometry); node.name = "tissue-surface"
                        self.meshNode = node; view.scene?.rootNode.addChildNode(node)
                        self.appliedRevision = revision
                        view.accessibilityValue = "\(mesh.colors == nil ? "Yüzey" : "Renkli yüzey") hazır · \(mesh.vertices.count) köşe · \(mesh.triangles.count) üçgen"
                        self.center = built.center; self.radius = built.radius
                        if self.indicators.parent == nil { view.scene?.rootNode.addChildNode(self.indicators) }
                        self.refreshIndicators(); self.resetCamera()
                    }
                }
            }
            refreshIndicators()
            if appliedReset != parent.resetToken { appliedReset = parent.resetToken; resetCamera() }
            view.setNeedsDisplay()
        }
        @objc func pick(_ recognizer: UITapGestureRecognizer) {
            // A previous surface may still be visible while the replacement
            // geometry is built. It must never supply a point for the new mesh.
            guard parent.selecting, appliedRevision == parent.revision, let view, let meshNode else { return }
            let hits = view.hitTest(recognizer.location(in: view), options: [
                SCNHitTestOption.rootNode: meshNode,
                SCNHitTestOption.searchMode: SCNHitTestSearchMode.closest.rawValue,
                SCNHitTestOption.backFaceCulling: false
            ])
            guard let hit = hits.first(where: { $0.node === meshNode }) else { return }
            let point = hit.localCoordinates
            parent.onPick(LabPoint(x: Double(point.x), y: Double(point.y), z: Double(point.z)))
        }
        private func resetCamera() {
            guard let view else { return }
            let camera = view.pointOfView ?? SCNNode()
            if camera.camera == nil { camera.camera = SCNCamera() }
            camera.camera?.zNear = 0.01; camera.camera?.zFar = Double(max(10000, radius * 100))
            camera.position = SCNVector3(center.x, center.y - radius * 0.7, center.z + radius * 3.2)
            camera.look(at: center)
            if camera.parent == nil { view.scene?.rootNode.addChildNode(camera) }
            view.pointOfView = camera; view.defaultCameraController.target = center
            view.defaultCameraController.inertiaEnabled = true
        }
        private func refreshIndicators() {
            indicators.childNodes.forEach { $0.removeFromParentNode() }
            let dotRadius = CGFloat(max(0.12, min(0.4, radius * 0.006)))
            for pair in parent.pairs {
                addDot(Self.transformed(pair.source, by: parent.transform), radius: dotRadius,
                       color: pair.checkOnly ? .systemYellow : .systemCyan)
            }
            if let selected = parent.selected { addDot(selected, radius: dotRadius * 1.3, color: .systemPink) }
            for target in parent.targets { addDot(target.point, radius: dotRadius * 0.7, color: .systemBlue) }
            for landmark in parent.landmarks {
                addDot(landmark.center, radius: dotRadius * 1.3, color: landmark.isMUA ? .systemTeal : .systemOrange)
                let endpoint = landmark.center + landmark.axis * 4
                addLine(landmark.center, endpoint, color: landmark.isMUA ? .systemTeal : .systemOrange)
            }
        }
        private func addDot(_ point: LabPoint, radius: CGFloat, color: UIColor) {
            let sphere = SCNSphere(radius: radius); sphere.segmentCount = 8
            sphere.firstMaterial?.diffuse.contents = color
            let node = SCNNode(geometry: sphere)
            node.position = SCNVector3(Float(point.x), Float(point.y), Float(point.z)); indicators.addChildNode(node)
        }
        private func addLine(_ start: LabPoint, _ end: LabPoint, color: UIColor) {
            let vertices = [SCNVector3(Float(start.x), Float(start.y), Float(start.z)), SCNVector3(Float(end.x), Float(end.y), Float(end.z))]
            let indices: [UInt32] = [0, 1]
            let data = indices.withUnsafeBufferPointer { Data(buffer: $0) }
            let element = SCNGeometryElement(data: data, primitiveType: .line, primitiveCount: 1, bytesPerIndex: 4)
            let geometry = SCNGeometry(sources: [SCNGeometrySource(vertices: vertices)], elements: [element])
            geometry.firstMaterial?.diffuse.contents = color
            indicators.addChildNode(SCNNode(geometry: geometry))
        }
        private static func transformed(_ point: LabPoint, by matrix: [[Double]]?) -> LabPoint {
            guard let t = matrix, t.count == 4, t.allSatisfy({ $0.count == 4 }) else { return point }
            return LabPoint(x: t[0][0]*point.x + t[0][1]*point.y + t[0][2]*point.z + t[0][3],
                            y: t[1][0]*point.x + t[1][1]*point.y + t[1][2]*point.z + t[1][3],
                            z: t[2][0]*point.x + t[2][1]*point.y + t[2][2]*point.z + t[2][3])
        }
        private static func geometry(_ mesh: TissueMesh) -> (geometry: SCNGeometry, center: SCNVector3, radius: Float) {
            let vertices = mesh.vertices.map { SCNVector3(Float($0.x), Float($0.y), Float($0.z)) }
            var normals = Array(repeating: SCNVector3Zero, count: vertices.count)
            var indices: [UInt32] = []; indices.reserveCapacity(mesh.triangles.count * 3)
            for face in mesh.triangles where face.count == 3 && face.allSatisfy({ $0 >= 0 && $0 < vertices.count }) {
                let a = vertices[face[0]], b = vertices[face[1]], c = vertices[face[2]]
                let u = SCNVector3(b.x-a.x, b.y-a.y, b.z-a.z), v = SCNVector3(c.x-a.x, c.y-a.y, c.z-a.z)
                let n = SCNVector3(u.y*v.z-u.z*v.y, u.z*v.x-u.x*v.z, u.x*v.y-u.y*v.x)
                for index in face {
                    normals[index].x += n.x; normals[index].y += n.y; normals[index].z += n.z
                    indices.append(UInt32(index))
                }
            }
            for index in normals.indices {
                let n = normals[index], length = sqrt(n.x*n.x + n.y*n.y + n.z*n.z)
                if length > 0 { normals[index] = SCNVector3(n.x/length, n.y/length, n.z/length) }
            }
            var sources = [SCNGeometrySource(vertices: vertices), SCNGeometrySource(normals: normals)]
            if let colors = mesh.colors, colors.count == vertices.count,
               colors.allSatisfy({ $0.count == 3 || $0.count == 4 }) {
                var rgba: [Float] = []; rgba.reserveCapacity(colors.count * 4)
                for color in colors {
                    rgba.append(Float(color[0]) / 255); rgba.append(Float(color[1]) / 255); rgba.append(Float(color[2]) / 255)
                    rgba.append(color.count > 3 ? Float(color[3]) / 255 : 1)
                }
                let data = rgba.withUnsafeBufferPointer { Data(buffer: $0) }
                sources.append(SCNGeometrySource(data: data, semantic: .color, vectorCount: colors.count,
                    usesFloatComponents: true, componentsPerVector: 4, bytesPerComponent: 4, dataOffset: 0, dataStride: 16))
            }
            let data = indices.withUnsafeBufferPointer { Data(buffer: $0) }
            let element = SCNGeometryElement(data: data, primitiveType: .triangles, primitiveCount: indices.count/3, bytesPerIndex: 4)
            let geometry = SCNGeometry(sources: sources, elements: [element])
            let material = SCNMaterial(); material.isDoubleSided = true; material.lightingModel = .blinn
            material.diffuse.contents = mesh.colors == nil ? UIColor(red: 0.76, green: 0.52, blue: 0.52, alpha: 1) : UIColor.white
            geometry.materials = [material]
            let minimum = SCNVector3(vertices.map(\.x).min() ?? -1, vertices.map(\.y).min() ?? -1, vertices.map(\.z).min() ?? -1)
            let maximum = SCNVector3(vertices.map(\.x).max() ?? 1, vertices.map(\.y).max() ?? 1, vertices.map(\.z).max() ?? 1)
            let center = SCNVector3((minimum.x+maximum.x)/2, (minimum.y+maximum.y)/2, (minimum.z+maximum.z)/2)
            let dx = maximum.x-minimum.x, dy = maximum.y-minimum.y, dz = maximum.z-minimum.z
            return (geometry, center, max(1, sqrt(dx*dx+dy*dy+dz*dz)/2))
        }
    }
}

#if DEBUG
/// A native UI fixture uses the real workspace/parser/registration/export path.
/// Its temporary data and entry point are unavailable in a release build.
struct TissueAlignmentTestHost: View {
    @State private var prepared: TissueUITestFixture.Prepared?
    @State private var started = false
    @State private var failure: String?
    var body: some View {
        Group {
            if let prepared {
                TissueAlignmentView(session: prepared.session, repository: prepared.repository)
            } else if let failure { Text(failure).accessibilityIdentifier("tissueFixtureError") }
            else { ProgressView("Sentetik UI verisi hazırlanıyor…") }
        }.safeAreaInset(edge: .top) {
            Text("SENTETİK UI TESTİ · FİZİKSEL ÖLÇÜM DEĞİL")
                .font(.caption2.bold()).frame(maxWidth: .infinity).padding(8)
                .background(Color.orange.opacity(0.18)).accessibilityIdentifier("tissueSyntheticBanner")
        }.task {
            guard !started, ProcessInfo.processInfo.arguments.contains("--ui-testing"),
                  ProcessInfo.processInfo.arguments.contains("--ui-tissue-test") else { return }
            started = true
            do { prepared = try await Task.detached(priority: .userInitiated) { try await TissueUITestFixture.make() }.value }
            catch { failure = error.localizedDescription }
        }
    }
}

private enum TissueUITestFixture {
    struct Prepared { let session: String; let repository: CaptureRepository }
    static func make() async throws -> Prepared {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("TissueUITest-" + UUID().uuidString)
        let repository = CaptureRepository(root: root)
        let session = captureID(), file = try repository.resultURL(session)
        try FileManager.default.createDirectory(at: file.deletingLastPathComponent(), withIntermediateDirectories: true)
        let points: [[Double]] = [[-3,-3,0], [3,-3,0], [-3,3,0], [0,0,0]]
        let fdis = [16,14,12,22,24,26]
        let centers: [LabPoint] = (0..<6).map { index in
            let angle = Double(index) / 5 * .pi
            return LabPoint(x: cos(angle)*24, y: sin(angle)*26, z: 1)
        }
        let markers: [[String: Any]] = centers.enumerated().map { id, center in
            let matrix = [[1.0,0,0,center.x], [0,1,0,center.y], [0,0,1,center.z], [0,0,0,1]]
            return ["id": id, "fdi": fdis[id], "T_world_marker": matrix, "T_world_mua": NSNull()]
        }
        // mode=scan exercises the physical-session code path only in this
        // DEBUG fixture. The host keeps a synthetic banner on every screenshot.
        let result: [String: Any] = ["id": session, "mode": "scan", "state": "complete",
            "message": "Sentetik arayüz test verisi; kamera ölçümü değildir.", "ui_fixture_synthetic": true,
            "result": ["units": "mm", "status": "research_result", "missing_markers": [Int](),
                "markers": markers, "rig": ["dictionary": "DAL_DOTS4_V1",
                    "markers": (0..<6).map { ["id": $0, "points_mm": points] as [String: Any] }]]]
        try JSONSerialization.data(withJSONObject: result).write(to: file)
        let offset = LabPoint(x: 12, y: -7, z: 4)
        let workspace = TissueWorkspace(repository: repository, session: session)
        var state = try await workspace.importMesh(data: mesh(centers: centers, points: points, offset: offset),
                                                    name: "SYNTHETIC-colored-arch.ply")
        // Six distributed fitting points and a seventh withheld check are
        // generated in source coordinates with a known translation.
        let chosen = ["0:0", "1:1", "2:2", "3:0", "4:1", "5:2", "3:3"]
        for (index, id) in chosen.enumerated() {
            guard let target = state.targets.first(where: { $0.id == id }) else { throw LabError.message("Sentetik hedef eksik.") }
            state = try await workspace.setPair(targetID: id, source: target.point - offset, checkOnly: index == 6)
        }
        return Prepared(session: session, repository: repository)
    }
    private static func mesh(centers: [LabPoint], points: [[Double]], offset: LabPoint) -> Data {
        var vertices: [LabPoint] = [], colors: [[Int]] = [], faces: [[Int]] = []
        func vertex(_ point: LabPoint, _ color: [Int]) -> Int {
            let index = vertices.count; vertices.append(point - offset); colors.append(color); return index
        }
        func quad(_ points: [LabPoint], _ color: [Int]) {
            let indices = points.map { vertex($0, color) }
            faces.append([indices[0], indices[1], indices[2]])
            faces.append([indices[0], indices[2], indices[3]])
        }
        func gum(_ angle: Double, _ radius: Double) -> LabPoint {
            LabPoint(x: cos(angle)*radius, y: sin(angle)*(radius+2), z: -2.5 + cos((radius-24)/7)*1.2)
        }
        for section in 0..<40 {
            let a = Double(section)/40 * .pi, b = Double(section+1)/40 * .pi
            for band in 0..<6 {
                let r = 17 + Double(band)*2
                quad([gum(a,r), gum(b,r), gum(b,r+2), gum(a,r+2)], [195,105+band*5,120+band*3])
            }
        }
        for center in centers {
            quad([LabPoint(x:-4,y:-4,z:-0.08), LabPoint(x:4,y:-4,z:-0.08),
                  LabPoint(x:4,y:4,z:-0.08), LabPoint(x:-4,y:4,z:-0.08)].map { $0 + center }, [24,44,48])
            for point in points {
                let dot = center + LabPoint(x:point[0],y:point[1],z:point[2])
                let middle = vertex(dot, [245,245,238])
                let ring = (0..<16).map { index -> Int in
                    let angle = Double(index)/16 * 2 * .pi
                    return vertex(dot + LabPoint(x:cos(angle)*0.65,y:sin(angle)*0.65,z:0), [245,245,238])
                }
                for index in 0..<16 { faces.append([middle, ring[index], ring[(index+1)%16]]) }
            }
        }
        var lines = ["ply", "format ascii 1.0", "comment SYNTHETIC UI TEST ONLY; units mm",
            "element vertex \(vertices.count)", "property double x", "property double y", "property double z",
            "property uchar red", "property uchar green", "property uchar blue", "element face \(faces.count)",
            "property list uchar int vertex_indices", "end_header"]
        for (index, point) in vertices.enumerated() {
            let color = colors[index]
            lines.append("\(point.x) \(point.y) \(point.z) \(color[0]) \(color[1]) \(color[2])")
        }
        for face in faces { lines.append("3 \(face[0]) \(face[1]) \(face[2])") }
        return Data((lines.joined(separator: "\n") + "\n").utf8)
    }
}
#endif
