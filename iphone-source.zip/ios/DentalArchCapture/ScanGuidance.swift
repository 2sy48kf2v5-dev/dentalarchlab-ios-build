import Foundation

/// Advice from observed IDs and accepted coverage only; no inferred spatial locations.
struct ScanGuidance: Equatable {
    let title: String
    let detail: String
    let action: String
    let pendingIDs: [Int]
    let isStalled: Bool
    let isCoverageReady: Bool

    static func make(feedback: LiveFeedback?, plan: DentalPlan, markerCount: Int,
                     mode: String, secondsSinceProgress: Double? = nil) -> ScanGuidance {
        guard [4, 6].contains(markerCount) else {
            return ScanGuidance(title: "Bayrak planını kontrol edin",
                detail: "Bu tarama için dört veya altı bayrak seçilmelidir.",
                action: "FDI planını açıp bayrak sayısını düzeltin.", pendingIDs: [],
                isStalled: false, isCoverageReady: false)
        }
        let expected = Array(0..<markerCount)
        func label(_ id: Int) -> String {
            plan.tooth(for: id).map { "FDI \($0) · ID \(id)" } ?? "ID \(id)"
        }
        func labels(_ ids: [Int]) -> String { ids.map(label).joined(separator: ", ") }
        guard let feedback else {
            return ScanGuidance(title: "Bayraklar bekleniyor",
                detail: "Henüz analiz edilmiş görüntü yok. Beklenen: \(labels(expected)).",
                action: "Bayrakların dört beyaz noktasını kadraja alın.", pendingIDs: expected,
                isStalled: false, isCoverageReady: false)
        }
        // Never infer completion from a detection, candidate count, or absent dictionary key.
        let target = max(1, feedback.targetViews)
        let pending = expected.filter { feedback.views[$0, default: 0] < target }
        let seen = Set(feedback.markers.map(\.id)).intersection(expected)
        let ready = feedback.targetViews > 0 && feedback.targetFrames > 0 &&
            pending.isEmpty && feedback.coverageReached
        if ready {
            return ScanGuidance(title: "Örnek kapsamı toplandı",
                detail: mode == "trial"
                    ? "Seçilen tüm bayrakların tanıma örnekleri kaydedildi. Bu deneme 3B ölçüm yapmaz."
                    : "Seçilen tüm bayraklar için görüntü hedefi karşılandı. 3B çözüm ayrıca kontrol edilecek.",
                action: "Sonuç işleminin tamamlanmasını bekleyin.", pendingIDs: [],
                isStalled: false, isCoverageReady: true)
        }
        let stalled = secondsSinceProgress.map { $0.isFinite && $0 > 8 } ?? false
        let summary = "Son karede \(seen.count)/\(markerCount) görüldü; \(markerCount - pending.count)/\(markerCount) için yeterli örnek var."
        if pending.isEmpty {
            return ScanGuidance(title: stalled ? "İlerleme durakladı" : "Ek görüntü gerekli",
                detail: summary + " Toplam görüntü hedefi: \(feedback.frames)/\(feedback.targetFrames).",
                action: "Farklı açılardan yeni görüntüler toplamaya devam edin.", pendingIDs: [],
                isStalled: stalled, isCoverageReady: false)
        }
        let pendingText = " Eksik: \(labels(pending))."
        let reasons = Set(feedback.candidateReasons)
        let evidence: String
        let reasonAction: String?
        // Diagnostics describe candidates in this image, not the identity of an unseen flag.
        if reasons.contains("clipped") {
            evidence = " Bazı aday desenler kadraj sınırında kesilmiş."
            reasonAction = "Bayrakların dört noktasını da görüntünün içine alın."
        } else if reasons.contains("too_small") {
            evidence = " Bazı aday desenler bu görüntüde çok küçük."
            reasonAction = "Telefonu yavaşça biraz yaklaştırın; dört noktanın net ve eksiksiz kaldığını kontrol edin."
        } else if reasons.contains("ambiguous_identity") {
            evidence = " Bazı adayların kimliği güvenle ayırt edilemedi."
            reasonAction = "Eksik bayrağın desenini daha net ve farklı bir açıdan gösterin; yanındaki desenleri örtmeyin."
        } else if reasons.contains("invalid_layout") {
            evidence = " Bazı adayların nokta düzeni beklenen bayrak geometrisiyle eşleşmedi."
            reasonAction = "Doğru bayrak desenini kullandığınızı ve dört noktanın tamamının görünür olduğunu kontrol edin."
        } else if reasons.contains("no_valid_geometry") {
            evidence = " Bu karede bazı adaylar için geçerli bayrak geometrisi bulunamadı."
            reasonAction = "Dört beyaz noktanın örtülmediğini, yansımayla birleşmediğini ve net göründüğünü kontrol edin."
        } else {
            evidence = " Bu veriden eksik örneklerin nedeni kesin belirlenemiyor."
            reasonAction = nil
        }
        let recovery = mode == "trial"
            ? "Görüntü net değilse taramayı duraklatıp Yeniden netle'yi kullanın; onaylar korunur."
            : "Telefonun açısını yavaşça değiştirip yeni görüntüler toplayın; bayrakları yerinden oynatmayın."
        let action = reasonAction.map { stalled ? "\($0) \(recovery)" : $0 } ??
            (stalled ? recovery : mode == "trial"
                ? "Eksik bayrakların dört noktasını net biçimde gösterin."
                : "Farklı açılardan yeni görüntüler toplamaya devam edin.")
        return ScanGuidance(title: stalled ? "İlerleme durakladı" : "\(pending.count) bayrak için örnek gerekli",
            detail: summary + pendingText + evidence, action: action, pendingIDs: pending,
            isStalled: stalled, isCoverageReady: false)
    }
}
