import SwiftUI
import UIKit
import AVFoundation

struct LiveCaptureView: View {
    @EnvironmentObject var model: CaptureModel
    @State private var focusAssist = false
    @State private var showingDetails = false
    @State private var lastProgressDate = Date()
    let finish: () -> Void
    private var working: Bool { model.busy || model.analyzing || model.uploading || model.computing }
    private var autoUnavailable: Bool {
        !model.autoRunning && (!model.ready || working || model.pendingCount > 0)
    }
    private var calibrationFrames: Int {
        model.current?.acceptedCount ?? model.calibrationFeedback?.acceptedFrames ?? 0
    }
    private var calibrationRecordClosed: Bool {
        guard let capture = model.current else { return false }
        return capture.engine != "iphone_native_v1" || capture.state != "collecting"
    }
    private var calibrationUnavailable: Bool {
        model.computing || model.calibrationLimitReached || calibrationRecordClosed ||
        (!model.autoRunning && (working || model.cameraStarting || model.pendingCount > 0))
    }
    private var calibrationButtonTitle: String {
        if model.computing { return "Kalibrasyon hesaplanıyor…" }
        if model.current?.state == "complete" { return "Kalibrasyon tamamlandı" }
        if model.calibrationLimitReached || calibrationRecordClosed { return "Yeni kayıt gerekli" }
        if model.cameraStarting { return "Kamera hazırlanıyor…" }
        if model.autoRunning { return "Duraklat" }
        return model.currentID == nil ? "Kalibrasyon taramasını başlat" : "Devam et"
    }
    private var cameraStatus: String {
        if model.cameraStarting { return "KAMERA HAZIRLANIYOR" }
        return model.ready ? "CANLI · SABİT ODAK" : "KAMERA KAPALI"
    }
    var body: some View {
        GeometryReader { geometry in
            TimelineView(.animation(minimumInterval: 0.08, paused: !model.ready)) { context in
                let accepted = acceptedFrameVisible(at: context.date)
                ZStack {
                    FullScreenCameraPreview(session: model.camera.session)
                        .scaleEffect(focusAssist ? 2 : 1)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                    if accepted {
                        if model.mode == "calibration", let feedback = model.calibrationFeedback, let image = model.calibrationFeedbackImage {
                            CalibrationCameraFrameView(feedback: feedback, image: image)
                        } else if let feedback = model.feedback, let image = model.feedbackImage {
                            AnalyzedFrameView(feedback: feedback, image: image, plan: model.plan)
                        }
                    }
                    RoundedRectangle(cornerRadius: 16)
                        .strokeBorder(accepted ? Color.green : Color.white.opacity(0.25),
                                      style: StrokeStyle(lineWidth: accepted ? 5 : 1, dash: accepted ? [] : [12, 9]))
                        .padding(8).allowsHitTesting(false)
                    VStack(spacing: 0) {
                        cameraHeader
                        Spacer(minLength: 12)
                        cameraFooter(accepted: accepted, date: context.date)
                    }
                }.frame(width: geometry.size.width, height: geometry.size.height).clipped()
                    .accessibilityElement(children: .contain).accessibilityIdentifier("fullScreenCamera")
            }
        }.background(.black).preferredColorScheme(.dark)
            .onChange(of: model.feedback?.views) { old, new in
                if (new?.values.reduce(0, +) ?? 0) > (old?.values.reduce(0, +) ?? 0) { lastProgressDate = Date() }
            }
            .onChange(of: model.autoRunning) { _, running in if running { lastProgressDate = Date() } }
            .onChange(of: model.currentID) { _, _ in lastProgressDate = Date() }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showingDetails) {
                NavigationStack {
                    captureDetails.navigationTitle("Çekim ayrıntıları").navigationBarTitleDisplayMode(.inline)
                        .toolbar(.visible, for: .navigationBar)
                        .toolbar {
                            ToolbarItem(placement: .confirmationAction) {
                                Button("Kapat") { showingDetails = false }.accessibilityIdentifier("closeCaptureDetails")
                            }
                        }
                }.preferredColorScheme(.dark)
            }
    }
    private func acceptedFrameVisible(at date: Date) -> Bool {
        guard model.ready else { return false }
        if model.mode == "calibration" {
            guard let feedback = model.calibrationFeedback, feedback.usable, !feedback.preview,
                  model.calibrationFeedbackImage != nil, let sampled = model.calibrationFeedbackDate else { return false }
            return (0..<0.35).contains(date.timeIntervalSince(sampled))
        }
        guard !model.newlyConfirmedIDs.isEmpty,
              let feedback = model.feedback, feedback.usable, !feedback.preview,
              model.feedbackImage != nil, let sampled = model.feedbackDate else { return false }
        return (0..<0.35).contains(date.timeIntervalSince(sampled))
    }
    private var cameraHeader: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text(model.mode == "calibration" ? "Kalibrasyon" : model.mode == "scan" ? "3B araştırma" : "Bayrak deneyi · 2B")
                        .font(.headline)
                    Label(cameraStatus, systemImage: "camera").font(.caption2.bold())
                }
                Spacer()
                Label("Bu iPhone", systemImage: "cpu").font(.caption2).accessibilityIdentifier("localCaptureEngine")
                Button { showingDetails = true } label: {
                    Image(systemName: "slider.horizontal.3").font(.title3).frame(width: 44, height: 44)
                }.accessibilityLabel("Çekim ayrıntılarını aç").accessibilityIdentifier("captureDetails")
            }
            if model.mode == "calibration" {
                HStack {
                    Text("\(calibrationFrames)/\(model.calibrationTarget) uygun kare")
                        .accessibilityIdentifier("calibrationFrameCount")
                    Spacer()
                    Text("\(model.calibrationFeedback?.cornerCount ?? 0)/54 iç köşe")
                        .accessibilityIdentifier("calibrationCornerCount")
                }.font(.caption.bold()).monospacedDigit()
                ProgressView(value: min(1, Double(calibrationFrames) / Double(max(1, model.calibrationTarget)))).tint(.mint)
                Text(model.cameraStarting ? "Tahtayı ortala ve sabit tut; kamera netleniyor."
                     : "9 × 6 iç köşenin tamamını göster; uygun kareler otomatik kaydedilir.")
                    .font(.caption).accessibilityIdentifier("calibrationGuidance")
                Text("Telefonu hafifçe eğin; her yeni açıda kısa süre durun.")
                    .font(.caption2).foregroundStyle(.white.opacity(0.8)).accessibilityIdentifier("calibrationMovementGuidance")
                if let guidance = model.calibrationGuidance {
                    Text(guidance).font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationAdditionalViews")
                }
                if (calibrationRecordClosed && model.current?.state != "complete" && !model.computing) || model.calibrationLimitReached {
                    Text("Başlangıç'ta Yeni kayıt hazırla ile yeniden başlayın.")
                        .font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationNewRecordRequired")
                }
            } else {
                HStack {
                    Text("\(model.feedback?.completedIDs.count ?? 0)/\(model.markerCount) bayrak tamamlandı")
                    Spacer()
                    NavigationLink { DentalPlanView().toolbar(.visible, for: .navigationBar) } label: { Text("FDI planı") }
                        .accessibilityLabel("FDI planını aç")
                }.font(.caption.bold()).accessibilityElement(children: .contain).accessibilityIdentifier("coveragePanel")
                HStack(spacing: 6) {
                    ForEach(0..<model.markerCount, id: \.self) { id in
                        let done = model.feedback?.completedIDs.contains(id) == true
                        let seen = model.feedback?.markers.contains(where: { $0.id == id }) == true
                        let target = model.feedback?.targetViews ?? (model.mode == "trial" ? 1 : 8)
                        let views = model.feedback?.views[id] ?? 0
                        VStack(spacing: 3) {
                            ZStack {
                                Circle().stroke(.white.opacity(0.25), lineWidth: 3)
                                Circle().trim(from: 0, to: min(1, Double(views)/Double(max(1,target))))
                                    .stroke(done ? Color.green : Color.cyan, style: StrokeStyle(lineWidth: 3, lineCap: .round)).rotationEffect(.degrees(-90))
                                if done { Image(systemName: "checkmark").font(.caption.bold()).foregroundStyle(.green) }
                                else { Text("\(id)").font(.caption.bold()).foregroundStyle(seen ? .orange : .white) }
                            }.frame(width: 30, height: 30)
                            Text(model.plan.tooth(for: id).map { "FDI \($0)" } ?? "ID \(id)").font(.system(size: 9))
                            Text(done ? "TAMAM" : "\(views)/\(target)").font(.system(size: 9, weight: .semibold)).foregroundStyle(done ? .green : .white)
                        }.frame(maxWidth: .infinity).accessibilityElement(children: .ignore)
                            .accessibilityLabel("Bayrak \(id): \(done ? "tamamlandı" : "bekleniyor")")
                    }
                }.accessibilityIdentifier("confirmedFlagIDs")
                Text(model.mode == "trial" ? "Her bayrak bir kez kaydedilir; tamamlanınca sonuç açılır."
                     : "\(model.current?.acceptedCount ?? 0)/24 kare · her bayrak en az 8 farklı görünüm. Sonuç otomatik açılır.")
                    .font(.caption2).foregroundStyle(.white.opacity(0.85))
                Text(model.mode == "trial" ? "Ekran deneyi: bayrak kimlikleri kontrol edilir; XYZ hesaplanmaz."
                     : "Gerçek, sabit bayrakları farklı açılardan tara. Sanal ağız ekranı için 2B deneyi seç.")
                    .font(.caption2).foregroundStyle(.white.opacity(0.85))
                    .accessibilityIdentifier("captureGeometryScope")
            }
        }.padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [.black.opacity(0.86), .black.opacity(0.58), .clear], startPoint: .top, endPoint: .bottom))
            .foregroundStyle(.white)
    }
    private func cameraFooter(accepted: Bool, date: Date) -> some View {
        let guidance = ScanGuidance.make(feedback: model.feedback, plan: model.plan, markerCount: model.markerCount,
            mode: model.mode, secondsSinceProgress: model.autoRunning ? date.timeIntervalSince(lastProgressDate) : nil)
        return VStack(spacing: 9) {
            if accepted {
                Label(model.mode == "calibration" ? "Uygun kare kaydedildi" : "Bayrak onaylandı: " + model.newlyConfirmedIDs.map(String.init).joined(separator: ", "), systemImage: "checkmark.circle.fill")
                    .font(.callout.bold()).foregroundStyle(.green).accessibilityIdentifier("acceptedFrameCue")
                Text("ANALİZ EDİLEN KARE").font(.caption2.bold()).foregroundStyle(.white)
            }
            Text(model.status).font(.caption).lineLimit(3).frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityIdentifier("captureStatus")
            if model.mode != "calibration", model.feedback != nil, !guidance.isCoverageReady {
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Label(guidance.title, systemImage: guidance.isStalled ? "exclamationmark.circle" : "viewfinder").font(.caption.bold())
                        Spacer()
                        Button("İncele") { showingDetails = true }.font(.caption.bold()).accessibilityIdentifier("inspectRecognition")
                    }
                    Text(guidance.detail).font(.caption2).lineLimit(2)
                    Text(guidance.action).font(.caption2.bold()).lineLimit(2)
                }.foregroundStyle(guidance.isStalled ? .orange : .white)
                    .padding(10).background(.black.opacity(0.68)).clipShape(RoundedRectangle(cornerRadius: 12))
                    .accessibilityIdentifier("liveScanGuidance")
            }
            HStack(alignment: .center, spacing: 8) {
                Text(model.cameraFocusGuidance).font(.caption2).lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading).accessibilityIdentifier("cameraFocusGuidance")
                Button(action: model.refocusCamera) {
                    Image(systemName: "scope").font(.title3).frame(width: 44, height: 44)
                }.accessibilityLabel("Yeniden netle").accessibilityIdentifier("refocusCamera").disabled(!model.canRefocus)
                Button { focusAssist.toggle() } label: {
                    Text(focusAssist ? "1×" : "2×").font(.subheadline.bold()).frame(width: 44, height: 44)
                }.accessibilityLabel(focusAssist ? "1× önizleme" : "2× odak yardımı").accessibilityIdentifier("focusAssist")
            }
            captureControls
            Text(model.mode == "calibration" && !model.physicalBoard
                 ? "Ekran denemesi · fiziksel doğruluk ölçülmedi"
                 : "Yeşil = veri kapsamı tamam · fiziksel doğruluk ölçülmedi")
                .font(.system(size: 10)).foregroundStyle(.white.opacity(0.75))
                .accessibilityIdentifier(model.mode == "calibration" && !model.physicalBoard ? "screenCalibrationNote" : "captureAccuracyNote")
        }.padding(.horizontal, 16).padding(.top, 20).padding(.bottom, 10)
            .background(LinearGradient(colors: [.clear, .black.opacity(0.8), .black.opacity(0.95)], startPoint: .top, endPoint: .bottom))
            .foregroundStyle(.white)
    }
    private var captureControls: some View {
        VStack(spacing: 8) {
            if model.mode == "calibration" {
                Button {
                    if model.autoRunning { model.pauseAutomatic() } else { model.beginCalibrationScan() }
                } label: {
                    Label(calibrationButtonTitle, systemImage: model.autoRunning ? "pause.fill" : "checkerboard.rectangle")
                        .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(.vertical, 9)
                }.buttonStyle(.borderedProminent).tint(.mint)
                    .foregroundStyle(calibrationUnavailable ? Color.white : Color.black)
                    .accessibilityIdentifier("autoCalibration").disabled(calibrationUnavailable)
                HStack(spacing: 10) {
                    cameraControl
                    Spacer()
                    Button(action: model.takePhoto) {
                        Label("Tek kare", systemImage: "camera.aperture").font(.subheadline).padding(.vertical, 5)
                    }.buttonStyle(.bordered).accessibilityLabel("Görüntüyü kaydet").accessibilityIdentifier("calibrationCapture")
                        .disabled(!model.ready || working || model.autoRunning || model.calibrationLimitReached || calibrationRecordClosed)
                }
            } else {
                HStack(spacing: 10) {
                    cameraControl
                    Button {
                        if model.autoRunning { model.pauseAutomatic() } else { model.startAutomatic() }
                    } label: {
                        Label(model.autoRunning ? "Duraklat" : "Taramayı başlat", systemImage: model.autoRunning ? "pause.fill" : "viewfinder")
                            .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(.vertical, 9)
                    }.buttonStyle(.borderedProminent).tint(.mint)
                        .foregroundStyle(autoUnavailable ? Color.white : Color.black).accessibilityIdentifier("autoScan").disabled(autoUnavailable)
                }
                HStack {
                    Button(action: model.takePhoto) { Label("Tek kare", systemImage: "camera.aperture") }
                        .font(.caption).accessibilityLabel("Görüntüyü kaydet").disabled(!model.ready || working || model.autoRunning)
                    Spacer()
                    Button(model.computing ? "iPhone hesaplıyor…" : "Hesapla / deneyi tamamla", action: finish)
                        .font(.caption).disabled(working || model.autoRunning || model.current == nil)
                }.padding(.vertical, 4)
            }
        }
    }
    private var captureDetails: some View {
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(model.mode == "scan" ? "3B araştırma" : model.mode == "calibration" ? "Kalibrasyon" : "Bayrak deneyi · 2B").font(.headline)
                        Text(model.mode == "calibration" ? "DentalArchLab / 9 × 6 iç köşe" : "DentalArchLab / \(model.markerCount) bayrak").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) {
                        Label("Bu iPhone", systemImage: "cpu").foregroundStyle(.mint).accessibilityIdentifier("localCaptureEngine")
                        if let t = model.analysisSeconds { Text(String(format: "Yanıt %.2f sn", t)).monospacedDigit() }
                        if let ms = model.detectorMilliseconds { Text(String(format: "Tanıma %.0f ms", ms)).monospacedDigit() }
                    }.font(.caption)
                }
                if model.mode == "calibration" { calibrationGuidance }
                else { coverage }
                HStack {
                    Text(model.status).font(.callout).frame(maxWidth: .infinity, alignment: .leading)
                    Button { model.soundEnabled.toggle() } label: {
                        Image(systemName: model.soundEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill").font(.title3)
                    }.accessibilityLabel(model.soundEnabled ? "Sesi kapat" : "Sesi aç")
                }.padding(14).background(.white.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 16))
                if model.mode == "calibration", let feedback = model.calibrationFeedback,
                   let image = model.calibrationFeedbackImage, let date = model.calibrationFeedbackDate {
                    CalibrationAnalyzedFrameView(feedback: feedback, image: image, date: date)
                }
                if let diagnostic = model.cameraDiagnostic {
                    DisclosureGroup("Kamera hata ayrıntıları") {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(diagnostic).font(.caption.monospaced()).textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            Button {
                                UIPasteboard.general.string = diagnostic
                            } label: {
                                Label("Ayrıntıları kopyala", systemImage: "doc.on.doc")
                            }.buttonStyle(.bordered).accessibilityIdentifier("copyCameraDiagnostic")
                        }.padding(.top, 8)
                    }.font(.callout).accessibilityIdentifier("cameraDiagnostics")
                }
                if let feedback = model.feedback, model.mode != "calibration" {
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Label("Son kare: \(feedback.markers.count)/\(model.markerCount) bayrak", systemImage: "viewfinder")
                            Spacer()
                            Text("Yerel analiz").foregroundStyle(.mint)
                        }.font(.caption.bold())
                        if !feedback.missingInSample.isEmpty {
                            Text("Bu karede eksik: " + feedback.missingInSample.map { id in
                                model.plan.tooth(for: id).map { "FDI \($0)" } ?? "ID \(id)"
                            }.joined(separator: ", ")).font(.caption).foregroundStyle(.orange)
                        }
                        if let hint = feedback.hint, !feedback.usable { Text(hint).font(.caption).foregroundStyle(.secondary) }
                        let advice = ScanGuidance.make(feedback: feedback, plan: model.plan, markerCount: model.markerCount, mode: model.mode)
                        Text(advice.detail).font(.caption)
                        Text(advice.action).font(.caption.bold()).foregroundStyle(.orange)
                        Text("\(feedback.candidateCount) nokta grubu · \(feedback.markers.count) doğrulanmış kimlik").font(.caption2)
                        if let seconds = model.cycleSeconds {
                            Text(String(format: "Son örnek döngüsü %.2f sn · kamera, analiz ve kayıt", seconds)).font(.caption2).foregroundStyle(.secondary)
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                        .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 14))
                        .accessibilityIdentifier("recognitionDiagnostics")
                }
                if model.mode != "calibration" {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("Tanıma raporu", systemImage: "doc.text.magnifyingglass").font(.headline)
                        Text("Son analiz edilen fotoğrafı, gerçek kamera ayarlarını ve ret nedenlerini kaydeder. Rapor fotoğraf içerir; yalnız Paylaş'a bastığınızda seçtiğiniz yere gönderilir.")
                            .font(.caption).foregroundStyle(.secondary)
                        Button(action: model.prepareRecognitionReport) { Label("Tanıma raporu hazırla", systemImage: "doc.badge.plus") }
                            .buttonStyle(.bordered).disabled(!model.canPrepareRecognitionReport).accessibilityIdentifier("prepareRecognitionReport")
                        if let url = model.diagnosticFileURL {
                            ShareLink(item: url) { Label("Tanıma raporunu paylaş", systemImage: "square.and.arrow.up") }
                                .accessibilityIdentifier("shareRecognitionReport")
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                        .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 14))
                }
                if model.mode != "calibration" {
                    HStack {
                        Text("\(model.current?.acceptedCount ?? 0) uygun kare").font(.caption)
                        Spacer()
                        Button(action: model.takePhoto) { Label("Tek kare", systemImage: "camera.aperture") }
                            .buttonStyle(.bordered).accessibilityLabel("Görüntüyü kaydet").disabled(!model.ready || working || model.autoRunning)
                    }
                }
                VStack(alignment: .leading, spacing: 9) {
                    Label("Otomatik odak", systemImage: "viewfinder").font(.callout.bold())
                    Text(model.cameraFocusGuidance).font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("cameraFocusGuidance")
                    if model.mode == "calibration" {
                        Text("Başlangıçta kamera otomatik netlenir; kalibrasyon boyunca aynı odak korunur.")
                            .font(.caption2).foregroundStyle(.secondary)
                            .accessibilityIdentifier("calibrationFocusExplanation")
                    }
                    Button(action: model.refocusCamera) {
                        Label("Yeniden netle", systemImage: "scope")
                    }.buttonStyle(.bordered).accessibilityIdentifier("refocusCamera")
                        .disabled(!model.canRefocus)
                }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                    .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 14))
                if model.pendingCount > 0 {
                    Button("Kayıtlı kareleri işle (\(model.pendingCount))") { Task { await model.sendPending() } }.disabled(working || model.autoRunning)
                }
                if model.mode == "calibration" {
                    Text("Yeterli farklı açı toplandığında kalibrasyon otomatik hesaplanır. Gerekirse ek açılar istenir.")
                        .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("automaticCalibrationExplanation")
                } else {
                    Button(model.computing ? "iPhone hesaplıyor…" : "Hesapla / deneyi tamamla", action: finish)
                        .buttonStyle(.bordered).disabled(working || model.autoRunning || model.current == nil)
                }
                if model.mode != "calibration", let feedback = model.feedback, let image = model.feedbackImage, let date = model.feedbackDate {
                    DisclosureGroup("Son analizi ayrıntılı incele") { FeedbackCard(feedback: feedback, image: image, date: date) }
                }
                if model.mode != "calibration" {
                    Text("Yeşil ve ses = yeni bayrak tamamlandı. Aynı kimlik tekrar onaylanmaz. Fiziksel doğruluk ölçülmedi.").font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.035, green: 0.065, blue: 0.11)).preferredColorScheme(.dark)
    }
    private var cameraControl: some View {
        Button {
            if model.ready || model.cameraStarting { model.stopCamera() } else { model.openCamera() }
        } label: {
            HStack(spacing: 6) {
                if model.cameraStarting { ProgressView().controlSize(.small).accessibilityHidden(true) }
                Label(model.cameraStarting ? "İptal" : model.ready ? "Kapat" : "Kamerayı aç",
                      systemImage: model.cameraStarting ? "xmark" : model.ready ? "camera.fill" : "camera")
            }.font(.subheadline.bold()).padding(.vertical, 9)
        }.buttonStyle(.bordered).accessibilityIdentifier("cameraControl")
            .disabled(!model.cameraStarting && (model.busy || model.computing || (model.analyzing && !model.ready)))
    }
    private var calibrationGuidance: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("\(calibrationFrames)/\(model.calibrationTarget) uygun kare")
                    .font(.subheadline.bold()).monospacedDigit().accessibilityIdentifier("calibrationFrameCount")
                Spacer()
                Text("\(model.calibrationFeedback?.cornerCount ?? 0)/54 iç köşe")
                    .font(.caption.monospacedDigit()).accessibilityIdentifier("calibrationCornerCount")
            }
            ProgressView(value: min(1, Double(calibrationFrames) / Double(max(1, model.calibrationTarget))))
                .tint(.mint).accessibilityLabel("Toplanan kalibrasyon kareleri")
            if model.calibrationLimitReached || (calibrationRecordClosed && model.current?.state != "complete" && !model.computing) {
                Text("Bu kayıt çekime kapalı. Başlangıç sekmesinde Yeni kayıt hazırla ile yeniden başlayın.")
                    .font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationNewRecordRequired")
            }
            if let guidance = model.calibrationGuidance {
                Label(guidance, systemImage: "arrow.triangle.2.circlepath")
                    .font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationAdditionalViews")
            } else if calibrationFrames >= model.calibrationTarget && model.current?.state == "collecting" && !model.computing {
                Text("Ek açı gerekli").font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationAdditionalViews")
            }
            Text("Başlat'a basın; kamera açılır, uygun görüntüler otomatik kaydedilir. Tahtanın 9 × 6 iç köşesinin tamamı görünsün.")
                .font(.caption).accessibilityIdentifier("calibrationGuidance")
            Text("Tahtayı sabit tutun. Telefonu sağa, sola, yukarı ve aşağı kaydırıp hafifçe eğin; her yeni açıda kısa süre durun.")
                .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("calibrationMovementGuidance")
            if !model.physicalBoard {
                Text("Ekrandaki tahta yalnız deneme içindir; fiziksel ölçek ve ölçüm doğruluğu doğrulanmaz.")
                    .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("screenCalibrationNote")
            }
        }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
            .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 12))
    }
    private var coverage: some View {
        VStack(spacing: 12) {
            HStack(spacing: 16) {
                ZStack {
                    Circle().stroke(.white.opacity(0.12), lineWidth: 6)
                    Circle().trim(from: 0, to: model.feedback?.fraction ?? 0).stroke(.mint, style: StrokeStyle(lineWidth: 6, lineCap: .round)).rotationEffect(.degrees(-90))
                    Text("\(Int((model.feedback?.fraction ?? 0) * 100))%").font(.headline.monospacedDigit())
                }.frame(width: 60, height: 60)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Görüntü kapsamı").font(.subheadline.bold())
                    Text("\(model.feedback?.completedIDs.count ?? 0)/\(model.markerCount) bayrak tamamlandı").font(.caption)
                    Text("Kırmızı: görülmedi · Sarı: eksik · Yeşil: kapsam").font(.system(size: 10)).foregroundStyle(.secondary)
                }
                Spacer()
                NavigationLink { DentalPlanView() } label: { Image(systemName: "slider.horizontal.3") }.accessibilityLabel("FDI planını aç")
            }
            OdontogramView(plan: model.plan, views: model.feedback?.views ?? [:], target: model.feedback?.targetViews ?? 4)
            if model.plan.assignments.contains(where: { $0.fdi == nil }) {
                NavigationLink("Önce FDI dişlerini seç") { DentalPlanView() }.font(.caption.bold())
            }
        }.padding(14).background(.white.opacity(0.06)).clipShape(RoundedRectangle(cornerRadius: 20))
            .accessibilityElement(children: .contain).accessibilityIdentifier("coveragePanel")
    }
}

/// Preview only: frame capture keeps the original sensor pixels and coordinates.
private struct FullScreenCameraPreview: UIViewRepresentable {
    let session: AVCaptureSession
    func makeUIView(context: Context) -> PreviewView {
        let view = PreviewView()
        view.preview.session = session
        view.preview.videoGravity = .resizeAspectFill
        return view
    }
    func updateUIView(_ uiView: PreviewView, context: Context) {
        if let connection = uiView.preview.connection, connection.isVideoRotationAngleSupported(90) {
            connection.videoRotationAngle = 90
        }
    }
}

/// Confirmed detections are drawn only over the exact sampled image, rotated with its points.
private struct CalibrationCameraFrameView: View {
    let feedback: CalibrationFeedback
    let image: UIImage
    private var displayImage: UIImage {
        guard let cg = image.cgImage else { return image }
        return UIImage(cgImage: cg, scale: 1, orientation: .right)
    }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black
                Image(uiImage: displayImage).resizable().scaledToFit()
                Canvas { context, size in
                    let viewport = FeedbackViewport(imageWidth: Double(feedback.height), imageHeight: Double(feedback.width),
                                                    viewWidth: size.width, viewHeight: size.height)
                    for corner in feedback.corners where corner.count == 2 {
                        let (x, y) = viewport.point([1 - corner[1], corner[0]])
                        context.stroke(Path(ellipseIn: CGRect(x: x - 3, y: y - 3, width: 6, height: 6)),
                                       with: .color(.green), lineWidth: 2)
                    }
                }
            }.frame(width: geometry.size.width, height: geometry.size.height)
        }.allowsHitTesting(false)
    }
}

struct AnalyzedFrameView: View {
    let feedback: LiveFeedback
    let image: UIImage
    let plan: DentalPlan
    private var displayImage: UIImage {
        guard let cg = image.cgImage else { return image }
        return UIImage(cgImage: cg, scale: 1, orientation: .right)
    }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black
                Image(uiImage: displayImage).resizable().scaledToFit()
                Canvas { context, size in
                    let viewport = FeedbackViewport(imageWidth: Double(feedback.height), imageHeight: Double(feedback.width), viewWidth: size.width, viewHeight: size.height)
                    for marker in feedback.markers {
                        let color: Color = feedback.completedIDs.contains(marker.id) ? .green : .orange
                        let points = marker.points.map { viewport.point([1 - $0[1], $0[0]]) }
                        let xs = points.map { $0.0 }, ys = points.map { $0.1 }
                        let x = xs.min()! - 9, y = ys.min()! - 9
                        let rect = CGRect(x: x, y: y, width: xs.max()! - x + 9, height: ys.max()! - y + 9)
                        context.stroke(Path(roundedRect: rect, cornerRadius: 7), with: .color(color), lineWidth: 2.5)
                        let label = plan.tooth(for: marker.id).map { "FDI \($0) · ID \(marker.id)" } ?? "ID \(marker.id)"
                        context.draw(Text(label).font(.system(size: 10, weight: .bold)).foregroundStyle(color), at: CGPoint(x: rect.midX, y: y - 9))
                    }
                }
            }.frame(width: geometry.size.width, height: geometry.size.height)
        }.allowsHitTesting(false)
    }
}

struct FeedbackCard: View {
    let feedback: LiveFeedback
    let image: UIImage
    let date: Date
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            TimelineView(.periodic(from: .now, by: 1)) { context in
                HStack {
                    Label("Son analiz edilen kare", systemImage: "photo.badge.checkmark")
                    Spacer()
                    Text("\(max(0, Int(context.date.timeIntervalSince(date)))) sn önce").monospacedDigit()
                }.font(.caption.bold())
            }
            GeometryReader { geometry in
                ZStack {
                    Image(uiImage: image).resizable().scaledToFit()
                    Canvas { context, size in
                        let viewport = FeedbackViewport(imageWidth: Double(feedback.width), imageHeight: Double(feedback.height),
                            viewWidth: size.width, viewHeight: size.height)
                        let color: Color = feedback.usable && !feedback.preview ? .green : .orange
                        for candidate in feedback.candidates where !candidate.accepted {
                            for point in candidate.points {
                                let (x, y) = viewport.point(point)
                                context.stroke(Path(ellipseIn: CGRect(x: x - 6, y: y - 6, width: 12, height: 12)), with: .color(.orange), lineWidth: 1.5)
                            }
                        }
                        for marker in feedback.markers {
                            for point in marker.points {
                                let (x, y) = viewport.point(point)
                                context.stroke(Path(ellipseIn: CGRect(x: x - 4, y: y - 4, width: 8, height: 8)), with: .color(color), lineWidth: 2)
                            }
                            let (x, y) = viewport.point(marker.points[0])
                            context.draw(Text("ID \(marker.id)").font(.caption2.bold()).foregroundStyle(color), at: CGPoint(x: x, y: y - 12))
                        }
                    }
                }.frame(width: geometry.size.width, height: geometry.size.height)
            }.frame(height: 190).background(.black).clipShape(RoundedRectangle(cornerRadius: 12))
            Label(feedback.usable ? (feedback.preview ? "Uygun örnek · kayıt onayı bekleniyor" : "Uygun görüntü kaydedildi") : "Bu örnek sayılmadı",
                systemImage: feedback.usable ? "checkmark.circle.fill" : "exclamationmark.circle")
                .font(.caption).foregroundStyle(feedback.usable ? Color.teal : Color.orange)
            Text("Turuncu halkalar doğrulanmamış nokta adaylarıdır. İşaretler bu sabit kareye aittir; hareketli görüntüyü takip etmez.").font(.caption2).foregroundStyle(.secondary)
        }.accessibilityIdentifier("analyzedFrame")
    }
}
