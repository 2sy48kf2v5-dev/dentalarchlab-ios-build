import SwiftUI
import UIKit
import AVFoundation

struct LiveCaptureView: View {
    @EnvironmentObject var model: CaptureModel
    @State private var focusAssist = false
    @State private var showingDetails = false
    @State private var lastProgressDate = Date()
    @State private var displayOrientation: CameraDisplayOrientation = .portrait
    let onExit: () -> Void
    let finish: () -> Void
    init(onExit: @escaping () -> Void = {}, finish: @escaping () -> Void) {
        self.onExit = onExit
        self.finish = finish
    }
    private var working: Bool { model.busy || model.analyzing || model.uploading || model.computing }
    private var autoUnavailable: Bool {
        !model.autoRunning && (working || model.cameraStarting || model.illuminationChanging || model.pendingCount > 0)
    }
    private var calibrationFrames: Int {
        model.current?.acceptedCount ?? model.calibrationFeedback?.acceptedFrames ?? 0
    }
    private var calibrationRecordClosed: Bool {
        guard let capture = model.current else { return false }
        return capture.engine != "iphone_native_v1" || capture.state != "collecting"
    }
    private var calibrationUnavailable: Bool {
        model.computing || model.illuminationChanging || model.calibrationLimitReached || calibrationRecordClosed ||
        (!model.autoRunning && (working || model.cameraStarting || model.pendingCount > 0))
    }
    private var calibrationButtonTitle: String {
        if model.computing { return "Kalibrasyon hesaplanıyor…" }
        if model.current?.state == "complete" { return "Kalibrasyon tamamlandı" }
        if model.calibrationLimitReached || calibrationRecordClosed { return "Yeni kayıt gerekli" }
        if model.cameraStarting { return "Kamera hazırlanıyor…" }
        if model.autoRunning { return "Duraklat" }
        return model.currentID == nil ? "Kalibrasyon taramasını başlat" : "Devam et"
    }
    private var cameraStatus: String {
        if model.cameraStarting { return "KAMERA HAZIRLANIYOR" }
        if model.illuminationChanging { return "IŞIK AYARLANIYOR" }
        if model.previewReady { return "CANLI · OTOMATİK ODAK" }
        return model.ready ? (model.autoRunning ? "TARANIYOR" : "CANLI · HAZIR") : "KAMERA KAPALI"
    }
    private var captureTitle: String {
        model.mode == "calibration" ? "Kalibrasyon" : model.mode == "scan" ? "Bayrak taraması · 3B" : "Bayrak deneyi · 2B"
    }
    private var scanButtonTitle: String {
        if model.computing { return "Sonuç hesaplanıyor…" }
        if model.cameraStarting { return "Kamera hazırlanıyor…" }
        if model.illuminationChanging { return "Işık ayarlanıyor…" }
        if model.autoRunning { return "Duraklat" }
        return model.currentID == nil ? "Taramayı başlat" : "Taramaya devam et"
    }
    private var geometryScope: String {
        model.mode == "trial" ? "Ekran deneyi: bayrak kimlikleri kontrol edilir; XYZ hesaplanmaz."
            : "Gerçek, sabit bayrakları farklı açılardan tara. Sanal ağız ekranı için 2B deneyi seç."
    }
    private var torchControlLabel: String {
        if model.illuminationChanging { return "Işık ayarlanıyor" }
        if model.cameraVisible { return model.torchStatus.isOn ? "Işığı kapat" : "Işığı aç" }
        return model.torchEnabled ? "Başlangıç ışığını kapat" : "Başlangıç ışığını aç"
    }
    private var opticsSummary: String {
        if model.cameraVisible, let optics = model.opticsStatus {
            let lens = optics.lens == "ultrawide" ? "YAKIN ÇEKİM · Ultra geniş" : "Geniş lens"
            return "\(lens) · \(model.previewReady ? "otomatik odak" : "ölçüm odağı sabit") · \(optics.outputWidth) × \(optics.outputHeight) px"
        }
        if model.mode == "scan" { return "Lens ve çözünürlük seçilen kalibrasyondan alınır" }
        return model.cameraOpticsChoice == "closeUp" ? "Yakın çekim seçili · lens açılışta doğrulanır" : "Standart çekim seçili · lens açılışta doğrulanır"
    }
    private var displayOrientationLabel: String {
        switch displayOrientation {
        case .landscapeLeft: return "Yatay sol"
        case .landscapeRight: return "Yatay sağ"
        case .portrait: return "Dikey"
        case .portraitUpsideDown: return "Dikey ters"
        }
    }
    var body: some View {
        GeometryReader { geometry in
            let landscape = geometry.size.width > geometry.size.height
            let railWidth = min(224, max(190, geometry.size.width * 0.26))
            let leftWidth = max(1, geometry.size.width - railWidth - 24)
            let headerHeight: CGFloat = 74
            let viewport = landscape
                ? CGRect(x: 8, y: headerHeight, width: leftWidth, height: max(1, geometry.size.height - headerHeight - 22))
                : CGRect(origin: .zero, size: geometry.size)
            ZStack(alignment: .topLeading) {
                // One native preview remains mounted across analysis AND rotation.
                // Both transient detections and video use this exact viewport.
                cameraViewport(size: viewport.size)
                    .frame(width: viewport.width, height: viewport.height)
                    .clipShape(RoundedRectangle(cornerRadius: landscape ? 15 : 0))
                    .position(x: viewport.midX, y: viewport.midY)
                if landscape {
                    HStack(alignment: .top, spacing: 16) {
                        VStack(spacing: 0) {
                            landscapeHeader.frame(height: headerHeight)
                            Spacer(minLength: 0)
                            Text(model.mode == "calibration" ? "9 × 6 iç köşe · her yeni açıda kısa süre durun" : "Model sabit · telefonu yavaşça farklı açılara taşı")
                                .font(.system(size: 10, weight: .medium)).foregroundStyle(.white.opacity(0.6))
                                .frame(height: 22).lineLimit(1).minimumScaleFactor(0.8)
                        }.frame(width: leftWidth)
                        landscapeControlRail.frame(width: railWidth)
                    }.padding(.horizontal, 8)
                        .accessibilityElement(children: .contain).accessibilityIdentifier("landscapeCaptureLayout")
                } else {
                    VStack(spacing: 0) {
                        cameraHeader
                        Spacer(minLength: 12)
                        HStack {
                            Spacer()
                            analyzedThumbnail
                        }.padding(.horizontal, 18)
                        TimelineView(.periodic(from: .now, by: 1)) { context in
                            cameraFooter(date: context.date)
                        }
                    }
                }
            }.frame(width: geometry.size.width, height: geometry.size.height).clipped()
                .accessibilityElement(children: .contain).accessibilityIdentifier("fullScreenCamera")
                .toolbar(landscape ? .hidden : .visible, for: .tabBar)
        }.background(.black).preferredColorScheme(.dark)
            .onChange(of: model.feedback?.views) { old, new in
                if (new?.values.reduce(0, +) ?? 0) > (old?.values.reduce(0, +) ?? 0) { lastProgressDate = Date() }
            }
            .onChange(of: model.autoRunning) { _, running in if running { lastProgressDate = Date() } }
            .onChange(of: model.currentID) { _, _ in lastProgressDate = Date(); focusAssist = false }
            .onChange(of: model.mode) { _, _ in focusAssist = false }
            .onChange(of: model.cameraOpticsChoice) { _, _ in focusAssist = false }
            .onChange(of: model.cameraStarting) { _, starting in if starting { focusAssist = false } }
            .onChange(of: model.opticsStatus?.lens) { _, _ in focusAssist = false }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showingDetails) {
                NavigationStack {
                    captureDetails.navigationTitle("Çekim ayrıntıları").navigationBarTitleDisplayMode(.inline)
                        .toolbar(.visible, for: .navigationBar)
                        .toolbar {
                            ToolbarItem(placement: .confirmationAction) {
                                Button("Kapat") { showingDetails = false }.accessibilityIdentifier("closeCaptureDetails")
                            }
                        }
                }.preferredColorScheme(.dark)
            }
    }
    private func cameraViewport(size: CGSize) -> some View {
        ZStack {
            FullScreenCameraPreview(session: model.camera.session, orientation: $displayOrientation)
                .scaleEffect(focusAssist ? 2 : 1)
                .frame(width: size.width, height: size.height).clipped()
            if model.mode != "calibration" {
                if !(model.feedback?.views.values.contains(where: { $0 > 0 }) ?? false), !model.computing {
                    VStack(spacing: 10) {
                        ArchFramingGuide().stroke(.white.opacity(0.45), style: StrokeStyle(lineWidth: 1.5, dash: [7, 5]))
                            .frame(width: min(size.width * 0.62, 300), height: min(size.height * 0.25, 140))
                        Text("Çeneyi kadraja al · yalnız hizalama")
                            .font(.system(size: 10, weight: .medium)).foregroundStyle(.white.opacity(0.65))
                    }.allowsHitTesting(false).accessibilityElement(children: .combine)
                        .accessibilityLabel("Çene kadraj kılavuzu; algılanmış bayrak veya ölçülmüş konum değildir.")
                        .accessibilityIdentifier("archFramingGuide")
                }
                RecentSamplePointsView(feedback: model.feedback, ready: model.ready,
                    captureUptime: model.feedbackCaptureUptime,
                    imageWidth: model.feedbackImage?.cgImage?.width,
                    imageHeight: model.feedbackImage?.cgImage?.height,
                    previewZoom: focusAssist ? 2 : 1, orientation: displayOrientation)
            } else if !model.cameraVisible && !model.cameraStarting {
                VStack(spacing: 12) {
                    Image(systemName: "checkerboard.rectangle").font(.system(size: 52, weight: .ultraLight))
                    Text("Tahtanın tamamını kadraja al").font(.caption)
                }.foregroundStyle(.white.opacity(0.35)).allowsHitTesting(false)
            }
        }.background(Color(white: 0.025)).accessibilityElement(children: .contain)
            .accessibilityIdentifier("captureViewport").accessibilityValue(displayOrientationLabel)
    }
    private var landscapeHeader: some View {
        VStack(spacing: 3) {
            HStack(spacing: 9) {
                Button(action: onExit) {
                    Image(systemName: "chevron.left").font(.system(size: 17, weight: .semibold))
                        .frame(width: 44, height: 44)
                }.buttonStyle(.plain).accessibilityLabel("Başlangıç ekranına dön")
                    .accessibilityIdentifier("captureExit")
                VStack(alignment: .leading, spacing: 3) {
                    Text(captureTitle).font(.system(size: 15, weight: .semibold)).lineLimit(1)
                    HStack(spacing: 5) {
                        Circle().fill(model.autoRunning ? Color.mint : Color.white.opacity(0.5)).frame(width: 5, height: 5)
                        Text(cameraStatus).font(.system(size: 9, weight: .semibold))
                        Text("Bu iPhone").font(.system(size: 9)).foregroundStyle(.white.opacity(0.5))
                            .accessibilityIdentifier("localCaptureEngine")
                    }.lineLimit(1)
                }.frame(maxWidth: .infinity, alignment: .leading)
                if model.mode != "calibration" {
                    Text("\(selectedCompletedCount)/\(model.markerCount)")
                        .font(.system(size: 20, weight: .semibold, design: .rounded)).monospacedDigit()
                        .accessibilityLabel("\(selectedCompletedCount)/\(model.markerCount) bayrak tamamlandı")
                        .accessibilityIdentifier("coveragePanel")
                }
            }
            if model.mode == "calibration" {
                HStack(spacing: 10) {
                    Text("\(calibrationFrames)/\(model.calibrationTarget) uygun kare")
                        .accessibilityIdentifier("calibrationFrameCount")
                    ProgressView(value: min(1, Double(calibrationFrames) / Double(max(1, model.calibrationTarget)))).tint(.mint)
                    Text("\(model.calibrationFeedback?.cornerCount ?? 0)/54 iç köşe")
                        .accessibilityIdentifier("calibrationCornerCount")
                }.font(.system(size: 11, weight: .semibold)).monospacedDigit().frame(height: 22)
            } else {
                HStack(spacing: 5) {
                    ForEach(model.selectedMarkerIDs, id: \.self) { id in landscapeFlagProgress(id: id) }
                }.accessibilityElement(children: .contain).accessibilityIdentifier("confirmedFlagIDs")
            }
        }.foregroundStyle(.white).padding(.bottom, 4)
    }
    private func landscapeFlagProgress(id: Int) -> some View {
        let done = model.feedback?.completedIDs.contains(id) == true
        let target = model.feedback?.targetViews ?? (model.mode == "trial" ? 1 : 8)
        let views = model.feedback?.views[id] ?? 0
        let tooth = model.plan.tooth(for: id).map { "FDI \($0)" } ?? "ID \(id)"
        return HStack(spacing: 4) {
            Image(systemName: done ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(done ? Color.green : Color.white.opacity(0.4))
            Text("\(id)").fontWeight(.bold)
            Text(done ? "✓" : "\(views)/\(target)").foregroundStyle(.white.opacity(0.65))
        }.font(.system(size: 11)).monospacedDigit().frame(maxWidth: .infinity, minHeight: 22)
            .background(.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 6))
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("Bayrak \(id), \(tooth): \(done ? "tamamlandı" : "\(views)/\(target) görünüm")")
            .accessibilityIdentifier("flagProgress_\(id)")
    }
    private var landscapeControlRail: some View {
        VStack(spacing: 8) {
            HStack(spacing: 10) { soundControl; torchControl; detailsControl }
                .frame(maxWidth: .infinity)
            primaryCaptureControl
            cameraControl.frame(maxWidth: .infinity)
            HStack(spacing: 0) {
                refocusControl
                Spacer(minLength: 0)
                magnificationControl
                Spacer(minLength: 0)
                singleFrameControl
                if model.mode != "calibration" { Spacer(minLength: 0); finishControl }
            }.buttonStyle(.plain)
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    Text(model.status).font(.system(size: 12)).fixedSize(horizontal: false, vertical: true)
                        .accessibilityIdentifier("captureStatus")
                    confirmationCue
                    if model.mode == "calibration" {
                        Text("9 × 6 iç köşenin tamamını göster; uygun kareler otomatik kaydedilir.")
                            .font(.caption2).accessibilityIdentifier("calibrationGuidance")
                        Text("Telefonu hafifçe eğin; her yeni açıda kısa süre durun.")
                            .font(.caption2).foregroundStyle(.white.opacity(0.7)).accessibilityIdentifier("calibrationMovementGuidance")
                        if let guidance = model.calibrationGuidance {
                            Text(guidance).font(.caption.bold()).foregroundStyle(.orange)
                                .accessibilityIdentifier("calibrationAdditionalViews")
                        }
                        if calibrationRecordClosed && model.current?.state != "complete" && !model.computing || model.calibrationLimitReached {
                            Text("Başlangıç'ta Yeni kayıt hazırla ile yeniden başlayın.")
                                .font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationNewRecordRequired")
                        }
                        if model.currentID == nil {
                            Button { showingDetails = true } label: {
                                Label(model.physicalBoard ? "Tahta: \(model.squareMM) mm / kare" : "Tahta ölçüsünü ayarla", systemImage: "ruler")
                                    .font(.caption.bold())
                            }.accessibilityIdentifier("calibrationBoardSettings")
                        }
                        Text(model.cameraFocusGuidance).font(.caption2).foregroundStyle(.white.opacity(0.7))
                            .accessibilityIdentifier("cameraFocusGuidance")
                    } else {
                        TimelineView(.periodic(from: .now, by: 1)) { context in
                            let guidance = ScanGuidance.make(feedback: model.feedback, plan: model.plan, markerCount: model.markerCount,
                                mode: model.mode, secondsSinceProgress: model.autoRunning ? context.date.timeIntervalSince(lastProgressDate) : nil)
                            if model.feedback != nil, !guidance.isCoverageReady { compactGuidance(guidance) }
                        }
                        if !model.autoRunning {
                            Text(geometryScope).font(.caption2).foregroundStyle(.white.opacity(0.7))
                                .accessibilityIdentifier("captureGeometryScope")
                        }
                    }
                    if let warning = model.soundStatus {
                        Button { showingDetails = true } label: {
                            Label(warning, systemImage: "speaker.badge.exclamationmark").font(.caption2)
                        }.foregroundStyle(.orange).accessibilityIdentifier("scanSoundWarning")
                    }
                    Text(opticsSummary).font(.caption2).foregroundStyle(.white.opacity(0.65))
                        .accessibilityIdentifier("captureOpticsSummary")
                    if !model.cameraVisible, !model.cameraStarting {
                        Text("Kamerayı açmadan önce hedefi ortala; netlenirken telefonu sabit tut.")
                            .font(.caption2).foregroundStyle(.white.opacity(0.65)).accessibilityIdentifier("cameraTargetBeforeStart")
                    }
                    analyzedThumbnail
                    Text(model.mode == "calibration" && !model.physicalBoard
                         ? "Ekran denemesi · fiziksel doğruluk ölçülmedi" : "Fiziksel doğruluk ölçülmedi")
                        .font(.system(size: 10)).foregroundStyle(.white.opacity(0.5))
                        .accessibilityIdentifier(model.mode == "calibration" && !model.physicalBoard ? "screenCalibrationNote" : "captureAccuracyNote")
                }.frame(maxWidth: .infinity, alignment: .leading).padding(.bottom, 8)
            }.scrollIndicators(.hidden).accessibilityIdentifier("captureRailDetails")
        }.padding(.top, 8).foregroundStyle(.white)
            .accessibilityElement(children: .contain).accessibilityIdentifier("captureControlRail")
    }
    private func acceptedFrameVisible(at date: Date) -> Bool {
        guard model.ready else { return false }
        if model.mode == "calibration" {
            guard let feedback = model.calibrationFeedback, feedback.usable, !feedback.preview,
                  model.calibrationFeedbackImage != nil, let sampled = model.calibrationFeedbackDate else { return false }
            return (0..<0.35).contains(date.timeIntervalSince(sampled))
        }
        guard detectionFrameVisible(at: date), !model.newlyConfirmedIDs.isEmpty,
              let feedback = model.feedback, feedback.usable, !feedback.preview,
              model.feedbackImage != nil, let sampled = model.feedbackDate else { return false }
        return (0..<0.35).contains(date.timeIntervalSince(sampled))
    }
    private func detectionFrameVisible(at date: Date) -> Bool {
        guard model.mode != "calibration" else { return false }
        return ScanDetectionOverlay.isVisible(ready: model.ready, feedback: model.feedback,
            sampledAt: model.feedbackDate, now: date, imageWidth: model.feedbackImage?.cgImage?.width,
            imageHeight: model.feedbackImage?.cgImage?.height)
    }
    @ViewBuilder private var analyzedThumbnail: some View {
        if model.ready {
            if model.mode == "calibration", let feedback = model.calibrationFeedback,
               let image = model.calibrationFeedbackImage, let date = model.calibrationFeedbackDate,
               image.cgImage?.width == feedback.width, image.cgImage?.height == feedback.height {
                sampleThumbnail(date: date) {
                    CalibrationCameraFrameView(feedback: feedback, image: image, orientation: displayOrientation)
                }
            } else if model.mode != "calibration", let feedback = model.feedback,
                      let image = model.feedbackImage, let date = model.feedbackDate,
                      ScanDetectionOverlay.matchesImage(feedback: feedback,
                        imageWidth: image.cgImage?.width, imageHeight: image.cgImage?.height) {
                sampleThumbnail(date: date) {
                    AnalyzedFrameView(feedback: feedback, image: image, plan: model.plan, orientation: displayOrientation)
                }
            }
        }
    }
    private func sampleThumbnail<Content: View>(date: Date, @ViewBuilder content: () -> Content) -> some View {
        let width: CGFloat = displayOrientation.swapsDimensions ? 100 : 160
        let height: CGFloat = displayOrientation.swapsDimensions ? 140 : 90
        return Button { showingDetails = true } label: {
            VStack(spacing: 0) {
                content().frame(width: width, height: height).clipped()
                TimelineView(.periodic(from: .now, by: 1)) { context in
                    VStack(spacing: 2) {
                        Text("SON ANALİZ").font(.system(size: 9, weight: .bold))
                        Text("\(max(0, Int(context.date.timeIntervalSince(date)))) sn önce · sabit kare")
                            .font(.system(size: 8)).monospacedDigit()
                    }.frame(width: width).padding(.vertical, 5)
                }
            }.background(.black.opacity(0.86)).clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(.white.opacity(0.35), lineWidth: 1))
        }.buttonStyle(.plain).foregroundStyle(.white)
            .accessibilityLabel("Son analiz edilen sabit kareyi ayrıntılı incele")
            .accessibilityIdentifier("analyzedSampleThumbnail")
    }
    private var confirmationCue: some View {
        TimelineView(.animation(minimumInterval: 0.1, paused: !model.ready)) { context in
            if acceptedFrameVisible(at: context.date) {
                Label(model.mode == "calibration" ? "Uygun kare kaydedildi" : "Bayrak onaylandı: " + model.newlyConfirmedIDs.map(String.init).joined(separator: ", "),
                      systemImage: "checkmark.circle.fill")
                    .font(.caption.bold()).foregroundStyle(.green).accessibilityIdentifier("acceptedFrameCue")
            }
        }
    }
    private var cameraHeader: some View {
        VStack(alignment: .leading, spacing: 10) {
            headerControls
            Label("Geniş çekim için telefonu yatay tut", systemImage: "rotate.right")
                .font(.system(size: 11, weight: .semibold)).foregroundStyle(.mint)
                .accessibilityIdentifier("captureLandscapeGuidance")
            Text(opticsSummary).font(.system(size: 12, weight: .medium)).foregroundStyle(.white.opacity(0.75))
                .lineLimit(2).accessibilityIdentifier("captureOpticsSummary")
            if model.mode == "calibration" { calibrationProgress }
            else { scanProgress }
        }.padding(.horizontal, 16).padding(.top, 6).padding(.bottom, 18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [.black.opacity(0.94), .black.opacity(0.72), .clear], startPoint: .top, endPoint: .bottom))
            .foregroundStyle(.white)
    }
    private var headerControls: some View {
        HStack(spacing: 6) {
            VStack(alignment: .leading, spacing: 5) {
                Text(captureTitle).font(.subheadline.bold()).lineLimit(1).minimumScaleFactor(0.8)
                HStack(spacing: 5) {
                    Circle().fill(model.autoRunning ? Color.mint : Color.white.opacity(0.5)).frame(width: 5, height: 5)
                    Text(cameraStatus).font(.system(size: 9, weight: .bold)).lineLimit(1)
                    Text("Bu iPhone").font(.system(size: 9)).foregroundStyle(.white.opacity(0.6))
                        .accessibilityIdentifier("localCaptureEngine")
                }
            }.frame(maxWidth: .infinity, alignment: .leading)
            soundControl
            torchControl
            detailsControl
        }.buttonStyle(.plain)
    }
    private var soundControl: some View {
        Button(action: model.toggleSound) {
                Image(systemName: model.soundEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill")
                    .font(.system(size: 17)).frame(width: 44, height: 44)
                    .foregroundStyle(model.soundStatus == nil ? Color.white : Color.orange)
                    .background(.white.opacity(0.1), in: Circle())
            }.accessibilityLabel(model.soundEnabled ? "Sesi kapat" : "Sesi aç")
                .accessibilityValue(model.soundEnabled ? "Açık" : "Kapalı").accessibilityIdentifier("scanSoundToggle")
                .buttonStyle(.plain)
    }
    private var torchControl: some View {
        Button(action: model.toggleTorch) {
                Image(systemName: (model.cameraVisible ? model.torchStatus.isOn : model.torchEnabled) ? "flashlight.on.fill" : "flashlight.off.fill")
                    .font(.system(size: 17)).frame(width: 44, height: 44)
                    .foregroundStyle((model.cameraVisible ? model.torchStatus.isOn : model.torchEnabled) ? Color.yellow : Color.white)
                    .background(.white.opacity(0.1), in: Circle())
            }.accessibilityLabel(torchControlLabel).accessibilityIdentifier("scanTorchToggle")
                .accessibilityValue(model.cameraVisible ? (model.torchStatus.isOn ? "Açık" : "Kapalı") : (model.torchEnabled ? "Başlangıçta açılacak" : "Kapalı"))
                .disabled(model.illuminationChanging || model.cameraStarting || model.computing)
                .buttonStyle(.plain)
    }
    private var detailsControl: some View {
        Button { showingDetails = true } label: {
                Image(systemName: "ellipsis").font(.system(size: 18, weight: .bold)).frame(width: 44, height: 44)
                    .background(.white.opacity(0.1), in: Circle())
            }.accessibilityLabel("Çekim ayrıntılarını aç").accessibilityIdentifier("captureDetails")
            .buttonStyle(.plain)
    }
    private var calibrationProgress: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text("\(calibrationFrames)/\(model.calibrationTarget) uygun kare").accessibilityIdentifier("calibrationFrameCount")
                Spacer()
                Text("\(model.calibrationFeedback?.cornerCount ?? 0)/54 iç köşe").accessibilityIdentifier("calibrationCornerCount")
            }.font(.caption.bold()).monospacedDigit()
            ProgressView(value: min(1, Double(calibrationFrames) / Double(max(1, model.calibrationTarget)))).tint(.mint)
            Text(model.cameraStarting ? "Tahtayı ortala ve sabit tut; kamera netleniyor."
                 : "9 × 6 iç köşenin tamamını göster; uygun kareler otomatik kaydedilir.")
                .font(.caption2).accessibilityIdentifier("calibrationGuidance")
            Text("Telefonu hafifçe eğin; her yeni açıda kısa süre durun.")
                .font(.caption2).foregroundStyle(.white.opacity(0.75)).accessibilityIdentifier("calibrationMovementGuidance")
            if let guidance = model.calibrationGuidance {
                Text(guidance).font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationAdditionalViews")
            }
            if (calibrationRecordClosed && model.current?.state != "complete" && !model.computing) || model.calibrationLimitReached {
                Text("Başlangıç'ta Yeni kayıt hazırla ile yeniden başlayın.")
                    .font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationNewRecordRequired")
            }
        }
    }
    private var selectedCompletedCount: Int {
        Set(model.feedback?.completedIDs ?? []).intersection(model.selectedMarkerIDs).count
    }
    private var scanProgress: some View {
        VStack(spacing: 9) {
            HStack {
                Text("\(selectedCompletedCount)/\(model.markerCount) bayrak tamamlandı").monospacedDigit()
                Spacer()
                NavigationLink { DentalPlanView().toolbar(.visible, for: .navigationBar) } label: {
                    HStack(spacing: 4) { Text("FDI planı"); Image(systemName: "chevron.right").font(.system(size: 9, weight: .bold)) }
                }.accessibilityLabel("FDI planını aç").foregroundStyle(.mint)
                    .disabled(model.autoRunning || model.cameraStarting || model.computing)
            }.font(.caption.bold()).accessibilityElement(children: .contain).accessibilityIdentifier("coveragePanel")
            HStack(spacing: 5) {
                ForEach(model.selectedMarkerIDs, id: \.self) { id in flagProgress(id: id) }
            }.accessibilityElement(children: .contain).accessibilityIdentifier("confirmedFlagIDs")
            if !model.autoRunning {
                Text(geometryScope).font(.system(size: 10)).foregroundStyle(.white.opacity(0.75))
                    .frame(maxWidth: .infinity, alignment: .leading).accessibilityIdentifier("captureGeometryScope")
            }
        }
    }
    private func flagProgress(id: Int) -> some View {
        let done = model.feedback?.completedIDs.contains(id) == true
        let target = model.feedback?.targetViews ?? (model.mode == "trial" ? 1 : 8)
        let views = model.feedback?.views[id] ?? 0
        let tooth = model.plan.tooth(for: id).map { "FDI \($0)" } ?? "ID \(id)"
        return VStack(spacing: 4) {
            ZStack {
                Circle().fill(done ? Color.green.opacity(0.15) : Color.black.opacity(0.35))
                Circle().stroke(.white.opacity(0.18), lineWidth: 2.5)
                Circle().trim(from: 0, to: min(1, Double(views) / Double(max(1, target))))
                    .stroke(done ? Color.green : Color.cyan, style: StrokeStyle(lineWidth: 2.5, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                if done { Image(systemName: "checkmark").font(.system(size: 15, weight: .bold)).foregroundStyle(.green) }
                else { Text("\(id)").font(.system(size: 14, weight: .semibold, design: .rounded)) }
            }.frame(width: 35, height: 35)
            Text(tooth).font(.system(size: 9, weight: .medium)).lineLimit(1).minimumScaleFactor(0.8)
            Text(done ? "TAMAM" : "\(views)/\(target)").font(.system(size: 8, weight: .bold)).monospacedDigit()
                .foregroundStyle(done ? Color.green : Color.white.opacity(0.6))
        }.frame(maxWidth: .infinity).accessibilityElement(children: .ignore)
            .accessibilityLabel("Bayrak \(id), \(tooth): \(done ? "tamamlandı" : "\(views)/\(target) görünüm")")
            .accessibilityIdentifier("flagProgress_\(id)")
    }
    private func cameraFooter(date: Date) -> some View {
        let guidance = ScanGuidance.make(feedback: model.feedback, plan: model.plan, markerCount: model.markerCount,
            mode: model.mode, secondsSinceProgress: model.autoRunning ? date.timeIntervalSince(lastProgressDate) : nil)
        return VStack(spacing: 8) {
            confirmationCue
            if let fps = model.cameraPerformance?.framesPerSecond {
                HStack {
                    Text(String(format: "Kamera %.0f FPS", fps))
                    Spacer()
                    if let cycle = model.cycleSeconds, cycle > 0 {
                        Text(String(format: "Analiz %.1f örnek/sn", 1 / cycle))
                    }
                }.font(.system(size: 10, weight: .medium)).monospacedDigit().foregroundStyle(.white.opacity(0.7))
                    .accessibilityIdentifier("liveCapturePerformance")
            }
            Text(model.status).font(.caption).lineLimit(2).frame(maxWidth: .infinity, alignment: .leading)
                .accessibilityIdentifier("captureStatus")
            if !model.cameraVisible, !model.cameraStarting {
                Text("Kamerayı açmadan önce hedefi ortala; netlenirken telefonu sabit tut.")
                    .font(.caption2).frame(maxWidth: .infinity, alignment: .leading)
                    .accessibilityIdentifier("cameraTargetBeforeStart")
            }
            if let soundWarning = model.soundStatus {
                Button { showingDetails = true } label: {
                    Label(soundWarning, systemImage: "speaker.badge.exclamationmark")
                        .font(.caption2).lineLimit(2).frame(maxWidth: .infinity, alignment: .leading)
                }.buttonStyle(.plain).foregroundStyle(.orange).accessibilityIdentifier("scanSoundWarning")
            }
            if model.mode != "calibration", model.feedback != nil, !guidance.isCoverageReady {
                compactGuidance(guidance)
            }
            if model.mode == "calibration" {
                if model.currentID == nil {
                    Button { showingDetails = true } label: {
                        Label(model.physicalBoard ? "Tahta: \(model.squareMM) mm / kare" : "Tahta ölçüsünü ayarla", systemImage: "ruler")
                            .font(.caption.bold())
                    }.buttonStyle(.plain).accessibilityIdentifier("calibrationBoardSettings")
                }
                Text(model.cameraFocusGuidance).font(.caption2).lineLimit(3)
                    .frame(maxWidth: .infinity, alignment: .leading).accessibilityIdentifier("cameraFocusGuidance")
            }
            captureControls
            Text(model.mode == "calibration"
                 ? (!model.physicalBoard ? "Ekran denemesi · fiziksel doğruluk ölçülmedi" : "Yeşil = uygun kare · fiziksel doğruluk ölçülmedi")
                 : "Yeşil nokta: tanıma · ✓: kapsam · doğruluk ölçülmedi")
                .font(.system(size: 10)).foregroundStyle(.white.opacity(0.75))
                .accessibilityIdentifier(model.mode == "calibration" && !model.physicalBoard ? "screenCalibrationNote" : "captureAccuracyNote")
        }.padding(.horizontal, 18).padding(.top, 22).padding(.bottom, 10)
            .background(LinearGradient(colors: [.clear, .black.opacity(0.8), .black.opacity(0.95)], startPoint: .top, endPoint: .bottom))
            .foregroundStyle(.white)
    }
    private func compactGuidance(_ guidance: ScanGuidance) -> some View {
        VStack {
            Button { showingDetails = true } label: {
                HStack(spacing: 9) {
                    Image(systemName: guidance.isStalled ? "exclamationmark.circle" : "viewfinder").font(.title3)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(guidance.title).font(.caption.bold())
                        Text(guidance.action).font(.caption2).lineLimit(2)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                    Image(systemName: "chevron.right").font(.caption.bold())
                }.foregroundStyle(guidance.isStalled ? Color.orange : Color.white)
                    .padding(10).background(.black.opacity(0.6), in: RoundedRectangle(cornerRadius: 14))
            }.buttonStyle(.plain).accessibilityLabel("\(guidance.title). \(guidance.action). Ayrıntıları incele")
                .accessibilityIdentifier("inspectRecognition")
        }.accessibilityElement(children: .contain).accessibilityIdentifier("liveScanGuidance")
    }
    private var captureControls: some View {
        VStack(spacing: 8) {
            primaryCaptureControl
            secondaryControls
        }
    }
    @ViewBuilder private var primaryCaptureControl: some View {
        if model.mode == "calibration" {
                Button {
                    if model.autoRunning { model.pauseAutomatic() } else { model.beginCalibrationScan() }
                } label: {
                    Label(calibrationButtonTitle, systemImage: model.autoRunning ? "pause.fill" : "checkerboard.rectangle")
                        .font(.subheadline.bold()).lineLimit(2).minimumScaleFactor(0.85)
                        .frame(maxWidth: .infinity).padding(.vertical, 7)
                }.buttonStyle(.borderedProminent).tint(.mint).controlSize(.large)
                    .foregroundStyle(calibrationUnavailable ? Color.white : Color.black)
                    .accessibilityIdentifier("autoCalibration").disabled(calibrationUnavailable)
            } else {
                Button {
                    if model.autoRunning { model.pauseAutomatic() } else { model.startGuidedScan() }
                } label: {
                    Label(scanButtonTitle, systemImage: model.autoRunning ? "pause.fill" : "viewfinder")
                        .font(.subheadline.bold()).lineLimit(2).minimumScaleFactor(0.85)
                        .frame(maxWidth: .infinity).padding(.vertical, 7)
                }.buttonStyle(.borderedProminent).tint(.mint).controlSize(.large)
                    .foregroundStyle(autoUnavailable ? Color.white : Color.black).accessibilityIdentifier("autoScan").disabled(autoUnavailable)
            }
    }
    private var secondaryControls: some View {
        HStack(spacing: 5) {
            cameraControl
            Spacer(minLength: 0)
            refocusControl
            magnificationControl
            singleFrameControl
            if model.mode != "calibration" { finishControl }
        }.buttonStyle(.plain).foregroundStyle(.white.opacity(0.9))
    }
    private var refocusControl: some View {
        Button(action: model.refocusCamera) {
                Image(systemName: "scope").font(.title3).frame(width: 44, height: 44)
            }.accessibilityLabel("Yeniden netle").accessibilityIdentifier("refocusCamera").disabled(!model.canRefocus)
    }
    private var magnificationControl: some View {
        Button { focusAssist.toggle() } label: {
                VStack(spacing: 1) {
                    Text(focusAssist ? "2×" : "1×").font(.subheadline.bold())
                    Text("ekran").font(.system(size: 8))
                }.frame(width: 44, height: 44)
            }.accessibilityLabel(focusAssist ? "2× ekran büyütme" : "1× ekran büyütme")
                .accessibilityHint("Yalnız önizlemeyi büyütür; lensi ve kaydedilen görüntüyü değiştirmez.")
                .accessibilityIdentifier("focusAssist")
    }
    @ViewBuilder private var singleFrameControl: some View {
        if model.mode == "calibration" {
                Button(action: model.takePhoto) {
                    Image(systemName: "camera.aperture").font(.title3).frame(width: 44, height: 44)
                }.accessibilityLabel("Görüntüyü kaydet").accessibilityIdentifier("calibrationCapture")
                    .disabled(!model.ready || working || model.autoRunning || model.calibrationLimitReached || calibrationRecordClosed)
            } else {
                Button(action: model.takePhoto) {
                    Image(systemName: "camera.aperture").font(.title3).frame(width: 44, height: 44)
                }.accessibilityLabel("Görüntüyü kaydet").accessibilityIdentifier("scanSingleFrame")
                    .disabled(!model.ready || working || model.autoRunning)
        }
    }
    private var finishControl: some View {
        Button(action: finish) {
                    Image(systemName: "checkmark.circle").font(.title3).frame(width: 44, height: 44)
                }.accessibilityLabel(model.computing ? "iPhone hesaplıyor…" : "Hesapla / deneyi tamamla")
                    .accessibilityIdentifier("finishScan").disabled(working || model.autoRunning || model.current == nil)
    }
    private var captureDetails: some View {
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(model.mode == "scan" ? "3B araştırma" : model.mode == "calibration" ? "Kalibrasyon" : "Bayrak deneyi · 2B").font(.headline)
                        Text(model.mode == "calibration" ? "DentalArchLab / 9 × 6 iç köşe" : "DentalArchLab / \(model.markerCount) bayrak").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    VStack(alignment: .trailing, spacing: 4) {
                        Label("Bu iPhone", systemImage: "cpu").foregroundStyle(.mint).accessibilityIdentifier("localCaptureEngine")
                        if let t = model.analysisSeconds { Text(String(format: "Yanıt %.2f sn", t)).monospacedDigit() }
                        if let ms = model.detectorMilliseconds { Text(String(format: "Tanıma %.0f ms", ms)).monospacedDigit() }
                    }.font(.caption)
                }
                if model.mode == "calibration" { calibrationGuidance }
                else { coverage }
                Text(model.status).font(.callout).frame(maxWidth: .infinity, alignment: .leading)
                    .padding(14).background(.white.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 16))
                soundAndLightDetails
                opticsDetails
                if let performance = model.cameraPerformance {
                    VStack(alignment: .leading, spacing: 5) {
                        Label("Kamera akışı", systemImage: "speedometer").font(.callout.bold())
                        if let fps = performance.framesPerSecond {
                            Text(String(format: "Gerçek kamera akışı: %.1f FPS", fps)).font(.caption.monospacedDigit())
                        }
                        Text("Düşen kamera karesi: \(performance.droppedFrames)").font(.caption.monospacedDigit())
                        if let milliseconds = performance.encodingMilliseconds {
                            Text(String(format: "Son görüntü hazırlama: %.0f ms", milliseconds)).font(.caption.monospacedDigit())
                        }
                        Text("Kamera FPS'i canlı görüntü akışıdır. Analiz örnek/sn değeri, bayrak hesabının hızıdır; aynı değer değildir.")
                            .font(.caption2).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                        .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
                        .accessibilityIdentifier("cameraPerformanceDetails")
                }
                if model.mode != "calibration" {
                    Text(geometryScope).font(.caption).foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading).accessibilityIdentifier("captureGeometryScope")
                    Text(model.mode == "trial" ? "Her bayrak bir kez onaylanır; tamamlanınca sonuç açılır."
                         : "\(model.current?.acceptedCount ?? 0)/24 kare · her bayrak en az 8 farklı görünüm. Sonuç otomatik açılır.")
                        .font(.caption).frame(maxWidth: .infinity, alignment: .leading)
                }
                if model.mode == "calibration", let feedback = model.calibrationFeedback,
                   let image = model.calibrationFeedbackImage, let date = model.calibrationFeedbackDate {
                    CalibrationAnalyzedFrameView(feedback: feedback, image: image, date: date, orientation: displayOrientation)
                }
                if model.mode == "calibration", model.currentID == nil {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Fiziksel kalibrasyon tahtası").font(.headline)
                        Toggle("Tahtadaki kare boyutunu ölçtüm", isOn: $model.physicalBoard)
                            .accessibilityIdentifier("capturePhysicalBoard")
                        if model.physicalBoard {
                            TextField("Bir kare kenarı (mm)", text: $model.squareMM).keyboardType(.decimalPad)
                                .textFieldStyle(.roundedBorder).accessibilityIdentifier("captureSquareMM")
                        }
                        Text("10 × 7 kare, 9 × 6 iç köşe. Birkaç karelik toplam uzunluğu kare sayısına böl. XYZ için düz, fiziksel ve ölçülmüş tahta gerekir.")
                            .font(.caption).foregroundStyle(.secondary)
                    }.padding(12).background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
                        .disabled(model.ready || working || model.cameraStarting)
                }
                if let diagnostic = model.cameraDiagnostic {
                    DisclosureGroup("Kamera hata ayrıntıları") {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(diagnostic).font(.caption.monospaced()).textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            Button {
                                UIPasteboard.general.string = diagnostic
                            } label: {
                                Label("Ayrıntıları kopyala", systemImage: "doc.on.doc")
                            }.buttonStyle(.bordered).accessibilityIdentifier("copyCameraDiagnostic")
                        }.padding(.top, 8)
                    }.font(.callout).accessibilityIdentifier("cameraDiagnostics")
                }
                if let feedback = model.feedback, model.mode != "calibration" {
                    VStack(alignment: .leading, spacing: 7) {
                        HStack {
                            Label("Son kare: \(feedback.markers.count)/\(model.markerCount) bayrak", systemImage: "viewfinder")
                            Spacer()
                            Text("Yerel analiz").foregroundStyle(.mint)
                        }.font(.caption.bold())
                        if !feedback.missingInSample.isEmpty {
                            Text("Bu karede eksik: " + feedback.missingInSample.map { id in
                                model.plan.tooth(for: id).map { "FDI \($0)" } ?? "ID \(id)"
                            }.joined(separator: ", ")).font(.caption).foregroundStyle(.orange)
                        }
                        if let hint = feedback.hint, !feedback.usable { Text(hint).font(.caption).foregroundStyle(.secondary) }
                        let advice = ScanGuidance.make(feedback: feedback, plan: model.plan, markerCount: model.markerCount, mode: model.mode)
                        Text(advice.detail).font(.caption)
                        Text(advice.action).font(.caption.bold()).foregroundStyle(.orange)
                        Text("\(feedback.candidateCount) nokta grubu · \(feedback.markers.count) doğrulanmış kimlik").font(.caption2)
                        if let seconds = model.cycleSeconds {
                            Text(String(format: "Son örnek döngüsü %.2f sn · kamera, analiz ve kayıt", seconds)).font(.caption2).foregroundStyle(.secondary)
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                        .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 14))
                        .accessibilityIdentifier("recognitionDiagnostics")
                }
                if model.mode != "calibration" {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("Tanıma raporu", systemImage: "doc.text.magnifyingglass").font(.headline)
                        Text("Son analiz edilen fotoğrafı, gerçek kamera ayarlarını ve ret nedenlerini kaydeder. Rapor fotoğraf içerir; yalnız Paylaş'a bastığınızda seçtiğiniz yere gönderilir.")
                            .font(.caption).foregroundStyle(.secondary)
                        Button(action: model.prepareRecognitionReport) { Label("Tanıma raporu hazırla", systemImage: "doc.badge.plus") }
                            .buttonStyle(.bordered).disabled(!model.canPrepareRecognitionReport).accessibilityIdentifier("prepareRecognitionReport")
                        if let url = model.diagnosticFileURL {
                            ShareLink(item: url) { Label("Tanıma raporunu paylaş", systemImage: "square.and.arrow.up") }
                                .accessibilityIdentifier("shareRecognitionReport")
                        }
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                        .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 14))
                }
                if model.mode != "calibration" {
                    HStack {
                        Text("\(model.current?.acceptedCount ?? 0) uygun kare").font(.caption)
                        Spacer()
                        Button(action: model.takePhoto) { Label("Tek kare", systemImage: "camera.aperture") }
                            .buttonStyle(.bordered).accessibilityLabel("Görüntüyü kaydet").disabled(!model.ready || working || model.autoRunning)
                    }
                }
                VStack(alignment: .leading, spacing: 9) {
                    Label("Otomatik odak", systemImage: "viewfinder").font(.callout.bold())
                    Text(model.cameraFocusGuidance).font(.caption).foregroundStyle(.secondary)
                        .accessibilityIdentifier("cameraFocusGuidance")
                    if model.mode == "calibration" {
                        Text("Başlangıçta kamera otomatik netlenir; kalibrasyon boyunca aynı odak korunur.")
                            .font(.caption2).foregroundStyle(.secondary)
                            .accessibilityIdentifier("calibrationFocusExplanation")
                    }
                    Button(action: model.refocusCamera) {
                        Label("Yeniden netle", systemImage: "scope")
                    }.buttonStyle(.bordered).accessibilityIdentifier("refocusCamera")
                        .disabled(!model.canRefocus)
                }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
                    .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 14))
                if model.pendingCount > 0 {
                    Button("Kayıtlı kareleri işle (\(model.pendingCount))") { Task { await model.sendPending() } }.disabled(working || model.autoRunning)
                }
                if model.mode == "calibration" {
                    Text("Yeterli farklı açı toplandığında kalibrasyon otomatik hesaplanır. Gerekirse ek açılar istenir.")
                        .font(.caption).foregroundStyle(.secondary).accessibilityIdentifier("automaticCalibrationExplanation")
                } else {
                    Button(model.computing ? "iPhone hesaplıyor…" : "Hesapla / deneyi tamamla", action: finish)
                        .buttonStyle(.bordered).disabled(working || model.autoRunning || model.current == nil)
                }
                if model.mode != "calibration", let feedback = model.feedback, let image = model.feedbackImage, let date = model.feedbackDate {
                    DisclosureGroup("Son analizi ayrıntılı incele") {
                        FeedbackCard(feedback: feedback, image: image, date: date, orientation: displayOrientation)
                    }
                }
                if model.mode != "calibration" {
                    Text("Canlı görüntü sürekli akar. Üzerindeki noktalar en fazla 0,25 sn yaşındaki son örneğe aittir; hareket takibi değildir. Daha eski tanımalar yalnız Son analiz kutusundaki kendi sabit karesinde gösterilir. Yeşil = kaydedilen tanıma; üstte ✓ = görüntü kapsamı tamam. Fiziksel doğruluk ölçülmedi.").font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(18)
        }.background(Color(red: 0.035, green: 0.065, blue: 0.11)).preferredColorScheme(.dark)
    }
    private var soundAndLightDetails: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Ses ve ışık", systemImage: "speaker.wave.2.fill").font(.headline)
            HStack(spacing: 10) {
                Button(action: model.toggleSound) {
                    Label(model.soundEnabled ? "Ses açık" : "Ses kapalı",
                          systemImage: model.soundEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill")
                }.buttonStyle(.bordered).accessibilityIdentifier("detailsSoundToggle")
                Button(action: model.testScanSound) {
                    Label("Sesi dene", systemImage: "play.fill")
                }.buttonStyle(.bordered).accessibilityIdentifier("testScanSound").disabled(!model.soundEnabled)
            }.font(.caption.bold())
            if let status = model.soundStatus {
                Text(status).font(.caption).foregroundStyle(.orange).accessibilityIdentifier("scanSoundStatus")
            }
            Text("Ses duyulmuyorsa iPhone'un medya sesini yükselt ve Bluetooth ses çıkışını kontrol et. Ses denemesi bayrak onayı sayılmaz.")
                .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("scanSoundHelp")
            Divider()
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: model.torchStatus.isOn ? "flashlight.on.fill" : "flashlight.off.fill")
                    .foregroundStyle(model.torchStatus.isOn ? Color.yellow : Color.secondary)
                VStack(alignment: .leading, spacing: 4) {
                    Text(model.cameraVisible ? (model.torchStatus.isOn ? "Kamera ışığı açık" : "Kamera ışığı kapalı")
                         : model.torchEnabled ? "Kamera açılırken ışık açılacak" : "Kamera açılırken ışık kapalı kalacak")
                        .font(.caption.bold())
                    Text(model.torchStatus.message).font(.caption2).foregroundStyle(.secondary)
                        .accessibilityIdentifier("scanTorchStatus")
                }
            }
            Text("Üstteki fener düğmesi sürekli kamera ışığını değiştirir. Parlama görürsen ışığı kapatıp farklı bir açı dene.")
                .font(.caption2).foregroundStyle(.secondary)
        }.frame(maxWidth: .infinity, alignment: .leading).padding(14)
            .background(.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 16))
    }
    private var opticsDetails: some View {
        VStack(alignment: .leading, spacing: 7) {
            Label("Lens ve yakın netlik", systemImage: "camera.macro").font(.callout.bold())
            Text(opticsSummary).font(.caption).accessibilityIdentifier("cameraLensDetails")
            if model.cameraVisible, let optics = model.opticsStatus {
                Text("Sensör akışı: \(optics.sensorWidth) × \(optics.sensorHeight) px · işlenen kayıt: \(optics.outputWidth) × \(optics.outputHeight) px")
                    .font(.caption.monospacedDigit()).accessibilityIdentifier("cameraResolutionDetails")
                if let minimum = optics.minimumFocusDistanceMM, minimum > 0 {
                    Text("Lensin bildirdiği minimum netleme mesafesi \(minimum) mm. Bu değer, seçilen sabit odakta netlik garantisi değildir; hedefin netliğini görüntüde kontrol et.")
                        .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("cameraMinimumFocus")
                } else {
                    Text("Bu lens minimum netleme mesafesi bildirmedi. Hedefin netliğini görüntüde kontrol et.")
                        .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("cameraMinimumFocus")
                }
            }
            Text("Yakın çekim için Başlangıç'ta lens tercihini seç ve o lensle yeni kalibrasyon yap. 3B taramada seçilen kalibrasyonun lensi ve odağı korunur; her uzaklıkta netlik bekleme.")
                .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("cameraOpticsCalibrationScope")
            Text("1× / 2× ekran büyütme yalnız önizlemeyi kırpar. Kaydedilen kareyi, çözünürlüğü ve fiziksel odak uzaklığını değiştirmez.")
                .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("previewMagnificationScope")
        }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
            .background(.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 14))
    }
    private var cameraControl: some View {
        Button {
            if model.cameraVisible || model.cameraStarting { model.stopCamera() } else { model.prepareCameraPreview() }
        } label: {
            HStack(spacing: 6) {
                if model.cameraStarting { ProgressView().controlSize(.small).accessibilityHidden(true) }
                Label(model.cameraStarting ? "İptal" : model.cameraVisible ? "Kapat" : "Kamerayı aç",
                      systemImage: model.cameraStarting ? "xmark" : model.cameraVisible ? "camera.fill" : "camera")
            }.font(.subheadline.bold()).padding(.vertical, 9)
        }.buttonStyle(.bordered).accessibilityIdentifier("cameraControl")
            .disabled(!model.cameraStarting && (model.busy || model.computing || (model.analyzing && !model.cameraVisible)))
    }
    private var calibrationGuidance: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("\(calibrationFrames)/\(model.calibrationTarget) uygun kare")
                    .font(.subheadline.bold()).monospacedDigit().accessibilityIdentifier("calibrationFrameCount")
                Spacer()
                Text("\(model.calibrationFeedback?.cornerCount ?? 0)/54 iç köşe")
                    .font(.caption.monospacedDigit()).accessibilityIdentifier("calibrationCornerCount")
            }
            ProgressView(value: min(1, Double(calibrationFrames) / Double(max(1, model.calibrationTarget))))
                .tint(.mint).accessibilityLabel("Toplanan kalibrasyon kareleri")
            if model.calibrationLimitReached || (calibrationRecordClosed && model.current?.state != "complete" && !model.computing) {
                Text("Bu kayıt çekime kapalı. Başlangıç sekmesinde Yeni kayıt hazırla ile yeniden başlayın.")
                    .font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationNewRecordRequired")
            }
            if let guidance = model.calibrationGuidance {
                Label(guidance, systemImage: "arrow.triangle.2.circlepath")
                    .font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationAdditionalViews")
            } else if calibrationFrames >= model.calibrationTarget && model.current?.state == "collecting" && !model.computing {
                Text("Ek açı gerekli").font(.caption.bold()).foregroundStyle(.orange).accessibilityIdentifier("calibrationAdditionalViews")
            }
            Text("Başlat'a basın; kamera açılır, uygun görüntüler otomatik kaydedilir. Tahtanın 9 × 6 iç köşesinin tamamı görünsün.")
                .font(.caption).accessibilityIdentifier("calibrationGuidance")
            Text("Tahtayı sabit tutun. Telefonu sağa, sola, yukarı ve aşağı kaydırıp hafifçe eğin; her yeni açıda kısa süre durun.")
                .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("calibrationMovementGuidance")
            if !model.physicalBoard {
                Text("Ekrandaki tahta yalnız deneme içindir; fiziksel ölçek ve ölçüm doğruluğu doğrulanmaz.")
                    .font(.caption2).foregroundStyle(.secondary).accessibilityIdentifier("screenCalibrationNote")
            }
        }.frame(maxWidth: .infinity, alignment: .leading).padding(12)
            .background(.white.opacity(0.05)).clipShape(RoundedRectangle(cornerRadius: 12))
    }
    private var coverage: some View {
        VStack(spacing: 12) {
            HStack(spacing: 16) {
                ZStack {
                    Circle().stroke(.white.opacity(0.12), lineWidth: 6)
                    Circle().trim(from: 0, to: model.feedback?.fraction ?? 0).stroke(.mint, style: StrokeStyle(lineWidth: 6, lineCap: .round)).rotationEffect(.degrees(-90))
                    Text("\(Int((model.feedback?.fraction ?? 0) * 100))%").font(.headline.monospacedDigit())
                }.frame(width: 60, height: 60)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Görüntü kapsamı").font(.subheadline.bold())
                    Text("\(selectedCompletedCount)/\(model.markerCount) bayrak tamamlandı").font(.caption)
                    Text("Kırmızı: görülmedi · Sarı: eksik · Yeşil: kapsam").font(.system(size: 10)).foregroundStyle(.secondary)
                }
                Spacer()
                NavigationLink { DentalPlanView() } label: { Image(systemName: "slider.horizontal.3") }.accessibilityLabel("FDI planını aç")
            }
            OdontogramView(plan: model.plan, views: model.feedback?.views ?? [:], target: model.feedback?.targetViews ?? 4)
            if model.plan.assignments.contains(where: { $0.fdi == nil }) {
                NavigationLink("Önce FDI dişlerini seç") { DentalPlanView() }.font(.caption.bold())
            }
        }.padding(14).background(.white.opacity(0.06)).clipShape(RoundedRectangle(cornerRadius: 20))
            .accessibilityElement(children: .contain).accessibilityIdentifier("coveragePanel")
    }
}

/// Original, static composition guide. It never represents tracked anatomy or marker poses.
private struct ArchFramingGuide: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addCurve(to: CGPoint(x: rect.midX, y: rect.maxY),
                      control1: CGPoint(x: rect.width * 0.04, y: rect.height * 0.76),
                      control2: CGPoint(x: rect.width * 0.20, y: rect.maxY))
        path.addCurve(to: CGPoint(x: rect.maxX, y: rect.minY),
                      control1: CGPoint(x: rect.width * 0.80, y: rect.maxY),
                      control2: CGPoint(x: rect.width * 0.96, y: rect.height * 0.76))
        return path
    }
}

/// Transient last-sample hints, never a frozen image or a tracked AR overlay.
/// Expiry is scheduled once per capture timestamp, outside the native preview.
private struct RecentSamplePointsView: View {
    let feedback: LiveFeedback?
    let ready: Bool
    let captureUptime: TimeInterval?
    let imageWidth: Int?
    let imageHeight: Int?
    let previewZoom: Double
    let orientation: CameraDisplayOrientation
    @State private var presenting = false
    private var sampleIdentity: String {
        "\(ready)-\(feedback?.sampleID ?? "none")-\(captureUptime ?? -1)-\(imageWidth ?? 0)-\(imageHeight ?? 0)"
    }
    private var remainingTime: TimeInterval {
        ScanDetectionOverlay.remainingLiveTime(ready: ready, feedback: feedback, captureUptime: captureUptime,
            nowUptime: ProcessInfo.processInfo.systemUptime, imageWidth: imageWidth, imageHeight: imageHeight)
    }
    var body: some View {
        GeometryReader { geometry in
            if presenting, remainingTime > 0, let feedback {
                ZStack {
                    Canvas { context, size in
                        let color: Color = feedback.usable && !feedback.preview ? .green : .orange
                        let centers = ScanDetectionOverlay.liveCenters(feedback: feedback,
                            viewWidth: size.width, viewHeight: size.height, previewZoom: previewZoom, orientation: orientation)
                        for point in centers {
                            let ring = Path(ellipseIn: CGRect(x: point.x - 5, y: point.y - 5, width: 10, height: 10))
                            context.stroke(ring, with: .color(color), lineWidth: 2)
                        }
                    }
                    Text("SON ÖRNEK · <0,25 sn").font(.system(size: 9, weight: .medium))
                        .foregroundStyle(.white).padding(.horizontal, 6).padding(.vertical, 3)
                        .background(.black.opacity(0.5), in: Capsule())
                        .position(x: geometry.size.width / 2, y: geometry.size.height * 0.28)
                }.accessibilityIdentifier("recentSamplePoints")
            }
        }.allowsHitTesting(false)
            .task(id: sampleIdentity) {
                presenting = false
                let remaining = remainingTime
                guard remaining > 0 else { return }
                presenting = true
                do { try await Task.sleep(nanoseconds: UInt64(remaining * 1_000_000_000)) }
                catch { return }
                guard !Task.isCancelled else { return }
                presenting = false
            }
    }
}

/// Preview only: frame capture keeps the original sensor pixels and coordinates.
private struct FullScreenCameraPreview: UIViewControllerRepresentable {
    let session: AVCaptureSession
    @Binding var orientation: CameraDisplayOrientation
    func makeUIViewController(context: Context) -> CameraPreviewController {
        let controller = CameraPreviewController()
        controller.preview.session = session
        controller.preview.videoGravity = .resizeAspectFill
        return controller
    }
    func updateUIViewController(_ controller: CameraPreviewController, context: Context) {
        controller.orientationChanged = { value in
            if orientation != value { orientation = value }
        }
        controller.synchronizeOrientation()
    }
}

/// Observe the actual interface orientation, including 180° landscape flips
/// whose width and height are identical. Only the preview connection rotates.
private final class CameraPreviewController: UIViewController {
    private let previewView = PreviewView()
    var preview: AVCaptureVideoPreviewLayer { previewView.preview }
    var orientationChanged: ((CameraDisplayOrientation) -> Void)?
    private var lastOrientation: CameraDisplayOrientation = .portrait
    private var observingOrientation = false
    private var settledOrientationRead: DispatchWorkItem?
    override func loadView() { view = previewView }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        synchronizeOrientation()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !observingOrientation {
            observingOrientation = true
            UIDevice.current.beginGeneratingDeviceOrientationNotifications()
            NotificationCenter.default.addObserver(self, selector: #selector(deviceOrientationChanged),
                name: UIDevice.orientationDidChangeNotification, object: nil)
        }
        synchronizeOrientation()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if observingOrientation {
            observingOrientation = false
            NotificationCenter.default.removeObserver(self, name: UIDevice.orientationDidChangeNotification, object: nil)
            UIDevice.current.endGeneratingDeviceOrientationNotifications()
        }
        settledOrientationRead?.cancel()
        settledOrientationRead = nil
    }
    @objc private func deviceOrientationChanged() {
        // This notification is only a wakeup. Physical orientation must never
        // substitute for interface orientation (rotation lock may keep it fixed).
        synchronizeOrientation()
        settledOrientationRead?.cancel()
        let read = DispatchWorkItem { [weak self] in self?.synchronizeOrientation() }
        settledOrientationRead = read
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: read)
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: { [weak self] _ in
            self?.synchronizeOrientation()
        }, completion: { [weak self] _ in
            self?.synchronizeOrientation()
        })
    }
    func synchronizeOrientation() {
        guard let interface = viewIfLoaded?.window?.windowScene?.interfaceOrientation,
              let current = CameraDisplayOrientation(interfaceOrientation: interface) else { return }
        if let connection = preview.connection {
            let angle = current.previewRotationAngle
            if connection.isVideoRotationAngleSupported(angle), connection.videoRotationAngle != angle {
                connection.videoRotationAngle = angle
            }
            // Back-camera output and detections must share handedness.
            if connection.isVideoMirroringSupported {
                connection.automaticallyAdjustsVideoMirroring = false
                connection.isVideoMirrored = false
            }
        }
        lastOrientation = current
        // Publishing during a representable update is deferred to the next run loop.
        DispatchQueue.main.async { [weak self] in
            guard let self, self.lastOrientation == current else { return }
            self.orientationChanged?(current)
        }
    }
}

/// Calibration thumbnails use their exact sampled image, rotated with its points.
private struct CalibrationCameraFrameView: View {
    let feedback: CalibrationFeedback
    let image: UIImage
    let orientation: CameraDisplayOrientation
    private var displayImage: UIImage {
        guard let cg = image.cgImage else { return image }
        return UIImage(cgImage: cg, scale: 1, orientation: orientation.imageOrientation)
    }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black
                Image(uiImage: displayImage).resizable().scaledToFit()
                Canvas { context, size in
                    let color: Color = feedback.usable && !feedback.preview ? .green : .orange
                    let viewport = orientation.viewport(imageWidth: feedback.width, imageHeight: feedback.height,
                                                        viewWidth: size.width, viewHeight: size.height)
                    for corner in feedback.corners where corner.count == 2 {
                        let (x, y) = viewport.point(orientation.normalizedPoint(corner))
                        context.stroke(Path(ellipseIn: CGRect(x: x - 3, y: y - 3, width: 6, height: 6)),
                                       with: .color(color), lineWidth: 2)
                    }
                }
            }.frame(width: geometry.size.width, height: geometry.size.height)
        }.allowsHitTesting(false)
    }
}

struct AnalyzedFrameView: View {
    let feedback: LiveFeedback
    let image: UIImage
    let plan: DentalPlan
    var orientation: CameraDisplayOrientation = .portrait
    private var displayImage: UIImage {
        guard let cg = image.cgImage else { return image }
        return UIImage(cgImage: cg, scale: 1, orientation: orientation.imageOrientation)
    }
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Color.black
                Image(uiImage: displayImage).resizable().scaledToFit()
                Canvas { context, size in
                    let rejected = ScanDetectionOverlay.rejectedCenters(feedback: feedback,
                        viewWidth: size.width, viewHeight: size.height, orientation: orientation)
                    for point in rejected {
                        let ring = Path(ellipseIn: CGRect(x: point.x - 5, y: point.y - 5, width: 10, height: 10))
                        context.stroke(ring, with: .color(.orange), lineWidth: 1.5)
                    }
                    let outlines = ScanDetectionOverlay.outlines(feedback: feedback,
                        viewWidth: size.width, viewHeight: size.height, orientation: orientation)
                    for marker in outlines {
                        let color: Color = marker.accepted ? .green : .orange
                        context.stroke(Path(roundedRect: marker.bounds, cornerRadius: 7), with: .color(color), lineWidth: 2.5)
                        for point in marker.centers {
                            let ring = Path(ellipseIn: CGRect(x: point.x - 5, y: point.y - 5, width: 10, height: 10))
                            context.stroke(ring, with: .color(color), lineWidth: 2)
                            let center = Path(ellipseIn: CGRect(x: point.x - 1.5, y: point.y - 1.5, width: 3, height: 3))
                            context.fill(center, with: .color(color))
                        }
                        let label = plan.tooth(for: marker.id).map { "FDI \($0) · ID \(marker.id)" } ?? "ID \(marker.id)"
                        context.draw(Text(label).font(.system(size: 10, weight: .bold)).foregroundStyle(color),
                                     at: CGPoint(x: marker.bounds.midX, y: max(9, marker.bounds.minY - 9)))
                    }
                }
            }.frame(width: geometry.size.width, height: geometry.size.height)
        }.allowsHitTesting(false).accessibilityIdentifier("detectedFlagFrame")
    }
}

struct FeedbackCard: View {
    let feedback: LiveFeedback
    let image: UIImage
    let date: Date
    var orientation: CameraDisplayOrientation = .portrait
    private var displayImage: UIImage {
        guard let cg = image.cgImage else { return image }
        return UIImage(cgImage: cg, scale: 1, orientation: orientation.imageOrientation)
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            TimelineView(.periodic(from: .now, by: 1)) { context in
                HStack {
                    Label("Son analiz edilen kare", systemImage: "photo.badge.checkmark")
                    Spacer()
                    Text("\(max(0, Int(context.date.timeIntervalSince(date)))) sn önce").monospacedDigit()
                }.font(.caption.bold())
            }
            GeometryReader { geometry in
                ZStack {
                    Image(uiImage: displayImage).resizable().scaledToFit()
                    Canvas { context, size in
                        let rejected = ScanDetectionOverlay.rejectedCenters(feedback: feedback,
                            viewWidth: size.width, viewHeight: size.height, orientation: orientation)
                        for point in rejected {
                            let ring = Path(ellipseIn: CGRect(x: point.x - 6, y: point.y - 6, width: 12, height: 12))
                            context.stroke(ring, with: .color(.orange), lineWidth: 1.5)
                        }
                        let outlines = ScanDetectionOverlay.outlines(feedback: feedback,
                            viewWidth: size.width, viewHeight: size.height, orientation: orientation)
                        for marker in outlines {
                            let color: Color = marker.accepted ? .green : .orange
                            context.stroke(Path(roundedRect: marker.bounds, cornerRadius: 5), with: .color(color), lineWidth: 1.5)
                            for point in marker.centers {
                                let ring = Path(ellipseIn: CGRect(x: point.x - 4, y: point.y - 4, width: 8, height: 8))
                                context.stroke(ring, with: .color(color), lineWidth: 2)
                            }
                            context.draw(Text("ID \(marker.id)").font(.caption2.bold()).foregroundStyle(color),
                                         at: CGPoint(x: marker.bounds.midX, y: max(9, marker.bounds.minY - 10)))
                        }
                    }
                }.frame(width: geometry.size.width, height: geometry.size.height)
            }.frame(height: 190).background(.black).clipShape(RoundedRectangle(cornerRadius: 12))
            Label(feedback.usable ? (feedback.preview ? "Uygun örnek · kayıt onayı bekleniyor" : "Uygun görüntü kaydedildi") : "Bu örnek sayılmadı",
                systemImage: feedback.usable ? "checkmark.circle.fill" : "exclamationmark.circle")
                .font(.caption).foregroundStyle(feedback.usable ? Color.teal : Color.orange)
            Text("Yeşil noktalar kaydedilen karedeki tanımayı gösterir; tamamlanma ve doğruluk anlamına gelmez. Turuncu = aday veya henüz kaydedilmemiş örnek. İşaretler bu sabit kareye aittir; hareketli görüntüyü takip etmez.").font(.caption2).foregroundStyle(.secondary)
        }.accessibilityIdentifier("analyzedFrame")
    }
}
