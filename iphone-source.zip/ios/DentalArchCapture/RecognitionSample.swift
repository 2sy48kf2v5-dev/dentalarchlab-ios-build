import Foundation

// One atomic image/response pair. In-memory rejected previews are retained only
// until the next sample; exporting is an explicit local user action.
struct RecognitionSample {
    let session: String
    let sample: String
    let image: Data
    let profile: CaptureProfile
    let timestamp: Double
    let mode: String
    let markerCount: Int
    let response: [String: Any]

    func write(to directory: URL) throws -> URL {
        guard ["trial", "scan"].contains(mode), [4, 6].contains(markerCount),
              timestamp.isFinite, timestamp >= 0, !image.isEmpty, image.count <= 8*1024*1024,
              session.count == 32, sample.count == 32,
              session.utf8.allSatisfy({ (48...57).contains($0) || (97...102).contains($0) }),
              sample.utf8.allSatisfy({ (48...57).contains($0) || (97...102).contains($0) }),
              response["id"] as? String == sample else {
            throw LabError.message("Tanıma görüntüsü ve analiz kimliği eşleşmedi.")
        }
        let digest = PreviewCommit.digest(image)
        guard response["sha256"] as? String == digest else {
            throw LabError.message("Tanıma görüntüsü ve analiz özeti eşleşmedi.")
        }
        let encodedProfile = try JSONSerialization.jsonObject(with: JSONEncoder().encode(profile))
        let content: [String: Any] = [
            "schema": "dentalarchlab_recognition_report_v1",
            "app_version": Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown",
            "app_build": Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "unknown",
            "created_utc": ISO8601DateFormatter().string(from: Date()),
            "session_id": session, "sample_id": sample, "timestamp_s": timestamp,
            "mode": mode, "marker_count": markerCount, "profile": encodedProfile,
            "image_encoding": image.starts(with: [0xff, 0xd8]) ? "jpeg" : "png",
            "image_base64": image.base64EncodedString(), "image_sha256": digest,
            "response": response, "physical_accuracy_um": NSNull(),
            "note": "Original sensor image and matching detector response; not physical accuracy validation."
        ]
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let destination = directory.appendingPathComponent("tanima-" + sample + ".json")
        try JSONSerialization.data(withJSONObject: content, options: [.prettyPrinted, .sortedKeys])
            .write(to: destination, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        return destination
    }
}
