import Foundation

/// Imported mesh coordinates are millimetres. No unit, scale or texture is guessed.
struct TissueMesh {
    var vertices: [LabPoint]
    var triangles: [[Int]]
    var colors: [[UInt8]]? = nil

    static func parse(data: Data, fileExtension: String) throws -> Self {
        guard !data.isEmpty, data.count <= TissueLimits.bytes else {
            throw TissueLimits.error("Model boş veya 64 MB sınırını aşıyor.")
        }
        let mesh: Self
        switch fileExtension.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: ".")) {
        case "stl": mesh = try TissueParser.stl(data)
        case "ply": mesh = try TissueParser.ply(data)
        case "obj": mesh = try TissueParser.obj(data)
        default: throw TissueLimits.error("Yalnız STL, PLY ve üçgen yüzeyli OBJ modelleri destekleniyor.")
        }
        try mesh.validate()
        return mesh
    }

    func validate() throws {
        guard !vertices.isEmpty, !triangles.isEmpty,
              vertices.count <= TissueLimits.elements, triangles.count <= TissueLimits.elements else {
            throw TissueLimits.error("Model boş veya bir milyon köşe/yüz sınırını aşıyor.")
        }
        for point in vertices { try TissueLimits.validate(point) }
        if let colors {
            guard colors.count == vertices.count, colors.allSatisfy({ $0.count == 3 }) else {
                throw TissueLimits.error("Modelin RGB renk sayısı köşe sayısıyla uyuşmuyor.")
            }
        }
        for face in triangles {
            guard face.count == 3, face.allSatisfy({ $0 >= 0 && $0 < vertices.count }),
                  Set(face).count == 3 else {
                throw TissueLimits.error("Modelde geçersiz üçgen köşe indeksi var.")
            }
            let a = vertices[face[1]] - vertices[face[0]]
            let b = vertices[face[2]] - vertices[face[0]]
            let scale = max(max(a.length, b.length), (a-b).length)
            guard scale > 1e-12, TissueMath.cross(a * (1/scale), b * (1/scale)).length > 1e-12 else {
                throw TissueLimits.error("Modelde alanı sıfır veya dejenere bir üçgen var.")
            }
        }
    }

    func transformed(_ matrix: [[Double]]) throws -> Self {
        try validate()
        try TissueRegistration.validateRigid(matrix)
        let result = Self(vertices: vertices.map { TissueMath.apply($0, matrix) }, triangles: triangles, colors: colors)
        try result.validate()
        return result
    }

    /// Binary STL has no portable vertex RGB representation; colors remain in the imported mesh only.
    func stlData() throws -> Data {
        try validate()
        let size = 84 + 50 * triangles.count
        guard size <= TissueLimits.bytes else { throw TissueLimits.error("STL çıktısı 64 MB sınırını aşıyor.") }
        var output = Data("DentalArchLab research tissue mesh; units=mm; binary STL".utf8)
        output.append(Data(repeating: 0, count: 80-output.count))
        TissueWriter.append(UInt32(triangles.count), to: &output)
        output.reserveCapacity(size)
        for face in triangles {
            // STL stores Float32. Refuse a face that collapses after quantization.
            let encoded = face.map { index -> LabPoint in
                let point=vertices[index]
                return LabPoint(x:Double(Float(point.x)), y:Double(Float(point.y)), z:Double(Float(point.z)))
            }
            let a = encoded[0], b = encoded[1], c = encoded[2]
            let normal = TissueMath.cross(b-a, c-a)
            let edgeScale=max((b-a).length,(c-a).length)
            guard edgeScale > 1e-12, TissueMath.cross((b-a)*(1/edgeScale),(c-a)*(1/edgeScale)).length > 1e-12 else {
                throw TissueLimits.error("Bir üçgen STL'nin sayı hassasiyetinde kayboluyor; model koordinatlarını kontrol edin.")
            }
            for point in [normal * (1/normal.length), a, b, c] {
                for value in [point.x, point.y, point.z] {
                    TissueWriter.append(Float(value).bitPattern, to: &output)
                }
            }
            output.append(contentsOf: [0, 0])
        }
        return output
    }
}

struct TissuePair {
    let source: LabPoint
    let target: LabPoint
}

/// Least-squares proper rigid fit: target = R * source + t. Scale is always one.
struct TissueRegistration {
    let transform: [[Double]]
    let rmsMM: Double
    let maxMM: Double
    let residualsMM: [Double]

    static func validateRigid(_ matrix: [[Double]]) throws {
        guard matrix.count == 4, matrix.allSatisfy({ $0.count == 4 && $0.allSatisfy(\.isFinite) }),
              abs(matrix[3][0]) < 1e-9, abs(matrix[3][1]) < 1e-9,
              abs(matrix[3][2]) < 1e-9, abs(matrix[3][3]-1) < 1e-9 else {
            throw TissueLimits.error("Dönüşüm sonlu bir 4×4 rijit matris olmalı.")
        }
        let columns = (0..<3).map { LabPoint(x: matrix[0][$0], y: matrix[1][$0], z: matrix[2][$0]) }
        for i in 0..<3 {
            guard abs(TissueMath.dot(columns[i], columns[i])-1) < 1e-6 else {
                throw TissueLimits.error("Dönüşüm ölçek içeriyor; yalnız rijit hizalama kullanılabilir.")
            }
            for j in 0..<i {
                guard abs(TissueMath.dot(columns[i], columns[j])) < 1e-6 else {
                    throw TissueLimits.error("Dönüşüm eksenleri birbirine dik değil.")
                }
            }
        }
        guard abs(TissueMath.dot(columns[0], TissueMath.cross(columns[1], columns[2]))-1) < 1e-6 else {
            throw TissueLimits.error("Dönüşüm yansıma içeriyor; sağ elli bir dönüş gerekli.")
        }
        try TissueLimits.validate(LabPoint(x: matrix[0][3], y: matrix[1][3], z: matrix[2][3]))
    }

    static func apply(_ point: LabPoint, matrix: [[Double]]) throws -> LabPoint {
        try TissueLimits.validate(point)
        try validateRigid(matrix)
        let result = TissueMath.apply(point, matrix)
        try TissueLimits.validate(result)
        return result
    }

    static func fit(_ pairs: [TissuePair]) throws -> Self {
        guard (3...256).contains(pairs.count) else {
            throw TissueLimits.error("Rijit hizalama için 3–256 eşleşmiş nokta gerekli.")
        }
        let source = pairs.map(\.source), target = pairs.map(\.target)
        try TissueMath.validateLandmarks(source)
        try TissueMath.validateLandmarks(target)
        let count = Double(pairs.count)
        let sourceMean = source.reduce(LabPoint.zero) { $0+$1 } * (1/count)
        let targetMean = target.reduce(LabPoint.zero) { $0+$1 } * (1/count)
        var h = Array(repeating: Array(repeating: 0.0, count: 3), count: 3)
        for pair in pairs {
            let a = pair.source-sourceMean, b = pair.target-targetMean
            let av = [a.x,a.y,a.z], bv = [b.x,b.y,b.z]
            for row in 0..<3 { for column in 0..<3 { h[row][column] += av[row]*bv[column] } }
        }
        let xx=h[0][0], xy=h[0][1], xz=h[0][2]
        let yx=h[1][0], yy=h[1][1], yz=h[1][2]
        let zx=h[2][0], zy=h[2][1], zz=h[2][2]
        // Horn's symmetric quaternion eigenproblem; the largest algebraic eigenvalue is required.
        let n = [[xx+yy+zz, yz-zy, zx-xz, xy-yx],
                 [yz-zy, xx-yy-zz, xy+yx, zx+xz],
                 [zx-xz, xy+yx, -xx+yy-zz, yz+zy],
                 [xy-yx, zx+xz, yz+zy, -xx-yy+zz]]
        let q = try TissueMath.largestEigenvector(n)
        let w=q[0], x=q[1], y=q[2], z=q[3]
        var matrix: [[Double]] = [[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w), 0],
                      [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w), 0],
                      [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y), 0],
                      [0.0, 0, 0, 1]]
        let shift = targetMean - TissueMath.apply(sourceMean, matrix)
        matrix[0][3]=shift.x; matrix[1][3]=shift.y; matrix[2][3]=shift.z
        try validateRigid(matrix)
        let residuals = pairs.map { (TissueMath.apply($0.source, matrix)-$0.target).length }
        return Self(transform: matrix, rmsMM: sqrt(residuals.reduce(0) { $0+$1*$1 }/count),
                    maxMM: residuals.max() ?? 0, residualsMM: residuals)
    }
}

private enum TissueLimits {
    static let bytes = 64*1024*1024
    static let elements = 1_000_000
    static func error(_ text: String) -> LabError { .message(text) }
    static func validate(_ point: LabPoint) throws {
        guard [point.x,point.y,point.z].allSatisfy({ $0.isFinite && abs($0) <= 100_000 }) else {
            throw error("Koordinatlar sonlu olmalı ve ±100.000 mm sınırında kalmalı; model birimini kontrol edin.")
        }
    }
}

private enum TissueMath {
    static func dot(_ a: LabPoint, _ b: LabPoint) -> Double { a.x*b.x+a.y*b.y+a.z*b.z }
    static func cross(_ a: LabPoint, _ b: LabPoint) -> LabPoint {
        LabPoint(x:a.y*b.z-a.z*b.y, y:a.z*b.x-a.x*b.z, z:a.x*b.y-a.y*b.x)
    }
    static func apply(_ p: LabPoint, _ m: [[Double]]) -> LabPoint {
        LabPoint(x:m[0][0]*p.x+m[0][1]*p.y+m[0][2]*p.z+m[0][3],
                 y:m[1][0]*p.x+m[1][1]*p.y+m[1][2]*p.z+m[1][3],
                 z:m[2][0]*p.x+m[2][1]*p.y+m[2][2]*p.z+m[2][3])
    }
    static func validateLandmarks(_ points: [LabPoint]) throws {
        for point in points { try TissueLimits.validate(point) }
        let origin = points[0]
        let offsets = points.map { $0-origin }
        guard let farthest = offsets.max(by: { $0.length < $1.length }), farthest.length > 1e-8 else {
            throw TissueLimits.error("Eşleştirme noktaları yeterince ayrı değil.")
        }
        let spread = farthest.length
        let direction = farthest * (1/spread)
        let area = offsets.map { cross(direction, $0 * (1/spread)).length }.max() ?? 0
        guard area > 1e-8 else { throw TissueLimits.error("Eşleştirme noktaları aynı doğru üzerinde; farklı yönde bir nokta seçin.") }
        for i in points.indices {
            for j in 0..<i {
                guard (points[i]-points[j]).length > max(1e-10, spread*1e-10) else {
                    throw TissueLimits.error("Aynı eşleştirme noktası birden fazla kez seçilmiş.")
                }
            }
        }
    }
    static func largestEigenvector(_ input: [[Double]]) throws -> [Double] {
        let scale = input.flatMap { $0 }.map(abs).max() ?? 0
        guard scale.isFinite, scale > 0 else { throw TissueLimits.error("Noktalardan kararlı bir dönüşüm hesaplanamadı.") }
        var a = input.map { $0.map { $0/scale } }
        var v = (0..<4).map { row in (0..<4).map { row == $0 ? 1.0 : 0.0 } }
        var converged = false
        for _ in 0..<100 {
            var p=0, q=1
            for i in 0..<4 { for j in (i+1)..<4 where abs(a[i][j]) > abs(a[p][q]) { p=i; q=j } }
            if abs(a[p][q]) < 1e-15 { converged=true; break }
            let tau = (a[q][q]-a[p][p])/(2*a[p][q])
            let t = (tau >= 0 ? 1.0 : -1.0)/(abs(tau)+hypot(1,tau))
            let c = 1/sqrt(1+t*t), s = t*c
            let apq=a[p][q], app=a[p][p], aqq=a[q][q]
            a[p][p]=app-t*apq; a[q][q]=aqq+t*apq; a[p][q]=0; a[q][p]=0
            for k in 0..<4 where k != p && k != q {
                let kp=a[k][p], kq=a[k][q]
                a[k][p]=c*kp-s*kq; a[p][k]=a[k][p]
                a[k][q]=s*kp+c*kq; a[q][k]=a[k][q]
            }
            for k in 0..<4 {
                let kp=v[k][p], kq=v[k][q]
                v[k][p]=c*kp-s*kq; v[k][q]=s*kp+c*kq
            }
        }
        guard converged, let index = (0..<4).max(by: { a[$0][$0] < a[$1][$1] }) else {
            throw TissueLimits.error("Rijit hizalama çözümü yakınsamadı.")
        }
        let eigenvector = (0..<4).map { v[$0][index] }
        let length = sqrt(eigenvector.reduce(0) { $0+$1*$1 })
        guard length > 0, length.isFinite else { throw TissueLimits.error("Rijit hizalama çözülemedi.") }
        return eigenvector.map { $0/length }
    }
}

private struct TissueVertexKey: Hashable {
    let x: Double; let y: Double; let z: Double
    init(_ point: LabPoint) { x=point.x; y=point.y; z=point.z }
}

private enum TissueWriter {
    static func append(_ value: UInt32, to data: inout Data) {
        for shift in stride(from: 0, to: 32, by: 8) { data.append(UInt8(truncatingIfNeeded: value >> shift)) }
    }
}

/// Byte-by-byte reads avoid alignment assumptions and unbounded token arrays.
private struct TissueCursor {
    let bytes: [UInt8]
    var index = 0
    init(_ data: Data) { bytes=Array(data) }
    var atEnd: Bool { index == bytes.count }
    mutating func unsigned(_ count: Int) throws -> UInt64 {
        guard count >= 0, count <= 8, index <= bytes.count-count else { throw TissueLimits.error("Model dosyası eksik veya kesilmiş.") }
        var value: UInt64 = 0
        for offset in 0..<count { value |= UInt64(bytes[index+offset]) << (8*offset) }
        index += count
        return value
    }
    mutating func line(limit: Int = 65_536) throws -> String? {
        if atEnd { return nil }
        let start=index
        while index < bytes.count && bytes[index] != 10 {
            guard index-start < limit else { throw TissueLimits.error("Model dosyasındaki satır çok uzun.") }
            index += 1
        }
        let end=index
        if index < bytes.count { index += 1 }
        guard let result=String(bytes: bytes[start..<end], encoding: .utf8) else { throw TissueLimits.error("Model başlığı geçerli UTF-8 değil.") }
        return result.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    mutating func skipSpace() {
        while index < bytes.count && [UInt8(9),10,11,12,13,32].contains(bytes[index]) { index += 1 }
    }
    mutating func token() throws -> String? {
        skipSpace()
        if atEnd { return nil }
        let start=index
        while index < bytes.count && ![UInt8(9),10,11,12,13,32].contains(bytes[index]) {
            guard index-start < 256 else { throw TissueLimits.error("Modelde çok uzun bir sayı veya alan adı var.") }
            index += 1
        }
        guard let value=String(bytes: bytes[start..<index], encoding: .utf8) else { throw TissueLimits.error("Model metni okunamadı.") }
        return value
    }
    mutating func require(_ value: String) throws {
        guard try token()?.lowercased() == value else { throw TissueLimits.error("Model dosyasında beklenen alan eksik: \(value).") }
    }
    mutating func number() throws -> Double {
        guard let token=try token(), let value=Double(token), value.isFinite else { throw TissueLimits.error("Modelde geçersiz veya eksik bir sayı var.") }
        return value
    }
    mutating func point(binary: Bool) throws -> LabPoint {
        var values: [Double] = []
        for _ in 0..<3 {
            if binary { values.append(Double(Float(bitPattern: UInt32(try unsigned(4))))) }
            else { values.append(try number()) }
        }
        let result=LabPoint(x: values[0], y: values[1], z: values[2])
        try TissueLimits.validate(result)
        return result
    }
    mutating func skipBOM() {
        if bytes.starts(with: [239,187,191]) { index=3 }
    }
}

private enum TissueParser {
    static func stl(_ data: Data) throws -> TissueMesh {
        var cursor=TissueCursor(data)
        var binaryCount: Int?
        if data.count >= 84 {
            cursor.index=80
            let count=Int(try cursor.unsigned(4))
            if count > 0, count <= TissueLimits.elements, 84+50*count == data.count { binaryCount=count }
        }
        var mesh=TissueMesh(vertices: [], triangles: [])
        var keys: [TissueVertexKey:Int] = [:]
        func add(_ points: [LabPoint]) throws {
            guard mesh.triangles.count < TissueLimits.elements else { throw TissueLimits.error("STL yüz sayısı sınırı aşıldı.") }
            var triangle: [Int] = []
            for point in points {
                let key=TissueVertexKey(point)
                if let index=keys[key] { triangle.append(index) }
                else {
                    guard mesh.vertices.count < TissueLimits.elements else { throw TissueLimits.error("STL köşe sayısı sınırı aşıldı.") }
                    keys[key]=mesh.vertices.count; triangle.append(mesh.vertices.count); mesh.vertices.append(point)
                }
            }
            mesh.triangles.append(triangle)
        }
        if let count=binaryCount {
            cursor.index=84
            for _ in 0..<count {
                // Stored normals may be zero or stale; geometry defines the export normal.
                for _ in 0..<3 { _ = try cursor.unsigned(4) }
                var points: [LabPoint] = []
                for _ in 0..<3 { points.append(try cursor.point(binary: true)) }
                _ = try cursor.unsigned(2)
                try add(points)
            }
        } else {
            cursor.index=0; cursor.skipBOM()
            try cursor.require("solid")
            _ = try cursor.line()
            var closed=false
            while let token=try cursor.token() {
                if token.lowercased() == "endsolid" {
                    _ = try cursor.line(); cursor.skipSpace()
                    guard cursor.atEnd else { throw TissueLimits.error("STL sonundan sonra beklenmeyen veri var.") }
                    closed=true; break
                }
                guard token.lowercased() == "facet" else { throw TissueLimits.error("STL yüz kaydı okunamadı.") }
                try cursor.require("normal")
                for _ in 0..<3 { _ = try cursor.number() }
                try cursor.require("outer"); try cursor.require("loop")
                var points: [LabPoint] = []
                for _ in 0..<3 { try cursor.require("vertex"); points.append(try cursor.point(binary: false)) }
                try cursor.require("endloop"); try cursor.require("endfacet")
                try add(points)
            }
            guard closed else { throw TissueLimits.error("STL dosyası tamamlanmamış.") }
        }
        return mesh
    }

    static func obj(_ data: Data) throws -> TissueMesh {
        var cursor=TissueCursor(data); cursor.skipBOM()
        var mesh=TissueMesh(vertices: [], triangles: [])
        while let line=try cursor.line() {
            let content=line.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false)[0]
            let tokens=content.split(whereSeparator: { $0.isWhitespace })
            guard let kind=tokens.first else { continue }
            switch kind {
            case "v":
                guard (tokens.count == 4 || tokens.count == 5), mesh.vertices.count < TissueLimits.elements,
                      let x=Double(tokens[1]), let y=Double(tokens[2]), let z=Double(tokens[3]) else {
                    throw TissueLimits.error("OBJ köşe kaydı geçersiz veya köşe sınırı aşıldı.")
                }
                if tokens.count == 5, Double(tokens[4]) != 1 { throw TissueLimits.error("OBJ homojen köşe ölçeği yalnız 1 olabilir.") }
                let point=LabPoint(x:x,y:y,z:z); try TissueLimits.validate(point); mesh.vertices.append(point)
            case "f":
                guard tokens.count == 4, mesh.triangles.count < TissueLimits.elements else {
                    throw TissueLimits.error("OBJ yalnız üçgen yüzleri destekliyor; modeli üçgenleştirerek dışa aktarın.")
                }
                var face: [Int] = []
                for token in tokens.dropFirst() {
                    let parts=token.split(separator: "/", omittingEmptySubsequences: false)
                    guard (1...3).contains(parts.count), let raw=Int(parts[0]), raw != 0,
                          raw >= -TissueLimits.elements, raw <= TissueLimits.elements else {
                        throw TissueLimits.error("OBJ yüz indeksi geçersiz.")
                    }
                    let index=raw > 0 ? raw-1 : mesh.vertices.count+raw
                    guard index >= 0 else { throw TissueLimits.error("OBJ negatif yüz indeksi sınır dışında.") }
                    face.append(index)
                }
                mesh.triangles.append(face)
            case "vt", "vn", "g", "o", "s", "usemtl", "mtllib": break
            default: throw TissueLimits.error("OBJ alanı desteklenmiyor: \(kind). Üçgen yüzeyli OBJ kullanın.")
            }
        }
        return mesh
    }

    private struct Property {
        let name: String
        let type: Scalar
        let count: Scalar?
    }
    private struct Element {
        let name: String
        let count: Int
        var properties: [Property] = []
    }
    private enum Scalar: String {
        case int8, uint8, int16, uint16, int32, uint32, float32, float64
        init?(_ token: String) {
            switch token {
            case "char", "int8": self = .int8
            case "uchar", "uint8": self = .uint8
            case "short", "int16": self = .int16
            case "ushort", "uint16": self = .uint16
            case "int", "int32": self = .int32
            case "uint", "uint32": self = .uint32
            case "float", "float32": self = .float32
            case "double", "float64": self = .float64
            default: return nil
            }
        }
        var integer: Bool { self != .float32 && self != .float64 }
        func read(_ cursor: inout TissueCursor, binary: Bool) throws -> Double {
            let value: Double
            if binary {
                switch self {
                case .int8: value=Double(Int8(bitPattern: UInt8(try cursor.unsigned(1))))
                case .uint8: value=Double(try cursor.unsigned(1))
                case .int16: value=Double(Int16(bitPattern: UInt16(try cursor.unsigned(2))))
                case .uint16: value=Double(try cursor.unsigned(2))
                case .int32: value=Double(Int32(bitPattern: UInt32(try cursor.unsigned(4))))
                case .uint32: value=Double(try cursor.unsigned(4))
                case .float32: value=Double(Float(bitPattern: UInt32(try cursor.unsigned(4))))
                case .float64: value=Double(bitPattern: try cursor.unsigned(8))
                }
            } else {
                value=try cursor.number()
                let bounds: (Double,Double)
                switch self {
                case .int8: bounds=(-128,127)
                case .uint8: bounds=(0,255)
                case .int16: bounds=(-32768,32767)
                case .uint16: bounds=(0,65535)
                case .int32: bounds=(-2147483648,2147483647)
                case .uint32: bounds=(0,4294967295)
                case .float32: bounds=(-Double(Float.greatestFiniteMagnitude),Double(Float.greatestFiniteMagnitude))
                case .float64: bounds=(-Double.greatestFiniteMagnitude,Double.greatestFiniteMagnitude)
                }
                guard value >= bounds.0, value <= bounds.1, !integer || value.rounded(.towardZero) == value else {
                    throw TissueLimits.error("PLY sayısı bildirilen veri türünün sınırları dışında.")
                }
            }
            guard value.isFinite else { throw TissueLimits.error("PLY sonlu olmayan bir sayı içeriyor.") }
            return value
        }
    }

    static func ply(_ data: Data) throws -> TissueMesh {
        var cursor=TissueCursor(data); cursor.skipBOM()
        guard try cursor.line() == "ply" else { throw TissueLimits.error("PLY başlığı bulunamadı.") }
        var elements: [Element] = []
        var binary: Bool?, ended=false
        while let line=try cursor.line() {
            guard cursor.index <= 65_536 else { throw TissueLimits.error("PLY başlığı çok büyük.") }
            let words=line.split(whereSeparator: { $0.isWhitespace }).map(String.init)
            guard let first=words.first else { continue }
            if first == "end_header" { ended=true; break }
            switch first {
            case "comment", "obj_info": continue
            case "format":
                guard binary == nil, words.count == 3, words[2] == "1.0",
                      words[1] == "ascii" || words[1] == "binary_little_endian" else {
                    throw TissueLimits.error("PLY yalnız ASCII veya binary little-endian 1.0 biçiminde okunabilir.")
                }
                binary = words[1] == "binary_little_endian"
            case "element":
                guard words.count == 3, elements.count < 16, let count=Int(words[2]),
                      count >= 0, count <= TissueLimits.elements,
                      !elements.contains(where: { $0.name == words[1] }) else {
                    throw TissueLimits.error("PLY eleman sayısı/başlığı geçersiz veya sınır dışında.")
                }
                elements.append(Element(name:words[1], count:count))
            case "property":
                guard !elements.isEmpty, elements[elements.count-1].properties.count < 64 else { throw TissueLimits.error("PLY özellik başlığı geçersiz.") }
                let property: Property
                if words.count == 3, let type=Scalar(words[1]) {
                    property=Property(name:words[2], type:type, count:nil)
                } else if words.count == 5, words[1] == "list", let count=Scalar(words[2]), count.integer, let type=Scalar(words[3]) {
                    property=Property(name:words[4], type:type, count:count)
                } else { throw TissueLimits.error("PLY özellik türü desteklenmiyor.") }
                guard !elements[elements.count-1].properties.contains(where: { $0.name == property.name }) else {
                    throw TissueLimits.error("PLY aynı özelliği birden fazla bildiriyor.")
                }
                elements[elements.count-1].properties.append(property)
            default: throw TissueLimits.error("PLY başlık alanı desteklenmiyor: \(first).")
            }
        }
        guard ended, let binary, let vertex=elements.first(where: { $0.name == "vertex" }), vertex.count > 0,
              let face=elements.first(where: { $0.name == "face" }), face.count > 0,
              elements.reduce(0, { $0+$1.count }) <= 2*TissueLimits.elements else {
            throw TissueLimits.error("PLY köşe/yüz bilgisi eksik veya dosya sınırı aşıldı.")
        }
        for coordinate in ["x","y","z"] {
            guard vertex.properties.contains(where: { $0.name == coordinate && $0.count == nil }) else {
                throw TissueLimits.error("PLY x, y, z köşe koordinatlarını içermeli.")
            }
        }
        let colorNames=["red","green","blue"]
        let colorCount=vertex.properties.filter { colorNames.contains($0.name) && $0.count == nil }.count
        guard colorCount == 0 || colorCount == 3 else { throw TissueLimits.error("PLY RGB renk alanları eksik.") }
        let faceProperties=face.properties.filter { $0.name == "vertex_indices" || $0.name == "vertex_index" }
        guard faceProperties.count == 1, let faceProperty=faceProperties.first, faceProperty.count != nil, faceProperty.type.integer else {
            throw TissueLimits.error("PLY üçgen köşe indekslerini içermeli.")
        }
        var mesh=TissueMesh(vertices: [], triangles: [], colors: colorCount == 3 ? [] : nil)
        mesh.vertices.reserveCapacity(vertex.count); mesh.triangles.reserveCapacity(face.count)
        for element in elements {
            for _ in 0..<element.count {
                var xyz=[0.0,0.0,0.0], rgb=[UInt8(0),0,0]
                for property in element.properties {
                    if let countType=property.count {
                        let count=try countType.read(&cursor, binary:binary)
                        guard count >= 0, count <= 1024 else { throw TissueLimits.error("PLY liste uzunluğu geçersiz veya sınır dışında.") }
                        let isFace=element.name == "face" && property.name == faceProperty.name
                        if isFace && count != 3 { throw TissueLimits.error("PLY yalnız üçgen yüzleri destekliyor; modeli üçgenleştirerek dışa aktarın.") }
                        var triangle: [Int] = []
                        for _ in 0..<Int(count) {
                            let value=try property.type.read(&cursor, binary:binary)
                            if isFace {
                                guard value >= 0, value < Double(vertex.count) else { throw TissueLimits.error("PLY yüz indeksi sınır dışında.") }
                                triangle.append(Int(value))
                            }
                        }
                        if isFace { mesh.triangles.append(triangle) }
                    } else {
                        let value=try property.type.read(&cursor, binary:binary)
                        if element.name == "vertex" {
                            if let axis=["x","y","z"].firstIndex(of: property.name) { xyz[axis]=value }
                            if let channel=colorNames.firstIndex(of: property.name) {
                                guard (0...255).contains(value), value.rounded(.towardZero) == value else { throw TissueLimits.error("PLY RGB değerleri 0–255 tamsayı olmalı.") }
                                rgb[channel]=UInt8(value)
                            }
                        }
                    }
                }
                if element.name == "vertex" {
                    let point=LabPoint(x:xyz[0],y:xyz[1],z:xyz[2]); try TissueLimits.validate(point)
                    mesh.vertices.append(point)
                    if colorCount == 3 { mesh.colors?.append(rgb) }
                }
            }
        }
        if !binary { cursor.skipSpace() }
        guard cursor.atEnd else { throw TissueLimits.error("PLY sonundan sonra beklenmeyen veri var.") }
        return mesh
    }
}
