import AVFoundation
import CoreImage
import Foundation
import ImageIO
import QuartzCore
import UniformTypeIdentifiers

// Camera setup, settings and frame callbacks share one serial queue.
// iOS 17+, Swift 5 mode. Real Xcode/device validation is still required.
final class CameraEngine: NSObject, CameraControlling, AVCaptureVideoDataOutputSampleBufferDelegate {
    let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "dal.camera.serial")
    private let context = CIContext()
    private var device: AVCaptureDevice?
    private var profile: CaptureProfile?
    private var ready = false
    private var generation = 0
    private var captureTicket = 0
    private var compactTrialFrame = false
    private var discardUntil: CFTimeInterval = 0
    private var pending: ((Result<(Data, CaptureProfile, Double), Error>) -> Void)?
    private var starting: (ticket: Int, completion: (Result<CaptureProfile, Error>) -> Void)?
    private var startupCheck: CameraStartupCheck?
    private var focusAcquisition: CameraFocusAcquisition?
    private var videoOutput: AVCaptureVideoDataOutput?
    private var startupFrames = 0
    private var startupDrops = 0
    private var startupWidth = 0
    private var startupHeight = 0
    private var requestedLens: Float = 0
    private var focusRequest: CameraFocusRequest = .automatic
    private var lastCapturedTimestamp: Double?
    var onInterruption: ((String) -> Void)?

    override init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(interrupted), name: AVCaptureSession.wasInterruptedNotification, object: session)
        NotificationCenter.default.addObserver(self, selector: #selector(interrupted), name: AVCaptureSession.runtimeErrorNotification, object: session)
    }
    deinit { NotificationCenter.default.removeObserver(self) }
    @objc private func interrupted(_ note: Notification) {
        queue.async {
            guard self.ready || self.starting != nil || self.pending != nil || self.session.isRunning else { return }
            self.stopOnQueue()
            self.onInterruption?("Kamera kesintiye uğradı. Görüntüler korunuyor; Kamerayı aç ile yeniden deneyin.")
        }
    }
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) {
        queue.async {
            self.stopOnQueue()
            let ticket = self.generation
            self.starting = (ticket, completion)
            self.startupFrames = 0; self.startupDrops = 0
            self.startupWidth = 0; self.startupHeight = 0; self.focusRequest = focus
            if case .locked(let position) = focus { self.requestedLens = position }
            else { self.requestedLens = -1 }
            AVCaptureDevice.requestAccess(for: .video) { allowed in
                self.queue.async {
                    guard self.starting?.ticket == ticket, ticket == self.generation else { return }
                    guard allowed else {
                        self.finishStartup(ticket: ticket, result: .failure(LabError.message("Kamera izni yok. Ayarlar > DentalArchLab bölümünden izin verin.")))
                        return
                    }
                    // The model has a separate deadline on the MainActor, including
                    // permission and a potentially blocked startRunning() call.
                    self.queue.asyncAfter(deadline: .now() + 8) {
                        guard self.starting?.ticket == ticket else { return }
                        self.finishStartup(ticket: ticket, result: .failure(self.startupFailure()))
                    }
                    do {
                        if self.device == nil { try self.configure() }
                        guard let camera = self.device else { throw LabError.message("Kamera bulunamadı.") }
                        if case .locked(let position) = focus {
                            guard position.isFinite, (0...1).contains(position) else { throw LabError.message("Kaydedilen odak geçersiz; yeni kalibrasyon gerekli.") }
                        } else if !camera.isFocusModeSupported(.autoFocus) {
                            throw LabError.message("Bu kamera tek seferlik otomatik odağı desteklemiyor.")
                        }
                        if !self.session.isRunning { self.session.startRunning() }
                        guard self.session.isRunning, !self.session.isInterrupted else { throw LabError.message("Kamera başlatılamadı. Kamerayı aç ile yeniden deneyin.") }
                        try camera.lockForConfiguration()
                        camera.videoZoomFactor = 1
                        // Face-driven changes must not compete with a board or
                        // a saved optical profile. Change both flags under lock.
                        camera.automaticallyAdjustsFaceDrivenAutoFocusEnabled = false
                        camera.isFaceDrivenAutoFocusEnabled = false
                        if camera.isExposureModeSupported(.continuousAutoExposure) { camera.exposureMode = .continuousAutoExposure }
                        if camera.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) { camera.whiteBalanceMode = .continuousAutoWhiteBalance }
                        switch focus {
                        case .automatic:
                            if camera.isFocusPointOfInterestSupported { camera.focusPointOfInterest = CGPoint(x: 0.5, y: 0.5) }
                            if camera.isAutoFocusRangeRestrictionSupported { camera.autoFocusRangeRestriction = .none }
                            camera.focusMode = .autoFocus
                        case .locked(let position):
                            camera.setFocusModeLocked(lensPosition: position, completionHandler: nil)
                        }
                        camera.unlockForConfiguration()
                        if case .automatic = focus {
                            let now = CACurrentMediaTime()
                            self.focusAcquisition = CameraFocusAcquisition(earliestFrameTime: now + 1.5, deadline: now + 7.5)
                            return
                        }
                        self.queue.asyncAfter(deadline: .now() + 1.5) {
                            guard self.starting?.ticket == ticket, ticket == self.generation else { return }
                            do {
                                // Restore the canonical saved value; never substitute
                                // an autofocus result for an existing calibration.
                                try self.prepareLockedFrames(camera: camera, position: self.requestedLens, preserveCurrent: false)
                            } catch { self.finishStartup(ticket: ticket, result: .failure(error)) }
                        }
                    } catch { self.finishStartup(ticket: ticket, result: .failure(error)) }
                }
            }
        }
    }
    private func prepareLockedFrames(camera: AVCaptureDevice, position: Float, preserveCurrent: Bool) throws {
        try camera.lockForConfiguration()
        if preserveCurrent {
            // Apple's sentinel locks without commanding a second mechanical
            // position move or rounding the observed autofocus result.
            camera.setFocusModeLocked(lensPosition: AVCaptureDevice.currentLensPosition, completionHandler: nil)
        } else if !camera.isAdjustingFocus,
                  CameraFocusGuard.issue(expectedLens: position, focusLocked: camera.focusMode == .locked,
                                         adjustingFocus: false, lensPosition: camera.lensPosition) != nil {
            // One bounded restore retry after startup settles. Never substitute
            // another optical profile or extend the existing startup deadline.
            camera.setFocusModeLocked(lensPosition: position, completionHandler: nil)
        }
        if camera.isExposureModeSupported(.locked) { camera.exposureMode = .locked }
        if camera.isWhiteBalanceModeSupported(.locked) { camera.whiteBalanceMode = .locked }
        camera.unlockForConfiguration()
        let d = CMVideoFormatDescriptionGetDimensions(camera.activeFormat.formatDescription)
        requestedLens = position
        profile = CaptureProfile(device: camera.uniqueID, lensPosition: position,
            width: Int(d.width), height: Int(d.height),
            format: String(CMFormatDescriptionGetMediaSubType(camera.activeFormat.formatDescription)))
        discardUntil = CACurrentMediaTime() + 0.3
        startupCheck = CameraStartupCheck(requestedLens: position, earliestFrameTime: discardUntil)
    }
    private func finishStartup(ticket: Int, result: Result<CaptureProfile, Error>) {
        guard let request = starting, request.ticket == ticket, generation == ticket else { return }
        starting = nil; startupCheck = nil; focusAcquisition = nil
        switch result {
        case .success: ready = true
        case .failure: ready = false; profile = nil
        }
        request.completion(result)
        if case .failure = result, session.isRunning { session.stopRunning() }
    }
    private func configure() throws {
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back),
              camera.isLockingFocusWithCustomLensPositionSupported else { throw LabError.message("Sabit odak destekleyen geniş kamera bulunamadı.") }
        guard let format = camera.formats.first(where: {
            let d = CMVideoFormatDescriptionGetDimensions($0.formatDescription)
            return d.width == 1920 && d.height == 1080 && $0.videoSupportedFrameRateRanges.contains { $0.minFrameRate <= 30 && $0.maxFrameRate >= 30 }
        }) else { throw LabError.message("1920 × 1080 / 30 fps biçimi bulunamadı.") }
        session.beginConfiguration(); defer { session.commitConfiguration() }
        session.sessionPreset = .inputPriority
        let input = try AVCaptureDeviceInput(device: camera)
        guard session.canAddInput(input) else { throw LabError.message("Kamera girişi eklenemedi.") }
        session.addInput(input)
        let output = AVCaptureVideoDataOutput()
        do {
            try camera.lockForConfiguration()
            camera.activeFormat = format
            camera.activeVideoMinFrameDuration = CMTime(value: 1, timescale: 30)
            camera.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: 30)
            camera.isSubjectAreaChangeMonitoringEnabled = false
            camera.automaticallyAdjustsVideoHDREnabled = false
            if format.isVideoHDRSupported { camera.isVideoHDREnabled = false }
            camera.unlockForConfiguration()
            output.alwaysDiscardsLateVideoFrames = true
            // activeFormat alone does not guarantee the dimensions of delegate
            // buffers. Disable iOS preview sizing and request native dimensions.
            output.automaticallyConfiguresOutputBufferDimensions = false
            output.deliversPreviewSizedOutputBuffers = false
            output.setSampleBufferDelegate(self, queue: queue)
            guard session.canAddOutput(output) else { throw LabError.message("Görüntü çıkışı eklenemedi.") }
            session.addOutput(output)
            guard let connection = output.connection(with: .video), connection.isVideoRotationAngleSupported(0) else {
                throw LabError.message("Sensör yönünde kayıt bağlantısı oluşturulamadı.")
            }
            connection.isEnabled = true
            if connection.isVideoStabilizationSupported { connection.preferredVideoStabilizationMode = .off }
            if connection.isVideoMirroringSupported { connection.automaticallyAdjustsVideoMirroring = false; connection.isVideoMirrored = false }
            connection.videoRotationAngle = 0
            // Set dimensions after native orientation: AVFoundation requires
            // width/height to agree with the connection's rotation and aspect.
            output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                                    kCVPixelBufferWidthKey as String: 1920,
                                    kCVPixelBufferHeightKey as String: 1080]
            self.videoOutput = output
            self.device = camera
        } catch {
            if session.outputs.contains(where: { $0 === output }) { session.removeOutput(output) }
            session.removeInput(input); throw error
        }
    }
    private func startupFailure() -> CameraStartupFailure {
        let issue: CameraStartupIssue
        if session.isInterrupted { issue = .sessionInterrupted }
        else if !session.isRunning { issue = .sessionStopped }
        else if startupFrames == 0 { issue = .noFrames }
        else { issue = startupCheck?.lastIssue ?? focusAcquisition?.lastIssue ?? .settling }
        let connection = videoOutput?.connection(with: .video)
        let formatSize = device.map { CMVideoFormatDescriptionGetDimensions($0.activeFormat.formatDescription) }
        let version = (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "?"
        let details = """
        DentalArchLab \(version) / \(issue.rawValue)
        \(issue.explanation)
        Kayıt kareleri: \(startupFrames); düşen: \(startupDrops)
        Gelen boyut: \(startupWidth) × \(startupHeight); hedef: 1920 × 1080
        Sensör biçimi: \(formatSize?.width ?? 0) × \(formatSize?.height ?? 0)
        Odak seçimi: \(focusRequest == .automatic ? "otomatik → kilit" : "kayıtlı odak")
        Odak hedefi: \(requestedLens); okunan: \(device?.lensPosition ?? -1)
        Odak kilitli: \(device?.focusMode == .locked); ayarlanıyor: \(device?.isAdjustingFocus ?? false)
        Oturum: \(session.isRunning); kesinti: \(session.isInterrupted)
        Kayıt bağlantısı etkin: \(connection?.isEnabled ?? false); aktif: \(connection?.isActive ?? false)
        Kayıt dönüşü: \(connection?.videoRotationAngle ?? -1)
        Otomatik boyut: \(videoOutput?.automaticallyConfiguresOutputBufferDimensions ?? true)
        Önizleme boyutu: \(videoOutput?.deliversPreviewSizedOutputBuffers ?? true)
        """
        return CameraStartupFailure(message: "\(issue.explanation) [\(issue.rawValue)] Kamera hata ayrıntılarını açıp kopyalayabilirsiniz.", details: details)
    }
    func capture(compactTrial: Bool = false, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        queue.async {
            guard self.ready, self.session.isRunning, self.pending == nil else { completion(.failure(LabError.message("Kamera henüz hazır değil."))); return }
            self.compactTrialFrame = compactTrial
            self.pending = completion
            let ticket = self.generation
            self.captureTicket += 1; let shot = self.captureTicket
            self.queue.asyncAfter(deadline: .now() + 4) {
                if ticket == self.generation, shot == self.captureTicket, let pending = self.pending {
                    self.pending = nil; pending(.failure(LabError.message("Yeni kare alınamadı. Yeniden deneyin.")))
                }
            }
        }
    }
    func stop() { queue.async { self.stopOnQueue() } }
    private func stopOnQueue() {
        ready = false; generation += 1; startupCheck = nil; focusAcquisition = nil; profile = nil; lastCapturedTimestamp = nil
        let startup = starting; starting = nil
        let shot = pending; pending = nil
        startup?.completion(.failure(LabError.message("Kamera açılışı iptal edildi.")))
        shot?(.failure(LabError.message("Çekim durduruldu.")))
        if session.isRunning { session.stopRunning() }
    }
    func captureOutput(_ output: AVCaptureOutput, didOutput sample: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixels = CMSampleBufferGetImageBuffer(sample) else { return }
        if starting != nil {
            startupFrames += 1; startupWidth = CVPixelBufferGetWidth(pixels); startupHeight = CVPixelBufferGetHeight(pixels)
        }
        if var acquisition = focusAcquisition, let request = starting, let camera = device {
            let acquiredLens = acquisition.observe(now: CACurrentMediaTime(), running: session.isRunning,
                interrupted: session.isInterrupted, focusLocked: camera.focusMode == .locked,
                adjustingFocus: camera.isAdjustingFocus, lensPosition: camera.lensPosition,
                width: CVPixelBufferGetWidth(pixels), height: CVPixelBufferGetHeight(pixels),
                timestamp: CMSampleBufferGetPresentationTimeStamp(sample).seconds)
            focusAcquisition = acquisition
            if let acquiredLens {
                focusAcquisition = nil
                do { try prepareLockedFrames(camera: camera, position: acquiredLens, preserveCurrent: true) }
                catch { finishStartup(ticket: request.ticket, result: .failure(error)) }
            }
        }
        if var check = startupCheck, let request = starting, let camera = device, let p = profile {
            let usable = check.observe(now: CACurrentMediaTime(), running: session.isRunning,
                interrupted: session.isInterrupted, focusLocked: camera.focusMode == .locked,
                adjustingFocus: camera.isAdjustingFocus, lensPosition: camera.lensPosition,
                width: CVPixelBufferGetWidth(pixels), height: CVPixelBufferGetHeight(pixels),
                timestamp: CMSampleBufferGetPresentationTimeStamp(sample).seconds)
            startupCheck = check
            if usable { finishStartup(ticket: request.ticket, result: .success(p)) }
        }
        guard ready, CACurrentMediaTime() >= discardUntil, let callback = pending, let profile else { return }
        pending = nil
        guard let camera = device else { callback(.failure(LabError.message("Kamera bağlantısı yok."))); return }
        if let issue = CameraFocusGuard.issue(expectedLens: profile.lensPosition, focusLocked: camera.focusMode == .locked,
                                             adjustingFocus: camera.isAdjustingFocus, lensPosition: camera.lensPosition) {
            let message = "\(issue.explanation) Bu kare kaydedilmedi. Kamerayı yeniden açın; kayıtlı kareler korunuyor."
            stopOnQueue(); callback(.failure(LabError.message(message))); onInterruption?(message)
            return
        }
        guard CVPixelBufferGetWidth(pixels) == profile.width, CVPixelBufferGetHeight(pixels) == profile.height else {
            callback(.failure(LabError.message("Çözünürlük değişti; yeni kalibrasyon gerekli."))); return
        }
        let timestamp = CMSampleBufferGetPresentationTimeStamp(sample).seconds
        guard timestamp.isFinite, timestamp >= 0, lastCapturedTimestamp.map({ timestamp > $0 }) ?? true else {
            callback(.failure(LabError.message("Kameradan yeni zaman damgalı kare gelmedi."))); return
        }
        do {
            let ci = CIImage(cvPixelBuffer: pixels)
            guard let cg = context.createCGImage(ci, from: ci.extent) else { throw LabError.message("Görüntü oluşturulamadı.") }
            let bytes = NSMutableData()
            guard let target = CGImageDestinationCreateWithData(bytes, (compactTrialFrame ? UTType.jpeg : UTType.png).identifier as CFString, 1, nil) else { throw LabError.message("PNG açılamadı.") }
            let properties: CFDictionary? = compactTrialFrame ? [kCGImageDestinationLossyCompressionQuality: 0.94] as CFDictionary : nil
            CGImageDestinationAddImage(target, cg, properties)
            guard CGImageDestinationFinalize(target) else { throw LabError.message("PNG tamamlanamadı.") }
            lastCapturedTimestamp = timestamp
            callback(.success((bytes as Data, profile, timestamp)))
        } catch { callback(.failure(error)) }
    }
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        if starting != nil { startupDrops += 1 }
    }
}
