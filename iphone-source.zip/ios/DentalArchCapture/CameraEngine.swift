import AVFoundation
import Foundation
import QuartzCore

// Camera setup, settings and frame callbacks share one serial queue.
// iOS 17+, Swift 5 mode. Real Xcode/device validation is still required.
final class CameraEngine: NSObject, CameraControlling, AVCaptureVideoDataOutputSampleBufferDelegate {
    let session = AVCaptureSession()
    private let queue = DispatchQueue(label: "dal.camera.serial", qos: .userInitiated)
    private let encodingQueue = DispatchQueue(label: "dal.camera.encoding", qos: .userInitiated)
    private let frameEncoder = CameraFrameEncoder()
    private var frameWork = CameraFrameWorkGate()
    private var performance = CameraPerformanceMeter()
    private var lastPerformance: CameraPerformance?
    private var device: AVCaptureDevice?
    private var profile: CaptureProfile?
    private var ready = false
    private var generation = 0
    private var captureTicket = 0
    private var compactTrialFrame = false
    private var discardUntil: CFTimeInterval = 0
    private var pending: ((Result<CapturedCameraFrame, Error>) -> Void)?
    private var starting: (ticket: Int, completion: (Result<CaptureProfile, Error>) -> Void)?
    private var previewStarting: (ticket: Int, completion: (Result<Void, Error>) -> Void)?
    private var previewCheck: CameraPreviewCheck?
    private var previewActive = false
    private var startupCheck: CameraStartupCheck?
    private var focusAcquisition: CameraFocusAcquisition?
    private var waitingForLockedFrame: (ticket: Int, earliest: Double)?
    private var videoOutput: AVCaptureVideoDataOutput?
    private var startupFrames = 0
    private var startupDrops = 0
    private var startupWidth = 0
    private var startupHeight = 0
    private var requestedLens: Float = 0
    private var focusRequest: CameraFocusRequest = .automatic
    private var lastCapturedTimestamp: Double?
    private var illumination = CameraIllumination()
    private var torchDevice: AVCameraTorchDevice?
    private var torchObservations: [NSKeyValueObservation] = []
    private var lastTorchStatus: TorchStatus?
    private var opticsRequest: CameraOpticsRequest = .standard
    private var opticsChoice: CameraOpticsChoice?
    private var lastOpticsStatus: CameraOpticsStatus?
    private var opticsPublication = CameraOpticsPublicationGate()
    var onInterruption: ((String) -> Void)?
    var onIlluminationChanged: ((TorchStatus) -> Void)?
    var onPerformanceChanged: ((CameraPerformance) -> Void)?
    var onOpticsChanged: ((CameraOpticsStatus) -> Void)?

    override init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(interrupted), name: AVCaptureSession.wasInterruptedNotification, object: session)
        NotificationCenter.default.addObserver(self, selector: #selector(interrupted), name: AVCaptureSession.runtimeErrorNotification, object: session)
    }
    deinit {
        NotificationCenter.default.removeObserver(self)
        torchObservations.forEach { $0.invalidate() }
        let torch = torchDevice
        let captureSession = session
        queue.async {
            try? torch?.switchTorchOff()
            if captureSession.isRunning { captureSession.stopRunning() }
        }
    }
    func configureIllumination(enabled: Bool) {
        // Queued before start by the model. Never toggle lighting in the middle
        // of a frame or after the exposure/focus profile has already been locked.
        queue.async { self.illumination.configure(enabled: enabled) }
    }
    func configureOptics(_ request: CameraOpticsRequest) {
        // Selection is applied only by the next stopped-session startup. An
        // in-progress measurement never changes its physical camera or format.
        queue.async { self.opticsRequest = request }
    }
    private func publishOptics(width: Int, height: Int) {
        guard let camera=device, let choice=opticsChoice,
              opticsPublication.shouldPublish(now: CACurrentMediaTime()) else { return }
        let dimensions=CMVideoFormatDescriptionGetDimensions(camera.activeFormat.formatDescription)
        let minimum=camera.minimumFocusDistance
        let status=CameraOpticsStatus(lens:choice.lens, minimumFocusDistanceMM:minimum > 0 ? minimum : nil,
            sensorWidth:Int(dimensions.width), sensorHeight:Int(dimensions.height), outputWidth:width, outputHeight:height,
            focusTracking:camera.focusMode == .continuousAutoFocus, focusLocked:camera.focusMode == .locked,
            lensPosition:camera.lensPosition.isFinite ? camera.lensPosition : nil)
        guard status != lastOpticsStatus else { return }
        lastOpticsStatus=status; onOpticsChanged?(status)
    }
    private func publishIllumination() {
        let value = illumination.status(device: torchDevice)
        guard value != lastTorchStatus else { return }
        lastTorchStatus = value
        onIlluminationChanged?(value)
    }
    private func observeIllumination(camera: AVCaptureDevice) {
        torchObservations = [
            camera.observe(\.isTorchAvailable, options: [.new]) { [weak self] _, _ in
                guard let self else { return }
                self.queue.async { self.publishIllumination() }
            },
            camera.observe(\.isTorchActive, options: [.new]) { [weak self] _, _ in
                guard let self else { return }
                self.queue.async { self.publishIllumination() }
            }
        ]
    }
    @objc private func interrupted(_ note: Notification) {
        queue.async {
            guard self.ready || self.starting != nil || self.previewStarting != nil || self.pending != nil || self.session.isRunning else { return }
            self.stopOnQueue()
            self.onInterruption?("Kamera kesintiye uğradı. Görüntüler korunuyor; Kamerayı aç ile yeniden deneyin.")
        }
    }
    func startPreview(completion: @escaping (Result<Void, Error>) -> Void) {
        queue.async {
            self.stopOnQueue()
            let ticket = self.generation
            self.previewStarting = (ticket, completion)
            self.performance = CameraPerformanceMeter(); self.lastPerformance = nil
            self.startupFrames = 0; self.startupDrops = 0
            self.startupWidth = 0; self.startupHeight = 0
            // A restored metric profile must never enter autofocus preview.
            if case .restoring = self.opticsRequest {
                self.finishPreview(ticket: ticket, result: .failure(LabError.message("Kayıtlı ölçüm profili otomatik odak önizlemesine alınamaz.")))
                return
            }
            AVCaptureDevice.requestAccess(for: .video) { allowed in
                self.queue.async {
                    guard self.previewStarting?.ticket == ticket, self.generation == ticket else { return }
                    guard allowed else {
                        self.finishPreview(ticket: ticket, result: .failure(LabError.message("Kamera izni yok. Ayarlar > DentalArchLab bölümünden izin verin.")))
                        return
                    }
                    self.queue.asyncAfter(deadline: .now() + 8) {
                        guard self.previewStarting?.ticket == ticket, self.generation == ticket else { return }
                        self.finishPreview(ticket: ticket, result: .failure(self.startupFailure()))
                    }
                    do {
                        try self.configure()
                        guard let camera = self.device, camera.isFocusModeSupported(.continuousAutoFocus) else {
                            throw LabError.message("Bu fiziksel kamera sürekli otomatik odak takibini desteklemiyor.")
                        }
                        try camera.lockForConfiguration()
                        defer { camera.unlockForConfiguration() }
                        camera.videoZoomFactor = 1
                        camera.automaticallyAdjustsFaceDrivenAutoFocusEnabled = false
                        camera.isFaceDrivenAutoFocusEnabled = false
                        if camera.isFocusPointOfInterestSupported { camera.focusPointOfInterest = CGPoint(x: 0.5, y: 0.5) }
                        if camera.isAutoFocusRangeRestrictionSupported {
                            camera.autoFocusRangeRestriction = self.opticsChoice?.lens == "ultrawide" ? .near : .none
                        }
                        camera.focusMode = .continuousAutoFocus
                        if camera.isExposureModeSupported(.continuousAutoExposure) { camera.exposureMode = .continuousAutoExposure }
                        if camera.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) { camera.whiteBalanceMode = .continuousAutoWhiteBalance }
                    } catch { self.finishPreview(ticket: ticket, result: .failure(error)); return }
                    if !self.session.isRunning { self.session.startRunning() }
                    guard self.session.isRunning, !self.session.isInterrupted else {
                        self.finishPreview(ticket: ticket, result: .failure(LabError.message("Kamera önizlemesi başlatılamadı.")))
                        return
                    }
                    self.illumination.start(device: self.torchDevice, sessionRunning: true)
                    self.publishIllumination()
                    self.previewCheck = CameraPreviewCheck()
                }
            }
        }
    }
    private func finishPreview(ticket: Int, result: Result<Void, Error>) {
        guard let request = previewStarting, request.ticket == ticket, generation == ticket else { return }
        previewStarting = nil; previewCheck = nil
        // Even a successful AF preview may not issue a measurement CaptureProfile.
        ready = false; profile = nil
        switch result {
        case .success: previewActive = true
        case .failure:
            previewActive = false
            illumination.stop(device: torchDevice)
            if session.isRunning { session.stopRunning() }
            publishIllumination()
        }
        request.completion(result)
    }
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) {
        queue.async {
            self.stopOnQueue()
            let ticket = self.generation
            self.starting = (ticket, completion)
            self.performance = CameraPerformanceMeter(); self.lastPerformance = nil
            self.startupFrames = 0; self.startupDrops = 0
            self.startupWidth = 0; self.startupHeight = 0; self.focusRequest = focus
            if case .locked(let position) = focus { self.requestedLens = position }
            else { self.requestedLens = -1 }
            AVCaptureDevice.requestAccess(for: .video) { allowed in
                self.queue.async {
                    guard self.starting?.ticket == ticket, ticket == self.generation else { return }
                    guard allowed else {
                        self.finishStartup(ticket: ticket, result: .failure(LabError.message("Kamera izni yok. Ayarlar > DentalArchLab bölümünden izin verin.")))
                        return
                    }
                    // The model has a separate deadline on the MainActor, including
                    // permission and a potentially blocked startRunning() call.
                    self.queue.asyncAfter(deadline: .now() + 8) {
                        guard self.starting?.ticket == ticket else { return }
                        self.finishStartup(ticket: ticket, result: .failure(self.startupFailure()))
                    }
                    do {
                        try self.configure()
                        guard let camera = self.device else { throw LabError.message("Kamera bulunamadı.") }
                        if case .locked(let position) = focus {
                            guard position.isFinite, (0...1).contains(position) else { throw LabError.message("Kaydedilen odak geçersiz; yeni kalibrasyon gerekli.") }
                        } else if !camera.isFocusModeSupported(.autoFocus) {
                            throw LabError.message("Bu kamera tek seferlik otomatik odağı desteklemiyor.")
                        }
                        if !self.session.isRunning { self.session.startRunning() }
                        guard self.session.isRunning, !self.session.isInterrupted else { throw LabError.message("Kamera başlatılamadı. Kamerayı aç ile yeniden deneyin.") }
                        self.illumination.start(device: self.torchDevice, sessionRunning: true)
                        self.publishIllumination()
                        do {
                            try camera.lockForConfiguration()
                            defer { camera.unlockForConfiguration() }
                            camera.videoZoomFactor = 1
                            // Restore the same fixed rate after every session
                            // restart; keep the validated format and field of view.
                            let fps = CameraPerformance.targetFramesPerSecond
                            guard camera.activeFormat.videoSupportedFrameRateRanges.contains(where: {
                                $0.minFrameRate <= Double(fps) && $0.maxFrameRate >= Double(fps)
                            }) else { throw LabError.message("Kayıtlı kamera biçimi 30 fps desteklemiyor.") }
                            camera.activeVideoMinFrameDuration = CMTime(value: 1, timescale: Int32(fps))
                            camera.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: Int32(fps))
                            // Face-driven changes must not compete with a board or
                            // a saved optical profile. Change both flags under lock.
                            camera.automaticallyAdjustsFaceDrivenAutoFocusEnabled = false
                            camera.isFaceDrivenAutoFocusEnabled = false
                            if camera.isExposureModeSupported(.continuousAutoExposure) { camera.exposureMode = .continuousAutoExposure }
                            if camera.isWhiteBalanceModeSupported(.continuousAutoWhiteBalance) { camera.whiteBalanceMode = .continuousAutoWhiteBalance }
                            switch focus {
                            case .automatic:
                                if camera.isFocusPointOfInterestSupported { camera.focusPointOfInterest = CGPoint(x: 0.5, y: 0.5) }
                                if camera.isAutoFocusRangeRestrictionSupported {
                                    camera.autoFocusRangeRestriction = self.opticsChoice?.lens == "ultrawide" ? .near : .none
                                }
                                camera.focusMode = .autoFocus
                            case .locked(let position):
                                camera.setFocusModeLocked(lensPosition: position, completionHandler: nil)
                            }
                        }
                        if case .automatic = focus {
                            let now = CACurrentMediaTime()
                            self.focusAcquisition = CameraFocusAcquisition(earliestFrameTime: now + 1.5, deadline: now + 7.5)
                            return
                        }
                        // The saved-focus path also requires an actual delivered
                        // buffer before its profile can describe output dimensions.
                        self.waitingForLockedFrame = (ticket, CACurrentMediaTime() + 1.5)
                    } catch { self.finishStartup(ticket: ticket, result: .failure(error)) }
                }
            }
        }
    }
    private func prepareLockedFrames(camera: AVCaptureDevice, position: Float, preserveCurrent: Bool) throws {
        try camera.lockForConfiguration()
        defer { camera.unlockForConfiguration() }
        try validateActiveOptics(camera)
        if preserveCurrent {
            // Apple's sentinel locks without commanding a second mechanical
            // position move or rounding the observed autofocus result.
            camera.setFocusModeLocked(lensPosition: AVCaptureDevice.currentLensPosition, completionHandler: nil)
        } else if !camera.isAdjustingFocus,
                  CameraFocusGuard.issue(expectedLens: position, focusLocked: camera.focusMode == .locked,
                                         adjustingFocus: false, lensPosition: camera.lensPosition) != nil {
            // One bounded restore retry after startup settles. Never substitute
            // another optical profile or extend the existing startup deadline.
            camera.setFocusModeLocked(lensPosition: position, completionHandler: nil)
        }
        if camera.isExposureModeSupported(.locked) { camera.exposureMode = .locked }
        if camera.isWhiteBalanceModeSupported(.locked) { camera.whiteBalanceMode = .locked }
        guard let choice=opticsChoice, startupWidth == 1920, startupHeight == 1080 else {
            throw LabError.message("Kamera 1920 × 1080 ölçüm karesi üretmedi; farklı boyutla devam edilmedi.")
        }
        requestedLens = position
        profile = CaptureProfile(device: camera.uniqueID, lensPosition: position,
            width: startupWidth, height: startupHeight, format: choice.signature)
        profile?.lens = choice.lens
        discardUntil = CACurrentMediaTime() + 0.3
        startupCheck = CameraStartupCheck(requestedLens: position, earliestFrameTime: discardUntil)
    }
    private func validateActiveOptics(_ camera: AVCaptureDevice) throws {
        guard let choice=opticsChoice else { throw LabError.message("Fiziksel kamera seçimi bulunamadı.") }
        let actual=camera.activeFormat
        let dimensions=CMVideoFormatDescriptionGetDimensions(actual.formatDescription)
        guard Int(dimensions.width) == choice.format.width, Int(dimensions.height) == choice.format.height,
              CMFormatDescriptionGetMediaSubType(actual.formatDescription) == choice.format.mediaSubtype,
              actual.videoFieldOfView.bitPattern == choice.format.fieldOfView.bitPattern,
              actual.isVideoBinned == choice.format.binned, camera.videoZoomFactor == 1 else {
            throw LabError.message("Sensör biçimi veya görüş açısı değişti; farklı optikle kare kabul edilmedi.")
        }
        if let expected=choice.distortionCorrection {
            let actualCorrection=camera.isGeometricDistortionCorrectionSupported && camera.isGeometricDistortionCorrectionEnabled
            guard actualCorrection == expected else { throw LabError.message("Kamera bozulma düzeltmesi kayıtlı profille eşleşmiyor.") }
        }
    }
    private func finishStartup(ticket: Int, result: Result<CaptureProfile, Error>) {
        guard let request = starting, request.ticket == ticket, generation == ticket else { return }
        starting = nil; startupCheck = nil; focusAcquisition = nil; waitingForLockedFrame = nil
        switch result {
        case .success: ready = true
        case .failure:
            ready = false; profile = nil
            illumination.stop(device: torchDevice)
            if session.isRunning { session.stopRunning() }
            publishIllumination()
        }
        request.completion(result)
    }
    private func configure() throws {
        guard !session.isRunning else { throw LabError.message("Optik seçimi için kamera önce durdurulmalı.") }
        let lens=try CameraOpticsPolicy.lens(for: opticsRequest)
        let type: AVCaptureDevice.DeviceType = lens == "ultrawide" ? .builtInUltraWideCamera : .builtInWideAngleCamera
        // Physical inputs do not silently switch lenses when distance changes.
        guard let camera=AVCaptureDevice.default(type, for:.video, position:.back), !camera.isVirtualDevice,
              camera.isFocusModeSupported(.autoFocus), camera.isLockingFocusWithCustomLensPositionSupported else {
            throw LabError.message(lens == "ultrawide"
                ? "Bu cihazda sabitlenebilir otomatik odaklı yakın kamera yok. Standart kamerayı seçin."
                : "Sabit odak destekleyen standart kamera bulunamadı.")
        }
        let formats=camera.formats.enumerated().map { index, format -> CameraOpticsFormat in
            let size=CMVideoFormatDescriptionGetDimensions(format.formatDescription)
            return CameraOpticsFormat(index:index, mediaSubtype:CMFormatDescriptionGetMediaSubType(format.formatDescription),
                width:Int(size.width), height:Int(size.height), fieldOfView:format.videoFieldOfView,
                binned:format.isVideoBinned, phaseDetection:format.autoFocusSystem == .phaseDetection,
                supports30FPS:format.videoSupportedFrameRateRanges.contains { $0.minFrameRate <= 30 && $0.maxFrameRate >= 30 })
        }
        let choice=try CameraOpticsPolicy.choose(opticsRequest,deviceID:camera.uniqueID,lens:lens,
            supportsDistortionCorrection:camera.isGeometricDistortionCorrectionSupported,formats:formats)
        let format=camera.formats[choice.format.index]
        session.beginConfiguration(); defer { session.commitConfiguration() }
        // start() already stopped the session and cancelled prior frame tickets.
        // Invalidate observers/delegates before replacing their physical input.
        torchObservations.forEach { $0.invalidate() }; torchObservations=[]
        videoOutput?.setSampleBufferDelegate(nil, queue:nil)
        for output in session.outputs { session.removeOutput(output) }
        for input in session.inputs { session.removeInput(input) }
        device=nil; videoOutput=nil; torchDevice=nil; opticsChoice=nil
        lastTorchStatus=nil; lastOpticsStatus=nil; opticsPublication=CameraOpticsPublicationGate()
        session.sessionPreset = .inputPriority
        let input = try AVCaptureDeviceInput(device: camera)
        guard session.canAddInput(input) else { throw LabError.message("Kamera girişi eklenemedi.") }
        session.addInput(input)
        let output = AVCaptureVideoDataOutput()
        do {
            do {
                try camera.lockForConfiguration()
                defer { camera.unlockForConfiguration() }
                camera.activeFormat = format
                camera.activeVideoMinFrameDuration = CMTime(value: 1, timescale: 30)
                camera.activeVideoMaxFrameDuration = CMTime(value: 1, timescale: 30)
                camera.isSubjectAreaChangeMonitoringEnabled = false
                camera.automaticallyAdjustsVideoHDREnabled = false
                if format.isVideoHDRSupported { camera.isVideoHDREnabled = false }
                if let correction=choice.distortionCorrection {
                    guard !correction || camera.isGeometricDistortionCorrectionSupported else {
                        throw LabError.message("Seçilen sensör biçimi kayıtlı bozulma düzeltmesini desteklemiyor.")
                    }
                    if camera.isGeometricDistortionCorrectionSupported { camera.isGeometricDistortionCorrectionEnabled=correction }
                }
            }
            output.alwaysDiscardsLateVideoFrames = true
            // iOS16+ supports same-aspect downscaling via videoSettings. The
            // native preview uses the selected sensor format; measurement
            // buffers remain 1080p, with exact observed dimensions checked.
            output.automaticallyConfiguresOutputBufferDimensions = false
            output.deliversPreviewSizedOutputBuffers = false
            output.setSampleBufferDelegate(self, queue: queue)
            guard session.canAddOutput(output) else { throw LabError.message("Görüntü çıkışı eklenemedi.") }
            session.addOutput(output)
            guard let connection = output.connection(with: .video), connection.isVideoRotationAngleSupported(0) else {
                throw LabError.message("Sensör yönünde kayıt bağlantısı oluşturulamadı.")
            }
            connection.isEnabled = true
            if connection.isVideoStabilizationSupported { connection.preferredVideoStabilizationMode = .off }
            if connection.isVideoMirroringSupported { connection.automaticallyAdjustsVideoMirroring = false; connection.isVideoMirrored = false }
            connection.videoRotationAngle = 0
            // Set dimensions after native orientation: AVFoundation requires
            // width/height to agree with the connection's rotation and aspect.
            output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA,
                                    kCVPixelBufferWidthKey as String: 1920,
                                    kCVPixelBufferHeightKey as String: 1080]
            // Apple permits enabling this only before startRunning. The optional
            // attachment describes each delivered sample, not a guessed FOV.
            if connection.isCameraIntrinsicMatrixDeliverySupported { connection.isCameraIntrinsicMatrixDeliveryEnabled = true }
            self.videoOutput = output
            self.device = camera
            self.opticsChoice = choice
            self.torchDevice = AVCameraTorchDevice(camera)
            self.observeIllumination(camera: camera)
        } catch {
            output.setSampleBufferDelegate(nil, queue:nil)
            if session.outputs.contains(where: { $0 === output }) { session.removeOutput(output) }
            session.removeInput(input); throw error
        }
    }
    private func startupFailure() -> CameraStartupFailure {
        let issue: CameraStartupIssue
        if session.isInterrupted { issue = .sessionInterrupted }
        else if !session.isRunning { issue = .sessionStopped }
        else if startupFrames == 0 { issue = .noFrames }
        else { issue = startupCheck?.lastIssue ?? focusAcquisition?.lastIssue ?? previewCheck?.lastIssue ?? .settling }
        let connection = videoOutput?.connection(with: .video)
        let formatSize = device.map { CMVideoFormatDescriptionGetDimensions($0.activeFormat.formatDescription) }
        let version = (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "?"
        let details = """
        DentalArchLab \(version) / \(issue.rawValue)
        \(issue.explanation)
        Kayıt kareleri: \(startupFrames); düşen: \(startupDrops)
        Gelen boyut: \(startupWidth) × \(startupHeight); hedef: 1920 × 1080
        Sensör biçimi: \(formatSize?.width ?? 0) × \(formatSize?.height ?? 0)
        Fiziksel lens: \(opticsChoice?.lens ?? "yok"); minimum netleme: \(device?.minimumFocusDistance ?? -1) mm
        Optik imza: \(opticsChoice?.signature ?? "yok")
        Odak seçimi: \(focusRequest == .automatic ? "otomatik → kilit" : "kayıtlı odak")
        Odak hedefi: \(requestedLens); okunan: \(device?.lensPosition ?? -1)
        Odak kilitli: \(device?.focusMode == .locked); ayarlanıyor: \(device?.isAdjustingFocus ?? false)
        Flaş tercihi: \(illumination.requestedEnabled); ışık veriyor: \(device?.isTorchActive ?? false); kullanılabilir: \(device?.isTorchAvailable ?? false)
        Kamera hedefi: 30 fps; gelen kare hızı: \(lastPerformance?.framesPerSecond.map { String(format: "%.1f", $0) } ?? "henüz ölçülmedi")
        Kamera düşen kareleri: \(lastPerformance?.droppedFrames ?? 0); son kodlama: \(lastPerformance?.encodingMilliseconds.map { String(format: "%.1f ms", $0) } ?? "yok")
        Oturum: \(session.isRunning); kesinti: \(session.isInterrupted)
        Kayıt bağlantısı etkin: \(connection?.isEnabled ?? false); aktif: \(connection?.isActive ?? false)
        Kayıt dönüşü: \(connection?.videoRotationAngle ?? -1)
        Otomatik boyut: \(videoOutput?.automaticallyConfiguresOutputBufferDimensions ?? true)
        Önizleme boyutu: \(videoOutput?.deliversPreviewSizedOutputBuffers ?? true)
        """
        return CameraStartupFailure(message: "\(issue.explanation) [\(issue.rawValue)] Kamera hata ayrıntılarını açıp kopyalayabilirsiniz.", details: details)
    }
    func capture(compactTrial: Bool = false, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        captureFrame(compactTrial: compactTrial) { result in
            completion(result.map { ($0.image, $0.profile, $0.timestamp) })
        }
    }
    func captureFrame(compactTrial: Bool = false, completion: @escaping (Result<CapturedCameraFrame, Error>) -> Void) {
        queue.async {
            guard self.ready, self.session.isRunning, self.pending == nil else { completion(.failure(LabError.message("Kamera henüz hazır değil."))); return }
            guard self.frameWork.isIdle else { completion(.failure(LabError.message("Önceki görüntünün kodlanması tamamlanmadı; yeniden deneyin."))); return }
            self.compactTrialFrame = compactTrial
            self.pending = completion
            let ticket = self.generation
            self.captureTicket += 1; let shot = self.captureTicket
            self.queue.asyncAfter(deadline: .now() + 4) {
                if ticket == self.generation, shot == self.captureTicket, let pending = self.pending {
                    self.pending = nil; self.frameWork.cancel()
                    pending(.failure(LabError.message("Yeni kare alınamadı veya kodlanamadı. Yeniden deneyin.")))
                }
            }
        }
    }
    func stop() { queue.async { self.stopOnQueue() } }
    private func stopOnQueue() {
        ready = false; generation += 1; startupCheck = nil; focusAcquisition = nil; waitingForLockedFrame = nil; profile = nil; lastCapturedTimestamp = nil
        previewActive = false; previewCheck = nil
        let startup = starting; starting = nil
        let preview = previewStarting; previewStarting = nil
        let shot = pending; pending = nil
        frameWork.cancel()
        illumination.stop(device: torchDevice)
        if session.isRunning { session.stopRunning() }
        publishIllumination()
        startup?.completion(.failure(LabError.message("Kamera açılışı iptal edildi.")))
        preview?.completion(.failure(LabError.message("Kamera önizlemesi iptal edildi.")))
        shot?(.failure(LabError.message("Çekim durduruldu.")))
    }
    func captureOutput(_ output: AVCaptureOutput, didOutput sample: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard output === videoOutput else { return }
        publishIllumination()
        guard let pixels = CMSampleBufferGetImageBuffer(sample) else { return }
        publishOptics(width:CVPixelBufferGetWidth(pixels),height:CVPixelBufferGetHeight(pixels))
        let frameTimestamp = CMSampleBufferGetPresentationTimeStamp(sample).seconds
        if let measurement = performance.observe(timestamp: frameTimestamp, now: CACurrentMediaTime()) {
            lastPerformance = measurement; onPerformanceChanged?(measurement)
        }
        if starting != nil || previewStarting != nil {
            startupFrames += 1; startupWidth = CVPixelBufferGetWidth(pixels); startupHeight = CVPixelBufferGetHeight(pixels)
        }
        if var check = previewCheck, let request = previewStarting, let camera = device {
            let usable = check.observe(running: session.isRunning, interrupted: session.isInterrupted,
                continuousFocus: camera.focusMode == .continuousAutoFocus,
                width: CVPixelBufferGetWidth(pixels), height: CVPixelBufferGetHeight(pixels), timestamp: frameTimestamp)
            previewCheck = check
            if usable { finishPreview(ticket: request.ticket, result: .success(Void())) }
        }
        if let waiting=waitingForLockedFrame, waiting.ticket == generation,
           starting?.ticket == waiting.ticket, CACurrentMediaTime() >= waiting.earliest, let camera=device {
            waitingForLockedFrame=nil
            do {
                // Preserve the canonical calibrated focus, never an AF substitute.
                try prepareLockedFrames(camera:camera,position:requestedLens,preserveCurrent:false)
            } catch { finishStartup(ticket:waiting.ticket,result:.failure(error)) }
        }
        if var acquisition = focusAcquisition, let request = starting, let camera = device {
            let acquiredLens = acquisition.observe(now: CACurrentMediaTime(), running: session.isRunning,
                interrupted: session.isInterrupted, focusLocked: camera.focusMode == .locked,
                adjustingFocus: camera.isAdjustingFocus, lensPosition: camera.lensPosition,
                width: CVPixelBufferGetWidth(pixels), height: CVPixelBufferGetHeight(pixels),
                timestamp: CMSampleBufferGetPresentationTimeStamp(sample).seconds)
            focusAcquisition = acquisition
            if let acquiredLens {
                focusAcquisition = nil
                do { try prepareLockedFrames(camera: camera, position: acquiredLens, preserveCurrent: true) }
                catch { finishStartup(ticket: request.ticket, result: .failure(error)) }
            }
        }
        if var check = startupCheck, let request = starting, let camera = device, let p = profile {
            let usable = check.observe(now: CACurrentMediaTime(), running: session.isRunning,
                interrupted: session.isInterrupted, focusLocked: camera.focusMode == .locked,
                adjustingFocus: camera.isAdjustingFocus, lensPosition: camera.lensPosition,
                width: CVPixelBufferGetWidth(pixels), height: CVPixelBufferGetHeight(pixels),
                timestamp: CMSampleBufferGetPresentationTimeStamp(sample).seconds)
            startupCheck = check
            if usable { finishStartup(ticket: request.ticket, result: .success(p)) }
        }
        guard ready, CACurrentMediaTime() >= discardUntil, pending != nil, frameWork.isIdle, let profile else { return }
        guard let camera = device else { completePendingCapture(.failure(LabError.message("Kamera bağlantısı yok."))); return }
        do { try validateActiveOptics(camera) }
        catch {
            let callback=pending; pending=nil
            stopOnQueue(); callback?(.failure(error)); onInterruption?(error.localizedDescription)
            return
        }
        if let issue = CameraFocusGuard.issue(expectedLens: profile.lensPosition, focusLocked: camera.focusMode == .locked,
                                             adjustingFocus: camera.isAdjustingFocus, lensPosition: camera.lensPosition) {
            let message = "\(issue.explanation) Bu kare kaydedilmedi. Kamerayı yeniden açın; kayıtlı kareler korunuyor."
            let callback = pending; pending = nil
            stopOnQueue(); callback?(.failure(LabError.message(message))); onInterruption?(message)
            return
        }
        guard CVPixelBufferGetWidth(pixels) == profile.width, CVPixelBufferGetHeight(pixels) == profile.height else {
            completePendingCapture(.failure(LabError.message("Çözünürlük değişti; yeni kalibrasyon gerekli."))); return
        }
        let timestamp = frameTimestamp
        guard timestamp.isFinite, timestamp >= 0, lastCapturedTimestamp.map({ timestamp > $0 }) ?? true else {
            completePendingCapture(.failure(LabError.message("Kameradan yeni zaman damgalı kare gelmedi."))); return
        }
        let ticket = CameraFrameTicket(generation: generation, request: captureTicket)
        guard frameWork.begin(ticket) else { return }
        // Read while this exact CMSampleBuffer is live; value types travel with
        // its copied pixels through the same generation/request encoding ticket.
        let intrinsics = FrameCameraIntrinsics.read(from: sample, width: profile.width, height: profile.height)
        do {
            // Do not retain AVFoundation pool memory throughout PNG compression.
            // Only this bounded copy runs on the callback queue; camera control,
            // readiness and later frame delivery remain responsive while encoding.
            let ownedPixels = try CameraFrameEncoder.copyPixels(pixels)
            let compactTrial = compactTrialFrame
            encodingQueue.async {
                let started = CACurrentMediaTime()
                let result = Result { try self.frameEncoder.encode(ownedPixels, compactTrial: compactTrial) }
                let elapsed = CACurrentMediaTime() - started
                self.queue.async {
                    let deliver = self.frameWork.finish(ticket)
                    guard deliver, ticket.generation == self.generation,
                          ticket.request == self.captureTicket, self.pending != nil else { return }
                    self.performance.recordEncoding(seconds: elapsed)
                    switch result {
                    case .success(let data):
                        self.lastCapturedTimestamp = timestamp
                        self.completePendingCapture(.success(CapturedCameraFrame(image: data, profile: profile,
                                                                                timestamp: timestamp, intrinsics: intrinsics)))
                    case .failure(let error): self.completePendingCapture(.failure(error))
                    }
                }
            }
        } catch {
            _ = frameWork.finish(ticket)
            completePendingCapture(.failure(error))
        }
    }
    private func completePendingCapture(_ result: Result<CapturedCameraFrame, Error>) {
        let callback = pending; pending = nil; callback?(result)
    }
    func captureOutput(_ output: AVCaptureOutput, didDrop sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard output === videoOutput else { return }
        performance.recordDrop()
        if starting != nil || previewStarting != nil { startupDrops += 1 }
    }
}
