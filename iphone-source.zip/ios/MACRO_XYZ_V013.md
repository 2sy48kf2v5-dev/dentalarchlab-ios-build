# Yakın çekim ve XYZ · 0.13.0 (21)

Yakın çekim, kamera hazırlığı → fiziksel kalibrasyon → dört noktalı bayrak tanıma → çoklu görünüm XYZ hesabı boyunca kullanılır. 3B konum için gerçek basılmış bayraklar gerekir; bilgisayar ekranındaki ağız yalnız kimlik denemesidir.

## Telefonda deneme

1. Mevcut uygulamayı silmeden yeni IPA ile güncelle. Başlangıç'ta 0.13.0 yazmalı.
2. **Yeni kayıt hazırla → 3. Yakın çekim XYZ taraması**. Uygun ultra geniş lens kalibrasyonu yoksa kalibrasyon açılır. Eski geniş lens kalibrasyonu bu düğmeyle kullanılmaz.
3. Kalibrasyonda **Tahta ölçüsünü ayarla**: düz fiziksel tahtanın kare kenarını mm olarak gir. Örneğin beş karenin toplamı gerçekten 82 mm ise bir kare 16,4 mm'dir. Ölçünü yeniden doğrula; yazıcı ölçeklendirmesine güvenme. Tahta 10×7 kare / 9×6 iç köşedir.
4. **Kamerayı aç**: önizleme sürekli otomatik netler. Tahtayı, bayrakları tarayacağın çalışma mesafesinde net göster. **Kalibrasyon taramasını başlat**: kamera o anda netleyip odağı kilitler; farklı eğimler ve kadraj bölgelerinden uygun kareleri toplar.
5. Kalibrasyondan sonra **Yeni kayıt hazırla → Yakın çekim XYZ taraması**. Lens, odak, biçim ve çözünürlük kalibrasyondan geri çağrılır. Üstte **YAKIN ÇEKİM · Ultra geniş** görünmeli.
6. Gerçek model sabit kalsın. En az iki bayrağın dört beyaz noktası birlikte görünsün; telefonu yavaşça farklı açılara taşı. 24 uygun kare ve her bayrak için 8 görünüm hedeflenir. Yeşil noktalar tanımayı, ilerleme halkaları görünüm kapsamını gösterir.
7. Sonuçtaki XYZ, referans bayrağa göre araştırma geometrisidir. Ölçülmüş bayrak–MUA dönüşümü olmadan MUA merkezi/ekseni üretilmez. Doku birleştirme ve Exocad kapıları önceki sürümdeki fiziksel doğrulama koşullarını korur.

## Değişiklikler

- Önizlemede erken odak kilidi kaldırıldı. Önizleme ölçüm kaydı oluşturmaz; tek kare kaydetme henüz açık değildir. Tarama başlangıcında ayrı doğrulanmış ölçüm profili oluşturulur.
- Yeni 2B denemelerinde kareye ait AVFoundation kamera matrisi kullanılır. Eksik matris için odak uzaklığı uydurulmaz. Bu matris fiziksel distorsiyon kalibrasyonu değildir ve metrik ölçüm sayılmaz.
- 3B tarama da aynı iyileştirilmiş tanıma motorunu kullanır; kamera matrisi ve distorsiyon **ölçülmüş yerel kalibrasyondan** gelir. Donanım matrisi bu değerlerin üzerine yazılmaz.
- Global eşik yanında sınırlı yerel ışık uyarlaması gölgedeki aday noktaları bulur. Alt piksel iyileştirme özgün görüntüde yapılır. Kimlik, keskinlik, boyut, poz ve çoklu görünüm şartları gevşetilmedi.
- Aynı bayrağın iki maske tarafından bulunması tek adayda birleştirilir; fiziksel iki bayrağın aynı kimliği kullanması hâlâ reddedilir.
- Kareye ait matris, kalıcı kayıt/yeniden analiz/önizleme onayı/tanıma raporunda aynı görüntüye bağlanır. Sonradan değiştirilen matris eski analiz onayıyla kullanılamaz.

Eski 2B kayıtları geriye uyumluluk için eski tanıma yolunu korur; yeni yol için **Yeni kayıt hazırla** kullan. Kayıtlı fiziksel 3B oturumunda odak veya lens kendiliğinden değiştirilmez. Her mesafede optik netlik sağlanamaz; hedefi kalibrasyonla uyumlu netlik aralığında tutmak gerekir.

## Doğrulama kapsamı

Yeni testler sentetik dört/altı bayrak görüntüleri, gölge, eğik yakın görüntü, gürültü, eksik/yanlış nokta ve yinelenen kimlikleri sınar. Native kalibrasyon → tanıma → XYZ hesap → kayıt yeniden açma zinciri bilinen sentetik geometrilerle karşılaştırılır. Sürümün teslim raporu Apple üzerinde gerçekte çalıştırılan testlerin sonucunu ayrıca kaydeder.

Simulator testi fiziksel iPhone lensini, minimum mesafeyi, baskı toleransını veya hasta ağzındaki doğruluğu ölçmez. Gerçek denemede Ayrıntılar → **Tanıma raporu hazırla**, analiz edilen özgün kare ve tanıyı telefona kaydeder. Rapor fotoğraf içerir; paylaşımı kullanıcı başlatır. Mikron doğruluğu ancak kalibre referans ölçümle belirlenebilir.
