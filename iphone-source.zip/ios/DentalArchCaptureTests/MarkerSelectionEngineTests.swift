import Foundation
import XCTest
@testable import DentalArchCapture

/// Synthetic CAD pixels exercise real native detection and durable Swift
/// sessions. IDs remain physical dictionary identities throughout the pipeline.
@MainActor final class MarkerSelectionEngineTests: XCTestCase {
    private let selected = [1, 2, 4, 5]
    private var profile: CaptureProfile {
        CaptureProfile(device: "synthetic-selection", lensPosition: 0.55,
            width: 1920, height: 1080, format: "synthetic-selection-format")
    }
    private func folder() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("selected-ids-" + UUID().uuidString)
    }
    private func object<T: Encodable>(_ value: T) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(value)) as? [String: Any])
    }
    private func json(_ value: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }
    private func fixture() throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "vertical_arch", withExtension: "dat"))
        let data = try Data(contentsOf: url)
        XCTAssertEqual(PreviewCommit.digest(data), "4ef275ae3632262554517fe4ea93090a4a26ec633f39043658cd3bda71b4a730")
        return data
    }
    private func hardware() throws -> FrameCameraIntrinsics {
        try FrameCameraIntrinsics(width: 1920, height: 1080, fx: 2208, fy: 2208, cx: 960, cy: 540)
    }
    private func creation(mode: String = "trial", calibration: String? = nil) -> CaptureCreation {
        var value = CaptureCreation(mode: mode, markerCount: 4, profile: profile,
            physical: false, squareMM: nil, calibrationID: calibration)
        value.markerIDs = selected
        value.trialIntrinsicsRequired = true
        var plan = DentalPlan.vidaMUA9
        let teeth = [46, 43, 33, 36]
        plan.assignments = selected.enumerated().map { ToothAssignment(markerID: $0.element, fdi: teeth[$0.offset], componentCode: "MG-MUASBU") }
        value.dentalPlan = plan
        return value
    }
    private func measuredCamera() throws -> [String: Any] {
        ["schema_version": 1, "model": "opencv_pinhole",
         "K": [[2208.0,0,960],[0,2208,540],[0,0,1]], "image_size": [1920,1080], "distortion": [0.0,0,0,0,0],
         "metadata": ["status": "measured_research", "rms_px": 0.1, "views": 20, "warnings": [String](),
             "capture_profile": try object(profile), "physical_accuracy_validated": false, "synthetic_fixture": true]]
    }
    private func seedCalibration(_ client: OfflineClient, at root: URL) async throws -> String {
        let creation = CaptureCreation(mode: "calibration", markerCount: 6, profile: profile,
            physical: true, squareMM: 16.4, calibrationID: nil)
        var state = try await client.send("sessions", value: creation)
        state["state"] = "complete"; state["calibration"] = try measuredCamera()
        try json(state).write(to: root.appendingPathComponent(creation.id + ".json"))
        return creation.id
    }
    private func observation(_ id: Int, span: Double = 60, shift: Double = 0) -> [String: Any] {
        let x = 100 + Double(id)*180 + shift
        return ["marker": id, "corners": [[x,100],[x+span,100],[x,100+span],[x+span/3,100+span/3]],
            "min_side_px": span, "blur_laplacian": 100.0]
    }

    func testSelectionValidatesActualIdentitiesAndStrictJSONTypes() throws {
        XCTAssertEqual(try MarkerSelection.resolve(count: 4, ids: [5,1,4,2]), selected)
        XCTAssertEqual(try MarkerSelection.resolve(count: 4, ids: nil), [0,1,2,3])
        XCTAssertEqual(try MarkerSelection.decode(count: 6, raw: nil), [0,1,2,3,4,5])
        for ids in [[0,1,1,5], [0,1,4], [-1,1,4,5], [0,1,4,6]] {
            XCTAssertThrowsError(try MarkerSelection.resolve(count: 4, ids: ids))
        }
        XCTAssertThrowsError(try MarkerSelection.resolve(count: 5, ids: [0,1,2,3,4]))
        let invalid: [Any] = [NSNull(), "1,2,4,5", [true,2,4,5] as [Any], [1.5,2,4,5], ["1",2,4,5] as [Any], [Double.infinity,2,4,5]]
        for raw in invalid {
            XCTAssertThrowsError(try MarkerSelection.decode(count: 4, raw: raw))
        }
    }

    func testCreationRoundTripKeepsSelectionAndLegacyPrefixRemainsExplicit() throws {
        let model = creation()
        let decoded = try JSONDecoder().decode(CaptureCreation.self, from: JSONEncoder().encode(model))
        XCTAssertEqual(decoded.markerIDs, selected)
        var legacy = try object(model); legacy.removeValue(forKey: "marker_ids"); legacy.removeValue(forKey: "dental_plan")
        let old = try JSONDecoder().decode(CaptureCreation.self, from: json(legacy))
        XCTAssertNil(old.markerIDs)
        XCTAssertEqual(try MarkerSelection.resolve(count: old.markerCount, ids: old.markerIDs), [0,1,2,3])
    }

    func testOptionalCaseReferencePersistsLocallyAndRejectsOversizeOrControlCharacters() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root))
        var model = creation(); model.caseReference = "SYNTHETIC-CASE-01"
        let initial = try await client.send("sessions", value: model)
        XCTAssertEqual(initial["case_reference"] as? String, "SYNTHETIC-CASE-01")
        let decoded = try JSONDecoder().decode(CaptureCreation.self, from: JSONEncoder().encode(model))
        XCTAssertEqual(decoded.caseReference, model.caseReference)
        for reference in [String(repeating: "a", count: 81), "case\nsecond-line"] {
            var invalid = creation(); invalid.caseReference = reference
            do { _ = try await client.send("sessions", value: invalid); XCTFail("Invalid reference accepted") }
            catch { XCTAssertTrue(error.localizedDescription.contains("80")) }
        }
        let legacy = try JSONDecoder().decode(CaptureCreation.self, from: JSONEncoder().encode(creation()))
        XCTAssertNil(legacy.caseReference)
    }

    func testArbitraryFourTrialDetectsActualIDsPersistsCoverageAndReopensSummary() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root)), model = creation()
        let state = try await client.send("sessions", value: model)
        XCTAssertEqual(state["marker_ids"] as? [Int], selected)
        let bytes = try fixture(), k = try hardware(), frame = captureID()
        let receipt = try await client.frame("sessions/\(model.id)/frames", id: frame,
            image: bytes, profile: profile, timestamp: 2, intrinsics: k)
        XCTAssertEqual(receipt["accepted"] as? Bool, true)
        XCTAssertEqual((receipt["marker_ids"] as? [Int])?.sorted(), selected)
        XCTAssertEqual(receipt["expected_marker_ids"] as? [Int], selected)
        let feedback = try XCTUnwrap(receipt["feedback"] as? [String: Any])
        XCTAssertEqual(feedback["expected_marker_ids"] as? [Int], selected)
        XCTAssertEqual(feedback["missing_ids"] as? [Int], [])
        XCTAssertEqual(receipt["views"] as? [String: Int], ["1":1,"2":1,"4":1,"5":1])
        let done = try await client.request("sessions/\(model.id)/process", body: [:])
        let summary = try XCTUnwrap(done["trial_summary"] as? [String: Any])
        XCTAssertEqual(summary["recognized_ids"] as? [Int], selected)
        XCTAssertEqual(summary["expected_marker_ids"] as? [Int], selected)
        XCTAssertEqual(summary["expected_count"] as? Int, 4)
        XCTAssertNil(done["result"])
        let reopened = OfflineClient(engine: OfflineEngine(root: root))
        let persisted = try await reopened.request("sessions/\(model.id)")
        XCTAssertEqual(try json(persisted), try json(done))
    }

    func testSelectedScanUsesMeasuredCameraAndReportExportsThatExactBinding() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root))
        let calibration = try await seedCalibration(client, at: root)
        let model = creation(mode: "scan", calibration: calibration)
        _ = try await client.send("sessions", value: model)
        // Deliberately different hardware K must never override metric K.
        let hardware = try FrameCameraIntrinsics(width: 1920, height: 1080, fx: 600, fy: 600, cx: 960, cy: 540)
        let bytes = try fixture(), frame = captureID()
        let receipt = try await client.frame("sessions/\(model.id)/frames", id: frame,
            image: bytes, profile: profile, timestamp: 3, intrinsics: hardware)
        XCTAssertEqual(receipt["accepted"] as? Bool, true)
        XCTAssertEqual((receipt["marker_ids"] as? [Int])?.sorted(), selected)
        XCTAssertEqual(receipt["calibration_id"] as? String, calibration)
        XCTAssertEqual(receipt["used_camera_calibration"] as? NSDictionary, try measuredCamera() as NSDictionary)
        var sample = RecognitionSample(session: model.id, sample: frame, image: bytes, profile: profile,
            timestamp: 3, mode: "scan", markerCount: 4, response: receipt, intrinsics: hardware, markerIDs: selected)
        let path = try sample.write(to: root.appendingPathComponent("report"))
        let report = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: path)) as? [String: Any])
        XCTAssertEqual(report["marker_ids"] as? [Int], selected)
        XCTAssertEqual(report["calibration_id"] as? String, calibration)
        XCTAssertEqual(report["used_camera_calibration"] as? NSDictionary, try measuredCamera() as NSDictionary)
        XCTAssertEqual(report["frame_intrinsics"] as? NSDictionary, hardware.nativeDictionary() as NSDictionary)
        XCTAssertEqual(Data(base64Encoded: try XCTUnwrap(report["image_base64"] as? String)), bytes)
        let originalReport = try Data(contentsOf: path)
        var wrongMode = receipt; wrongMode["mode"] = "trial"
        var wrongSession = receipt; wrongSession["session_id"] = captureID()
        var wrongTime = receipt; wrongTime["timestamp_s"] = 4.0
        var missingCamera = receipt; missingCamera["used_camera_calibration"] = NSNull()
        var missingLink = receipt; missingLink["calibration_id"] = NSNull()
        var changedCamera = try measuredCamera()
        var cameraMetadata = try XCTUnwrap(changedCamera["metadata"] as? [String: Any])
        var changedProfile = profile; changedProfile.lens = "ultrawide"
        cameraMetadata["capture_profile"] = try object(changedProfile); changedCamera["metadata"] = cameraMetadata
        var wrongOptics = receipt; wrongOptics["used_camera_calibration"] = changedCamera
        for changed in [wrongMode, wrongSession, wrongTime, missingCamera, missingLink, wrongOptics] {
            let invalid = RecognitionSample(session: model.id, sample: frame, image: bytes, profile: profile,
                timestamp: 3, mode: "scan", markerCount: 4, response: changed, intrinsics: hardware, markerIDs: selected)
            XCTAssertThrowsError(try invalid.write(to: root.appendingPathComponent("report")))
        }
        XCTAssertEqual(try Data(contentsOf: path), originalReport)
        sample.markerIDs = [0,1,2,3]
        XCTAssertThrowsError(try sample.write(to: root.appendingPathComponent("report")))
        do { _ = try await client.request("sessions/\(model.id)/process", body: [:]); XCTFail("One frame cannot establish XYZ") }
        catch { XCTAssertTrue(error.localizedDescription.contains("12")) }
    }

    func testPreviewCommitAndReplayKeepSelectedCoverageAndCalibrationProvenance() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root)), model = creation()
        _ = try await client.send("sessions", value: model)
        let bytes = try fixture(), k = try hardware(), frame = captureID(), path = "sessions/\(model.id)"
        let preview = try await client.frame(path + "/preview", id: frame, image: bytes,
            profile: profile, timestamp: 4, intrinsics: k)
        XCTAssertEqual(preview["accepted"] as? Bool, true)
        var commit = PreviewCommit(session: model.id, id: frame, sha256: PreviewCommit.digest(bytes), profile: profile, timestamp: 4)
        commit.intrinsics = k
        let receipt = try await client.send(path + "/commit-preview", value: commit)
        XCTAssertEqual(receipt["expected_marker_ids"] as? [Int], selected)
        XCTAssertEqual(receipt["views"] as? [String: Int], ["1":1,"2":1,"4":1,"5":1])
        XCTAssertTrue(receipt["used_camera_calibration"] is NSNull)
        let replay = try await client.send(path + "/commit-preview", value: commit)
        XCTAssertEqual(try json(replay), try json(receipt))
    }

    func testSelectionMismatchRejectsCreationAndUnexpectedObservedID() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root))
        var model = creation(); model.markerIDs = [0,1,2,3]
        do { _ = try await client.send("sessions", value: model); XCTFail("FDI IDs were silently remapped") }
        catch { XCTAssertTrue(error.localizedDescription.contains("FDI")) }
        for bad in [[1,1,4,5] as [Any], [true,2,4,5] as [Any], [1.25,2,4,5] as [Any]] {
            var data = try object(creation()); data["marker_ids"] = bad
            do { _ = try await client.request("sessions", body: data); XCTFail("Invalid physical IDs accepted") }
            catch { XCTAssertFalse(error.localizedDescription.isEmpty) }
        }
        let sharp: [String: Any] = ["blur_laplacian": 100.0]
        XCTAssertTrue(try OfflineEngine.assess([observation(4), observation(5)], quality: sharp,
            history: [], markerCount: 4, markerIDs: selected).0)
        XCTAssertThrowsError(try OfflineEngine.assess([observation(0), observation(5)], quality: sharp,
            history: [], markerCount: 4, markerIDs: selected))
        XCTAssertThrowsError(try OfflineEngine.assess([observation(4), observation(4)], quality: sharp,
            history: [], markerCount: 4, markerIDs: selected))
        XCTAssertFalse(try OfflineEngine.assess([observation(4, span: 44.9), observation(5)], quality: sharp,
            history: [], markerCount: 4, markerIDs: selected).0)
    }

    func testCredibleSmallCandidatesExplainScaleBeforeMissingIdentityWithoutAcceptance() throws {
        let quality: [String: Any] = ["blur_laplacian": 100.0, "candidate_diagnostics": [
            ["best_id": 4, "best_score_px": 0.7, "reason": "ambiguous_identity", "span_px": 31.0,
             "centers_px": [[100.0,100],[131,100],[100,131],[110,110]]]]]
        let result = try OfflineEngine.assess([], quality: quality, history: [], markerCount: 4, markerIDs: selected)
        XCTAssertFalse(result.0)
        XCTAssertTrue(result.1.contains("31.0 px")); XCTAssertTrue(result.1.contains("45 px"))
        let insufficient = try OfflineEngine.assess([observation(4)], quality: ["blur_laplacian":100.0],
            history: [], markerCount: 4, markerIDs: selected)
        XCTAssertFalse(insufficient.0); XCTAssertTrue(insufficient.1.contains("En az 2"))
        let accepted = try OfflineEngine.assess([observation(4), observation(5)], quality: quality,
            history: [], markerCount: 4, markerIDs: selected)
        XCTAssertTrue(accepted.0, "Unselected small candidates must not veto sharp selected observations")
        let unselected = try OfflineEngine.assess([], quality: ["unselected_marker_ids": [0,3]],
            history: [], markerCount: 4, markerIDs: selected)
        XCTAssertFalse(unselected.0); XCTAssertTrue(unselected.1.contains("0, 3"))
        XCTAssertTrue(unselected.1.contains("seçili değil"))
    }

    func testLegacyMissingSelectionKeepsPrefixAndDoesNotAdoptNewPlanIDs() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root))
        var model = creation(); model.markerIDs = nil; model.dentalPlan = nil
        let initial = try await client.send("sessions", value: model)
        XCTAssertEqual(initial["marker_ids"] as? [Int], [0,1,2,3])
        let bytes = try fixture(), k = try hardware()
        let receipt = try await client.frame("sessions/\(model.id)/frames", id: captureID(), image: bytes,
            profile: profile, timestamp: 1, intrinsics: k)
        XCTAssertEqual((receipt["marker_ids"] as? [Int])?.sorted(), [0,1,2,3])
        XCTAssertEqual(receipt["views"] as? [String: Int], ["0":1,"1":1,"2":1,"3":1])
        var corrupted = try await client.request("sessions/\(model.id)")
        corrupted["marker_ids"] = [1,2,4,5]
        try json(corrupted).write(to: root.appendingPathComponent(model.id + ".json"))
        do { _ = try await client.request("sessions/\(model.id)/process", body: [:]); XCTFail("Saved observations were silently relabelled") }
        catch { XCTAssertTrue(error.localizedDescription.contains("eşleşmiyor")) }
    }
}
