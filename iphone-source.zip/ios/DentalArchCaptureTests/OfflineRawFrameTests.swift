import Foundation
import UIKit
import XCTest
@testable import DentalArchCapture

@MainActor final class OfflineRawFrameTests: XCTestCase {
    private var profile: CaptureProfile {
        CaptureProfile(device: "raw-frame-test", lensPosition: 0.55, width: 1920, height: 1080, format: "fixture")
    }
    private func creation(mode: String = "trial") -> CaptureCreation {
        var value = CaptureCreation(mode: mode, markerCount: 6, profile: profile,
            physical: false, squareMM: nil, calibrationID: nil)
        if mode == "trial" { var plan = DentalPlan(); plan.useExample(count: 6); value.dentalPlan = plan }
        return value
    }
    private func fixture() throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "vertical_arch", withExtension: "dat"))
        return try Data(contentsOf: url)
    }
    private func directory() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("raw-frame-" + UUID().uuidString)
    }
    private func canonical(_ receipt: [String: Any], removeTiming: Bool = false) throws -> Data {
        var value = receipt
        if removeTiming { value.removeValue(forKey: "timing") }
        return try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }
    private func legacy(_ client: OfflineClient, path: String, id: String, image: Data) async throws -> [String: Any] {
        try await client.send(path, value: FrameUpload(id: id, image: image.base64EncodedString(), profile: profile, timestamp: 3.5))
    }
    private func assertRejected(_ client: OfflineClient, path: String, id: String, image: Data,
        actualProfile: CaptureProfile? = nil, timestamp: Double = 3.5,
        file: StaticString = #filePath, line: UInt = #line) async {
        do {
            _ = try await client.frame(path, id: id, image: image, profile: actualProfile ?? profile, timestamp: timestamp)
            XCTFail("Invalid raw frame was accepted", file: file, line: line)
        } catch {
            XCTAssertFalse(error.localizedDescription.isEmpty, file: file, line: line)
        }
    }
    private func png(width: Int, height: Int, chessboard: Bool = false) -> Data {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        return UIGraphicsImageRenderer(size: CGSize(width: CGFloat(width), height: CGFloat(height)), format: format).pngData { context in
            UIColor.white.setFill(); context.fill(CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))
            if chessboard {
                UIColor.black.setFill()
                for row in 0..<7 { for column in 0..<10 where (row + column) % 2 == 0 {
                    context.fill(CGRect(x: 360 + column*100, y: 180 + row*100, width: 100, height: 100))
                } }
            }
        }
    }

    func testRawAndLegacyFlagFramesHaveIdenticalGeometryHashAndCoverage() async throws {
        let first = directory(), second = directory()
        defer { try? FileManager.default.removeItem(at: first); try? FileManager.default.removeItem(at: second) }
        let rawClient = OfflineClient(engine: OfflineEngine(root: first))
        let encodedClient = OfflineClient(engine: OfflineEngine(root: second))
        let value = creation(), id = captureID(), image = try fixture()
        _ = try await rawClient.send("sessions", value: value)
        _ = try await encodedClient.send("sessions", value: value)
        let path = "sessions/\(value.id)/frames"
        let raw = try await rawClient.frame(path, id: id, image: image, profile: profile, timestamp: 3.5)
        let encoded = try await legacy(encodedClient, path: path, id: id, image: image)
        XCTAssertEqual(try canonical(raw, removeTiming: true), try canonical(encoded, removeTiming: true))
        XCTAssertEqual(raw["sha256"] as? String, PreviewCommit.digest(image))
        XCTAssertEqual(raw["accepted"] as? Bool, true)
        XCTAssertEqual((raw["marker_ids"] as? [Int])?.sorted(), Array(0..<6))
        let feedback = try LiveFeedback.decode(raw, session: value.id, sample: id, count: 6)
        XCTAssertEqual(feedback.completedIDs, Array(0..<6))
        let stored = try await rawClient.request("sessions/\(value.id)")
        let saved = try XCTUnwrap((stored["accepted"] as? [[String: Any]])?.first)
        XCTAssertNil(saved["image"], "Raw bytes belong to CaptureRepository, not observation JSON")
    }

    func testRawPreviewCommitsThroughExistingCacheAndReplaysAfterActorReopen() async throws {
        let folder = directory(); defer { try? FileManager.default.removeItem(at: folder) }
        let client = OfflineClient(engine: OfflineEngine(root: folder))
        let value = creation(), id = captureID(), image = try fixture()
        _ = try await client.send("sessions", value: value)
        let base = "sessions/\(value.id)"
        let preview = try await client.frame(base + "/preview", id: id, image: image, profile: profile, timestamp: 3.5)
        XCTAssertEqual(preview["accepted"] as? Bool, true)
        XCTAssertEqual(preview["count"] as? Int, 0)
        let before = try await client.request(base)
        XCTAssertEqual((before["receipts"] as? [String: Any])?.count, 0)
        let commit = PreviewCommit(session: value.id, id: id, sha256: PreviewCommit.digest(image), profile: profile, timestamp: 3.5)
        let receipt = try await client.send(base + "/commit-preview", value: commit)
        XCTAssertEqual(receipt["count"] as? Int, 1)
        XCTAssertEqual((receipt["timing"] as? [String: Double])?["detection_ms"], 0)
        let reopened = OfflineClient(engine: OfflineEngine(root: folder))
        let repeated = try await reopened.frame(base + "/frames", id: id, image: image, profile: profile, timestamp: 3.5)
        XCTAssertEqual(try canonical(receipt), try canonical(repeated))
        let legacyReplay = try await legacy(reopened, path: base + "/frames", id: id, image: image)
        XCTAssertEqual(try canonical(receipt), try canonical(legacyReplay))
    }

    func testLegacyReceiptReplaysThroughRawPathAndDifferentBytesCannotReuseIdentity() async throws {
        let folder = directory(); defer { try? FileManager.default.removeItem(at: folder) }
        let client = OfflineClient(engine: OfflineEngine(root: folder))
        let value = creation(), id = captureID(), image = try fixture()
        _ = try await client.send("sessions", value: value)
        let path = "sessions/\(value.id)/frames"
        let receipt = try await legacy(client, path: path, id: id, image: image)
        let raw = try await client.frame(path, id: id, image: image, profile: profile, timestamp: 3.5)
        XCTAssertEqual(try canonical(receipt), try canonical(raw))
        var changed = image; changed.append(0)
        await assertRejected(client, path: path, id: id, image: changed)
        let state = try await client.request("sessions/\(value.id)")
        XCTAssertEqual(state["count"] as? Int, 1)
        XCTAssertEqual((state["receipts"] as? [String: Any])?.count, 1)
    }

    func testRawPathRejectsInvalidBytesSizeProfileTimestampIdentityAndEndpoint() async throws {
        let folder = directory(); defer { try? FileManager.default.removeItem(at: folder) }
        let client = OfflineClient(engine: OfflineEngine(root: folder))
        let value = creation(), image = try fixture()
        _ = try await client.send("sessions", value: value)
        let base = "sessions/\(value.id)", path = base + "/frames"
        for bytes in [Data(), Data("not an image".utf8), Data(repeating: 0, count: 8*1024*1024+1), png(width: 32, height: 32)] {
            await assertRejected(client, path: path, id: captureID(), image: bytes)
        }
        var wrong = profile; wrong.width = 1280
        await assertRejected(client, path: path, id: captureID(), image: image, actualProfile: wrong)
        wrong = profile; wrong.lensPosition = .nan
        await assertRejected(client, path: path, id: captureID(), image: image, actualProfile: wrong)
        await assertRejected(client, path: path, id: "../frame", image: image)
        await assertRejected(client, path: path, id: captureID(), image: image, timestamp: -.infinity)
        await assertRejected(client, path: path, id: captureID(), image: image, timestamp: -1)
        for endpoint in [base + "/process", base + "/commit-preview", "sessions/../frames", "status"] {
            await assertRejected(client, path: endpoint, id: captureID(), image: image)
        }
        let state = try await client.request(base)
        XCTAssertEqual(state["count"] as? Int, 0)
        XCTAssertEqual((state["receipts"] as? [String: Any])?.count, 0)
    }

    func testReplacedPreviewStillRequiresFallbackWithTheOriginalFrameBytes() async throws {
        let folder = directory(); defer { try? FileManager.default.removeItem(at: folder) }
        let client = OfflineClient(engine: OfflineEngine(root: folder))
        let value = creation(), firstID = captureID(), secondID = captureID(), image = try fixture()
        _ = try await client.send("sessions", value: value)
        let base = "sessions/\(value.id)"
        _ = try await client.frame(base + "/preview", id: firstID, image: image, profile: profile, timestamp: 3.5)
        _ = try await client.frame(base + "/preview", id: secondID, image: image, profile: profile, timestamp: 4)
        let oldCommit = PreviewCommit(session: value.id, id: firstID, sha256: PreviewCommit.digest(image), profile: profile, timestamp: 3.5)
        do {
            _ = try await client.send(base + "/commit-preview", value: oldCommit)
            XCTFail("Replaced cache entry was accepted")
        } catch let error as BridgeHTTPError { XCTAssertEqual(error.status, 409) }
        let fallback = try await client.frame(base + "/frames", id: firstID, image: image, profile: profile, timestamp: 3.5)
        XCTAssertEqual(fallback["id"] as? String, firstID)
        XCTAssertEqual(fallback["sha256"] as? String, oldCommit.sha256)
        XCTAssertEqual(fallback["count"] as? Int, 1)
    }

    func testRawAndLegacyCalibrationPreviewPreserveCornersAndRemainUncommitted() async throws {
        let first = directory(), second = directory()
        defer { try? FileManager.default.removeItem(at: first); try? FileManager.default.removeItem(at: second) }
        let rawClient = OfflineClient(engine: OfflineEngine(root: first))
        let encodedClient = OfflineClient(engine: OfflineEngine(root: second))
        let value = creation(mode: "calibration"), id = captureID()
        let image = png(width: 1920, height: 1080, chessboard: true)
        _ = try await rawClient.send("sessions", value: value)
        _ = try await encodedClient.send("sessions", value: value)
        let path = "sessions/\(value.id)/preview"
        let raw = try await rawClient.frame(path, id: id, image: image, profile: profile, timestamp: 3.5)
        let encoded = try await legacy(encodedClient, path: path, id: id, image: image)
        XCTAssertEqual(try canonical(raw, removeTiming: true), try canonical(encoded, removeTiming: true))
        let feedback = try CalibrationFeedback.decode(raw, session: value.id, sample: id)
        XCTAssertEqual(feedback.cornerCount, 54)
        XCTAssertEqual(feedback.acceptedFrames, 0)
        XCTAssertTrue(feedback.preview)
        XCTAssertEqual(raw["sha256"] as? String, PreviewCommit.digest(image))
    }

    func testRawFrameKeepsTrialRefocusExceptionButCalibrationFocusMustMatch() async throws {
        let folder = directory(); defer { try? FileManager.default.removeItem(at: folder) }
        let client = OfflineClient(engine: OfflineEngine(root: folder))
        let trial = creation(), calibration = creation(mode: "calibration"), image = try fixture()
        _ = try await client.send("sessions", value: trial)
        _ = try await client.send("sessions", value: calibration)
        var refocused = profile; refocused.lensPosition = 0.73
        let accepted = try await client.frame("sessions/\(trial.id)/frames", id: captureID(), image: image,
            profile: refocused, timestamp: 3.5)
        XCTAssertEqual(accepted["accepted"] as? Bool, true)
        let actual = try XCTUnwrap(accepted["capture_profile"] as? [String: Any])
        XCTAssertEqual(actual["lens_position"] as? Double ?? -1, Double(refocused.lensPosition), accuracy: 1e-6)
        await assertRejected(client, path: "sessions/\(calibration.id)/frames", id: captureID(), image: image,
            actualProfile: refocused)
        let state = try await client.request("sessions/\(calibration.id)")
        XCTAssertEqual(state["count"] as? Int, 0)
    }
}
