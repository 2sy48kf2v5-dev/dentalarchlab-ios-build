import Foundation
import UIKit
import XCTest
@testable import DentalArchCapture

/// Original DAL CAD pixel fixtures. These test the production native detector,
/// including calibrated macro inputs; they are not photographs or metrology.
final class NativeMacroRecognitionTests: XCTestCase {
    private let hashes = [
        "macro_oblique_id0": "35702858d64372799736182120e165aa6c69dd489d46192e58897c7c98e1c99d",
        "macro_oblique_id4": "29dfe3672c9f47049b5d875e862e55290d26ecd3eca9e5afc0c2f712bf8c8371",
        "shadowed_vertical_arch": "276e65b54419f387f0af42cfd6d3e82f12ce9f7aa4ddfdc77a29d98d809091dd",
        "macro_noise": "eb68d4ff58e0656bf2f903c74a684d42b418912de460b8cc4cb5c6ca0578c2c4",
        "macro_backface": "c7c94868f6218f3a6dae1e376aec8265487f087b55e28e1561c58fe29716f0f0",
        "macro_wrong_layout": "f7b9b2ef8f21febb647cb4925ccc2de8368402d82ef118549c35f42e43d63678",
        "macro_occluded": "e60da15327c60b266a096c527a2edfb7317785854d113f99ba464dd8b96790f9",
        "macro_highlight": "9b9dec9f0f90de88cb326621eecf2c1191a757150311cf82ea14068aa9a127a6",
        "macro_duplicate_id4": "4dd650dbc11e6005e3449a023b7dbf16b311f4ac1398605a6fe24139b539daa9"
    ]
    private func fixture(_ name: String) throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "dat"))
        let data = try Data(contentsOf: url)
        XCTAssertEqual(PreviewCommit.digest(data), try XCTUnwrap(hashes[name]))
        return data
    }
    private func intrinsics(focal: Double = 600, width: Int = 1920, height: Int = 1080,
                            source: String = "avfoundation_sample_buffer") -> [String: Any] {
        ["K": [[focal, 0, Double(width)/2], [0, focal, Double(height)/2], [0, 0, 1]],
         "width": width, "height": height, "source": source]
    }
    private func camera(focal: Double = 600) -> [String: Any] {
        ["schema_version": 1, "model": "opencv_pinhole", "K": intrinsics(focal: focal)["K"]!,
         "image_size": [1920,1080], "distortion": [0.0,0,0,0,0]]
    }
    private func ids(_ result: [String: Any]) throws -> [Int] {
        try XCTUnwrap(result["observations"] as? [[String: Any]])
            .map { try XCTUnwrap($0["marker"] as? Int) }.sorted()
    }
    private func quality(_ result: [String: Any]) throws -> [String: Any] {
        try XCTUnwrap(result["quality"] as? [String: Any])
    }
    private func evidence(_ result: [String: Any], _ name: String) throws {
        let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        let attachment = XCTAttachment(data: data, uniformTypeIdentifier: "public.json")
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }
    private func rejects(_ name: String) throws {
        let result = try DALNativeEngine.detect(image: fixture(name), camera: camera(), markerCount: 6)
        try evidence(result, name + ".json")
        XCTAssertEqual(try ids(result), [])
    }

    func testCalibratedMacroObliqueIDsZeroAndFourUseActualLensK() throws {
        for marker in [0,4] {
            let image = try fixture("macro_oblique_id\(marker)")
            let result = try DALNativeEngine.detect(image: image, camera: camera(), markerCount: 6)
            XCTAssertEqual(try ids(result), [marker])
            XCTAssertEqual(result["metric_intrinsics"] as? Bool, true)
            XCTAssertEqual(try quality(result)["detector_mode"] as? String, "calibrated_pose_3d")
            try evidence(result, "macro-calibrated-\(marker).json")
            // This reproduces the prior ultra-wide failure: wide-lens focal K
            // cannot be substituted merely because the JPEG size is unchanged.
            let wrong = try DALNativeEngine.detect(image: image, camera: camera(focal: 2208), markerCount: 6)
            XCTAssertEqual(try ids(wrong), [])
        }
    }

    func testHardwareIntrinsicsTrialRecognizesMacroButNeverClaimsMetric() throws {
        let result = try DALNativeEngine.detectTrial(image: fixture("macro_oblique_id4"),
            intrinsics: intrinsics(), markerCount: 6)
        XCTAssertEqual(try ids(result), [4])
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, false)
        let q = try quality(result)
        XCTAssertEqual(q["preview_only"] as? Bool, true)
        XCTAssertEqual(q["detector_mode"] as? String, "hardware_intrinsics_pose_2d")
        XCTAssertEqual(q["intrinsics_source"] as? String, "avfoundation_sample_buffer")
        XCTAssertEqual(q["distortion_source"] as? String, "unmodeled_zero_preview")
        XCTAssertNil(result["T_world_marker"])
    }

    func testTrialMissingHardwareMetadataHasTypedErrorInsteadOfInventedFocal() throws {
        let image = try fixture("macro_oblique_id4")
        XCTAssertThrowsError(try DALNativeEngine.detectTrial(image: image, intrinsics: nil, markerCount: 6)) { error in
            let error = error as NSError
            XCTAssertEqual(error.domain, "DentalArchLab.NativeEngine")
            XCTAssertEqual(error.code, 1001)
            XCTAssertEqual(error.userInfo["reason"] as? String, "trial_intrinsics_required")
        }
    }

    func testTrialRejectsMissingKWrongResolutionOrUntrustedSource() throws {
        let image = try fixture("macro_oblique_id0")
        var missingK = intrinsics(); missingK.removeValue(forKey: "K")
        var guessed = intrinsics(); guessed["source"] = "guessed_focal"
        var wrongResolution = intrinsics(); wrongResolution["width"] = 1280
        var badK = intrinsics(); badK["K"] = [[0.0,0,960],[0,600,540],[0,0,1]]
        for value in [missingK, guessed, wrongResolution, badK] {
            XCTAssertThrowsError(try DALNativeEngine.detectTrial(image: image, intrinsics: value, markerCount: 6)) { error in
                XCTAssertEqual((error as NSError).code, 1002)
                XCTAssertEqual((error as NSError).userInfo["reason"] as? String, "trial_intrinsics_invalid")
            }
        }
    }

    func testLocallyCalibratedTrialStillCannotProduceMetricMeasurements() throws {
        var value = intrinsics(source: "local_calibration"); value["distortion"] = [0.0,0,0,0,0]
        let result = try DALNativeEngine.detectTrial(image: fixture("macro_oblique_id4"), intrinsics: value, markerCount: 6)
        XCTAssertEqual(try ids(result), [4])
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, false)
        XCTAssertEqual(try quality(result)["detector_mode"] as? String, "local_calibration_pose_2d")
        XCTAssertEqual(try quality(result)["distortion_source"] as? String, "calibration_coefficients")
        value.removeValue(forKey: "distortion")
        XCTAssertThrowsError(try DALNativeEngine.detectTrial(image: fixture("macro_oblique_id4"), intrinsics: value, markerCount: 6))
    }

    func testEmptyHardwareDistortionIsExplicitlyAnUncalibratedPreviewApproximation() throws {
        var value = intrinsics(); value["distortion"] = [Double]()
        let result = try DALNativeEngine.detectTrial(image: fixture("macro_oblique_id0"), intrinsics: value, markerCount: 6)
        XCTAssertEqual(try ids(result), [0])
        XCTAssertEqual(try quality(result)["distortion_source"] as? String, "unmodeled_zero_preview")
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, false)
        value["distortion"] = [0.0, 0, 0] // Unsupported length must never be padded.
        XCTAssertThrowsError(try DALNativeEngine.detectTrial(image: fixture("macro_oblique_id0"), intrinsics: value, markerCount: 6))
    }

    func testCalibratedShadowedActualVerticalCADRecoversAllSixWithoutChangingThresholds() throws {
        let result = try DALNativeEngine.detect(image: fixture("shadowed_vertical_arch"), camera: camera(focal: 1920), markerCount: 6)
        try evidence(result, "calibrated-shadow-original-cad.json")
        XCTAssertEqual(try ids(result), [0,1,2,3,4,5])
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, true)
        let q = try quality(result)
        let proposal = try XCTUnwrap(q["proposal_diagnostics"] as? [String: Any])
        XCTAssertEqual(proposal["global_groups"] as? Int, 0)
        XCTAssertEqual(proposal["local_groups"] as? Int, 6)
        XCTAssertEqual(proposal["budget_exceeded"] as? Bool, false)
        XCTAssertEqual(proposal["refinement_pixels"] as? String, "original_gray")
        for match in try XCTUnwrap(q["identity_matches"] as? [[String: Any]]) {
            XCTAssertLessThanOrEqual(try XCTUnwrap(match["score"] as? Double), 0.85)
            XCTAssertLessThanOrEqual(try XCTUnwrap(match["identity_ratio"] as? Double), 0.60)
            XCTAssertGreaterThanOrEqual(try XCTUnwrap(match["identity_gap_px"] as? Double), 0.20)
        }
    }

    func testRepeatedProposalMasksDoNotCountOnePhysicalFlagTwice() throws {
        let result = try DALNativeEngine.detect(image: fixture("macro_oblique_id4"), camera: camera(), markerCount: 6)
        XCTAssertEqual(try ids(result), [4])
        let q = try quality(result), p = try XCTUnwrap(q["proposal_diagnostics"] as? [String: Any])
        XCTAssertEqual(q["dot_groups"] as? Int, 1)
        XCTAssertEqual(p["global_groups"] as? Int, 1)
        XCTAssertEqual(p["local_groups"] as? Int, 1)
        XCTAssertEqual(p["deduplicated_groups"] as? Int, 1)
        XCTAssertFalse(try XCTUnwrap(q["rejected"] as? [String]).contains { $0.contains("Yinelenen") })
    }

    func testIdenticalShadowedImageProducesExactlyIdenticalGeometryAndDiagnostics() throws {
        let image = try fixture("shadowed_vertical_arch")
        let first = try DALNativeEngine.detect(image: image, camera: camera(focal: 1920), markerCount: 6)
        let expected = try JSONSerialization.data(withJSONObject: first, options: [.sortedKeys])
        for _ in 0..<3 {
            let next = try DALNativeEngine.detect(image: image, camera: camera(focal: 1920), markerCount: 6)
            XCTAssertEqual(try JSONSerialization.data(withJSONObject: next, options: [.sortedKeys]), expected)
        }
    }

    func testSeededPixelNoiseIsBoundedAndCannotProduceAFlag() throws {
        let value: [String: Any] = ["schema_version": 1, "model": "opencv_pinhole",
            "K": [[400.0,0,256],[0,400,256],[0,0,1]], "image_size": [512,512], "distortion": [0.0,0,0,0,0]]
        let result = try DALNativeEngine.detect(image: fixture("macro_noise"), camera: value, markerCount: 6)
        XCTAssertEqual(try ids(result), [])
        let q = try quality(result), p = try XCTUnwrap(q["proposal_diagnostics"] as? [String: Any])
        XCTAssertEqual(p["budget_exceeded"] as? Bool, true)
        XCTAssertEqual(p["budget_reason"] as? String, "contour_limit")
        XCTAssertEqual(p["refined_circle_proposals"] as? Int, 0)
        XCTAssertFalse(try XCTUnwrap(q["rejected"] as? [String]).isEmpty)
    }

    private func crowdedCircles(side: Int, isolated: Bool) -> Data {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        return UIGraphicsImageRenderer(size: CGSize(width: 1920, height: 1080), format: format).pngData { context in
            UIColor(white: 210.0/255, alpha: 1).setFill()
            context.fill(CGRect(x: 0, y: 0, width: 1920, height: 1080))
            if !isolated {
                UIColor(white: 12.0/255, alpha: 1).setFill()
                context.fill(CGRect(x: 100, y: 100, width: CGFloat(side * 20), height: CGFloat(side * 20)))
            }
            for row in 0..<side { for column in 0..<side {
                let x = CGFloat(100 + column * (isolated ? 24 : 20))
                let y = CGFloat(100 + row * (isolated ? 24 : 20))
                if isolated {
                    UIColor(white: 12.0/255, alpha: 1).setFill()
                    context.fill(CGRect(x: x, y: y, width: 20, height: 20))
                }
                UIColor(white: 236.0/255, alpha: 1).setFill()
                context.cgContext.fillEllipse(in: CGRect(x: x + 5, y: y + 5, width: 10, height: 10))
            } }
        }
    }
    private func rejectedBudget(_ image: Data, reason: String) throws -> [String: Any] {
        let result = try DALNativeEngine.detect(image: image, camera: camera(), markerCount: 6)
        XCTAssertEqual(try ids(result), [], "No partial result may hide a duplicate in discarded proposals")
        let p = try XCTUnwrap(try quality(result)["proposal_diagnostics"] as? [String: Any])
        XCTAssertEqual(p["budget_exceeded"] as? Bool, true)
        XCTAssertEqual(p["budget_reason"] as? String, reason)
        return p
    }
    func testCrowdedParentCannotBeSilentlySkippedAndHideDuplicateIdentities() throws {
        let p = try rejectedBudget(crowdedCircles(side: 11, isolated: false), reason: "component_circle_limit")
        XCTAssertGreaterThan(try XCTUnwrap(p["refined_circle_proposals"] as? Int), 120)
    }
    func testIndependentCircleProposalsStopAtRefinementBudget() throws {
        let p = try rejectedBudget(crowdedCircles(side: 25, isolated: true), reason: "refinement_limit")
        XCTAssertEqual(p["refined_circle_proposals"] as? Int, 512)
    }
    func testDenseCandidateCombinationsStopBeforeUnboundedPoseWork() throws {
        _ = try rejectedBudget(crowdedCircles(side: 9, isolated: false), reason: "group_limit")
    }

    func testMirroredBackfaceCannotBecomeAFrontFacingIdentity() throws { try rejects("macro_backface") }
    func testFourOuterCirclesAreNotAValidFlagLayout() throws { try rejects("macro_wrong_layout") }
    func testOccludedInnerCircleCannotBeInferred() throws { try rejects("macro_occluded") }
    func testSpecularBandJoiningDotsCannotBeAccepted() throws { try rejects("macro_highlight") }

    func testTwoPhysicalCopiesOfSameIDAreStillBothRejected() throws {
        let result = try DALNativeEngine.detect(image: fixture("macro_duplicate_id4"), camera: camera(), markerCount: 6)
        XCTAssertEqual(try ids(result), [])
        let q = try quality(result)
        let candidates = try XCTUnwrap(q["candidate_diagnostics"] as? [[String: Any]])
        XCTAssertEqual(candidates.count, 2)
        for candidate in candidates {
            XCTAssertEqual(candidate["best_id"] as? Int, 4)
            XCTAssertEqual(candidate["reason"] as? String, "duplicate_identity")
            XCTAssertEqual(candidate["accepted"] as? Bool, false)
        }
    }
}
