import Foundation
import XCTest
@testable import DentalArchCapture

final class CameraOpticsTests: XCTestCase {
    private let subtype: UInt32 = 875704438
    private func format(_ index: Int, width: Int = 3840, height: Int = 2160, fov: Float = 82,
                        binned: Bool = false, phase: Bool = true, fps: Bool = true) -> CameraOpticsFormat {
        CameraOpticsFormat(index:index,mediaSubtype:subtype,width:width,height:height,fieldOfView:fov,
                           binned:binned,phaseDetection:phase,supports30FPS:fps)
    }
    private func profile(_ signature: String, lens: String = "wide", device: String = "physical-device") -> CaptureProfile {
        var result=CaptureProfile(device:device,lensPosition:0.3,width:1920,height:1080,format:signature)
        result.lens=lens
        return result
    }
    private func choose(_ request: CameraOpticsRequest, lens: String = "wide", correction: Bool = true,
                        formats: [CameraOpticsFormat]) throws -> CameraOpticsChoice {
        try CameraOpticsPolicy.choose(request,deviceID:"physical-device",lens:lens,
                                      supportsDistortionCorrection:correction,formats:formats)
    }

    func testNewStandardAndCloseUpPreferRealUHDWhileOutputProfileRemains1080() throws {
        let choices=[format(0,width:1920,height:1080),format(1)]
        let standard=try choose(.standard,formats:choices)
        let macro=try choose(.closeUp,lens:"ultrawide",formats:choices)
        XCTAssertEqual(standard.format.width,3840)
        XCTAssertEqual(macro.format.height,2160)
        XCTAssertEqual(macro.lens,"ultrawide")
        XCTAssertTrue(macro.signature.contains("sensor=3840x2160"))
        XCTAssertEqual(profile(macro.signature,lens:"ultrawide").width,1920)
        XCTAssertEqual(profile(macro.signature,lens:"ultrawide").height,1080)
    }

    func testUnsupportedUHDFallsBackToActual1080WithVersionedSignature() throws {
        let chosen=try choose(.standard,formats:[format(0,fps:false),format(1,width:1920,height:1080)])
        XCTAssertEqual(chosen.format.width,1920)
        XCTAssertTrue(chosen.signature.contains("sensor=1920x1080"))
        XCTAssertTrue(chosen.signature.hasPrefix("dal-optics-v2|"))
        XCTAssertNotEqual(chosen.signature,String(subtype))
    }

    func testPhaseDetectionThenUnbinnedThenStableIndexRanksEqualResolution() throws {
        let chosen=try choose(.standard,formats:[format(0,phase:false),format(1,binned:true),format(4),format(2)])
        XCTAssertEqual(chosen.format.index,2)
    }

    func testPhysicalCloseUpNeverFallsBackToWideAndUnsupportedModesFail() throws {
        XCTAssertEqual(try CameraOpticsPolicy.lens(for:.closeUp),"ultrawide")
        XCTAssertEqual(try CameraOpticsPolicy.lens(for:.standard),"wide")
        XCTAssertThrowsError(try choose(.closeUp,lens:"wide",formats:[format(0)]))
        XCTAssertThrowsError(try choose(.standard,formats:[format(0,width:1280,height:720)]))
        XCTAssertThrowsError(try choose(.standard,formats:[format(0,fps:false)]))
        XCTAssertThrowsError(try choose(.standard,formats:[format(0,fov:.nan)]))
    }

    func testLegacyWideCalibrationRestoresOriginalFirst1080FormatWithoutUpgrade() throws {
        let legacy=profile(String(subtype))
        let first=format(1,width:1920,height:1080,binned:true,phase:false)
        let choice=try choose(.restoring(legacy),formats:[format(0),first,format(2,width:1920,height:1080)])
        XCTAssertEqual(choice.format,first)
        XCTAssertEqual(choice.signature,legacy.format)
        XCTAssertNil(choice.distortionCorrection)
        XCTAssertThrowsError(try choose(.restoring(legacy),formats:[format(0)]))
        XCTAssertThrowsError(try choose(.restoring(profile(String(subtype),lens:"ultrawide")),lens:"ultrawide",formats:[first]))
    }

    func testLegacyCannotChooseDifferentSubtypeToPretendOldFormatIsRestored() throws {
        let first=CameraOpticsFormat(index:0,mediaSubtype:123,width:1920,height:1080,fieldOfView:82,
                                    binned:false,phaseDetection:true,supports30FPS:true)
        XCTAssertThrowsError(try choose(.restoring(profile(String(subtype))),formats:[first,format(1,width:1920,height:1080)]))
        XCTAssertThrowsError(try choose(.restoring(profile(String(subtype))),formats:[format(0,width:1920,height:1080,fov:0),format(1,width:1920,height:1080)]))
    }

    func testNewSignatureRestoresExactLensFormatAndCorrectionOrFails() throws {
        let formats=[format(0,width:1920,height:1080),format(1)]
        let original=try choose(.closeUp,lens:"ultrawide",formats:formats)
        let saved=profile(original.signature,lens:"ultrawide")
        let restored=try choose(.restoring(saved),lens:"ultrawide",formats:formats)
        XCTAssertEqual(restored.signature,original.signature)
        XCTAssertEqual(restored.format,original.format)
        XCTAssertEqual(restored.distortionCorrection,true)
        XCTAssertThrowsError(try choose(.restoring(saved),lens:"ultrawide",formats:[formats[0]]))
        XCTAssertThrowsError(try choose(.restoring(saved),lens:"ultrawide",correction:false,formats:formats))
        XCTAssertThrowsError(try choose(.restoring(saved),lens:"wide",formats:formats))
    }

    func testProfileRejectsOtherDeviceOutputSizeZoomAndUnrecognizedSignature() throws {
        let signature=format(0).signature(correction:true)
        var wrongSize=profile(signature); wrongSize.width=3840
        var zoomed=profile(signature); zoomed.zoom=2
        var unknownLens=profile(signature); unknownLens.lens="triple"
        for invalid in [profile(signature,device:"other-camera"),wrongSize,zoomed,unknownLens,profile("bad|gdc=1")] {
            XCTAssertThrowsError(try choose(.restoring(invalid),formats:[format(0)]))
        }
    }

    func testSignatureDistinguishesFOVBinningSensorAndCorrectionState() {
        let original=format(0).signature(correction:true)
        let distinct=[format(0,fov:83).signature(correction:true),
                      format(0,binned:true).signature(correction:true),
                      format(0,width:1920,height:1080).signature(correction:true),
                      format(0).signature(correction:false),format(1).signature(correction:true)]
        for value in distinct { XCTAssertNotEqual(original,value) }
    }

    func testUnsupportedCorrectionIsRecordedAsOffAndRestoresExactly() throws {
        let choice=try choose(.standard,correction:false,formats:[format(0)])
        XCTAssertEqual(choice.distortionCorrection,false)
        XCTAssertTrue(choice.signature.hasSuffix("|gdc=0"))
        let restored=try choose(.restoring(profile(choice.signature)),correction:false,formats:[format(0)])
        XCTAssertEqual(restored.signature,choice.signature)
    }
}
