import XCTest
import UIKit
@testable import DentalArchCapture

final class FramePresentationTests: XCTestCase {
    func testBackgroundDecodeKeepsOriginalFixtureDimensionsAndBytes() async throws {
        let file = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "vertical_arch", withExtension: "dat"))
        let data = try Data(contentsOf: file)
        let originalHash = PreviewCommit.digest(data)
        let expected = try XCTUnwrap(UIImage(data: data)?.cgImage)
        let prepared = await FramePresentation.decode(data)
        let actual = try XCTUnwrap(prepared?.cgImage)
        XCTAssertEqual(actual.width, expected.width)
        XCTAssertEqual(actual.height, expected.height)
        XCTAssertEqual(prepared?.imageOrientation, .up)
        let preparedHash = await FramePresentation.digest(data)
        XCTAssertEqual(preparedHash, originalHash, "Presentation must not re-encode the measurement image.")
    }

    func testInvalidPresentationBytesProduceNoImage() async {
        let decoded = await FramePresentation.decode(Data("not-an-image".utf8))
        XCTAssertNil(decoded)
        let digest = await FramePresentation.digest(Data("abc".utf8))
        XCTAssertEqual(digest, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    }
}
