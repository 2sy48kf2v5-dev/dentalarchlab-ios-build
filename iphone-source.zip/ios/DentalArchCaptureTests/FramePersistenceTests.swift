import Foundation
import XCTest
@testable import DentalArchCapture

final class FramePersistenceTests: XCTestCase {
    private var profile: CaptureProfile {
        CaptureProfile(device: "persistence-test", lensPosition: 0.55, width: 1920, height: 1080, format: "fixture")
    }

    func testConcurrentAppendStatusUpdateAndAcknowledgementPreserveBothOriginalsAndPendingFrame() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: folder) }
        let repository = CaptureRepository(root: folder), io = FramePersistence(repository: repository)
        // All three operations read-modify-write capture.json. Their actor order
        // may vary, but none may erase another operation's fields or image bytes.
        for iteration in 0..<12 {
            let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile,
                physical: false, squareMM: nil, calibrationID: nil)
            try repository.create(creation)
            let first = captureID(), second = captureID(), actualProfile = profile
            let firstBytes = Data([0xff, 0xd8, UInt8(iteration), 0xff, 0xd9])
            let secondBytes = Data([0x89, 0x50, 0x4e, 0x47, UInt8(iteration)])
            _ = try await io.append(session: creation.id, image: firstBytes, timestamp: 1, frame: first, profile: actualProfile)
            let receipt: [String: Any] = ["id": first, "count": 1, "accepted": true, "message": "Accepted"]
            try await withThrowingTaskGroup(of: Void.self) { group in
                group.addTask {
                    _ = try await io.append(session: creation.id, image: secondBytes, timestamp: 2,
                        frame: second, profile: actualProfile)
                }
                group.addTask {
                    try await io.update(session: creation.id, state: "collecting", message: "Refreshed")
                }
                group.addTask {
                    try await io.acknowledge(session: creation.id, frame: first, receipt: receipt)
                }
                try await group.waitForAll()
            }
            let capture = try repository.get(creation.id)
            XCTAssertEqual(capture.pending.map(\.id), [second])
            XCTAssertEqual(capture.frameCount, 2)
            XCTAssertEqual(capture.acceptedCount, 1)
            XCTAssertEqual(capture.state, "collecting")
            XCTAssertEqual(capture.activeProfile, actualProfile)
            let savedFirst = try await io.image(session: creation.id, frame: first)
            let savedSecond = try await io.image(session: creation.id, frame: second)
            XCTAssertEqual(savedFirst, firstBytes)
            XCTAssertEqual(savedSecond, secondBytes)
        }
    }

    func testWrongReceiptCannotClearPendingFrameAndRepeatedAcknowledgementRetainsOriginal() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: folder) }
        let repository = CaptureRepository(root: folder), io = FramePersistence(repository: repository)
        let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile,
            physical: false, squareMM: nil, calibrationID: nil)
        try repository.create(creation)
        let frame = captureID(), bytes = Data([0xff, 0xd8, 1, 2, 3, 0xff, 0xd9])
        _ = try await io.append(session: creation.id, image: bytes, timestamp: 1, frame: frame, profile: profile)
        do {
            try await io.acknowledge(session: creation.id, frame: frame,
                receipt: ["id": captureID(), "count": 5])
            XCTFail("A mismatched receipt must not acknowledge a pending frame")
        } catch {
            XCTAssertEqual(try repository.get(creation.id).pending.map(\.id), [frame])
            XCTAssertEqual(try repository.get(creation.id).acceptedCount, 0)
        }
        let receipt: [String: Any] = ["id": frame, "count": 1, "accepted": true, "message": "Accepted"]
        try await io.acknowledge(session: creation.id, frame: frame, receipt: receipt)
        try await io.update(session: creation.id, state: "collecting", message: "Refreshed")
        try await io.acknowledge(session: creation.id, frame: frame, receipt: receipt)
        let capture = try repository.get(creation.id)
        XCTAssertTrue(capture.pending.isEmpty)
        XCTAssertEqual(capture.frameCount, 1)
        XCTAssertEqual(capture.acceptedCount, 1)
        let original = try await io.image(session: creation.id, frame: frame)
        XCTAssertEqual(original, bytes)
    }
}
