import Foundation
import UIKit
import XCTest
@testable import DentalArchCapture

@MainActor final class OfflineEngineTests: XCTestCase {
    private var profile: CaptureProfile {
        CaptureProfile(device: "offline-test-wide", lensPosition: 0.55,
                       width: 1920, height: 1080, format: "test-1920x1080")
    }
    private func creation(mode: String = "trial", calibration: String? = nil) -> CaptureCreation {
        var value = CaptureCreation(mode: mode, markerCount: 6, profile: profile,
                                    physical: false, squareMM: nil, calibrationID: calibration)
        if mode != "calibration" {
            var plan = DentalPlan(); plan.useExample(count: 6); value.dentalPlan = plan
        }
        return value
    }
    private func object<T: Encodable>(_ value: T) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(value)) as? [String: Any])
    }
    private func data(_ value: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }
    private func fixture() -> (OfflineEngine, URL) {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("offline-engine-" + UUID().uuidString)
        return (OfflineEngine(root: folder), folder)
    }
    private func reject(_ engine: OfflineEngine, path: String, body: Data?,
                        file: StaticString = #filePath, line: UInt = #line) async {
        do {
            _ = try await engine.request(path, body: body)
            XCTFail("Invalid local request was accepted: \(path)", file: file, line: line)
        } catch {
            XCTAssertFalse(error.localizedDescription.isEmpty, file: file, line: line)
        }
    }
    private func png(_ color: UIColor, width: Int = 1920, height: Int = 1080) -> Data {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: CGFloat(width), height: CGFloat(height)), format: format)
        return renderer.pngData { context in
            color.setFill()
            context.fill(CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))
        }
    }
    private func board(shift: Int = 0) -> Data {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        return UIGraphicsImageRenderer(size: CGSize(width: 1920, height: 1080), format: format).pngData { context in
            UIColor.white.setFill(); context.fill(CGRect(x: 0, y: 0, width: 1920, height: 1080))
            UIColor.black.setFill()
            for y in 0..<7 { for x in 0..<10 where (x+y)%2 == 0 {
                context.fill(CGRect(x: 360+x*100+shift, y: 180+y*100, width: 100, height: 100))
            } }
        }
    }
    private func commitBody(_ image: Data, id: String) throws -> Data {
        try data(["id": id, "sha256": PreviewCommit.digest(image), "timestamp_s": 3.5, "profile": object(profile)])
    }
    private func frame(_ image: Data, id: String = captureID(), profile: CaptureProfile? = nil) throws -> [String: Any] {
        ["id": id, "timestamp_s": 3.5, "profile": try object(profile ?? self.profile), "image": image.base64EncodedString()]
    }
    private func observation(_ id: Int, shift: Double = 0, minSide: Double = 60) -> [String: Any] {
        let x = 200.0 + Double(id) * 180 + shift
        return ["marker": id, "corners": [[x, 200.0], [x + 60, 200.0], [x + 60, 260.0], [x, 260.0]],
                "min_side_px": minSide]
    }
    private var sharp: [String: Any] { ["blur_laplacian": 100.0] }
    private func writeCalibration(_ creation: CaptureCreation, folder: URL, status: String,
                                  storedProfile: CaptureProfile? = nil) throws {
        var state = try object(creation)
        state["engine"] = "iphone_native_v1"
        state["state"] = "complete"
        state["calibration"] = ["metadata": ["status": status, "warnings": [String](),
            "rms_px": 0.2, "views": 16, "capture_profile": try object(storedProfile ?? profile)]]
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try data(state).write(to: folder.appendingPathComponent(creation.id + ".json"))
    }
    private func projectedCalibrationViews(diverse: Bool, count: Int = 20) -> [[[Double]]] {
        (0..<count).map { index in
            let phase = Double(index) * 2 * Double.pi / Double(count)
            let ax = diverse ? 0.3*sin(phase) : 0, ay = diverse ? 0.28*cos(phase) : 0
            let tx = -24 + 30*cos(phase), ty = -15 + 17*sin(phase), tz = 180 + (diverse ? 12*sin(2*phase) : 0)
            return (0..<54).map { corner in
                let x = Double(corner%9)*6, y = Double(corner/9)*6
                let rx = cos(ay)*x + sin(ay)*sin(ax)*y, ry = cos(ax)*y
                let rz = -sin(ay)*x + cos(ay)*sin(ax)*y
                return [1600*(rx+tx)/(rz+tz)+960, 1585*(ry+ty)/(rz+tz)+540]
            }
        }
    }
    private func seedCalibrationObservations(_ state: [String: Any], views: [[[Double]]], folder: URL) throws {
        // Analytically projected ground-truth observations isolate processing
        // from pixel detection (exercised independently above). Production never
        // calls this test helper and no calibration result is manufactured.
        var seeded = state
        seeded["accepted"] = views.enumerated().map { index, corners -> [String: Any] in
            ["id": captureID(), "timestamp_s": Double(index+10), "observations": [], "corners": corners]
        }
        seeded["count"] = views.count
        let id = try XCTUnwrap(state["id"] as? String)
        try data(seeded).write(to: folder.appendingPathComponent(id + ".json"))
    }

    func testStatusIdentifiesLocalResearchEngine() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let status = try await engine.request("status", body: nil)
        XCTAssertEqual(status["engine"] as? String, "iphone_native_v1")
        XCTAssertEqual(status["research_only"] as? Bool, true)
        XCTAssertFalse(FileManager.default.fileExists(atPath: folder.path))
    }

    func testCreationRoundTripIsIdempotentAndSurvivesActorReopen() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(); let encoded = try JSONEncoder().encode(value)
        let first = try await engine.request("sessions", body: encoded)
        let repeated = try await engine.request("sessions", body: encoded)
        XCTAssertEqual(try data(first), try data(repeated))
        let reopened = OfflineEngine(root: folder)
        let restored = try await reopened.request("sessions/" + value.id, body: nil)
        XCTAssertEqual(try data(first), try data(restored))
        XCTAssertEqual(restored["count"] as? Int, 0)
        XCTAssertEqual(restored["state"] as? String, "collecting")
        XCTAssertTrue(restored["physical_accuracy_um"] is NSNull)
    }

    func testSameSessionCannotBeRecreatedWithChangedProfile() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        var value = creation()
        _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
        value.profile.lensPosition = 0.62
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(value))
        let preserved = try await engine.request("sessions/" + value.id, body: nil)
        let originalProfile = try XCTUnwrap(preserved["profile"] as? [String: Any])
        XCTAssertEqual(originalProfile["lens_position"] as? Double ?? -1, Double(profile.lensPosition), accuracy: 0.00001)
    }

    func testMalformedCameraProfilesAndBoardScaleAreRejected() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let variants: [(inout CaptureProfile) -> Void] = [
            { $0.width = 640 }, { $0.height = 1920 }, { $0.lensPosition = -0.1 },
            { $0.lensPosition = 1.1 }, { $0.focus = "auto" }, { $0.stabilization = "on" },
            { $0.pipeline = "unknown" }, { $0.orientation = "portrait" },
            { $0.lens = "ultra-wide" }, { $0.zoom = 2 }
        ]
        for change in variants {
            var value = creation(); change(&value.profile)
            await reject(engine, path: "sessions", body: try JSONEncoder().encode(value))
        }
        var board = creation(mode: "calibration"); board.board.physicalMeasured = true; board.board.squareMM = 0
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(board))
    }

    func testTraversalAndMalformedRequestBodiesAreRejected() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        for path in ["sessions/../escape", "sessions/%2e%2e", "sessions/..", "sessions/not-hex", "outside/status"] {
            await reject(engine, path: path, body: nil)
        }
        for body in [Data("[]".utf8), Data("null".utf8), Data("{".utf8)] {
            await reject(engine, path: "sessions", body: body)
        }
        var badID = creation(); badID.id = "../outside"
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(badID))
        XCTAssertFalse(FileManager.default.fileExists(atPath: folder.path))
    }

    func testScanRejectsMissingOrUnknownCalibration() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(creation(mode: "scan")))
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(creation(mode: "scan", calibration: captureID())))
    }

    func testScanRejectsScreenCalibrationEvenWithLowPixelRMS() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let calibration = creation(mode: "calibration")
        try writeCalibration(calibration, folder: folder, status: "screen_experimental")
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(creation(mode: "scan", calibration: calibration.id)))
    }

    func testScanRejectsCalibrationFromDifferentFocus() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let calibration = creation(mode: "calibration")
        var changed = profile; changed.lensPosition = 0.63
        try writeCalibration(calibration, folder: folder, status: "measured_research", storedProfile: changed)
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(creation(mode: "scan", calibration: calibration.id)))
    }

    func testMalformedImageAndChangedFrameProfileDoNotModifySession() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation()
        _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
        var invalid = try frame(Data([0, 1, 2]))
        invalid["image"] = "not base64!"
        await reject(engine, path: "sessions/\(value.id)/frames", body: try data(invalid))
        invalid = try frame(Data("not a PNG".utf8))
        await reject(engine, path: "sessions/\(value.id)/frames", body: try data(invalid))
        var changed = profile; changed.lensPosition = 0.65
        invalid = try frame(Data(), profile: changed)
        await reject(engine, path: "sessions/\(value.id)/frames", body: try data(invalid))
        let state = try await engine.request("sessions/" + value.id, body: nil)
        XCTAssertEqual(state["count"] as? Int, 0)
        XCTAssertTrue((state["receipts"] as? [String: Any])?.isEmpty == true)
    }

    func testRealOpenCVBlankFrameRejectsAndRetryIsIdempotent() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation()
        _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
        let id = captureID()
        let payload = try data(frame(png(.white), id: id))
        let first = try await engine.request("sessions/\(value.id)/frames", body: payload)
        XCTAssertEqual(first["accepted"] as? Bool, false)
        XCTAssertEqual(first["count"] as? Int, 0)
        let feedback = try XCTUnwrap(first["feedback"] as? [String: Any])
        XCTAssertTrue((feedback["markers"] as? [[String: Any]])?.isEmpty == true)
        let again = try await engine.request("sessions/\(value.id)/frames", body: payload)
        XCTAssertEqual(try data(first), try data(again))
        await reject(engine, path: "sessions/\(value.id)/frames", body: try data(frame(png(.black), id: id)))
        let state = try await engine.request("sessions/" + value.id, body: nil)
        XCTAssertEqual((state["receipts"] as? [String: Any])?.count, 1)
        XCTAssertEqual(state["count"] as? Int, 0)
    }

    func testRealOpenCVBlankCalibrationHasNoInventedCorners() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration")
        _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
        let receipt = try await engine.request("sessions/\(value.id)/frames", body: data(frame(png(.white))))
        XCTAssertEqual(receipt["accepted"] as? Bool, false)
        XCTAssertEqual(receipt["count"] as? Int, 0)
        let feedback = try XCTUnwrap(receipt["calibration_feedback"] as? [String: Any])
        XCTAssertEqual(feedback["detected_count"] as? Int, 0)
        XCTAssertEqual(feedback["reason"] as? String, "not_found")
        let state = try await engine.request("sessions/" + value.id, body: nil)
        XCTAssertTrue((state["accepted"] as? [[String: Any]])?.isEmpty == true)
        await reject(engine, path: "sessions/\(value.id)/process", body: nil)
    }

    func testCalibrationPreviewCommitRetryAndDuplicateBoardUseRealPixels() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration")
        _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
        let bytes = board(), id = captureID(), path = "sessions/\(value.id)"
        let preview = try await engine.request(path + "/preview", body: data(frame(bytes, id: id)))
        XCTAssertEqual(preview["accepted"] as? Bool, true)
        let f = try XCTUnwrap(preview["calibration_feedback"] as? [String: Any])
        XCTAssertEqual(f["session_id"] as? String, value.id); XCTAssertEqual(f["sample_id"] as? String, id)
        XCTAssertEqual(f["preview"] as? Bool, true); XCTAssertEqual(f["sample_usable"] as? Bool, true)
        XCTAssertEqual(f["detected_count"] as? Int, 54); XCTAssertEqual(f["expected_corners"] as? Int, 54)
        XCTAssertEqual(f["target_frames"] as? Int, 20); XCTAssertEqual(f["accepted_frames"] as? Int, 0)
        XCTAssertEqual(f["coordinates"] as? String, "sensor_normalized")
        XCTAssertEqual(f["metric"] as? String, "accepted_calibration_views_not_accuracy")
        XCTAssertTrue(f["physical_accuracy_um"] is NSNull)
        let corners = try XCTUnwrap(f["corners"] as? [[Double]])
        XCTAssertEqual(corners.count, 54)
        XCTAssertTrue(corners.allSatisfy { $0.count == 2 && $0.allSatisfy { (0...1).contains($0) } })
        let provisional = try await engine.request(path, body: nil)
        XCTAssertEqual(provisional["count"] as? Int, 0)
        XCTAssertTrue((provisional["receipts"] as? [String: Any])?.isEmpty == true)
        let commit = try commitBody(bytes, id: id)
        let receipt = try await engine.request(path + "/commit-preview", body: commit)
        XCTAssertEqual(receipt["accepted"] as? Bool, true); XCTAssertEqual(receipt["count"] as? Int, 1)
        let committedFeedback = try XCTUnwrap(receipt["calibration_feedback"] as? [String: Any])
        XCTAssertEqual(committedFeedback["preview"] as? Bool, false)
        XCTAssertEqual(committedFeedback["accepted_frames"] as? Int, 1)
        let repeated = try await engine.request(path + "/commit-preview", body: commit)
        XCTAssertEqual(try data(repeated), try data(receipt))
        let fallback = try await engine.request(path + "/frames", body: data(frame(bytes, id: id)))
        XCTAssertEqual(try data(fallback), try data(receipt))
        let duplicateID = captureID()
        let duplicate = try await engine.request(path + "/preview", body: data(frame(bytes, id: duplicateID)))
        let duplicateFeedback = try XCTUnwrap(duplicate["calibration_feedback"] as? [String: Any])
        XCTAssertEqual(duplicate["accepted"] as? Bool, false)
        XCTAssertEqual(duplicateFeedback["reason"] as? String, "duplicate")
        XCTAssertEqual(duplicateFeedback["detected_count"] as? Int, 54)
        XCTAssertEqual(duplicateFeedback["accepted_frames"] as? Int, 1)
        await reject(engine, path: path + "/commit-preview", body: try commitBody(bytes, id: duplicateID))
        let preserved = try await engine.request(path, body: nil)
        XCTAssertEqual((preserved["receipts"] as? [String: Any])?.count, 1)
        let shifted = board(shift: 65), shiftedID = captureID()
        let newAngle = try await engine.request(path + "/preview", body: data(frame(shifted, id: shiftedID)))
        XCTAssertEqual(newAngle["accepted"] as? Bool, true)
        let next = try await engine.request(path + "/commit-preview", body: commitBody(shifted, id: shiftedID))
        XCTAssertEqual(next["count"] as? Int, 2)
        await reject(engine, path: path + "/commit-preview", body: try commitBody(bytes, id: shiftedID))
    }

    func testRejectedCalibrationPreviewsDoNotPersistOrSpendFrameLimit() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration"), path = "sessions/"
        let initial = try await engine.request("sessions", body: JSONEncoder().encode(value))
        let bytes = png(.white)
        for _ in 0..<2 {
            let response = try await engine.request(path + value.id + "/preview", body: data(frame(bytes)))
            XCTAssertEqual(response["accepted"] as? Bool, false)
            XCTAssertEqual(response["count"] as? Int, 0)
            XCTAssertEqual((response["calibration_feedback"] as? [String: Any])?["detected_count"] as? Int, 0)
        }
        let after = try await engine.request(path + value.id, body: nil)
        XCTAssertEqual(try data(initial), try data(after))
        XCTAssertTrue((after["receipts"] as? [String: Any])?.isEmpty == true)
    }

    func testCalibrationCachedPreviewRechecksAViewCommittedInBetween() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration"), bytes = board(), id = captureID()
        let path = "sessions/\(value.id)"
        _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
        _ = try await engine.request(path + "/preview", body: data(frame(bytes, id: id)))
        let other = try await engine.request(path + "/frames", body: data(frame(bytes)))
        XCTAssertEqual(other["count"] as? Int, 1)
        let stale = try await engine.request(path + "/commit-preview", body: commitBody(bytes, id: id))
        XCTAssertEqual(stale["accepted"] as? Bool, false)
        XCTAssertEqual(stale["count"] as? Int, 1)
        XCTAssertEqual((stale["calibration_feedback"] as? [String: Any])?["reason"] as? String, "duplicate")
        let state = try await engine.request(path, body: nil)
        XCTAssertEqual((state["accepted"] as? [Any])?.count, 1)
    }

    func testAutomaticCalibrationRequiresTargetThenUsesRealNativeOptimizer() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration"), path = "sessions/"
        let initial = try await engine.request("sessions", body: JSONEncoder().encode(value))
        let process = path + value.id + "/process", body = try data(["automatic": true])
        try seedCalibrationObservations(initial, views: Array(projectedCalibrationViews(diverse: true).prefix(19)), folder: folder)
        await reject(engine, path: process, body: body)
        let before = try await engine.request(path + value.id, body: nil)
        XCTAssertEqual(before["state"] as? String, "collecting")
        XCTAssertNil(before["calibration"])
        try seedCalibrationObservations(initial, views: projectedCalibrationViews(diverse: true), folder: folder)
        let complete = try await engine.request(process, body: body)
        XCTAssertEqual(complete["state"] as? String, "complete")
        let calibration = try XCTUnwrap(complete["calibration"] as? [String: Any])
        let metadata = try XCTUnwrap(calibration["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["status"] as? String, "screen_experimental")
        XCTAssertTrue(metadata["square_mm"] is NSNull)
        XCTAssertEqual(metadata["views"] as? Int, 20)
        XCTAssertEqual(metadata["physical_accuracy_validated"] as? Bool, false)
        XCTAssertEqual((metadata["warnings"] as? [String])?.count, 0)
        XCTAssertLessThan(try XCTUnwrap(metadata["rms_px"] as? Double), 0.01)
        let repeated = try await engine.request(process, body: body)
        XCTAssertEqual(try data(complete), try data(repeated))
        await reject(engine, path: "sessions", body: try JSONEncoder().encode(creation(mode: "scan", calibration: value.id)))
    }

    func testAutomaticCalibrationRetainsPoorAngleViewsAndRequestsFiveMore() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration"), path = "sessions/"
        let initial = try await engine.request("sessions", body: JSONEncoder().encode(value))
        try seedCalibrationObservations(initial, views: projectedCalibrationViews(diverse: false), folder: folder)
        let retry = try await engine.request(path + value.id + "/process", body: data(["automatic": true]))
        XCTAssertEqual(retry["state"] as? String, "collecting")
        XCTAssertEqual(retry["next_calibration_target"] as? Int, 25)
        XCTAssertEqual(retry["calibration_paused"] as? Bool, false)
        XCTAssertEqual((retry["accepted"] as? [Any])?.count, 20)
        XCTAssertNil(retry["calibration"]); XCTAssertNil(retry["result"])
        XCTAssertFalse((retry["calibration_guidance"] as? String ?? "").isEmpty)
        let diagnostic = try XCTUnwrap(retry["calibration_diagnostic"] as? [String: Any])
        XCTAssertTrue(!(diagnostic["warnings"] as? [String] ?? []).isEmpty || diagnostic["error"] is String)
        let guidance = try XCTUnwrap(retry["calibration_guidance"] as? String)
        for warning in diagnostic["warnings"] as? [String] ?? [] { XCTAssertTrue(guidance.contains(warning)) }
        if let error = diagnostic["error"] as? String { XCTAssertTrue(guidance.contains(error)) }
        XCTAssertEqual(retry["message"] as? String, guidance)
        let preview = try await engine.request(path + value.id + "/preview", body: data(frame(board())))
        let feedback = try XCTUnwrap(preview["calibration_feedback"] as? [String: Any])
        XCTAssertEqual(feedback["target_frames"] as? Int, 25)
        XCTAssertEqual(feedback["accepted_frames"] as? Int, 20)
    }

    func testAutomaticCalibrationPausesAtSixtyAfterNumericalInputFailure() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration"), path = "sessions/"
        let initial = try await engine.request("sessions", body: JSONEncoder().encode(value))
        // Simulate a damaged persisted corner list. The native boundary must
        // reject it, retain evidence, and stop automatic retries at the cap.
        try seedCalibrationObservations(initial, views: Array(repeating: [[0,0]], count: 60), folder: folder)
        let retry = try await engine.request(path + value.id + "/process", body: data(["automatic": true]))
        XCTAssertEqual(retry["state"] as? String, "collecting")
        XCTAssertEqual(retry["next_calibration_target"] as? Int, 60)
        XCTAssertEqual(retry["calibration_paused"] as? Bool, true)
        XCTAssertEqual((retry["accepted"] as? [Any])?.count, 60)
        XCTAssertNil(retry["calibration"])
        XCTAssertTrue((retry["calibration_diagnostic"] as? [String: Any])?["error"] is String)
        let diagnostic = try XCTUnwrap(retry["calibration_diagnostic"] as? [String: Any])
        let nativeError = try XCTUnwrap(diagnostic["error"] as? String)
        let guidance = try XCTUnwrap(retry["calibration_guidance"] as? String)
        XCTAssertTrue(guidance.contains(nativeError))
        XCTAssertTrue(guidance.contains("otomatik çekim durdu"))
        XCTAssertFalse(guidance.contains("Farklı eğimler gerekli"))
        let reopened = OfflineEngine(root: folder)
        let persisted = try await reopened.request(path + value.id, body: nil)
        XCTAssertEqual(persisted["message"] as? String, guidance)
        XCTAssertEqual((persisted["accepted"] as? [Any])?.count, 60)
    }

    func testCalibrationHighResidualAndCoverageFailureKeepTheirOwnRemediesAtLimit() {
        let message = OfflineEngine.calibrationFailureMessage([
            "warnings": ["Kalibrasyon görüntü uyum hatası yüksek.", "Tahtayı görüntünün farklı bölgelerinde gösterin."],
            "rms_px": 1.27, "retained_views": 54
        ], count: 60)
        XCTAssertTrue(message.contains("1,270"))
        XCTAssertTrue(message.contains("Tahtanın düzlüğünü"))
        XCTAssertTrue(message.contains("sol, sağ, üst ve alt"))
        XCTAssertFalse(message.contains("eğim çeşitliliği yetersiz"))
        XCTAssertFalse(message.contains("Kalibrasyon tamamlandı"))
    }

    func testCalibrationNumericalFailureDoesNotInventOpticalCause() {
        let message = OfflineEngine.calibrationFailureMessage([
            "warnings": [], "error": "Her kalibrasyon karesinde 54 iç köşe gerekli."
        ], count: 20)
        XCTAssertTrue(message.contains("54 iç köşe"))
        XCTAssertFalse(message.contains("eğik gösterin"))
        XCTAssertFalse(message.contains("Tahtanın düzlüğünü"))
        XCTAssertFalse(message.contains("otomatik çekim durdu"))
    }

    func testReopeningInterruptedCalibrationPreservesViewsAndDropsPartialResults() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration"), path = "sessions/"
        var interrupted = try await engine.request("sessions", body: JSONEncoder().encode(value))
        interrupted["state"] = "processing"; interrupted["next_calibration_target"] = 25
        interrupted["calibration_diagnostic"] = ["rms_px": 1.2, "warnings": ["Prior inadequate fit"]]
        interrupted["calibration_guidance"] = "Additional board tilts required"
        interrupted["calibration"] = ["incomplete": true]; interrupted["result"] = ["incomplete": true]
        try seedCalibrationObservations(interrupted, views: projectedCalibrationViews(diverse: true), folder: folder)
        let stored = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: folder.appendingPathComponent(value.id + ".json"))) as? [String: Any])
        let reopened = OfflineEngine(root: folder)
        let recovered = try await reopened.request(path + value.id, body: nil)
        XCTAssertEqual(recovered["state"] as? String, "collecting")
        XCTAssertEqual(recovered["next_calibration_target"] as? Int, 25)
        XCTAssertEqual(recovered["count"] as? Int, 20)
        XCTAssertEqual(try data(["accepted": recovered["accepted"]!]), try data(["accepted": stored["accepted"]!]))
        XCTAssertEqual(try data(["diagnostic": recovered["calibration_diagnostic"]!]), try data(["diagnostic": stored["calibration_diagnostic"]!]))
        XCTAssertEqual(recovered["calibration_guidance"] as? String, "Additional board tilts required")
        XCTAssertNil(recovered["calibration"]); XCTAssertNil(recovered["result"])
        XCTAssertTrue(recovered["physical_accuracy_um"] is NSNull)
        let provenance = try XCTUnwrap(recovered["calibration_recovery"] as? [String: Any])
        XCTAssertEqual(provenance["kind"] as? String, "interrupted_native_fit")
        XCTAssertEqual(provenance["accepted_frames"] as? Int, 20)
        let reread = try await reopened.request(path + value.id, body: nil)
        XCTAssertEqual(try data(recovered), try data(reread))
        let reopenedAgain = OfflineEngine(root: folder)
        let persisted = try await reopenedAgain.request(path + value.id, body: nil)
        XCTAssertEqual(try data(recovered), try data(persisted))
        await reject(reopened, path: path + value.id + "/process", body: try data(["automatic": true]))
    }

    func testInterruptedCalibrationCanRefitRetainedGroundTruthAfterEngineReopen() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "calibration")
        var interrupted = try await engine.request("sessions", body: JSONEncoder().encode(value))
        interrupted["state"] = "processing"
        interrupted["calibration"] = ["incomplete": true]
        try seedCalibrationObservations(interrupted, views: projectedCalibrationViews(diverse: true), folder: folder)
        let reopened = OfflineEngine(root: folder)
        let completed = try await reopened.request("sessions/\(value.id)/process", body: data(["automatic": true]))
        XCTAssertEqual(completed["state"] as? String, "complete")
        let camera = try XCTUnwrap(completed["calibration"] as? [String: Any])
        XCTAssertNil(camera["incomplete"])
        let metadata = try XCTUnwrap(camera["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["views"] as? Int, 20)
        XCTAssertEqual(metadata["status"] as? String, "screen_experimental")
        XCTAssertEqual((metadata["warnings"] as? [String])?.count, 0)
        XCTAssertLessThan(try XCTUnwrap(metadata["rms_px"] as? Double), 0.01)
        XCTAssertTrue(completed["physical_accuracy_um"] is NSNull)
        XCTAssertEqual((completed["calibration_recovery"] as? [String: Any])?["kind"] as? String, "interrupted_native_fit")
    }

    func testCalibrationRecoveryDoesNotRewriteOtherModes() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation(mode: "trial")
        var state = try await engine.request("sessions", body: JSONEncoder().encode(value))
        state["state"] = "processing"
        try data(state).write(to: folder.appendingPathComponent(value.id + ".json"))
        let reopened = OfflineEngine(root: folder)
        let preserved = try await reopened.request("sessions/" + value.id, body: nil)
        XCTAssertEqual(try data(state), try data(preserved))
        XCTAssertNil(preserved["calibration_recovery"])
    }

    func testRealOpenCVRejectsImageWithWrongSensorDimensions() async throws {
        let (engine, folder) = fixture(); defer { try? FileManager.default.removeItem(at: folder) }
        let value = creation()
        _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
        await reject(engine, path: "sessions/\(value.id)/frames", body: try data(frame(png(.white, width: 320, height: 180))))
    }

    func testQualityGateRejectsBlurAndSmallPoints() throws {
        let markers = [observation(0), observation(1)]
        XCTAssertFalse(try OfflineEngine.assess(markers, quality: ["blur_laplacian": 34.9], history: [], markerCount: 6).0)
        XCTAssertFalse(try OfflineEngine.assess([observation(0, minSide: 44.9), observation(1)], quality: sharp, history: [], markerCount: 6).0)
        XCTAssertTrue(try OfflineEngine.assess(markers, quality: sharp, history: [], markerCount: 6).0)
    }

    func testQualityGateRequiresTwoOverlappingFlagsBetweenFrames() throws {
        let history: [[String: Any]] = [["observations": [observation(0), observation(1)]]]
        XCTAssertFalse(try OfflineEngine.assess([observation(2), observation(3)], quality: sharp, history: history, markerCount: 6).0)
        XCTAssertFalse(try OfflineEngine.assess([observation(1), observation(2)], quality: sharp, history: history, markerCount: 6).0)
        XCTAssertTrue(try OfflineEngine.assess([observation(0, shift: 10), observation(1, shift: 10), observation(2)], quality: sharp, history: history, markerCount: 6).0)
    }

    func testQualityGateRejectsRepeatedAngleAndAcceptsNewView() throws {
        let history: [[String: Any]] = [["observations": [observation(0), observation(1)]]]
        XCTAssertFalse(try OfflineEngine.assess([observation(0), observation(1)], quality: sharp, history: history, markerCount: 6).0)
        XCTAssertFalse(try OfflineEngine.assess([observation(0, shift: 3.9), observation(1, shift: 3.9)], quality: sharp, history: history, markerCount: 6).0)
        XCTAssertTrue(try OfflineEngine.assess([observation(0, shift: 15), observation(1, shift: 15)], quality: sharp, history: history, markerCount: 6).0)
    }

    func testQualityGateRejectsDuplicateIDsMalformedCornersAndSingleFlag() throws {
        XCTAssertThrowsError(try OfflineEngine.assess([observation(0), observation(0)], quality: sharp, history: [], markerCount: 6))
        XCTAssertThrowsError(try OfflineEngine.assess([observation(0), observation(6)], quality: sharp, history: [], markerCount: 6))
        var malformed = observation(1); malformed["corners"] = [[Double.nan, 0.0], [1.0, 2.0]]
        XCTAssertThrowsError(try OfflineEngine.assess([observation(0), malformed], quality: sharp, history: [], markerCount: 6))
        XCTAssertFalse(try OfflineEngine.assess([observation(0)], quality: sharp, history: [], markerCount: 6).0)
    }
}
