import AVFoundation
import Combine
import Foundation
import XCTest
@testable import DentalArchCapture

private final class MacroWorkflowCamera: CameraControlling {
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    var previewCompletions: [(Result<Void, Error>) -> Void] = []
    var measurementCompletions: [(Result<CaptureProfile, Error>) -> Void] = []
    var focusRequests: [CameraFocusRequest] = []
    var opticsRequests: [CameraOpticsRequest] = []
    var captureCount = 0
    var stopCount = 0
    var onCapture: (() -> Void)?
    func configureOptics(_ request: CameraOpticsRequest) { opticsRequests.append(request) }
    func startPreview(completion: @escaping (Result<Void, Error>) -> Void) { previewCompletions.append(completion) }
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) {
        focusRequests.append(focus); measurementCompletions.append(completion)
    }
    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        captureCount += 1; onCapture?()
        // Deliberately provide no image. These are workflow/state tests, not a
        // synthetic result pretending to be a real camera measurement.
        completion(.failure(LabError.message("Test karesi sağlanmadı.")))
    }
    func stop() { stopCount += 1 }
}

@MainActor final class MacroWorkflowTests: XCTestCase {
    private func fixture(timeout: UInt64 = 2_000_000_000) -> (CaptureModel, MacroWorkflowCamera, URL) {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let camera = MacroWorkflowCamera()
        return (CaptureModel(repository: CaptureRepository(root: root), camera: camera,
                             cameraStartTimeoutNanoseconds: timeout), camera, root)
    }
    private func cleanup(_ model: CaptureModel, root: URL) {
        model.stopCamera(); try? FileManager.default.removeItem(at: root)
    }
    private func profile(lens: String = "ultrawide", focus: Float = 0.7134) -> CaptureProfile {
        var value = CaptureProfile(device: "test-physical-\(lens)", lensPosition: focus, width: 1920, height: 1080,
                                   format: "test-format-\(lens)")
        value.lens = lens; return value
    }
    @discardableResult private func calibration(_ repository: CaptureRepository, lens: String = "ultrawide",
                                                physical: Bool = true, warnings: [String] = [],
                                                rms: Double = 0.2, views: Int = 20) throws -> CaptureCreation {
        let value = CaptureCreation(mode: "calibration", markerCount: 6, profile: profile(lens: lens),
                                    physical: physical, squareMM: physical ? 16.4 : nil, calibrationID: nil)
        try repository.create(value)
        try repository.update(session: value.id, state: "complete", message: "Fixture")
        let actual = try JSONSerialization.jsonObject(with: JSONEncoder().encode(value.profile))
        let object: [String: Any] = ["calibration": ["metadata": ["status": "measured_research",
            "warnings": warnings, "rms_px": rms, "views": views, "capture_profile": actual]]]
        try JSONSerialization.data(withJSONObject: object).write(to: repository.resultURL(value.id))
        return value
    }
    private func previewComplete(_ model: CaptureModel, camera: MacroWorkflowCamera, index: Int = 0,
                                 result: Result<Void, Error> = .success(Void())) async {
        let finished = expectation(description: "Preview callback consumed")
        let observation = model.$cameraStarting.dropFirst().filter { !$0 }.prefix(1).sink { _ in finished.fulfill() }
        defer { observation.cancel() }
        camera.previewCompletions[index](result)
        await fulfillment(of: [finished], timeout: 1)
    }
    private func measurementComplete(_ model: CaptureModel, camera: MacroWorkflowCamera, index: Int = 0,
                                     result: Result<CaptureProfile, Error>) async {
        let finished = expectation(description: "Measurement camera callback consumed")
        let observation = model.$cameraStarting.dropFirst().filter { !$0 }.prefix(1).sink { _ in finished.fulfill() }
        defer { observation.cancel() }
        camera.measurementCompletions[index](result)
        await fulfillment(of: [finished], timeout: 1)
    }

    func testAimingPreviewNeverCreatesRecordLocksFocusOrAcceptsCapture() async throws {
        for mode in ["trial", "calibration"] {
            let (model, camera, root) = fixture(); defer { cleanup(model, root: root) }
            model.mode = mode; model.prepareCameraPreview()
            XCTAssertEqual(camera.previewCompletions.count, 1)
            XCTAssertTrue(camera.measurementCompletions.isEmpty); XCTAssertTrue(camera.focusRequests.isEmpty)
            XCTAssertEqual(camera.opticsRequests, [.closeUp])
            await previewComplete(model, camera: camera)
            XCTAssertTrue(model.previewReady); XCTAssertTrue(model.cameraVisible); XCTAssertFalse(model.ready)
            model.takePhoto(); model.startAutomatic()
            XCTAssertEqual(camera.captureCount, 0); XCTAssertFalse(model.autoRunning)
            XCTAssertNil(model.currentID); XCTAssertTrue(try model.repository.list().isEmpty)
        }
    }

    func testStoppedPreviewCannotBecomeReadyFromLateCompletion() async {
        let (model, camera, root) = fixture(); defer { cleanup(model, root: root) }
        model.prepareCameraPreview(); model.stopCamera()
        let stale = expectation(description: "Cancelled preview never becomes visible"); stale.isInverted = true
        let observation = model.$previewReady.dropFirst().filter { $0 }.sink { _ in stale.fulfill() }
        camera.previewCompletions[0](.success(Void()))
        await fulfillment(of: [stale], timeout: 0.06); observation.cancel()
        XCTAssertFalse(model.cameraVisible); XCTAssertFalse(model.busy); XCTAssertNil(model.currentID)
        model.prepareCameraPreview(); await previewComplete(model, camera: camera, index: 1)
        XCTAssertTrue(model.previewReady); XCTAssertFalse(model.ready)
    }

    func testPreviewTimeoutClearsBusyAndIgnoresLateSuccess() async {
        let (model, camera, root) = fixture(timeout: 30_000_000); defer { cleanup(model, root: root) }
        let timedOut = expectation(description: "Preview timeout clears startup")
        let observation = model.$cameraStarting.dropFirst().filter { !$0 }.prefix(1).sink { _ in timedOut.fulfill() }
        model.prepareCameraPreview()
        await fulfillment(of: [timedOut], timeout: 1); observation.cancel()
        XCTAssertFalse(model.busy); XCTAssertFalse(model.cameraVisible)
        XCTAssertTrue(model.status.contains("zaman aşımına"))
        model.prepareCameraPreview()
        camera.previewCompletions[0](.success(Void()))
        await previewComplete(model, camera: camera, index: 1)
        XCTAssertTrue(model.previewReady); XCTAssertFalse(model.ready)
    }

    func testCalibrationOnlyLocksAtExplicitStartThenRequestsFirstMeasurementFrame() async throws {
        let (model, camera, root) = fixture(); defer { cleanup(model, root: root) }
        model.mode = "calibration"; model.physicalBoard = true; model.squareMM = "16.4"
        model.prepareCameraPreview(); await previewComplete(model, camera: camera)
        XCTAssertTrue(camera.focusRequests.isEmpty); XCTAssertEqual(camera.captureCount, 0)
        model.beginCalibrationScan()
        XCTAssertFalse(model.previewReady); XCTAssertFalse(model.ready); XCTAssertTrue(model.cameraStarting)
        XCTAssertEqual(camera.focusRequests, [.automatic]); XCTAssertEqual(camera.opticsRequests, [.closeUp, .closeUp])
        XCTAssertTrue(try model.repository.list().isEmpty); XCTAssertEqual(camera.captureCount, 0)
        let firstFrame = expectation(description: "Measurement begins only after verified lock")
        camera.onCapture = { firstFrame.fulfill() }
        await measurementComplete(model, camera: camera, result: .success(profile()))
        await fulfillment(of: [firstFrame], timeout: 1)
        XCTAssertTrue(model.ready); XCTAssertFalse(model.previewReady)
        XCTAssertEqual(model.focus, profile().lensPosition); XCTAssertEqual(camera.captureCount, 1)
    }

    func testInvalidPhysicalSquareDoesNotExitPreviewOrStartMeasurement() async {
        let (model, camera, root) = fixture(); defer { cleanup(model, root: root) }
        model.mode = "calibration"; model.physicalBoard = true; model.squareMM = "0"
        model.prepareCameraPreview(); await previewComplete(model, camera: camera)
        model.beginCalibrationScan()
        XCTAssertTrue(model.previewReady); XCTAssertFalse(model.ready)
        XCTAssertTrue(camera.measurementCompletions.isEmpty); XCTAssertEqual(camera.captureCount, 0)
        XCTAssertTrue(model.status.contains("Kare boyutunu"))
    }

    func testXYZShortcutKeepsSelectedEligibleMacroCalibrationAndNeverUsesWide() throws {
        let (initial, camera, root) = fixture(); defer { cleanup(initial, root: root) }
        let macro = try calibration(initial.repository)
        _ = try calibration(initial.repository)
        let wide = try calibration(initial.repository, lens: "wide")
        let model = CaptureModel(repository: initial.repository, camera: camera); defer { model.stopCamera() }
        model.calibrationID = macro.id; model.cameraOpticsChoice = "standard"
        model.prepareMacroXYZ()
        XCTAssertEqual(model.mode, "scan"); XCTAssertEqual(model.calibrationID, macro.id)
        XCTAssertEqual(model.cameraOpticsChoice, "closeUp")
        model.calibrationID = wide.id; model.prepareMacroXYZ()
        XCTAssertEqual(model.mode, "scan"); XCTAssertNotEqual(model.calibrationID, wide.id)
        XCTAssertTrue(model.availableCalibrations.contains { $0.id == model.calibrationID && $0.creation.profile.lens == "ultrawide" })
        XCTAssertTrue(camera.previewCompletions.isEmpty); XCTAssertTrue(camera.measurementCompletions.isEmpty)
    }

    func testWideOnlyAndIneligibleMacroRecordsRouteXYZToNewPhysicalCalibration() throws {
        let (initial, camera, root) = fixture(); defer { cleanup(initial, root: root) }
        let wide = try calibration(initial.repository, lens: "wide")
        _ = try calibration(initial.repository, warnings: ["coverage"])
        _ = try calibration(initial.repository, rms: 0.9)
        _ = try calibration(initial.repository, views: 5)
        _ = try calibration(initial.repository, physical: false)
        let model = CaptureModel(repository: initial.repository, camera: camera); defer { model.stopCamera() }
        model.mode = "scan"; model.calibrationID = wide.id
        model.prepareMacroXYZ()
        XCTAssertEqual(model.mode, "calibration"); XCTAssertEqual(model.calibrationID, "")
        XCTAssertEqual(model.cameraOpticsChoice, "closeUp")
        XCTAssertTrue(model.status.contains("fiziksel tahta"))
        XCTAssertTrue(camera.previewCompletions.isEmpty); XCTAssertTrue(camera.measurementCompletions.isEmpty)
    }

    func testXYZPreviewEntryRestoresExactMacroProfileAndRejectsAFSubstitution() async throws {
        let (initial, camera, root) = fixture(); defer { cleanup(initial, root: root) }
        let saved = try calibration(initial.repository)
        let model = CaptureModel(repository: initial.repository, camera: camera); defer { model.stopCamera() }
        model.prepareMacroXYZ(); model.prepareCameraPreview()
        XCTAssertTrue(camera.previewCompletions.isEmpty)
        XCTAssertEqual(camera.focusRequests, [.locked(saved.profile.lensPosition)])
        XCTAssertEqual(camera.opticsRequests, [.restoring(saved.profile)])
        var wrong = saved.profile; wrong.lensPosition += 0.02
        await measurementComplete(model, camera: camera, result: .success(wrong))
        XCTAssertFalse(model.ready); XCTAssertFalse(model.previewReady); XCTAssertEqual(camera.captureCount, 0)
        model.prepareCameraPreview()
        await measurementComplete(model, camera: camera, index: 1, result: .success(saved.profile))
        XCTAssertTrue(model.ready); XCTAssertFalse(model.previewReady)
        XCTAssertFalse(model.canRefocus); XCTAssertEqual(model.focus, saved.profile.lensPosition)
        XCTAssertEqual(camera.focusRequests, [.locked(saved.profile.lensPosition), .locked(saved.profile.lensPosition)])
    }

    func testSavedTrialEntryRestoresExistingProfileInsteadOfChangingToPreviewAF() async throws {
        let (initial, camera, root) = fixture(); defer { cleanup(initial, root: root) }
        let saved = CaptureCreation(mode: "trial", markerCount: 6, profile: profile(), physical: false, squareMM: nil, calibrationID: nil)
        try initial.repository.create(saved)
        let model = CaptureModel(repository: initial.repository, camera: camera); defer { model.stopCamera() }
        model.select(try model.repository.get(saved.id)); model.prepareCameraPreview()
        XCTAssertTrue(camera.previewCompletions.isEmpty)
        XCTAssertEqual(camera.focusRequests, [.locked(saved.profile.lensPosition)])
        XCTAssertEqual(camera.opticsRequests, [.restoring(saved.profile)])
        await measurementComplete(model, camera: camera, result: .success(saved.profile))
        XCTAssertTrue(model.ready); XCTAssertFalse(model.previewReady)
        XCTAssertEqual(model.currentID, saved.id); XCTAssertEqual(camera.captureCount, 0)
    }
    func testGenericScanSelectionAlsoUsesMacroCalibrationAndCannotSwitchBackToWide() throws {
        let (initial, camera, root) = fixture(); defer { cleanup(initial, root: root) }
        let wide = try calibration(initial.repository, lens: "wide")
        let macro = try calibration(initial.repository)
        let model = CaptureModel(repository: initial.repository, camera: camera); defer { model.stopCamera() }
        model.calibrationID = wide.id; model.selectWorkMode("scan")
        XCTAssertTrue(model.macroXYZRequested); XCTAssertEqual(model.mode, "scan")
        XCTAssertEqual(model.calibrationID, macro.id)
        model.chooseCalibration(try model.repository.get(wide.id))
        XCTAssertEqual(model.calibrationID, macro.id)
        model.calibrationID = wide.id; model.openCamera()
        XCTAssertTrue(camera.measurementCompletions.isEmpty)
        XCTAssertTrue(model.status.contains("ultra geniş"))
        model.newSession(); model.selectWorkMode("scan"); model.openCamera()
        XCTAssertEqual(camera.opticsRequests, [.restoring(macro.profile)])
    }

    func testGenericScanWithoutMacroRoutesToCalibrationAndTrialCanExitIntent() throws {
        let (initial, camera, root) = fixture(); defer { cleanup(initial, root: root) }
        _ = try calibration(initial.repository, lens: "wide")
        let model = CaptureModel(repository: initial.repository, camera: camera); defer { model.stopCamera() }
        model.selectWorkMode("scan")
        XCTAssertEqual(model.mode, "calibration"); XCTAssertTrue(model.macroXYZRequested)
        XCTAssertTrue(model.calibrationID.isEmpty)
        model.cameraOpticsChoice = "standard"; model.prepareCameraPreview()
        XCTAssertEqual(camera.opticsRequests, [.closeUp])
        model.stopCamera()
        model.selectWorkMode("trial")
        XCTAssertFalse(model.macroXYZRequested); XCTAssertEqual(model.mode, "trial")
    }

    func testSavedSelectionAndCaseReferenceRestoreWithoutReindexing() throws {
        let (model, _, root) = fixture(); defer { cleanup(model, root: root) }
        var saved = CaptureCreation(mode: "trial", markerCount: 4, profile: profile(), physical: false, squareMM: nil, calibrationID: nil)
        saved.markerIDs = [0, 3, 4, 5]; saved.caseReference = "Model A"
        try model.repository.create(saved)
        model.select(try model.repository.get(saved.id))
        XCTAssertEqual(model.selectedMarkerIDs, [0, 3, 4, 5])
        XCTAssertEqual(model.plan.markerIDs, [0, 3, 4, 5]); XCTAssertEqual(model.caseReference, "Model A")
        model.newSession(); XCTAssertEqual(model.caseReference, "")
        XCTAssertEqual(model.selectedMarkerIDs, [0, 3, 4, 5])
    }

    func testNewXYZCaseFromLegacyWideRecordReentersMacroSetup() async throws {
        let (initial, camera, root) = fixture(); defer { cleanup(initial, root: root) }
        let wide = try calibration(initial.repository, lens: "wide")
        let macro = try calibration(initial.repository)
        let saved = CaptureCreation(mode: "scan", markerCount: 4, profile: wide.profile,
            physical: false, squareMM: nil, calibrationID: wide.id)
        try initial.repository.create(saved)
        let model = CaptureModel(repository: initial.repository, camera: camera); defer { model.stopCamera() }
        model.select(try model.repository.get(saved.id)); model.openCamera()
        XCTAssertEqual(camera.opticsRequests, [.restoring(wide.profile)], "Saved measurements retain their original profile")
        await measurementComplete(model, camera: camera, result: .success(wide.profile))
        model.newSession()
        XCTAssertNil(model.currentID); XCTAssertTrue(model.macroXYZRequested)
        XCTAssertEqual(model.calibrationID, macro.id); XCTAssertEqual(model.mode, "scan")
        model.openCamera()
        XCTAssertEqual(camera.opticsRequests.last, .restoring(macro.profile))
    }

}
