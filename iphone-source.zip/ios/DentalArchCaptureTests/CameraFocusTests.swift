import XCTest
@testable import DentalArchCapture

final class CameraFocusTests: XCTestCase {
    private struct Frame {
        var now = 2.0
        var running = true
        var interrupted = false
        var locked = true
        var adjusting = false
        var lens: Float = 0.713
        var width = 1920
        var height = 1080
    }
    private func observe(_ acquisition: inout CameraFocusAcquisition, _ timestamp: Double,
                         _ change: (inout Frame) -> Void = { _ in }) -> Float? {
        var frame = Frame(); change(&frame)
        return acquisition.observe(now: frame.now, running: frame.running, interrupted: frame.interrupted,
                                   focusLocked: frame.locked, adjustingFocus: frame.adjusting, lensPosition: frame.lens,
                                   width: frame.width, height: frame.height, timestamp: timestamp)
    }

    func testAlreadyFocusedDeviceNeedsNoAdjustingTransitionOrCompletionCallback() throws {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        XCTAssertNil(observe(&acquisition, 1))
        XCTAssertNil(observe(&acquisition, 2))
        XCTAssertEqual(try XCTUnwrap(observe(&acquisition, 3)), 0.713, accuracy: 0.00001)
        XCTAssertEqual(acquisition.lastIssue, .ready)
    }

    func testAutoFocusMustReachLockedStateAndStopAdjusting() {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        for time in 1...5 { XCTAssertNil(observe(&acquisition, Double(time)) { $0.locked = false }) }
        for time in 6...9 { XCTAssertNil(observe(&acquisition, Double(time)) { $0.adjusting = true }) }
        XCTAssertEqual(acquisition.lastIssue, .focusMoving)
        XCTAssertNil(observe(&acquisition, 10)); XCTAssertNil(observe(&acquisition, 11))
        XCTAssertNotNil(observe(&acquisition, 12))
    }

    func testSettlingFramesDoNotCountTowardAcquisition() {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        for time in 1...4 { XCTAssertNil(observe(&acquisition, Double(time)) { $0.now = 1.49 }) }
        XCTAssertNil(observe(&acquisition, 5)); XCTAssertNil(observe(&acquisition, 6))
        XCTAssertNotNil(observe(&acquisition, 7))
    }

    func testMovingLensResetsStableWindowAndUsesLatestObservedValue() throws {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        XCTAssertNil(observe(&acquisition, 1) { $0.lens = 0.2 })
        XCTAssertNil(observe(&acquisition, 2) { $0.lens = 0.2 })
        XCTAssertNil(observe(&acquisition, 3) { $0.lens = 0.713 })
        XCTAssertEqual(acquisition.lastIssue, .focusMoving)
        XCTAssertNil(observe(&acquisition, 4))
        XCTAssertEqual(try XCTUnwrap(observe(&acquisition, 5)), 0.713, accuracy: 0.00001)
    }

    func testGradualLensDriftCannotAccumulateAsStableFrames() {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        XCTAssertNil(observe(&acquisition, 1) { $0.lens = 0.500 })
        XCTAssertNil(observe(&acquisition, 2) { $0.lens = 0.5015 })
        XCTAssertNil(observe(&acquisition, 3) { $0.lens = 0.503 })
        XCTAssertEqual(acquisition.lastIssue, .focusMoving)
    }

    func testInvalidFrameResetsAcquisitionBeforeAnyProfileCanBeCreated() {
        let failures: [(inout Frame) -> Void] = [
            { $0.running = false }, { $0.interrupted = true }, { $0.width = 1280 },
            { $0.height = 1920 }, { $0.lens = .nan }, { $0.lens = -.infinity },
            { $0.lens = -0.1 }, { $0.lens = 1.01 }, { $0.now = .nan }
        ]
        for failure in failures {
            var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
            XCTAssertNil(observe(&acquisition, 1)); XCTAssertNil(observe(&acquisition, 2))
            XCTAssertNil(observe(&acquisition, 3, failure))
            XCTAssertNil(observe(&acquisition, 4)); XCTAssertNil(observe(&acquisition, 5))
            XCTAssertNotNil(observe(&acquisition, 6))
        }
    }

    func testDuplicateOldAndNonfiniteTimestampsCannotCompleteAcquisition() {
        for invalid in [2.0, 1.0, -1.0, .nan, .infinity] {
            var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
            XCTAssertNil(observe(&acquisition, 1)); XCTAssertNil(observe(&acquisition, 2))
            XCTAssertNil(observe(&acquisition, invalid))
            XCTAssertEqual(acquisition.lastIssue, .invalidTimestamp)
            XCTAssertNil(observe(&acquisition, 3)); XCTAssertNil(observe(&acquisition, 4))
            XCTAssertNotNil(observe(&acquisition, 5))
        }
    }

    func testAutofocusDeadlineCannotBeBypassedByLaterGoodFrames() {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        XCTAssertNil(observe(&acquisition, 1)); XCTAssertNil(observe(&acquisition, 2))
        XCTAssertNil(observe(&acquisition, 3) { $0.now = 8 })
        XCTAssertTrue(acquisition.timedOut)
        for time in 4...8 { XCTAssertNil(observe(&acquisition, Double(time))) }
    }

    func testCancelAndNewAttemptDoNotShareAcquiredFrames() {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        XCTAssertNil(observe(&acquisition, 1)); XCTAssertNil(observe(&acquisition, 2))
        acquisition.cancel()
        XCTAssertNil(observe(&acquisition, 3))
        acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        XCTAssertNil(observe(&acquisition, 1)); XCTAssertNil(observe(&acquisition, 2))
        XCTAssertNotNil(observe(&acquisition, 3))
    }

    func testAutoAcquisitionStillRequiresSeparateFreshLockedReadinessFrames() throws {
        var acquisition = CameraFocusAcquisition(earliestFrameTime: 1.5, deadline: 8)
        XCTAssertNil(observe(&acquisition, 1)); XCTAssertNil(observe(&acquisition, 2))
        let lens = try XCTUnwrap(observe(&acquisition, 3))
        var readiness = CameraStartupCheck(requestedLens: lens, earliestFrameTime: 2.3)
        func ready(_ now: Double, _ timestamp: Double) -> Bool {
            readiness.observe(now: now, running: true, interrupted: false, focusLocked: true,
                              adjustingFocus: false, lensPosition: lens, width: 1920, height: 1080, timestamp: timestamp)
        }
        XCTAssertFalse(ready(2.2, 4)); XCTAssertFalse(ready(2.3, 5)); XCTAssertFalse(ready(2.4, 6))
        XCTAssertTrue(ready(2.5, 7))
    }

    func testSavedCalibrationFocusCannotBeSubstitutedWithAnotherStableLens() {
        XCTAssertEqual(CameraFocusGuard.issue(expectedLens: 0.55, focusLocked: true,
                                              adjustingFocus: false, lensPosition: 0.713), .lensPosition)
        XCTAssertNil(CameraFocusGuard.issue(expectedLens: 0.55, focusLocked: true,
                                            adjustingFocus: false, lensPosition: 0.5519))
    }

    func testCaptureGuardRejectsLostLockMovementAndDrift() {
        XCTAssertEqual(CameraFocusGuard.issue(expectedLens: 0.55, focusLocked: false,
                                              adjustingFocus: false, lensPosition: 0.55), .focusUnlocked)
        XCTAssertEqual(CameraFocusGuard.issue(expectedLens: 0.55, focusLocked: true,
                                              adjustingFocus: true, lensPosition: 0.55), .focusMoving)
        XCTAssertEqual(CameraFocusGuard.issue(expectedLens: 0.55, focusLocked: true,
                                              adjustingFocus: false, lensPosition: 0.553), .lensPosition)
        XCTAssertEqual(CameraFocusGuard.issue(expectedLens: .nan, focusLocked: true,
                                              adjustingFocus: false, lensPosition: 0.55), .lensPosition)
    }
}
