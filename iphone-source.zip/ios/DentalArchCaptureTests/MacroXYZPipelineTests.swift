import Foundation
import UIKit
import XCTest
@testable import DentalArchCapture

/// Synthetic optical geometry, not an iPhone specification or physical accuracy
/// claim. Unlike an identity-only test, these exercise calibrated pixels through
/// the native detector, triangulation and bundle adjustment to an XYZ result.
@MainActor final class MacroXYZPipelineTests: XCTestCase {
    private typealias Matrix = [[Double]]
    private let frames = 14
    private let fx = 600.0, fy = 595.0
    private let distortion = [-0.045, 0.008, 0.00025, -0.0002, 0.001]
    private let outer = [[-3.0, 2.4, 0.0], [3.3, 2.0, 0.0], [-1.7, -2.8, 0.0]]
    private let weights = [[0.60,0.22,0.18], [0.20,0.60,0.20], [0.20,0.20,0.60],
                           [0.43,0.41,0.16], [0.43,0.16,0.41], [0.16,0.42,0.42]]

    private var profile: CaptureProfile {
        var value = CaptureProfile(device: "synthetic-macro-XYZ-physical-camera", lensPosition: 0.72,
            width: 1920, height: 1080, format: "synthetic-fixed-macro-format-XYZ-v1")
        value.lens = "ultrawide"
        return value
    }

    // Explicit Rz * Ry * Rx and Brown-Conrady projection are independent of the
    // production OpenCV implementation. No fitted pose generates ground truth.
    private func transform(_ ax: Double, _ ay: Double, _ az: Double,
                           _ x: Double, _ y: Double, _ z: Double) -> Matrix {
        let a = cos(ax), b = cos(ay), c = cos(az)
        let d = sin(ax), e = sin(ay), f = sin(az)
        return [[c*b, c*e*d-f*a, c*e*a+f*d, x],
                [f*b, f*e*d+c*a, f*e*a-c*d, y],
                [-e, b*d, b*a, z], [0,0,0,1]]
    }
    private func multiply(_ a: Matrix, _ b: Matrix) -> Matrix {
        (0..<4).map { row in (0..<4).map { column in
            (0..<4).reduce(0.0) { $0 + a[row][$1]*b[$1][column] }
        } }
    }
    private func inverse(_ value: Matrix) -> Matrix {
        var result = transform(0,0,0,0,0,0)
        for row in 0..<3 {
            for column in 0..<3 { result[row][column] = value[column][row] }
            result[row][3] = -(0..<3).reduce(0.0) { $0 + result[row][$1]*value[$1][3] }
        }
        return result
    }
    private func project(_ points: [[Double]], pose: Matrix) -> [[Double]] {
        points.map { point in
            let p = (0..<3).map { row in
                pose[row][3] + (0..<3).reduce(0.0) { $0 + pose[row][$1]*point[$1] }
            }
            let x = p[0]/p[2], y = p[1]/p[2], r2 = x*x+y*y
            let radial = 1+distortion[0]*r2+distortion[1]*r2*r2+distortion[4]*r2*r2*r2
            let xd = x*radial+2*distortion[2]*x*y+distortion[3]*(r2+2*x*x)
            let yd = y*radial+distortion[2]*(r2+2*y*y)+2*distortion[3]*x*y
            return [fx*xd+960, fy*yd+540]
        }
    }
    private func markerPoints(_ id: Int) -> [[Double]] {
        let inner = (0..<3).map { axis in
            (0..<3).reduce(0.0) { $0 + outer[$1][axis]*weights[id][$1] }
        }
        return outer + [inner]
    }
    private func markerTruth(_ count: Int) -> [Matrix] {
        (0..<count).map { id in
            let a = Double.pi*Double(id)/Double(count-1)
            return transform(0.05*sin(a), 0.045*cos(a), 0.11*cos(a),
                             24*cos(a), 24*sin(a), 2*sin(2*a))
        }
    }
    private func cameraPose(_ index: Int) -> Matrix {
        let p = 2*Double.pi*Double(index)/Double(frames)
        return multiply(transform(0.17*sin(p), 0.2*cos(p), 0.015*sin(2*p),
                                  8*cos(p), 12+6*sin(p), 60+7*sin(2*p)),
                        transform(Double.pi,0,0,0,0,0))
    }
    private func cameraDictionary() throws -> [String: Any] {
        ["schema_version": 1, "model": "opencv_pinhole", "image_size": [1920,1080],
         "K": [[fx,0,960],[0,fy,540],[0,0,1]], "distortion": distortion,
         "metadata": ["status": "synthetic_known_intrinsics", "capture_profile": try object(profile),
                      "physical_accuracy_validated": false]]
    }
    private func object<T: Encodable>(_ value: T) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(value)) as? [String: Any])
    }
    private func json(_ value: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }
    private func creation(_ mode: String, count: Int, profile: CaptureProfile,
                          calibrationID: String? = nil) -> CaptureCreation {
        var value = CaptureCreation(mode: mode, markerCount: count, profile: profile,
            physical: mode == "calibration", squareMM: mode == "calibration" ? 3 : nil,
            calibrationID: calibrationID)
        if mode != "calibration" {
            var plan = DentalPlan.vidaMUA9; plan.useExample(count: count); value.dentalPlan = plan
        }
        return value
    }
    private func projectedBoard() -> [[[Double]]] {
        let points = (0..<54).map { [Double($0%9)*3, Double($0/9)*3, 0.0] }
        return (0..<20).map { index in
            let p = 2*Double.pi*Double(index)/20
            let pose = transform(0.32*sin(p), 0.3*cos(p), 0.04*sin(2*p),
                                 -12+18*cos(p), -7.5+10*sin(p), 62+5*sin(2*p))
            return project(points, pose: pose)
        }
    }
    private func calibration(engine: OfflineEngine, root: URL, count: Int) async throws -> CaptureCreation {
        let value = creation("calibration", count: count, profile: profile)
        var state = try await engine.request("sessions", body: JSONEncoder().encode(value))
        // Only the known checkerboard observations are injected. Native camera
        // fitting and all later flag pixels/acceptance/reconstruction run normally.
        let views = projectedBoard()
        state["accepted"] = views.enumerated().map { index, corners -> [String: Any] in
            ["id": captureID(), "timestamp_s": Double(index+1), "observations": [[String: Any]](), "corners": corners]
        }
        state["count"] = views.count
        try json(state).write(to: root.appendingPathComponent(value.id+".json"))
        let done = try await engine.request("sessions/\(value.id)/process", body: json(["automatic": true]))
        XCTAssertEqual(done["state"] as? String, "complete")
        let camera = try XCTUnwrap(done["calibration"] as? [String: Any])
        let K = try XCTUnwrap(camera["K"] as? [[Double]])
        XCTAssertEqual(K[0][0], fx, accuracy: 0.02); XCTAssertEqual(K[1][1], fy, accuracy: 0.02)
        let metadata = try XCTUnwrap(camera["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["warnings"] as? [String], [])
        XCTAssertEqual(metadata["capture_profile"] as? NSDictionary, try object(profile) as NSDictionary)
        XCTAssertEqual(metadata["physical_accuracy_validated"] as? Bool, false)
        return value
    }

    private func render(_ truth: [Matrix], frame: Int) throws -> Data {
        try autoreleasepool {
            let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
            let scale = 3.0, camera = cameraPose(frame)
            let high = UIGraphicsImageRenderer(size: CGSize(width: 5760, height: 3240), format: format).image { context in
                UIColor(white: 216/255.0, alpha: 1).setFill()
                context.fill(CGRect(x: 0,y: 0,width: 5760,height: 3240))
                func polygon(_ points: [[Double]], pose: Matrix, gray: Double) {
                    let uv = project(points, pose: pose)
                    let path = CGMutablePath()
                    for (index, point) in uv.enumerated() {
                        let p = CGPoint(x: point[0]*scale, y: point[1]*scale)
                        if index == 0 { path.move(to: p) } else { path.addLine(to: p) }
                    }
                    path.closeSubpath(); context.cgContext.addPath(path)
                    context.cgContext.setFillColor(UIColor(white: gray, alpha: 1).cgColor)
                    context.cgContext.fillPath()
                }
                for id in truth.indices {
                    let pose = multiply(camera, truth[id])
                    polygon([[-4.25,-3.6,0],[4.25,-3.6,0],[4.25,3.2,0],[-4.25,3.2,0]], pose: pose, gray: 14/255.0)
                    for point in markerPoints(id) {
                        let circle = (0..<96).map { sample -> [Double] in
                            let a = 2*Double.pi*Double(sample)/96
                            return [point[0]+0.55*cos(a), point[1]+0.55*sin(a), point[2]]
                        }
                        polygon(circle, pose: pose, gray: 242/255.0)
                    }
                }
            }
            let image = UIGraphicsImageRenderer(size: CGSize(width: 1920,height: 1080), format: format).image { context in
                context.cgContext.interpolationQuality = .high
                high.draw(in: CGRect(x: 0,y: 0,width: 1920,height: 1080))
            }
            return try XCTUnwrap(image.pngData())
        }
    }
    private func checkXYZ(_ result: [String: Any], truth: [Matrix], name: String) throws {
        XCTAssertEqual(result["status"] as? String, "research_result")
        XCTAssertEqual(result["world_anchor_marker_id"] as? Int, 0)
        XCTAssertEqual(result["frame_count"] as? Int, frames)
        XCTAssertEqual(result["observations_used"] as? Int, frames*truth.count)
        XCTAssertEqual(result["missing_markers"] as? [Int], [])
        XCTAssertTrue(result["physical_accuracy_um"] is NSNull)
        XCTAssertLessThan(try XCTUnwrap(result["reprojection_rms_px"] as? Double), 0.15)
        let adjustment = try XCTUnwrap(result["bundle_adjustment"] as? [[String: Any]])
        XCTAssertEqual(adjustment.first?["converged"] as? Bool, true)
        let rows = try XCTUnwrap(result["markers"] as? [[String: Any]])
        XCTAssertEqual(rows.count, truth.count)
        var metrics = [[String: Any]]()
        for row in rows {
            let id = try XCTUnwrap(row["id"] as? Int)
            let pose = try XCTUnwrap(row["T_world_marker"] as? Matrix)
            let expected = multiply(inverse(truth[0]), truth[id])
            let error = sqrt((0..<3).reduce(0.0) { $0 + pow(pose[$1][3]-expected[$1][3],2) })
            let dot = (0..<3).reduce(0.0) { $0 + pose[$1][2]*expected[$1][2] }
            let angle = acos(max(-1,min(1,dot)))*180/Double.pi
            // These are synthetic regression bounds, not clinical tolerances.
            XCTAssertLessThan(error, 0.25, "ID \(id) synthetic position")
            XCTAssertLessThan(angle, 1.0, "ID \(id) synthetic optical-normal angle")
            XCTAssertEqual(row["views"] as? Int, frames)
            XCTAssertGreaterThan(try XCTUnwrap(row["min_marker_side_px"] as? Double), 45)
            XCTAssertGreaterThan(try XCTUnwrap(row["min_corner_max_ray_angle_deg"] as? Double), 3)
            XCTAssertEqual(row["issues"] as? [String], ["missing_mua_calibration"])
            XCTAssertEqual(row["calibration_status"] as? String, "missing")
            XCTAssertTrue(row["T_world_mua"] is NSNull)
            XCTAssertTrue(row["center_mm"] is NSNull); XCTAssertTrue(row["axis"] is NSNull)
            metrics.append(["id": id, "position_error_mm": error, "optical_normal_error_deg": angle])
        }
        let evidence: [String: Any] = ["synthetic_only": true, "physical_accuracy_um": NSNull(),
            "name": name, "ground_truth_fx": fx, "ground_truth_fy": fy,
            "frames": frames, "marker_count": truth.count, "errors": metrics, "result": result]
        let attachment = XCTAttachment(data: try json(evidence), uniformTypeIdentifier: "public.json")
        attachment.name = name+".json"; attachment.lifetime = .keepAlways; add(attachment)
    }
    private func pixelPipeline(count: Int) async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("macro-XYZ-"+UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let engine = OfflineEngine(root: root)
        let calibrated = try await calibration(engine: engine, root: root, count: count)
        let scan = creation("scan", count: count, profile: profile, calibrationID: calibrated.id)
        let initial = try await engine.request("sessions", body: JSONEncoder().encode(scan))
        let sourceCamera = try XCTUnwrap(initial["camera"] as? [String: Any])
        let truth = markerTruth(count)
        for frame in 0..<frames {
            let pixels = try render(truth, frame: frame)
            let response = try await engine.submitFrame("sessions/\(scan.id)/frames", id: captureID(),
                image: pixels, profile: profile, timestamp: Double(frame+100))
            XCTAssertEqual(response["accepted"] as? Bool, true, "frame \(frame): \(response["message"] ?? "")")
            XCTAssertEqual((response["marker_ids"] as? [Int])?.sorted(), Array(0..<count))
            XCTAssertEqual(response["capture_profile"] as? NSDictionary, try object(profile) as NSDictionary)
            let feedback = try XCTUnwrap(response["feedback"] as? [String: Any])
            let diagnostics = try XCTUnwrap(feedback["diagnostics"] as? [String: Any])
            XCTAssertEqual(diagnostics["detector_mode"] as? String, "calibrated_pose_3d")
        }
        let collected = try await engine.request("sessions/\(scan.id)", body: nil)
        XCTAssertEqual(collected["camera"] as? NSDictionary, sourceCamera as NSDictionary)
        let history = try XCTUnwrap(collected["accepted"] as? [[String: Any]])
        XCTAssertEqual(history.count, frames)
        for frame in history {
            XCTAssertEqual(frame["capture_profile"] as? NSDictionary, try object(profile) as NSDictionary)
        }
        let done = try await engine.request("sessions/\(scan.id)/process", body: json([:]))
        XCTAssertEqual(done["state"] as? String, "complete")
        let result = try XCTUnwrap(done["result"] as? [String: Any])
        XCTAssertEqual(result["camera"] as? NSDictionary, sourceCamera as NSDictionary)
        try checkXYZ(result, truth: truth, name: "macro-pixels-to-XYZ-\(count)")
        let reopened = OfflineEngine(root: root)
        let restored = try await reopened.request("sessions/\(scan.id)", body: nil)
        XCTAssertEqual(restored["result"] as? NSDictionary, result as NSDictionary)
    }

    func testFourFlagSyntheticMacroPixelsProduceCalibratedXYZWithoutInventedMUA() async throws {
        try await pixelPipeline(count: 4)
    }
    func testSixFlagSyntheticMacroPixelsProduceCalibratedXYZWithoutInventedMUA() async throws {
        try await pixelPipeline(count: 6)
    }
    func testSyntheticMacroKnownMeasurementsPreserveXYZWithSeededSubpixelNoise() throws {
        for count in [4,6] {
            let truth = markerTruth(count)
            var seed: UInt64 = 0x44414c_001300 + UInt64(count)
            func noise() -> Double {
                seed = seed &* 6364136223846793005 &+ 1442695040888963407
                return (Double(seed >> 11)/9007199254740992.0-0.5)*0.05
            }
            var observations = [[String: Any]]()
            for frame in 0..<frames {
                for id in 0..<count {
                    var uv = project(markerPoints(id), pose: multiply(cameraPose(frame), truth[id]))
                    for point in uv.indices { uv[point][0] += noise(); uv[point][1] += noise() }
                    var span = 0.0
                    for a in uv { for b in uv { span = max(span,hypot(a[0]-b[0],a[1]-b[1])) } }
                    observations.append(["frame": String(format: "synthetic-%02d",frame), "marker": id,
                        "corners": uv, "min_side_px": span, "ambiguity_ratio": 0.0])
                }
            }
            let camera = try cameraDictionary()
            let result = try DALNativeEngine.reconstruct(observations: observations, camera: camera, markerCount: count)
            XCTAssertEqual(result["camera"] as? NSDictionary, camera as NSDictionary)
            try checkXYZ(result, truth: truth, name: "macro-noisy-measurements-XYZ-\(count)")
        }
    }
    func testSyntheticMacroScanRejectsChangedLensAndFocusBeforeDecodingPixels() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("macro-XYZ-profile-"+UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let engine = OfflineEngine(root: root)
        let calibrated = try await calibration(engine: engine, root: root, count: 6)
        let scan = creation("scan", count: 6, profile: profile, calibrationID: calibrated.id)
        let initial = try await engine.request("sessions", body: JSONEncoder().encode(scan))
        let mutations: [(inout CaptureProfile) -> Void] = [
            { $0.lens = "wide" }, { $0.lensPosition = 0.73 }, { $0.format += "-different-FOV" }
        ]
        for mutate in mutations {
            var changed = profile; mutate(&changed)
            let incompatible = creation("scan", count: 6, profile: changed, calibrationID: calibrated.id)
            do {
                _ = try await engine.request("sessions", body: JSONEncoder().encode(incompatible))
                XCTFail("A changed physical optical profile reused macro calibration")
            } catch { XCTAssertFalse(error.localizedDescription.isEmpty) }
            XCTAssertFalse(FileManager.default.fileExists(atPath: root.appendingPathComponent(incompatible.id+".json").path))
            do {
                _ = try await engine.submitFrame("sessions/\(scan.id)/frames", id: captureID(),
                    image: Data(), profile: changed, timestamp: 5)
                XCTFail("A changed profile reached the image decoder")
            } catch { XCTAssertEqual(error.localizedDescription, "Kamera profili bu kayıtla eşleşmiyor.") }
        }
        let preserved = try await engine.request("sessions/\(scan.id)", body: nil)
        XCTAssertEqual(try json(preserved), try json(initial))
    }
}
