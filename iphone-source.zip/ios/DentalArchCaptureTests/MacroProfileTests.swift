import Foundation
import XCTest
@testable import DentalArchCapture

@MainActor final class MacroProfileTests: XCTestCase {
    private let macroFormat = "dal-optics-v2|subtype=875704438|sensor=3840x2160|fov=1118070374|binned=0|index=10|gdc=1"

    private func profile(lens: String = "ultrawide") -> CaptureProfile {
        var result = CaptureProfile(device: "fixture-physical-" + lens, lensPosition: 0.55,
                                    width: 1920, height: 1080, format: macroFormat)
        result.lens = lens
        return result
    }

    private func creation(_ mode: String, profile: CaptureProfile, calibrationID: String? = nil) -> CaptureCreation {
        var result = CaptureCreation(mode: mode, markerCount: 6, profile: profile,
                                     physical: mode == "calibration", squareMM: mode == "calibration" ? 6 : nil,
                                     calibrationID: calibrationID)
        if mode != "calibration" {
            var plan = DentalPlan.vidaMUA9
            plan.useExample(count: 6)
            result.dentalPlan = plan
        }
        return result
    }

    private func object<T: Encodable>(_ value: T) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(value)) as? [String: Any])
    }

    private func data(_ value: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }

    private func folder() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("macro-profile-" + UUID().uuidString)
    }

    // Projected ground-truth board observations exercise the real optimizer.
    // They do not model an iPhone lens or establish physical macro accuracy.
    private func projectedBoardViews() -> [[[Double]]] {
        (0..<20).map { index in
            let phase = Double(index) * 2 * Double.pi / 20
            let ax = 0.3 * sin(phase), ay = 0.28 * cos(phase)
            let tx = -24 + 30 * cos(phase), ty = -15 + 17 * sin(phase)
            let tz = 180 + 12 * sin(2 * phase)
            return (0..<54).map { corner in
                let x = Double(corner % 9) * 6, y = Double(corner / 9) * 6
                let rx = cos(ay) * x + sin(ay) * sin(ax) * y
                let ry = cos(ax) * y
                let rz = -sin(ay) * x + cos(ay) * sin(ax) * y
                return [1600 * (rx + tx) / (rz + tz) + 960,
                        1585 * (ry + ty) / (rz + tz) + 540]
            }
        }
    }

    private func calibrate(_ profile: CaptureProfile, engine: OfflineEngine, root: URL) async throws -> CaptureCreation {
        let value = creation("calibration", profile: profile)
        var state = try await engine.request("sessions", body: JSONEncoder().encode(value))
        let views = projectedBoardViews()
        state["accepted"] = views.enumerated().map { index, corners -> [String: Any] in
            ["id": captureID(), "timestamp_s": Double(index + 10),
             "observations": [[String: Any]](), "corners": corners]
        }
        state["count"] = views.count
        try data(state).write(to: root.appendingPathComponent(value.id + ".json"))
        let result = try await engine.request("sessions/\(value.id)/process", body: data(["automatic": true]))
        XCTAssertEqual(result["state"] as? String, "complete")
        let camera = try XCTUnwrap(result["calibration"] as? [String: Any])
        let metadata = try XCTUnwrap(camera["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["status"] as? String, "measured_research")
        XCTAssertEqual(metadata["views"] as? Int, 20)
        XCTAssertEqual(metadata["warnings"] as? [String], [])
        XCTAssertLessThan(try XCTUnwrap(metadata["rms_px"] as? Double), 0.01)
        XCTAssertEqual(metadata["physical_accuracy_validated"] as? Bool, false)
        XCTAssertEqual(metadata["capture_profile"] as? NSDictionary, try object(profile) as NSDictionary)
        XCTAssertEqual(camera["image_size"] as? [Int], [1920, 1080])
        return value
    }

    private func rejectCreation(_ value: CaptureCreation, engine: OfflineEngine,
                                file: StaticString = #filePath, line: UInt = #line) async throws {
        do {
            _ = try await engine.request("sessions", body: JSONEncoder().encode(value))
            XCTFail("Incompatible camera profile was accepted: \(value.profile)", file: file, line: line)
        } catch {
            XCTAssertFalse(error.localizedDescription.isEmpty, file: file, line: line)
        }
    }

    func testMacroNativeCalibrationAndScanPreserveExactProfileAfterReopen() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let engine = OfflineEngine(root: root), macro = profile()
        let calibration = try await calibrate(macro, engine: engine, root: root)
        let reopened = OfflineEngine(root: root)
        let scan = creation("scan", profile: macro, calibrationID: calibration.id)
        let state = try await reopened.request("sessions", body: JSONEncoder().encode(scan))
        let persisted = try await reopened.request("sessions/\(scan.id)", body: nil)
        XCTAssertEqual(try data(state), try data(persisted))
        XCTAssertEqual(persisted["profile"] as? NSDictionary, try object(macro) as NSDictionary)
        let camera = try XCTUnwrap(persisted["camera"] as? [String: Any])
        let metadata = try XCTUnwrap(camera["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["capture_profile"] as? NSDictionary, try object(macro) as NSDictionary)
        XCTAssertEqual(persisted["count"] as? Int, 0)
        XCTAssertTrue(persisted["physical_accuracy_um"] is NSNull)

        // Any optical change invalidates reuse even when the delivered image
        // still has the exact same 1920 x 1080 dimensions.
        let changes: [(inout CaptureProfile) -> Void] = [
            { $0.lens = "wide" }, { $0.device = "another-physical-camera" },
            { $0.format = $0.format.replacingOccurrences(of: "3840x2160", with: "1920x1080") },
            { $0.format = $0.format.replacingOccurrences(of: "1118070374", with: "1118070375") },
            { $0.format = $0.format.replacingOccurrences(of: "gdc=1", with: "gdc=0") },
            { $0.lensPosition = 0.56 }
        ]
        for change in changes {
            var changed = macro; change(&changed)
            let rejected = creation("scan", profile: changed, calibrationID: calibration.id)
            try await rejectCreation(rejected, engine: reopened)
            XCTAssertFalse(FileManager.default.fileExists(atPath: root.appendingPathComponent(rejected.id + ".json").path))
            do {
                // Empty pixels ensure profile rejection happens before decode,
                // rather than succeeding and then failing on image content.
                _ = try await reopened.submitFrame("sessions/\(scan.id)/frames", id: captureID(),
                    image: Data(), profile: changed, timestamp: 123)
                XCTFail("A changed optical profile reached an existing scan")
            } catch {
                XCTAssertEqual(error.localizedDescription, "Kamera profili bu kayıtla eşleşmiyor.")
            }
        }
        let unchanged = try await reopened.request("sessions/\(scan.id)", body: nil)
        XCTAssertEqual(try data(persisted), try data(unchanged))
    }

    func testExistingWideCalibrationRemainsUsableButCannotBeReusedForMacro() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let engine = OfflineEngine(root: root)
        var wide = profile(lens: "wide")
        wide.format = "875704438" // Existing wide-camera records retain this signature.
        let calibration = try await calibrate(wide, engine: engine, root: root)
        let compatible = creation("scan", profile: wide, calibrationID: calibration.id)
        let scan = try await engine.request("sessions", body: JSONEncoder().encode(compatible))
        XCTAssertEqual(scan["state"] as? String, "collecting")
        try await rejectCreation(creation("scan", profile: profile(), calibrationID: calibration.id), engine: engine)
    }

    func testVirtualCameraCannotProduceMeasuredNativeCalibrationStatus() throws {
        var virtual = profile()
        virtual.lens = "triple"
        let result = try DALNativeEngine.calibrate(corners: projectedBoardViews(), width: 1920, height: 1080,
            squareMM: 6, physicalMeasured: true, profile: object(virtual))
        let metadata = try XCTUnwrap(result["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["status"] as? String, "screen_experimental")
        XCTAssertEqual(metadata["physical_accuracy_validated"] as? Bool, false)
        XCTAssertEqual(metadata["capture_profile"] as? NSDictionary, try object(virtual) as NSDictionary)
    }

    func testMacroDoesNotPermitVirtualLensesResizedMeasurementsOrUncontrolledOptics() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let engine = OfflineEngine(root: root)
        let invalid: [(inout CaptureProfile) -> Void] = [
            { $0.lens = "triple" }, { $0.lens = "dual" }, { $0.lens = "tele" },
            { $0.lens = "ultra-wide" }, { $0.lens = "" },
            { $0.width = 3840; $0.height = 2160 }, { $0.width = 960; $0.height = 540 },
            { $0.zoom = 2 }, { $0.focus = "continuous" }, { $0.stabilization = "on" },
            { $0.device = "" }, { $0.format = "" }, { $0.lensPosition = 1.1 }
        ]
        for change in invalid {
            var candidate = profile(); change(&candidate)
            try await rejectCreation(creation("calibration", profile: candidate), engine: engine)
        }
        XCTAssertFalse(FileManager.default.fileExists(atPath: root.path))
    }

    func testMacroTrialRefocusExceptionNeverAllowsAnotherLensOrFormat() {
        let original = profile()
        var refocused = original; refocused.lensPosition = 0.62
        XCTAssertTrue(original.accepts(refocused, mode: "trial"))
        XCTAssertFalse(original.accepts(refocused, mode: "scan"))
        XCTAssertFalse(original.accepts(refocused, mode: "calibration"))
        refocused.lens = "wide"
        XCTAssertFalse(original.accepts(refocused, mode: "trial"))
        refocused = original
        refocused.format += "-changed"
        XCTAssertFalse(original.accepts(refocused, mode: "trial"))
    }
}
