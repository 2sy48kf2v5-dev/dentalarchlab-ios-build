import Foundation
import UIKit
import XCTest
@testable import DentalArchCapture

/// Synthetic image diagnostics only. Proposal counters include background;
/// they must never label an unrecognized physical flag as blurred or missing.
final class NativeProposalDiagnosticsTests: XCTestCase {
    private func camera(size: Int = 512) -> [String: Any] {
        ["schema_version": 1, "model": "opencv_pinhole",
         "K": [[400.0,0,Double(size)/2],[0,400,Double(size)/2],[0,0,1]],
         "image_size": [size,size], "distortion": [0.0,0,0,0,0]]
    }

    private func fixture(_ name: String) throws -> Data {
        try Data(contentsOf: XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "dat")))
    }

    private func circles(count: Int, softEdges: Bool) throws -> Data {
        let centers = [(160.0,160.0),(350.0,160.0),(160.0,350.0),(350.0,350.0)]
        var pixels = [UInt8](repeating: softEdges ? 64 : 12, count: 512 * 512)
        for y in 0..<512 { for x in 0..<512 {
            var value = softEdges ? 64.0 : 12.0
            for (cx, cy) in centers.prefix(count) {
                let distance = hypot(Double(x) - cx, Double(y) - cy)
                if softEdges {
                    value = max(value, 64 + 140 * max(0, 1 - distance / 70))
                } else if distance <= 16 { value = 236 }
            }
            pixels[y * 512 + x] = UInt8(value.rounded())
        } }
        let provider = try XCTUnwrap(CGDataProvider(data: Data(pixels) as CFData))
        let image = try XCTUnwrap(CGImage(width: 512, height: 512, bitsPerComponent: 8,
            bitsPerPixel: 8, bytesPerRow: 512, space: CGColorSpaceCreateDeviceGray(),
            bitmapInfo: CGBitmapInfo(rawValue: 0), provider: provider, decode: nil,
            shouldInterpolate: false, intent: .defaultIntent))
        return try XCTUnwrap(UIImage(cgImage: image).pngData())
    }

    private func diagnostics(_ result: [String: Any]) throws -> ([String: Any], [String: Any], [String: Any]) {
        let quality = try XCTUnwrap(result["quality"] as? [String: Any])
        let proposal = try XCTUnwrap(quality["proposal_diagnostics"] as? [String: Any])
        let rejections = try XCTUnwrap(proposal["circle_rejections"] as? [String: Any])
        XCTAssertEqual(proposal["counts_scope"] as? String,
                       "all_image_proposals_across_masks_including_background_not_identified_flags")
        XCTAssertEqual(proposal["incomplete_component_definition"] as? String,
                       "one_to_three_eligible_circles_under_one_contour_parent")
        let eligible = try XCTUnwrap(proposal["eligible_circle_proposals"] as? Int)
        let lowContrast = try XCTUnwrap(rejections["low_edge_contrast"] as? Int)
        let incompleteEdges = try XCTUnwrap(rejections["insufficient_edge_samples"] as? Int)
        XCTAssertEqual(try XCTUnwrap(proposal["refined_circle_proposals"] as? Int),
                       eligible + lowContrast + incompleteEdges)
        for name in ["small_contour", "invalid_ellipse", "low_edge_contrast", "insufficient_edge_samples"] {
            XCTAssertGreaterThanOrEqual(try XCTUnwrap(rejections[name] as? Int), 0)
        }
        XCTAssertGreaterThanOrEqual(eligible, 0)
        XCTAssertLessThanOrEqual(eligible, 512)
        let incomplete = try XCTUnwrap(proposal["incomplete_circle_components"] as? Int)
        XCTAssertGreaterThanOrEqual(incomplete, 0)
        XCTAssertLessThanOrEqual(incomplete, eligible)
        let observations = try XCTUnwrap(result["observations"] as? [[String: Any]])
        XCTAssertEqual(quality["target_blur_available"] as? Bool, !observations.isEmpty)
        return (quality, proposal, rejections)
    }

    func testSharpSyntheticMacroKeepsItsIdentityAndMeasuredTargetBlur() throws {
        let calibration: [String: Any] = ["schema_version": 1, "model": "opencv_pinhole",
            "K": [[600.0,0,960],[0,600,540],[0,0,1]], "image_size": [1920,1080], "distortion": [0.0,0,0,0,0]]
        let result = try DALNativeEngine.detect(image: fixture("macro_oblique_id4"), camera: calibration, markerCount: 6)
        let observations = try XCTUnwrap(result["observations"] as? [[String: Any]])
        XCTAssertEqual(observations.compactMap { $0["marker"] as? Int }, [4])
        let (quality, proposal, _) = try diagnostics(result)
        XCTAssertEqual(quality["target_blur_available"] as? Bool, true)
        XCTAssertGreaterThan(try XCTUnwrap(quality["blur_laplacian"] as? Double), 0)
        XCTAssertGreaterThanOrEqual(try XCTUnwrap(proposal["eligible_circle_proposals"] as? Int), 4)
    }

    func testSoftSyntheticEdgesExposeLowContrastWithoutInventingTargetBlur() throws {
        let result = try DALNativeEngine.detect(image: circles(count: 4, softEdges: true), camera: camera(), markerCount: 6)
        let (quality, _, rejections) = try diagnostics(result)
        XCTAssertEqual((result["observations"] as? [Any])?.count, 0)
        XCTAssertGreaterThan(try XCTUnwrap(rejections["low_edge_contrast"] as? Int), 0)
        XCTAssertEqual(quality["target_blur_available"] as? Bool, false)
        XCTAssertEqual(quality["blur_laplacian"] as? Double, 0, "Legacy zero remains unavailable, not a measured target blur")
    }

    func testThreeSharpCirclesReportIncompleteComponentsWithoutAssigningAnIdentity() throws {
        let result = try DALNativeEngine.detect(image: circles(count: 3, softEdges: false), camera: camera(), markerCount: 6)
        let (quality, proposal, _) = try diagnostics(result)
        XCTAssertEqual((result["observations"] as? [Any])?.count, 0)
        XCTAssertGreaterThan(try XCTUnwrap(proposal["incomplete_circle_components"] as? Int), 0)
        XCTAssertEqual(quality["dot_groups"] as? Int, 0)
        XCTAssertEqual(quality["target_blur_available"] as? Bool, false)
    }

    func testFourOuterCirclesKeepTheirInvalidGeometryReasonWithoutInventingAnIdentity() throws {
        let result = try DALNativeEngine.detect(image: circles(count: 4, softEdges: false), camera: camera(), markerCount: 6)
        let (quality, proposal, _) = try diagnostics(result)
        XCTAssertEqual((result["observations"] as? [Any])?.count, 0)
        let candidates = try XCTUnwrap(quality["candidate_diagnostics"] as? [[String: Any]])
        XCTAssertFalse(candidates.isEmpty)
        XCTAssertTrue(candidates.allSatisfy { $0["reason"] as? String == "invalid_layout" })
        XCTAssertTrue(candidates.allSatisfy { $0["best_id"] is NSNull })
        XCTAssertGreaterThanOrEqual(try XCTUnwrap(proposal["eligible_circle_proposals"] as? Int), 4)
        XCTAssertEqual(quality["target_blur_available"] as? Bool, false)
    }

    func testBlankAndNoiseHaveNoMeasuredTargetBlurAndKeepBoundedDiagnostics() throws {
        let blank = try DALNativeEngine.detect(image: circles(count: 0, softEdges: false), camera: camera(), markerCount: 6)
        let (blankQuality, blankProposal, _) = try diagnostics(blank)
        XCTAssertEqual(blankQuality["target_blur_available"] as? Bool, false)
        XCTAssertEqual(blankProposal["eligible_circle_proposals"] as? Int, 0)
        XCTAssertEqual(blankProposal["incomplete_circle_components"] as? Int, 0)
        let noise = try DALNativeEngine.detect(image: fixture("macro_noise"), camera: camera(), markerCount: 6)
        let (noiseQuality, noiseProposal, _) = try diagnostics(noise)
        XCTAssertEqual(noiseQuality["target_blur_available"] as? Bool, false)
        XCTAssertEqual(noiseProposal["budget_exceeded"] as? Bool, true)
        XCTAssertEqual(noiseProposal["budget_reason"] as? String, "contour_limit")
        XCTAssertEqual(noiseProposal["refined_circle_proposals"] as? Int, 0)
    }
}
