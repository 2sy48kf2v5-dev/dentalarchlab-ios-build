import AVFoundation
import Foundation
import XCTest
@testable import DentalArchCapture

private final class CloseFocusCalibrationCamera: CameraControlling {
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    var starts: [(Result<CaptureProfile, Error>) -> Void] = []
    var focusRequests: [CameraFocusRequest] = []
    var opticsRequests: [CameraOpticsRequest] = []
    var previewCount = 0
    var captureCount = 0
    var pendingCapture: ((Result<(Data, CaptureProfile, Double), Error>) -> Void)?
    func configureOptics(_ request: CameraOpticsRequest) { opticsRequests.append(request) }
    func startPreview(completion: @escaping (Result<Void, Error>) -> Void) { previewCount += 1 }
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) {
        focusRequests.append(focus); starts.append(completion)
    }
    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        captureCount += 1; pendingCapture = completion
    }
    func stop() {
        let pending = pendingCapture; pendingCapture = nil
        pending?(.failure(LabError.message("Test kamerası durduruldu.")))
    }
    func deliver(_ image: Data, profile: CaptureProfile) {
        let pending = pendingCapture; pendingCapture = nil
        pending?(.success((image, profile, ProcessInfo.processInfo.systemUptime)))
    }
}

@MainActor final class CloseFocusCalibrationTests: XCTestCase {
    private func profile(focus: Float = 0.86, lens: String = "ultrawide") -> CaptureProfile {
        var profile = CaptureProfile(device: "close-focus-test", lensPosition: focus, width: 1920, height: 1080,
                                     format: "test-close-focus-format")
        profile.lens = lens
        return profile
    }
    private func fixture() -> (CaptureModel, CloseFocusCalibrationCamera, URL) {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let camera = CloseFocusCalibrationCamera()
        return (CaptureModel(repository: CaptureRepository(root: root), camera: camera), camera, root)
    }
    private func waitUntil(timeout: TimeInterval = 2, _ condition: () -> Bool,
                           file: StaticString = #filePath, line: UInt = #line) async throws {
        let deadline = Date().addingTimeInterval(timeout)
        while !condition(), Date() < deadline { try await Task.sleep(nanoseconds: 10_000_000) }
        XCTAssertTrue(condition(), file: file, line: line)
    }
    private func complete(_ model: CaptureModel, camera: CloseFocusCalibrationCamera, index: Int = 0,
                          result: Result<CaptureProfile, Error>) async throws {
        camera.starts[index](result)
        try await waitUntil { !model.cameraStarting }
    }
    private func cleanup(_ model: CaptureModel, root: URL) async throws {
        model.stopCamera()
        try await waitUntil { !model.analyzing && !model.uploading }
        try? FileManager.default.removeItem(at: root)
    }
    private func savedScan(_ initial: CaptureModel, camera: CloseFocusCalibrationCamera,
                           pending: Bool = false) throws -> (CaptureModel, LocalCapture) {
        var creation = CaptureCreation(mode: "scan", markerCount: 4, profile: profile(focus: 0.73725486),
                                       physical: false, squareMM: nil, calibrationID: String(repeating: "a", count: 32))
        creation.markerIDs = [0, 3, 4, 5]
        var plan = DentalPlan.vidaMUA9
        try plan.setMarkerIDs([0, 3, 4, 5]); plan.useExample(count: 4)
        creation.dentalPlan = plan
        try initial.repository.create(creation)
        if pending { try initial.repository.append(id: creation.id, image: Data([1, 2, 3]), timestamp: 1) }
        let model = CaptureModel(repository: initial.repository, camera: camera)
        let capture = try model.repository.get(creation.id)
        model.select(capture)
        return (model, capture)
    }

    func testPreparingNearFocusPreservesOldScanAndCreatesNoCalibrationFrames() async throws {
        let (initial, camera, root) = fixture()
        let (model, previous) = try savedScan(initial, camera: camera)
        let oldFile = root.appendingPathComponent(previous.id).appendingPathComponent("capture.json")
        let original = try Data(contentsOf: oldFile)
        model.physicalBoard = true; model.squareMM = "16.4"
        model.prepareCloseFocusCalibration()
        XCTAssertEqual(model.mode, "calibration"); XCTAssertNil(model.currentID)
        XCTAssertTrue(model.macroXYZRequested); XCTAssertTrue(model.closeFocusCalibrationRequested)
        XCTAssertEqual(model.cameraOpticsChoice, "closeUp"); XCTAssertTrue(model.calibrationID.isEmpty)
        XCTAssertFalse(model.physicalBoard); XCTAssertEqual(model.squareMM, "16.4")
        XCTAssertEqual(model.selectedMarkerIDs, [0, 3, 4, 5])
        XCTAssertEqual(camera.focusRequests, [.automatic]); XCTAssertEqual(camera.opticsRequests, [.closeUp])
        XCTAssertEqual(camera.captureCount, 0)
        try await complete(model, camera: camera, result: .success(profile()))
        XCTAssertTrue(model.closeFocusCalibrationReady); XCTAssertEqual(model.closeFocusCalibrationProfile, profile())
        XCTAssertFalse(model.autoRunning); XCTAssertEqual(camera.captureCount, 0)
        XCTAssertEqual(try model.repository.list().count, 1)
        XCTAssertEqual(try Data(contentsOf: oldFile), original)
        try await cleanup(model, root: root)
    }

    func testAllCaptureEntryPointsRequireFreshPhysicalBoardConfirmation() async throws {
        let (model, camera, root) = fixture()
        model.selectWorkMode("calibration")
        XCTAssertTrue(model.canPrepareCloseFocusCalibration)
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, result: .success(profile()))
        model.beginCalibrationScan(); model.startAutomatic(); model.takePhoto()
        XCTAssertEqual(camera.captureCount, 0); XCTAssertNil(model.currentID)
        XCTAssertTrue(model.status.contains("ölçümü doğrulayın"))
        model.physicalBoard = true; model.squareMM = "0"
        model.beginCalibrationScan()
        XCTAssertEqual(camera.captureCount, 0)
        try await cleanup(model, root: root)
    }

    func testBoardCollectionUsesTheArmedFocusWithoutAnotherAutofocus() async throws {
        let (model, camera, root) = fixture()
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, result: .success(profile()))
        model.physicalBoard = true; model.squareMM = "6,0"
        model.beginCalibrationScan()
        try await waitUntil { camera.captureCount == 1 }
        XCTAssertEqual(camera.focusRequests, [.automatic]); XCTAssertEqual(camera.previewCount, 0)
        XCTAssertEqual(model.closeFocusCalibrationProfile, profile())
        XCTAssertTrue(model.autoRunning)
        // Pending frames prevent switching profile/record while analysis owns a sample.
        XCTAssertFalse(model.canPrepareCloseFocusCalibration)
        model.prepareCloseFocusCalibration()
        XCTAssertEqual(camera.starts.count, 1)
        try await cleanup(model, root: root)
    }

    func testNewCalibrationRecordBindsTheArmedProfileAndNewMeasuredBoard() async throws {
        let (initial, camera, root) = fixture()
        let (model, previous) = try savedScan(initial, camera: camera)
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, result: .success(profile()))
        model.physicalBoard = true; model.squareMM = "6,0"
        model.beginCalibrationScan()
        try await waitUntil { camera.pendingCapture != nil }
        // The session is registered before image analysis. Invalid bytes ensure
        // this checks record binding without inventing a usable board image.
        camera.deliver(Data([0, 1]), profile: profile())
        try await waitUntil(timeout: 15) { model.currentID != nil && !model.analyzing }
        let calibration = try XCTUnwrap(model.current)
        XCTAssertNotEqual(calibration.id, previous.id)
        XCTAssertEqual(calibration.creation.mode, "calibration")
        XCTAssertEqual(calibration.creation.profile, profile())
        XCTAssertNil(calibration.creation.calibrationID)
        XCTAssertTrue(calibration.creation.board.physicalMeasured)
        XCTAssertEqual(calibration.creation.board.squareMM, 6)
        XCTAssertEqual(calibration.acceptedCount, 0)
        XCTAssertEqual(try model.repository.list().count, 2)
        XCTAssertEqual(try model.repository.get(previous.id).creation.profile, previous.creation.profile)
        try await cleanup(model, root: root)
    }

    func testDifferentProfileFrameCannotCreateANewCalibrationRecord() async throws {
        let (model, camera, root) = fixture()
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, result: .success(profile()))
        model.physicalBoard = true; model.squareMM = "6"
        model.takePhoto()
        camera.deliver(Data([0, 1]), profile: profile(focus: 0.75))
        try await waitUntil { !model.busy }
        XCTAssertNil(model.currentID)
        XCTAssertTrue(try model.repository.list().isEmpty)
        XCTAssertTrue(model.status.contains("kamera profili değişti"))
        try await cleanup(model, root: root)
    }

    func testInterruptedDraftRestoresExactProfileAndRejectsSubstitution() async throws {
        let (model, camera, root) = fixture()
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, result: .success(profile()))
        camera.onInterruption?("Test kesintisi")
        try await waitUntil { !model.ready }
        XCTAssertEqual(model.closeFocusCalibrationProfile, profile())
        model.physicalBoard = true; model.squareMM = "6"
        model.beginCalibrationScan()
        XCTAssertEqual(camera.focusRequests, [.automatic, .locked(profile().lensPosition)])
        XCTAssertEqual(camera.opticsRequests.last, .restoring(profile()))
        try await complete(model, camera: camera, index: 1, result: .success(profile(focus: 0.75)))
        XCTAssertFalse(model.ready); XCTAssertEqual(camera.captureCount, 0)
        model.beginCalibrationScan()
        try await complete(model, camera: camera, index: 2, result: .success(profile()))
        try await waitUntil { camera.captureCount == 1 }
        XCTAssertEqual(camera.focusRequests.last, .locked(profile().lensPosition))
        try await cleanup(model, root: root)
    }

    func testCancelledAcquisitionCannotArmFromLateCallbackOrImplicitlyAutofocus() async throws {
        let (model, camera, root) = fixture()
        model.prepareCloseFocusCalibration(); model.stopCamera()
        camera.starts[0](.success(profile()))
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertNil(model.closeFocusCalibrationProfile); XCTAssertFalse(model.closeFocusCalibrationReady)
        model.physicalBoard = true; model.squareMM = "6"
        model.beginCalibrationScan(); model.prepareCameraPreview(); model.openCamera()
        XCTAssertEqual(camera.starts.count, 1); XCTAssertEqual(camera.previewCount, 0)
        XCTAssertEqual(camera.captureCount, 0)
        XCTAssertTrue(model.canPrepareCloseFocusCalibration)
        model.prepareCloseFocusCalibration()
        XCTAssertFalse(model.physicalBoard)
        try await complete(model, camera: camera, index: 1, result: .success(profile(focus: 0.91)))
        XCTAssertEqual(model.closeFocusCalibrationProfile, profile(focus: 0.91))
        try await cleanup(model, root: root)
    }

    func testRefocusBeforeBoardCaptureRearmsAndRequiresAnotherBoardConfirmation() async throws {
        let (model, camera, root) = fixture()
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, result: .success(profile()))
        model.physicalBoard = true; model.squareMM = "6"
        model.refocusCamera()
        XCTAssertNil(model.closeFocusCalibrationProfile); XCTAssertFalse(model.physicalBoard)
        XCTAssertEqual(camera.focusRequests, [.automatic, .automatic])
        try await complete(model, camera: camera, index: 1, result: .success(profile(focus: 0.9)))
        XCTAssertEqual(camera.captureCount, 0); XCTAssertTrue(model.calibrationID.isEmpty)
        try await cleanup(model, root: root)
    }

    func testUnprocessedOldFramesBlockChangingTheCalibrationProfile() async throws {
        let (initial, camera, root) = fixture()
        let (model, previous) = try savedScan(initial, camera: camera, pending: true)
        XCTAssertEqual(model.pendingCount, 1); XCTAssertFalse(model.canPrepareCloseFocusCalibration)
        model.prepareCloseFocusCalibration()
        XCTAssertEqual(model.currentID, previous.id); XCTAssertEqual(model.mode, "scan")
        XCTAssertFalse(model.closeFocusCalibrationRequested); XCTAssertTrue(camera.starts.isEmpty)
        try await cleanup(model, root: root)
    }

    func testWideCameraCannotArmCloseFocusAndNewCaseClearsDraft() async throws {
        let (model, camera, root) = fixture()
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, result: .success(profile(lens: "wide")))
        XCTAssertNil(model.closeFocusCalibrationProfile); XCTAssertFalse(model.ready)
        model.prepareCloseFocusCalibration()
        try await complete(model, camera: camera, index: 1, result: .success(profile()))
        model.newSession()
        XCTAssertFalse(model.closeFocusCalibrationRequested); XCTAssertNil(model.closeFocusCalibrationProfile)
        XCTAssertFalse(model.ready); XCTAssertTrue(model.calibrationID.isEmpty)
        try await cleanup(model, root: root)
    }
}
