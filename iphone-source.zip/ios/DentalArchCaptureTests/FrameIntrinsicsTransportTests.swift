import Foundation
import XCTest
@testable import DentalArchCapture

/// Tests metadata transport and binding, not authenticity of a physical camera
/// or clinical calibration. Hardware K is never substituted for metric scan K.
@MainActor final class FrameIntrinsicsTransportTests: XCTestCase {
    private var profile: CaptureProfile {
        var value = CaptureProfile(device: "synthetic-hardware-K-transport", lensPosition: 0.72,
            width: 1920, height: 1080, format: "synthetic-macro-format-transport")
        value.lens = "ultrawide"
        return value
    }
    private func hardware(_ focal: Double = 600) throws -> FrameCameraIntrinsics {
        try FrameCameraIntrinsics(width: 1920, height: 1080, fx: focal, fy: focal, cx: 960, cy: 540)
    }
    private func image() throws -> Data {
        let path = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "macro_oblique_id0", withExtension: "dat"))
        let bytes = try Data(contentsOf: path)
        XCTAssertEqual(PreviewCommit.digest(bytes), "35702858d64372799736182120e165aa6c69dd489d46192e58897c7c98e1c99d")
        return bytes
    }
    private func object<T: Encodable>(_ value: T) throws -> [String: Any] {
        try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(value)) as? [String: Any])
    }
    private func json(_ value: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
    }
    private func comparable(_ value: [String: Any]) throws -> Data {
        var result = value; result.removeValue(forKey: "timing")
        return try json(result)
    }
    private func folder() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("intrinsics-transport-"+UUID().uuidString)
    }
    private func trial(required: Bool? = true) -> CaptureCreation {
        var value = CaptureCreation(mode: "trial", markerCount: 6, profile: profile,
            physical: false, squareMM: nil, calibrationID: nil)
        value.trialIntrinsicsRequired = required
        var plan = DentalPlan.vidaMUA9; plan.useExample(count: 6); value.dentalPlan = plan
        return value
    }
    private func diagnostics(_ receipt: [String: Any]) throws -> [String: Any] {
        let feedback = try XCTUnwrap(receipt["feedback"] as? [String: Any])
        XCTAssertTrue(feedback["physical_accuracy_um"] is NSNull)
        return try XCTUnwrap(feedback["diagnostics"] as? [String: Any])
    }
    private func assertHardwareTrial(_ receipt: [String: Any], k: FrameCameraIntrinsics) throws {
        XCTAssertEqual(receipt["accepted"] as? Bool, true)
        XCTAssertEqual(receipt["marker_ids"] as? [Int], [0])
        XCTAssertEqual(receipt["frame_intrinsics"] as? NSDictionary, k.nativeDictionary() as NSDictionary)
        let detail = try diagnostics(receipt)
        XCTAssertEqual(detail["detector_mode"] as? String, "hardware_intrinsics_pose_2d")
        XCTAssertEqual(detail["preview_only"] as? Bool, true)
        XCTAssertEqual(detail["intrinsics_source"] as? String, FrameCameraIntrinsics.hardwareSource)
        XCTAssertEqual(detail["distortion_source"] as? String, "unmodeled_zero_preview")
    }
    private func rejects(_ client: OfflineClient, path: String, body: [String: Any],
                         file: StaticString = #filePath, line: UInt = #line) async {
        do {
            _ = try await client.request(path, body: body)
            XCTFail("Invalid intrinsic metadata was accepted", file: file, line: line)
        } catch { XCTAssertFalse(error.localizedDescription.isEmpty, file: file, line: line) }
    }

    func testRequiredTrialRawDataAndJSONTransportHaveIdenticalNonmetricAnalysis() async throws {
        let a = folder(), b = folder()
        defer { try? FileManager.default.removeItem(at: a); try? FileManager.default.removeItem(at: b) }
        let raw = OfflineClient(engine: OfflineEngine(root: a)), encoded = OfflineClient(engine: OfflineEngine(root: b))
        let creation = trial(), bytes = try image(), k = try hardware(), id = captureID()
        _ = try await raw.send("sessions", value: creation)
        _ = try await encoded.send("sessions", value: creation)
        let path = "sessions/\(creation.id)/frames"
        let first = try await raw.frame(path, id: id, image: bytes, profile: profile, timestamp: 12.5, intrinsics: k)
        var upload = FrameUpload(id: id, image: bytes.base64EncodedString(), profile: profile, timestamp: 12.5)
        upload.intrinsics = k
        let second = try await encoded.send(path, value: upload)
        XCTAssertEqual(try comparable(first), try comparable(second))
        try assertHardwareTrial(first, k: k)
        let stored = try await raw.request("sessions/\(creation.id)")
        let accepted = try XCTUnwrap((stored["accepted"] as? [[String: Any]])?.first)
        XCTAssertEqual(accepted["frame_intrinsics"] as? NSDictionary, k.nativeDictionary() as NSDictionary)
        XCTAssertNil(stored["camera"])
        let done = try await raw.request("sessions/\(creation.id)/process", body: [:])
        XCTAssertEqual(done["state"] as? String, "complete")
        XCTAssertNil(done["result"]); XCTAssertNil(done["calibration"])
        let summary = try XCTUnwrap(done["trial_summary"] as? [String: Any])
        XCTAssertEqual(summary["metric"] as? String, "identity_only_no_3d")
        XCTAssertEqual(summary["recognized_ids"] as? [Int], [0])
        XCTAssertTrue(summary["physical_accuracy_um"] is NSNull)
    }

    func testRequiredTrialMissingAndInvalidIntrinsicsNeverFallBackToGuessedFocal() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root)), creation = trial()
        let initial = try await client.send("sessions", value: creation)
        let bytes = try image(), path = "sessions/\(creation.id)/frames"
        do {
            _ = try await client.frame(path, id: captureID(), image: bytes, profile: profile, timestamp: 1)
            XCTFail("New hardware-K trial accepted a frame without K")
        } catch {
            XCTAssertEqual((error as NSError).domain, "DentalArchLab.NativeEngine")
            XCTAssertEqual((error as NSError).code, 1001)
            XCTAssertEqual((error as NSError).userInfo["reason"] as? String, "trial_intrinsics_required")
        }
        let k = try object(hardware())
        var invalid = [[String: Any]]()
        var zero = k; zero["fx"] = 0.0; invalid.append(zero)
        var negative = k; negative["fy"] = -600.0; invalid.append(negative)
        var wrongSize = k; wrongSize["width"] = 1280; invalid.append(wrongSize)
        var guessed = k; guessed["source"] = "guessed_focal"; invalid.append(guessed)
        var incomplete = k; incomplete.removeValue(forKey: "cx"); invalid.append(incomplete)
        for metadata in invalid {
            var upload = try object(FrameUpload(id: captureID(), image: bytes.base64EncodedString(), profile: profile, timestamp: 2))
            upload["intrinsics"] = metadata
            await rejects(client, path: path, body: upload)
        }
        let preserved = try await client.request("sessions/\(creation.id)")
        XCTAssertEqual(try json(preserved), try json(initial))
    }

    func testLegacyCreationAndPendingRecordsWithoutIntrinsicFieldsRemainReadable() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let legacy = trial(required: nil)
        let encoded = try object(legacy)
        XCTAssertNil(encoded["trial_intrinsics_required"])
        let decoded = try JSONDecoder().decode(CaptureCreation.self, from: json(encoded))
        XCTAssertNil(decoded.trialIntrinsicsRequired)
        let pendingData = try json(["id": captureID(), "timestamp": 3.0])
        let oldPending = try JSONDecoder().decode(PendingFrame.self, from: pendingData)
        XCTAssertNil(oldPending.intrinsics); XCTAssertNil(oldPending.profile)
        let client = OfflineClient(engine: OfflineEngine(root: root))
        _ = try await client.send("sessions", value: decoded)
        let receipt = try await client.frame("sessions/\(decoded.id)/frames", id: captureID(),
            image: image(), profile: profile, timestamp: 3)
        // This macro fixture rejects the old guessed K. Compatibility must not
        // silently convert an old record into a new hardware-K or metric record.
        XCTAssertEqual(receipt["accepted"] as? Bool, false)
        XCTAssertEqual(receipt["marker_ids"] as? [Int], [])
        XCTAssertEqual(try diagnostics(receipt)["detector_mode"] as? String, "assumed_camera_pose_2d")
        XCTAssertTrue(receipt["frame_intrinsics"] is NSNull)
    }

    func testPendingPersistenceReopenAndReplayPreserveEachFramesExactMatrixAndPixels() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let repository = CaptureRepository(root: root.appendingPathComponent("captures"))
        let writer = FramePersistence(repository: repository), creation = trial(), bytes = try image()
        try repository.create(creation)
        let first = captureID(), second = captureID()
        let firstK = try FrameCameraIntrinsics(width: 1920,height: 1080,fx: 600.012345,fy: 600.054321,cx: 960.00234,cy: 540.05678)
        let secondK = try hardware(601.125)
        _ = try await writer.append(session: creation.id, image: bytes, timestamp: 4.125, frame: first, profile: profile, intrinsics: firstK)
        _ = try await writer.append(session: creation.id, image: bytes, timestamp: 5.25, frame: second, profile: profile, intrinsics: secondK)
        let reopened = CaptureRepository(root: repository.root)
        let pending = try reopened.get(creation.id).pending
        XCTAssertEqual(pending.map(\.id), [first,second])
        XCTAssertEqual(pending[0].intrinsics, firstK); XCTAssertEqual(pending[1].intrinsics, secondK)
        XCTAssertEqual(pending[0].timestamp, 4.125); XCTAssertEqual(pending[1].timestamp, 5.25)
        XCTAssertEqual(pending[0].profile, profile); XCTAssertEqual(pending[1].profile, profile)
        let reader = FramePersistence(repository: reopened)
        let pixels = try await reader.image(session: creation.id, frame: first)
        XCTAssertEqual(pixels, bytes)
        let client = OfflineClient(engine: OfflineEngine(root: root.appendingPathComponent("engine")))
        _ = try await client.send("sessions", value: creation)
        let receipt = try await client.frame("sessions/\(creation.id)/frames", id: pending[0].id,
            image: pixels, profile: try XCTUnwrap(pending[0].profile), timestamp: pending[0].timestamp, intrinsics: pending[0].intrinsics)
        try assertHardwareTrial(receipt, k: firstK)
        try await reader.acknowledge(session: creation.id, frame: first, receipt: receipt)
        let remaining = try reopened.get(creation.id).pending
        XCTAssertEqual(remaining.map(\.id), [second]); XCTAssertEqual(remaining.first?.intrinsics, secondK)
        XCTAssertEqual(try reopened.image(session: creation.id, frame: first), bytes)
    }

    func testSamePixelsAndFrameIDCannotReplayWithChangedOrMissingIntrinsicMetadata() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root)), creation = trial()
        _ = try await client.send("sessions", value: creation)
        let id = captureID(), bytes = try image(), k = try hardware(), path = "sessions/\(creation.id)/frames"
        let first = try await client.frame(path, id: id, image: bytes, profile: profile, timestamp: 2, intrinsics: k)
        let snapshot = try await client.request("sessions/\(creation.id)")
        for altered in [try hardware(2208), nil] as [FrameCameraIntrinsics?] {
            do {
                _ = try await client.frame(path, id: id, image: bytes, profile: profile, timestamp: 2, intrinsics: altered)
                XCTFail("Image hash alone must not authenticate changed K")
            } catch { XCTAssertFalse(error.localizedDescription.isEmpty) }
        }
        let replay = try await client.frame(path, id: id, image: bytes, profile: profile, timestamp: 2, intrinsics: k)
        XCTAssertEqual(try json(first), try json(replay))
        let after = try await client.request("sessions/\(creation.id)")
        XCTAssertEqual(try json(after), try json(snapshot))
    }

    func testPreviewCommitBindsTheAnalyzedIntrinsicMatrixWithoutConsumingCacheOnTamper() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root)), creation = trial()
        _ = try await client.send("sessions", value: creation)
        let id = captureID(), bytes = try image(), k = try hardware(), path = "sessions/\(creation.id)"
        let preview = try await client.frame(path+"/preview", id: id, image: bytes, profile: profile, timestamp: 7, intrinsics: k)
        try assertHardwareTrial(preview, k: k)
        var commitModel = PreviewCommit(session: creation.id, id: id, sha256: PreviewCommit.digest(bytes), profile: profile, timestamp: 7)
        var commit = try object(commitModel)
        await rejects(client, path: path+"/commit-preview", body: commit)
        commit["intrinsics"] = try object(hardware(2208))
        await rejects(client, path: path+"/commit-preview", body: commit)
        commitModel.intrinsics = k
        commit = try object(commitModel)
        XCTAssertEqual(commit["intrinsics"] as? NSDictionary, try object(k) as NSDictionary)
        let accepted = try await client.request(path+"/commit-preview", body: commit)
        try assertHardwareTrial(accepted, k: k)
        XCTAssertEqual(accepted["count"] as? Int, 1)
        let replay = try await client.request(path+"/commit-preview", body: commit)
        XCTAssertEqual(try json(replay), try json(accepted))
    }

    func testRecognitionReportPreservesBoundHardwareKAndRejectsDifferentOrUnboundK() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let client = OfflineClient(engine: OfflineEngine(root: root.appendingPathComponent("engine"))), creation = trial()
        _ = try await client.send("sessions", value: creation)
        let id = captureID(), bytes = try image(), k = try hardware()
        let receipt = try await client.frame("sessions/\(creation.id)/frames", id: id, image: bytes, profile: profile, timestamp: 1, intrinsics: k)
        var sample = RecognitionSample(session: creation.id, sample: id, image: bytes, profile: profile,
            timestamp: 1, mode: "trial", markerCount: 6, response: receipt, intrinsics: k)
        let reportFolder = root.appendingPathComponent("report")
        let path = try sample.write(to: reportFolder), original = try Data(contentsOf: path)
        let report = try XCTUnwrap(JSONSerialization.jsonObject(with: original) as? [String: Any])
        XCTAssertEqual(report["frame_intrinsics"] as? NSDictionary, k.nativeDictionary() as NSDictionary)
        XCTAssertEqual(report["image_sha256"] as? String, PreviewCommit.digest(bytes))
        XCTAssertEqual(Data(base64Encoded: try XCTUnwrap(report["image_base64"] as? String)), bytes)
        XCTAssertTrue(report["physical_accuracy_um"] is NSNull)
        sample.intrinsics = try hardware(2208)
        XCTAssertThrowsError(try sample.write(to: reportFolder))
        sample.intrinsics = nil
        XCTAssertThrowsError(try sample.write(to: reportFolder))
        var unbound = receipt; unbound.removeValue(forKey: "frame_intrinsics")
        let missingBinding = RecognitionSample(session: creation.id, sample: id, image: bytes, profile: profile,
            timestamp: 1, mode: "trial", markerCount: 6, response: unbound, intrinsics: k)
        XCTAssertThrowsError(try missingBinding.write(to: reportFolder))
        XCTAssertEqual(try Data(contentsOf: path), original)
    }

    func testCalibratedScanKeepsItsMeasuredCameraWhenHardwareKDisagrees() async throws {
        let root = folder(); defer { try? FileManager.default.removeItem(at: root) }
        let engine = OfflineEngine(root: root), client = OfflineClient(engine: engine)
        let calibration = CaptureCreation(mode: "calibration", markerCount: 6, profile: profile,
            physical: true, squareMM: 3, calibrationID: nil)
        var state = try await client.send("sessions", value: calibration)
        // A stored, approved calibration fixture isolates the transport branch.
        // Actual native camera fitting is covered by MacroXYZPipelineTests.
        let measured: [String: Any] = ["schema_version": 1, "model": "opencv_pinhole",
            "K": [[600.0,0,960],[0,600,540],[0,0,1]], "image_size": [1920,1080], "distortion": [0.0,0,0,0,0],
            "metadata": ["status": "measured_research", "rms_px": 0.1, "views": 20, "warnings": [String](),
                         "capture_profile": try object(profile), "physical_accuracy_validated": false, "synthetic_fixture": true]]
        state["state"] = "complete"; state["calibration"] = measured
        try json(state).write(to: root.appendingPathComponent(calibration.id+".json"))
        var scan = CaptureCreation(mode: "scan", markerCount: 6, profile: profile,
            physical: false, squareMM: nil, calibrationID: calibration.id)
        var plan = DentalPlan.vidaMUA9; plan.useExample(count: 6); scan.dentalPlan = plan
        scan.trialIntrinsicsRequired = true // Must never redirect a 3B record.
        _ = try await client.send("sessions", value: scan)
        let wrongHardware = try hardware(2208), bytes = try image()
        let receipt = try await client.frame("sessions/\(scan.id)/frames", id: captureID(), image: bytes,
            profile: profile, timestamp: 1, intrinsics: wrongHardware)
        XCTAssertEqual(receipt["marker_ids"] as? [Int], [0])
        XCTAssertEqual(receipt["accepted"] as? Bool, false, "Only one target is visible; 3B capture still requires at least two")
        let detail = try diagnostics(receipt)
        XCTAssertEqual(detail["detector_mode"] as? String, "calibrated_pose_3d")
        XCTAssertEqual(detail["preview_only"] as? Bool, false)
        XCTAssertEqual(receipt["frame_intrinsics"] as? NSDictionary, wrongHardware.nativeDictionary() as NSDictionary)
        let persisted = try await client.request("sessions/\(scan.id)")
        XCTAssertEqual(persisted["camera"] as? NSDictionary, measured as NSDictionary)
        XCTAssertEqual(persisted["count"] as? Int, 0)
        XCTAssertNil(persisted["result"])

        // Corrupt/missing saved calibration must not fall through to either
        // supplied hardware K or the legacy guessed-focal detector.
        var corrupted = persisted; corrupted.removeValue(forKey: "camera")
        try json(corrupted).write(to: root.appendingPathComponent(scan.id+".json"))
        do {
            _ = try await client.frame("sessions/\(scan.id)/frames", id: captureID(), image: bytes,
                profile: profile, timestamp: 2, intrinsics: hardware())
            XCTFail("Missing metric calibration fell back to hardware or guessed K")
        } catch {
            XCTAssertEqual(error.localizedDescription,
                "3B kaydının ölçülmüş kamera kalibrasyonu eksik. Kayıt korunuyor; yeni fiziksel kalibrasyonla başlayın.")
        }
        let afterCorruption = try await client.request("sessions/\(scan.id)")
        XCTAssertEqual(try json(afterCorruption), try json(corrupted))
    }
}
