import AVFoundation
import CoreMedia
import Foundation
import simd
import XCTest
@testable import DentalArchCapture

final class CameraPreviewAndIntrinsicsTests: XCTestCase {
    private func data(_ matrix: simd_float3x3) -> Data {
        var value = matrix
        return withUnsafeBytes(of: &value) { Data($0) }
    }
    private var matrix: simd_float3x3 {
        simd_float3x3(columns: (SIMD3<Float>(540,0,0), SIMD3<Float>(0,542,0), SIMD3<Float>(958,539,1)))
    }
    private func metadata(_ matrix: simd_float3x3) -> FrameCameraIntrinsics? {
        FrameCameraIntrinsics.fromHardwareAttachment(data(matrix), width: 1920, height: 1080)
    }
    private var profile: CaptureProfile { CaptureProfile(device: "physical", lensPosition: 0.42, width: 1920, height: 1080, format: "test") }

    func testPaddedColumnMajorHardwareMatrixKeepsPrincipalPointAndOutputGeometry() throws {
        let value = try XCTUnwrap(metadata(matrix))
        XCTAssertEqual(value.fx, 540); XCTAssertEqual(value.fy, 542)
        XCTAssertEqual(value.cx, 958); XCTAssertEqual(value.cy, 539)
        XCTAssertEqual(value.source, "avfoundation_sample_buffer")
        XCTAssertEqual(value.nativeDictionary()["K"] as? [[Double]], [[540,0,958],[0,542,539],[0,0,1]])
        XCTAssertTrue(value.matches(profile))
        let other = CaptureProfile(device: "physical", lensPosition: 0.42, width: 3840, height: 2160, format: "test")
        XCTAssertFalse(value.matches(other))
    }

    func testAbsentShortOversizeAndWrongResolutionMetadataNeverCreatesGuessedIntrinsics() {
        XCTAssertNil(FrameCameraIntrinsics.fromHardwareAttachment(Data(), width: 1920, height: 1080))
        XCTAssertNil(FrameCameraIntrinsics.fromHardwareAttachment(Data(data(matrix).dropLast()), width: 1920, height: 1080))
        XCTAssertNil(FrameCameraIntrinsics.fromHardwareAttachment(data(matrix) + Data([0]), width: 1920, height: 1080))
        XCTAssertNil(FrameCameraIntrinsics.fromHardwareAttachment(data(matrix), width: 3840, height: 2160))
        XCTAssertNil(FrameCameraIntrinsics.fromHardwareAttachment(data(matrix), width: 1080, height: 1920))
    }

    func testInvalidFocalLengthNonfiniteAndSkewedMatricesAreRejected() {
        var bad = matrix; bad.columns.0.x = 0; XCTAssertNil(metadata(bad))
        bad = matrix; bad.columns.1.y = -1; XCTAssertNil(metadata(bad))
        bad = matrix; bad.columns.2.x = .nan; XCTAssertNil(metadata(bad))
        bad = matrix; bad.columns.2.y = .infinity; XCTAssertNil(metadata(bad))
        bad = matrix; bad.columns.1.x = 2; XCTAssertNil(metadata(bad))
        bad = matrix; bad.columns.0.z = 0.1; XCTAssertNil(metadata(bad))
        bad = matrix; bad.columns.2.z = 0; XCTAssertNil(metadata(bad))
        bad = matrix; bad.columns.2.x = 3000; XCTAssertNil(metadata(bad))
    }

    func testIntrinsicCodableValidatesSourceAndDimensionsDuringDecode() throws {
        let value = try XCTUnwrap(metadata(matrix))
        let encoded = try JSONEncoder().encode(value)
        XCTAssertEqual(try JSONDecoder().decode(FrameCameraIntrinsics.self, from: encoded), value)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        object["source"] = "guessed_focal_length"
        XCTAssertThrowsError(try JSONDecoder().decode(FrameCameraIntrinsics.self, from: JSONSerialization.data(withJSONObject: object)))
        object["source"] = FrameCameraIntrinsics.hardwareSource; object["width"] = 3840
        XCTAssertThrowsError(try JSONDecoder().decode(FrameCameraIntrinsics.self, from: JSONSerialization.data(withJSONObject: object)))
        object["width"] = 1920; object["fy"] = 0
        XCTAssertThrowsError(try JSONDecoder().decode(FrameCameraIntrinsics.self, from: JSONSerialization.data(withJSONObject: object)))
    }

    func testSampleBufferAttachmentIsReadFromTheSpecificFrameNotGlobalLastK() throws {
        var pixels: CVPixelBuffer?
        XCTAssertEqual(CVPixelBufferCreate(kCFAllocatorDefault, 1920, 1080, kCVPixelFormatType_32BGRA, nil, &pixels), kCVReturnSuccess)
        let image = try XCTUnwrap(pixels)
        var format: CMVideoFormatDescription?
        XCTAssertEqual(CMVideoFormatDescriptionCreateForImageBuffer(allocator: kCFAllocatorDefault,
            imageBuffer: image, formatDescriptionOut: &format), noErr)
        var timing = CMSampleTimingInfo(duration: .invalid, presentationTimeStamp: CMTime(value: 1, timescale: 30), decodeTimeStamp: .invalid)
        var sample: CMSampleBuffer?
        XCTAssertEqual(CMSampleBufferCreateReadyWithImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: image,
            formatDescription: try XCTUnwrap(format), sampleTiming: &timing, sampleBufferOut: &sample), noErr)
        let buffer = try XCTUnwrap(sample)
        XCTAssertNil(FrameCameraIntrinsics.read(from: buffer, width: 1920, height: 1080))
        CMSetAttachment(buffer, key: kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix,
                        value: data(matrix) as CFData, attachmentMode: kCMAttachmentMode_ShouldNotPropagate)
        XCTAssertEqual(FrameCameraIntrinsics.read(from: buffer, width: 1920, height: 1080)?.fx, 540)
        XCTAssertNil(FrameCameraIntrinsics.read(from: buffer, width: 3840, height: 2160))
        var next = matrix; next.columns.0.x = 701
        CMSetAttachment(buffer, key: kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix,
                        value: data(next) as CFData, attachmentMode: kCMAttachmentMode_ShouldNotPropagate)
        XCTAssertEqual(FrameCameraIntrinsics.read(from: buffer, width: 1920, height: 1080)?.fx, 701)
        CMSetAttachment(buffer, key: kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix,
                        value: "bad" as CFString, attachmentMode: kCMAttachmentMode_ShouldNotPropagate)
        XCTAssertNil(FrameCameraIntrinsics.read(from: buffer, width: 1920, height: 1080))
    }

    func testPreviewNeedsThreeFreshFramesButDoesNotRequireAnArtificialFocusLock() {
        var check = CameraPreviewCheck()
        XCTAssertFalse(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: 1))
        XCTAssertFalse(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: 2))
        XCTAssertTrue(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: 3))
        XCTAssertEqual(check.lastIssue, .ready)
    }

    func testDuplicateTimestampAndWrongResolutionResetPreviewReadiness() {
        var check = CameraPreviewCheck()
        _ = check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: 1)
        XCTAssertFalse(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: 1))
        XCTAssertEqual(check.lastIssue, .invalidTimestamp)
        XCTAssertFalse(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1280, height: 720, timestamp: 2))
        XCTAssertEqual(check.lastIssue, .resolution)
        for time in [3.0,4.0] {
            XCTAssertFalse(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: time))
        }
        XCTAssertTrue(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: 5))
    }

    func testInterruptedStoppedOrNoncontinuousPreviewCannotBecomeReady() {
        var check = CameraPreviewCheck()
        XCTAssertFalse(check.observe(running: false, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: 1))
        XCTAssertEqual(check.lastIssue, .sessionStopped)
        XCTAssertFalse(check.observe(running: true, interrupted: true, continuousFocus: true, width: 1920, height: 1080, timestamp: 2))
        XCTAssertEqual(check.lastIssue, .sessionInterrupted)
        XCTAssertFalse(check.observe(running: true, interrupted: false, continuousFocus: false, width: 1920, height: 1080, timestamp: 3))
        XCTAssertEqual(check.lastIssue, .focusMoving)
        XCTAssertFalse(check.observe(running: true, interrupted: false, continuousFocus: true, width: 1920, height: 1080, timestamp: .nan))
        XCTAssertEqual(check.lastIssue, .invalidTimestamp)
    }

    func testOpticsReadbackNotificationsAreBoundedToFivePerSecond() {
        var gate = CameraOpticsPublicationGate()
        XCTAssertFalse(gate.shouldPublish(now: .nan)); XCTAssertFalse(gate.shouldPublish(now: -1))
        XCTAssertTrue(gate.shouldPublish(now: 10))
        for time in [10.01, 10.04, 10.1, 10.19] { XCTAssertFalse(gate.shouldPublish(now: time)) }
        XCTAssertTrue(gate.shouldPublish(now: 10.21))
        XCTAssertFalse(gate.shouldPublish(now: 10.22))
    }

    func testLegacyCameraWrapperPreservesImageProfileTimestampWithoutInventedK() throws {
        let camera = LegacyCamera(profile: profile)
        var captured: Result<CapturedCameraFrame, Error>?
        camera.captureFrame(compactTrial: true) { captured = $0 }
        let frame = try XCTUnwrap(captured).get()
        XCTAssertEqual(frame.image, Data([1,2,3])); XCTAssertEqual(frame.profile, profile)
        XCTAssertEqual(frame.timestamp, 7.25); XCTAssertNil(frame.intrinsics)
        XCTAssertTrue(camera.compactRequested)
    }

    func testLegacyCameraCannotPretendItSupportsContinuousPreview() throws {
        let camera = LegacyCamera(profile: profile)
        var result: Result<Void, Error>?
        camera.startPreview { result = $0 }
        XCTAssertThrowsError(try XCTUnwrap(result).get())
        XCTAssertFalse(camera.started)
    }
}

private final class LegacyCamera: CameraControlling {
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    let profile: CaptureProfile
    var compactRequested = false
    var started = false
    init(profile: CaptureProfile) { self.profile = profile }
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) {
        started = true; completion(.success(profile))
    }
    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        compactRequested = compactTrial; completion(.success((Data([1,2,3]), profile, 7.25)))
    }
    func stop() {}
}
