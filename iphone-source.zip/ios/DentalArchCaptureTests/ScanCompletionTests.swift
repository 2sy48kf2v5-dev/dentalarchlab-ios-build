import AVFoundation
import UIKit
import XCTest
@testable import DentalArchCapture

private final class TrialCamera: CameraControlling {
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    let image: Data
    let profile = CaptureProfile(device: "test-wide", lensPosition: 0.55, width: 1920, height: 1080, format: "fixture")
    var captures = 0
    init(image: Data) { self.image = image }
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) {
        completion(.success(profile))
    }
    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        captures += 1; completion(.success((image, profile, Double(captures))))
    }
    func captureFrame(compactTrial: Bool, completion: @escaping (Result<CapturedCameraFrame, Error>) -> Void) {
        capture(compactTrial: compactTrial) { result in
            completion(result.flatMap { image, profile, timestamp in Result {
                // Synthetic CAD fixture K; not hardware validation.
                CapturedCameraFrame(image: image, profile: profile, timestamp: timestamp,
                    intrinsics: try FrameCameraIntrinsics(width: 1920, height: 1080, fx: 2208, fy: 2208, cx: 960, cy: 540))
            } })
        }
    }
    func stop() {}
}

@MainActor final class ScanCompletionTests: XCTestCase {
    private func feedback(_ counts: [Int], preview: Bool = false, usable: Bool = true, target: Int = 1) -> LiveFeedback {
        LiveFeedback(sampleID: captureID(), preview: preview, usable: usable, markers: [],
            views: Dictionary(uniqueKeysWithValues: counts.enumerated().map { ($0.offset, $0.element) }),
            frames: target == 1 ? 1 : 24, targetFrames: target == 1 ? 1 : 24, targetViews: target,
            width: 1920, height: 1080, message: "test")
    }
    private func observation(_ id: Int, shift: Double = 0) -> [String: Any] {
        let x = 100.0 + Double(id)*180 + shift
        return ["marker": id, "corners": [[x,100], [x+70,100], [x+70,170], [x,170]], "min_side_px": 70.0]
    }
    private func envelope(_ ids: [Int]) -> [String: Any] {
        ["mode": "trial", "state": "complete", "marker_count": 6,
         "trial_summary": ["expected_count": 6, "recognized_ids": ids, "accepted_frames": 1,
             "metric": "identity_only_no_3d", "physical_accuracy_um": NSNull()]]
    }
    private func pixels() throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "vertical_arch", withExtension: "dat"))
        let data = try Data(contentsOf: url)
        XCTAssertEqual(PreviewCommit.digest(data), "4ef275ae3632262554517fe4ea93090a4a26ec633f39043658cd3bda71b4a730",
                       "The reviewed render must retain its privacy-sanitized PNG bytes")
        return data
    }
    func testIdentityCoverageCompletesOnceBut3DStillNeedsMultipleViews() {
        XCTAssertTrue(feedback([1,1,1,1,1,1]).coverageReached)
        XCTAssertFalse(feedback([1,1,1,1,1,0]).coverageReached)
        XCTAssertEqual(feedback([1,1,0,0,0,0]).pendingIDs, [2,3,4,5])
        XCTAssertFalse(feedback([8,8,8,8,8,7], target: 8).coverageReached)
        XCTAssertTrue(feedback([8,8,8,8,8,8], target: 8).coverageReached)
    }
    func testFlagCueNeverRepeatsCompletedIDsAcrossNewFramesOrPreviews() {
        var cue = FlagConfirmationCue()
        XCTAssertEqual(cue.consume(feedback([1,1,0,0], preview: true)), [])
        XCTAssertEqual(cue.consume(feedback([1,1,0,0], usable: false)), [])
        XCTAssertEqual(cue.consume(feedback([1,1,0,0])), [0,1])
        XCTAssertEqual(cue.consume(feedback([1,1,0,0])), [])
        XCTAssertEqual(cue.consume(feedback([1,1,1,1])), [2,3])
        XCTAssertEqual(cue.consume(feedback([1,1,1,1])), [])
    }
    func testRestoredCueDoesNotReplayPreviousSessionProgress() {
        var cue = FlagConfirmationCue(); cue.restore([0,1])
        XCTAssertEqual(cue.consume(feedback([1,1,1,0])), [2])
        cue = FlagConfirmationCue()
        XCTAssertEqual(cue.consume(feedback([1,1,0,0])), [0,1])
    }
    func test3DCueWaitsForRequiredViewsAndNeverSuppressesGeometry() {
        var cue = FlagConfirmationCue()
        XCTAssertEqual(cue.consume(feedback([7,7,7,7], target: 8)), [])
        XCTAssertEqual(cue.consume(feedback([8,7,8,7], target: 8)), [0,2])
        XCTAssertEqual(cue.consume(feedback([9,8,9,8], target: 8)), [1,3])
    }
    func testTrialRejectsAlreadySeenIDsEvenWhenMovedButAcceptsDisjointNewID() throws {
        let history: [[String: Any]] = [["observations": [observation(0), observation(1)]]]
        let sharp: [String: Any] = ["blur_laplacian": 100.0]
        XCTAssertFalse(try OfflineEngine.assess([observation(0, shift: 30), observation(1, shift: 30)], quality: sharp, history: history, markerCount: 6, identityOnly: true).0)
        XCTAssertTrue(try OfflineEngine.assess([observation(2)], quality: sharp, history: history, markerCount: 6, identityOnly: true).0)
        XCTAssertTrue(try OfflineEngine.assess([observation(0, shift: 30), observation(1, shift: 30)], quality: sharp, history: history, markerCount: 6).0)
        XCTAssertFalse(try OfflineEngine.assess([observation(2), observation(3)], quality: sharp, history: history, markerCount: 6).0)
        XCTAssertFalse(try OfflineEngine.assess([observation(2)], quality: ["blur_laplacian": 2.0], history: history, markerCount: 6, identityOnly: true).0)
    }
    func testTrialResultsShowMissingIDsWithoutInventing3D() throws {
        let result = try ResultSnapshot.decode(envelope([0,2,5]))
        XCTAssertEqual(result.trial?.recognizedIDs, [0,2,5])
        XCTAssertEqual(result.trial?.missingIDs, [1,3,4])
        XCTAssertTrue(result.landmarks.isEmpty); XCTAssertNil(result.rmsPX); XCTAssertFalse(result.hasMUA)
        XCTAssertThrowsError(try ResultSnapshot.decode(envelope([0,0])))
        XCTAssertThrowsError(try ResultSnapshot.decode(envelope([6])))
    }
    func testLegacyTrialResultRestoresUniqueIdentities() throws {
        let result = try ResultSnapshot.decode(["mode": "trial", "state": "complete", "marker_count": 6,
            "accepted": [["observations": [observation(0), observation(1)]], ["observations": [observation(0), observation(2)]]]])
        XCTAssertEqual(result.trial?.recognizedIDs, [0,1,2])
        XCTAssertEqual(result.trial?.acceptedFrames, 2)
    }
    func testNativeVerticalPixelsCommitOnlyOnceAndProduceIdentitySummary() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: folder) }
        let engine = OfflineEngine(root: folder), camera = TrialCamera(image: try pixels())
        var creation = CaptureCreation(mode: "trial", markerCount: 6, profile: camera.profile, physical: false, squareMM: nil, calibrationID: nil)
        var plan = DentalPlan(); plan.useExample(count: 6); creation.dentalPlan = plan
        _ = try await engine.request("sessions", body: JSONEncoder().encode(creation))
        let path = "sessions/\(creation.id)"
        let frame = FrameUpload(id: captureID(), image: camera.image.base64EncodedString(), profile: camera.profile, timestamp: 1)
        let first = try await engine.request(path + "/frames", body: JSONEncoder().encode(frame))
        XCTAssertEqual(first["accepted"] as? Bool, true)
        let feedback = try LiveFeedback.decode(first, session: creation.id, sample: frame.id, count: 6)
        XCTAssertEqual(feedback.completedIDs, Array(0..<6)); XCTAssertTrue(feedback.coverageReached)
        let replay = try await engine.request(path + "/frames", body: JSONEncoder().encode(frame))
        XCTAssertEqual(replay["count"] as? Int, 1)
        let next = FrameUpload(id: captureID(), image: camera.image.base64EncodedString(), profile: camera.profile, timestamp: 2)
        let duplicate = try await engine.request(path + "/frames", body: JSONEncoder().encode(next))
        XCTAssertEqual(duplicate["accepted"] as? Bool, false); XCTAssertEqual(duplicate["count"] as? Int, 1)
        let completed = try await engine.request(path + "/process", body: Data("{}".utf8))
        let result = try ResultSnapshot.decode(completed)
        XCTAssertEqual(result.trial?.recognizedIDs, Array(0..<6)); XCTAssertTrue(result.landmarks.isEmpty)
        XCTAssertNil(completed["result"])
    }
    func testAutomaticCaptureActuallyStopsAndOpensResultWithoutCalculateTap() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        // Match CameraEngine's trial upload encoding; direct-engine test above
        // independently covers the byte-preserved PNG fixture.
        let jpeg = try XCTUnwrap(UIImage(data: pixels())?.jpegData(compressionQuality: 0.94))
        let camera = TrialCamera(image: jpeg)
        let model = CaptureModel(repository: CaptureRepository(root: folder), camera: camera)
        defer { model.stopCamera(); try? FileManager.default.removeItem(at: folder) }
        model.plan.useExample(count: 6); model.soundEnabled = false; model.openCamera()
        for _ in 0..<100 where !model.ready { try await Task.sleep(nanoseconds: 20_000_000) }
        XCTAssertTrue(model.ready)
        model.startAutomatic()
        for _ in 0..<1000 {
            if model.resultSnapshot != nil && !model.computing && !model.autoRunning { break }
            try await Task.sleep(nanoseconds: 20_000_000)
        }
        XCTAssertEqual(model.current?.state, "complete", model.status)
        XCTAssertEqual(model.resultSnapshot?.trial?.recognizedIDs, Array(0..<6), model.status)
        XCTAssertEqual(camera.captures, 1); XCTAssertFalse(model.autoRunning); XCTAssertFalse(model.ready)
        XCTAssertEqual(model.pendingCount, 0); XCTAssertEqual(model.current?.acceptedCount, 1)
        XCTAssertEqual(model.exportFiles.count, 1)
        XCTAssertEqual(model.exportFiles.first?.pathExtension, "json")
        XCTAssertFalse(model.exportFiles.contains { ["csv", "ply"].contains($0.pathExtension) })
        let saved = try model.repository.get(try XCTUnwrap(model.currentID))
        model.newSession(); model.select(saved)
        XCTAssertEqual(model.resultSnapshot?.trial?.recognizedIDs, Array(0..<6))
    }
}
