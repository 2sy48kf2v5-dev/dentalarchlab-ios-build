import XCTest
@testable import DentalArchCapture

final class SelectedFeedbackTests: XCTestCase {
    private func receipt(expected: [Int] = [0, 3, 4, 5]) -> [String: Any] {
        ["id": "frame", "message": "Model", "feedback": [
            "schema": 1, "session_id": "session", "sample_id": "frame",
            "coordinates": "sensor_normalized", "metric": "accepted_image_coverage_not_accuracy",
            "physical_accuracy_um": NSNull(), "preview": false, "sample_usable": true,
            "image_size": [1920, 1080], "frames": 12, "target_frames": 12, "target_views": 4,
            "expected_marker_ids": expected, "views": ["0": 0, "3": 4, "4": 5, "5": 4],
            "markers": [["id": 5, "points": [[0.1, 0.2], [0.2, 0.2], [0.1, 0.3], [0.15, 0.25]]]],
            "diagnostics": ["unselected_marker_ids": [2]]
        ]]
    }
    private func decode(_ raw: [String: Any]) throws -> LiveFeedback {
        try LiveFeedback.decode(raw, session: "session", sample: "frame", count: 4, markerIDs: [5, 0, 4, 3])
    }
    func testSelectedIDsDriveCoverageAndGreenConfirmationWithoutRenumbering() throws {
        let value = try decode(receipt())
        XCTAssertEqual(value.completedIDs, [3, 4, 5]); XCTAssertEqual(value.pendingIDs, [0])
        XCTAssertEqual(value.markers.map(\.id), [5]); XCTAssertEqual(value.unselectedIDs, [2])
        XCTAssertFalse(value.coverageReached)
        var cue = FlagConfirmationCue()
        XCTAssertEqual(cue.consume(value), [3, 4, 5]); XCTAssertEqual(cue.consume(value), [])
    }
    func testAnotherSelectionOrMissingBindingCannotPaintSelectedFlagsGreen() {
        XCTAssertThrowsError(try decode(receipt(expected: [0, 1, 2, 3])))
        var raw = receipt(); var feedback = raw["feedback"] as! [String: Any]
        feedback.removeValue(forKey: "expected_marker_ids"); raw["feedback"] = feedback
        XCTAssertThrowsError(try decode(raw))
    }
    func testWrongViewKeysAndUnselectedObservationAreRejected() {
        var raw = receipt(); var feedback = raw["feedback"] as! [String: Any]
        feedback["views"] = ["0": 0, "1": 4, "2": 5, "3": 4]; raw["feedback"] = feedback
        XCTAssertThrowsError(try decode(raw))
        raw = receipt(); feedback = raw["feedback"] as! [String: Any]
        var marker = (feedback["markers"] as! [[String: Any]])[0]; marker["id"] = 2
        feedback["markers"] = [marker]; raw["feedback"] = feedback
        XCTAssertThrowsError(try decode(raw))
    }
    func testTrialSummaryReportsActualMissingIDAndRejectsAnotherSelection() throws {
        var raw: [String: Any] = ["marker_count": 4, "marker_ids": [0, 3, 4, 5],
            "trial_summary": ["expected_count": 4, "expected_marker_ids": [0, 3, 4, 5],
                "metric": "identity_only_no_3d", "physical_accuracy_um": NSNull(),
                "recognized_ids": [3, 4, 5], "accepted_frames": 3]]
        let result = try TrialSummary.decode(raw)
        XCTAssertEqual(result.recognizedIDs, [3, 4, 5]); XCTAssertEqual(result.missingIDs, [0])
        raw["marker_ids"] = [0, 1, 2, 3]
        XCTAssertThrowsError(try TrialSummary.decode(raw))
    }
    func testLegacyTrialStillUsesItsOriginalPrefixDictionary() throws {
        let raw: [String: Any] = ["marker_count": 4,
            "accepted": [["observations": [["marker": 1], ["marker": 3]]]]]
        XCTAssertEqual(try TrialSummary.decode(raw).missingIDs, [0, 2])
    }
}
