import CoreImage
import CoreVideo
import Foundation
import ImageIO
import UniformTypeIdentifiers
import XCTest
@testable import DentalArchCapture

final class CameraFrameProcessingTests: XCTestCase {
    private func pixels(width: Int = 19, height: Int = 13) throws -> CVPixelBuffer {
        var buffer: CVPixelBuffer?
        XCTAssertEqual(CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA,
                                          nil, &buffer), kCVReturnSuccess)
        let image = try XCTUnwrap(buffer)
        XCTAssertEqual(CVPixelBufferLockBaseAddress(image, []), kCVReturnSuccess)
        defer { CVPixelBufferUnlockBaseAddress(image, []) }
        let base = try XCTUnwrap(CVPixelBufferGetBaseAddress(image)).assumingMemoryBound(to: UInt8.self)
        let stride = CVPixelBufferGetBytesPerRow(image)
        for row in 0..<height {
            for column in 0..<width {
                let index = row * stride + column * 4
                base[index] = UInt8((column * 13 + row * 5) % 256)
                base[index + 1] = UInt8((column * 7 + row * 11) % 256)
                base[index + 2] = UInt8((column * 3 + row * 17) % 256)
                base[index + 3] = 255
            }
        }
        return image
    }
    private func logicalPixels(_ pixels: CVPixelBuffer) throws -> Data {
        XCTAssertEqual(CVPixelBufferLockBaseAddress(pixels, .readOnly), kCVReturnSuccess)
        defer { CVPixelBufferUnlockBaseAddress(pixels, .readOnly) }
        let base = try XCTUnwrap(CVPixelBufferGetBaseAddress(pixels))
        let stride = CVPixelBufferGetBytesPerRow(pixels)
        var result = Data()
        for row in 0..<CVPixelBufferGetHeight(pixels) {
            result.append(Data(bytes: base.advanced(by: row * stride), count: CVPixelBufferGetWidth(pixels) * 4))
        }
        return result
    }
    private func rgba(_ image: CGImage) throws -> Data {
        var output = [UInt8](repeating: 0, count: image.width * image.height * 4)
        try output.withUnsafeMutableBytes { bytes in
            let context = try XCTUnwrap(CGContext(data: bytes.baseAddress, width: image.width, height: image.height,
                bitsPerComponent: 8, bytesPerRow: image.width * 4, space: CGColorSpaceCreateDeviceRGB(),
                bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue))
            context.draw(image, in: CGRect(x: 0, y: 0, width: image.width, height: image.height))
        }
        return Data(output)
    }

    func testOwnedSnapshotPreservesEveryPixelWhenTheCapturePoolIsReused() throws {
        let source = try pixels()
        let expected = try logicalPixels(source)
        let owned = try CameraFrameEncoder.copyPixels(source)
        XCTAssertEqual(CVPixelBufferGetWidth(owned), 19)
        XCTAssertEqual(CVPixelBufferGetHeight(owned), 13)
        XCTAssertEqual(try logicalPixels(owned), expected)
        XCTAssertEqual(CVPixelBufferLockBaseAddress(source, []), kCVReturnSuccess)
        let sourceBase = try XCTUnwrap(CVPixelBufferGetBaseAddress(source))
        sourceBase.initializeMemory(as: UInt8.self, repeating: 0,
                                   count: CVPixelBufferGetBytesPerRow(source) * CVPixelBufferGetHeight(source))
        CVPixelBufferUnlockBaseAddress(source, [])
        XCTAssertNotEqual(try logicalPixels(source), expected)
        XCTAssertEqual(try logicalPixels(owned), expected, "Encoding must not depend on camera-pool storage after the delegate returns")
    }

    func testMeasurementPNGKeepsDimensionsAndDecodedPixelsOfTheExistingPipeline() throws {
        let source = try pixels()
        // Reference the previous CI rendering path before the queue split.
        let ci = CIImage(cvPixelBuffer: source)
        let reference = try XCTUnwrap(CIContext().createCGImage(ci, from: ci.extent))
        let owned = try CameraFrameEncoder.copyPixels(source)
        let encoded = try CameraFrameEncoder().encode(owned, compactTrial: false)
        XCTAssertTrue(encoded.starts(with: [137, 80, 78, 71, 13, 10, 26, 10]))
        let decodedSource = try XCTUnwrap(CGImageSourceCreateWithData(encoded as CFData, nil))
        XCTAssertEqual(CGImageSourceGetType(decodedSource) as String?, UTType.png.identifier)
        let decoded = try XCTUnwrap(CGImageSourceCreateImageAtIndex(decodedSource, 0, nil))
        XCTAssertEqual(decoded.width, reference.width)
        XCTAssertEqual(decoded.height, reference.height)
        XCTAssertEqual(try rgba(decoded), try rgba(reference), "Measurement frames stay lossless and uncropped")
    }

    func testOnlyExplicitIdentityTrialUsesJPEGAndNeverResizes() throws {
        let owned = try CameraFrameEncoder.copyPixels(pixels(width: 320, height: 180))
        let encoded = try CameraFrameEncoder().encode(owned, compactTrial: true)
        XCTAssertTrue(encoded.starts(with: [0xff, 0xd8]))
        let source = try XCTUnwrap(CGImageSourceCreateWithData(encoded as CFData, nil))
        XCTAssertEqual(CGImageSourceGetType(source) as String?, UTType.jpeg.identifier)
        let decoded = try XCTUnwrap(CGImageSourceCreateImageAtIndex(source, 0, nil))
        XCTAssertEqual(decoded.width, 320)
        XCTAssertEqual(decoded.height, 180)
    }

    func testSnapshotRefusesUnexpectedOversizedFramesInsteadOfResizingThem() throws {
        let source = try pixels(width: 1921, height: 1)
        XCTAssertThrowsError(try CameraFrameEncoder.copyPixels(source))
    }

    func testCancellationKeepsWorkerBoundedUntilTheOldJobReallyFinishes() {
        var gate = CameraFrameWorkGate()
        let old = CameraFrameTicket(generation: 1, request: 4)
        let restarted = CameraFrameTicket(generation: 2, request: 5)
        XCTAssertTrue(gate.begin(old))
        XCTAssertFalse(gate.begin(restarted))
        gate.cancel()
        XCTAssertFalse(gate.isIdle)
        XCTAssertFalse(gate.begin(restarted), "Stopping must not accumulate another full-resolution job")
        XCTAssertFalse(gate.finish(restarted), "An unrelated completion must not free the active worker slot")
        XCTAssertFalse(gate.isIdle)
        XCTAssertFalse(gate.finish(old), "Cancelled bytes must never be delivered to a new camera run")
        XCTAssertTrue(gate.isIdle)
        XCTAssertTrue(gate.begin(restarted))
        XCTAssertTrue(gate.finish(restarted))
        XCTAssertFalse(gate.finish(restarted), "Completion is delivered at most once")
    }

    func testFrameDeliveryRateIsMeasuredAndReportsAtMostOncePerSecond() throws {
        var meter = CameraPerformanceMeter()
        var reports: [CameraPerformance] = []
        for frame in 0...90 {
            let time = Double(frame) / 30
            if let report = meter.observe(timestamp: 10 + time, now: 100 + time) { reports.append(report) }
        }
        XCTAssertEqual(reports.count, 3)
        for report in reports {
            XCTAssertEqual(try XCTUnwrap(report.framesPerSecond), 30, accuracy: 0.0001)
            XCTAssertEqual(report.droppedFrames, 0)
            XCTAssertNil(report.encodingMilliseconds)
        }
    }

    func testDropsAndEncodingTimeDoNotPretendTheThirtyFPSTargetWasAchieved() throws {
        var meter = CameraPerformanceMeter()
        XCTAssertNil(meter.observe(timestamp: 0, now: 0))
        meter.recordEncoding(seconds: 0.125)
        var last: CameraPerformance?
        for frame in 1...15 {
            meter.recordDrop()
            last = meter.observe(timestamp: Double(frame) / 15, now: Double(frame) / 15) ?? last
        }
        let report = try XCTUnwrap(last)
        XCTAssertEqual(CameraPerformance.targetFramesPerSecond, 30)
        XCTAssertEqual(try XCTUnwrap(report.framesPerSecond), 15, accuracy: 0.0001)
        XCTAssertEqual(report.droppedFrames, 15)
        XCTAssertEqual(try XCTUnwrap(report.encodingMilliseconds), 125, accuracy: 0.0001)
    }

    func testInvalidDuplicateAndResetTimestampsCannotInventFPS() throws {
        var meter = CameraPerformanceMeter()
        XCTAssertNil(meter.observe(timestamp: 10, now: 0))
        XCTAssertNil(meter.observe(timestamp: .nan, now: 0.5))
        XCTAssertNil(meter.observe(timestamp: 11, now: .infinity))
        let duplicate = try XCTUnwrap(meter.observe(timestamp: 10, now: 1))
        XCTAssertNil(duplicate.framesPerSecond)
        XCTAssertNil(meter.observe(timestamp: 0, now: 1.5))
        let reset = try XCTUnwrap(meter.observe(timestamp: 0, now: 2))
        XCTAssertNil(reset.framesPerSecond)
        XCTAssertNil(meter.observe(timestamp: 0.5, now: 2.5))
        let recovered = try XCTUnwrap(meter.observe(timestamp: 1, now: 3))
        XCTAssertEqual(try XCTUnwrap(recovered.framesPerSecond), 2, accuracy: 0.0001)
    }

    func testInvalidEncoderDurationsCannotReplaceValidMeasuredTime() throws {
        var meter = CameraPerformanceMeter()
        meter.recordEncoding(seconds: 0.01)
        meter.recordEncoding(seconds: .nan)
        meter.recordEncoding(seconds: -.infinity)
        meter.recordEncoding(seconds: -1)
        meter.recordEncoding(seconds: Double.greatestFiniteMagnitude)
        XCTAssertNil(meter.observe(timestamp: 0, now: 0))
        let report = try XCTUnwrap(meter.observe(timestamp: 1, now: 1))
        XCTAssertEqual(try XCTUnwrap(report.encodingMilliseconds), 10, accuracy: 0.0001)
    }
}
