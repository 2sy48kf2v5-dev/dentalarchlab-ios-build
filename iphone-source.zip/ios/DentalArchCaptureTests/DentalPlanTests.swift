import XCTest
@testable import DentalArchCapture

final class DentalPlanTests: XCTestCase {
    func testFDIQuadrantsAndUniqueAssignments() throws {
        var p = DentalPlan()
        XCTAssertThrowsError(try p.validate(count: 6))
        p.useExample(count: 6)
        XCTAssertNoThrow(try p.validate(count: 6))
        p.assign(46, to: 2)
        XCTAssertNil(p.tooth(for: 0))
        XCTAssertEqual(p.tooth(for: 2), 46)
        XCTAssertThrowsError(try p.validate(count: 6))
        p.reset(count: 4, arch: "upper"); p.useExample(count: 4)
        XCTAssertEqual(p.assignments.compactMap(\.fdi), [16, 13, 23, 26])
        XCTAssertNoThrow(try p.validate(count: 4))
        p.assign(46, to: 0)
        XCTAssertEqual(p.tooth(for: 0), 16)
    }
    func testPlanRoundtripAndLegacyCreationDecode() throws {
        var p = DentalPlan(); p.useExample(count: 6)
        let encoded = try JSONEncoder().encode(p)
        XCTAssertEqual(try JSONDecoder().decode(DentalPlan.self, from: encoded), p)
        let json = try JSONSerialization.jsonObject(with: encoded) as! [String: Any]
        XCTAssertEqual((json["assignments"] as! [[String: Any]])[0]["component_code"] as? String, "MG-MUASB9")
        let profile = CaptureProfile(device: "test", lensPosition: 0.55, width: 1920, height: 1080, format: "test")
        let old = CaptureCreation(mode: "trial", markerCount: 6, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        XCTAssertNil(try JSONDecoder().decode(CaptureCreation.self, from: JSONEncoder().encode(old)).dentalPlan)
    }
    func testSoundOnlyForNewCommittedAcceptance() {
        var cue = AcceptanceCue()
        XCTAssertFalse(cue.consume(sample: "a", preview: true, usable: true))
        XCTAssertFalse(cue.consume(sample: "a", preview: false, usable: false))
        XCTAssertTrue(cue.consume(sample: "a", preview: false, usable: true))
        XCTAssertFalse(cue.consume(sample: "a", preview: false, usable: true))
        XCTAssertTrue(cue.consume(sample: "b", preview: false, usable: true))
    }
}
