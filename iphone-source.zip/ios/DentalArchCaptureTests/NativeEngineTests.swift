import XCTest
import UIKit
@testable import DentalArchCapture

final class NativeEngineTests: XCTestCase {
    private func image(checkerboard: Bool) throws -> Data {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        let rendered = UIGraphicsImageRenderer(size: CGSize(width: 1920, height: 1080), format: format).image { context in
            UIColor.white.setFill()
            context.fill(CGRect(x: 0, y: 0, width: 1920, height: 1080))
            if checkerboard {
                UIColor.black.setFill()
                for y in 0..<7 { for x in 0..<10 where (x+y)%2 == 0 {
                    context.fill(CGRect(x: 360+x*100, y: 180+y*100, width: 100, height: 100))
                } }
            }
        }
        return try XCTUnwrap(rendered.pngData())
    }

    func testSyntheticDetectorCalibrationAndFourAndSixFlagGroundTruth() throws {
        let result = try DALNativeEngine.validateSynthetic()
        let evidence = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        let attachment = XCTAttachment(data: evidence, uniformTypeIdentifier: "public.json")
        attachment.name = "native-synthetic-validation.json"
        attachment.lifetime = .keepAlways
        add(attachment)
        print("DAL_NATIVE_VALIDATION_JSON " + (String(data: evidence, encoding: .utf8) ?? "{}"))
        XCTAssertEqual(result["synthetic_only"] as? Bool, true)
        XCTAssertTrue(result["physical_accuracy_um"] is NSNull)
        let tests = try XCTUnwrap(result["tests"] as? [[String: Any]])
        XCTAssertEqual(tests.count, 6)
        for test in tests { XCTAssertEqual(test["passed"] as? Bool, true, "\(test)") }
        XCTAssertEqual(result["passed"] as? Bool, true)
    }

    func testBlankImageCannotBecomeRecognizedFlags() throws {
        let result = try DALNativeEngine.detect(image: image(checkerboard: false), camera: nil, markerCount: 6)
        XCTAssertEqual((result["observations"] as? [Any])?.count, 0)
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, false)
    }

    func testCheckerboardDetectionAndRepeatedViewRejection() throws {
        let data = try image(checkerboard: true)
        let first = try DALNativeEngine.checkBoard(image: data, previousCorners: [])
        XCTAssertEqual(first["accepted"] as? Bool, true)
        XCTAssertEqual(first["reason"] as? String, "accepted")
        XCTAssertEqual(first["detected_count"] as? Int, 54)
        let corners = try XCTUnwrap(first["corners"] as? [[Double]])
        XCTAssertEqual(corners.count, 54)
        let repeatShot = try DALNativeEngine.checkBoard(image: data, previousCorners: [corners])
        XCTAssertEqual(repeatShot["accepted"] as? Bool, false)
        XCTAssertTrue(repeatShot["corners"] is NSNull)
        XCTAssertEqual(repeatShot["detected_count"] as? Int, 54)
        XCTAssertEqual(repeatShot["reason"] as? String, "duplicate")
        XCTAssertEqual((repeatShot["detected_corners"] as? [[Double]])?.count, 54)
    }

    func testCheckerboardOriginReversalCannotInventANewView() throws {
        let data = try image(checkerboard: true)
        let first = try DALNativeEngine.checkBoard(image: data, previousCorners: [])
        let corners = try XCTUnwrap(first["corners"] as? [[Double]])
        let reversed = try DALNativeEngine.checkBoard(image: data, previousCorners: [Array(corners.reversed())])
        XCTAssertEqual(reversed["accepted"] as? Bool, false)
        XCTAssertEqual(reversed["reason"] as? String, "duplicate")
        XCTAssertEqual(reversed["detected_count"] as? Int, 54)
    }

    func testInvalidImageAndCalibrationFailAsErrors() throws {
        XCTAssertThrowsError(try DALNativeEngine.checkBoard(image: Data([1, 2, 3]), previousCorners: []))
        XCTAssertThrowsError(try DALNativeEngine.calibrate(corners: [], width: 1920, height: 1080,
            squareMM: 6, physicalMeasured: false, profile: [:]))
        XCTAssertThrowsError(try DALNativeEngine.detect(image: image(checkerboard: false), camera: ["K": []], markerCount: 6))
    }

    private var profile: [String: Any] { ["pipeline": "ios_avfoundation_v1", "device": "synthetic-test-camera",
        "width": 1920, "height": 1080, "lens_position": 0.55, "format": "fixture", "lens": "wide",
        "focus": "locked", "stabilization": "off", "zoom": 1, "orientation": "sensor_native"] }

    private func projectedBoardViews() -> [[ [Double] ]] {
        (0..<16).map { i in
            let phase = Double(i) * 2 * Double.pi / 16
            let ax = 0.3 * sin(phase), ay = 0.28 * cos(phase)
            let tx = -24 + 30*cos(phase), ty = -15 + 17*sin(phase), tz = 180 + 12*sin(2*phase)
            return (0..<54).map { j in
                let x = Double(j%9)*6, y = Double(j/9)*6
                let rx = cos(ay)*x + sin(ay)*sin(ax)*y
                let ry = cos(ax)*y
                let rz = -sin(ay)*x + cos(ay)*sin(ax)*y
                return [1600*(rx+tx)/(rz+tz)+960, 1585*(ry+ty)/(rz+tz)+540]
            }
        }
    }

    func testScreenCalibrationPreservesProfileAndCannotClaimPhysicalScale() throws {
        let result = try DALNativeEngine.calibrate(corners: projectedBoardViews(), width: 1920, height: 1080,
            squareMM: 6, physicalMeasured: false, profile: profile)
        let metadata = try XCTUnwrap(result["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["status"] as? String, "screen_experimental")
        XCTAssertTrue(metadata["square_mm"] is NSNull)
        XCTAssertEqual(metadata["physical_accuracy_validated"] as? Bool, false)
        XCTAssertEqual((metadata["capture_profile"] as? NSDictionary), profile as NSDictionary)
        XCTAssertLessThan(try XCTUnwrap(metadata["rms_px"] as? Double), 0.01)
    }

    func testPhysicalDeclarationStillRequiresControlledCameraProfile() throws {
        var invalid = profile
        invalid["focus"] = "continuous"
        let result = try DALNativeEngine.calibrate(corners: projectedBoardViews(), width: 1920, height: 1080,
            squareMM: 6, physicalMeasured: true, profile: invalid)
        let metadata = try XCTUnwrap(result["metadata"] as? [String: Any])
        XCTAssertEqual(metadata["status"] as? String, "screen_experimental")
        XCTAssertEqual(metadata["physical_accuracy_validated"] as? Bool, false)
    }
}
