import XCTest
@testable import DentalArchCapture

final class CaptureTests: XCTestCase {
    var directory: URL!
    override func setUpWithError() throws {
        directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    }
    override func tearDownWithError() throws {
        if FileManager.default.fileExists(atPath: directory.path) { try FileManager.default.removeItem(at: directory) }
    }
    func profile() -> CaptureProfile { CaptureProfile(device: "test-wide", lensPosition: 0.55, width: 1920, height: 1080, format: "test") }
    func testProfileUsesEngineFieldNames() throws {
        let json = try JSONSerialization.jsonObject(with: JSONEncoder().encode(profile())) as! [String: Any]
        XCTAssertEqual(json["pipeline"] as? String, "ios_avfoundation_v1")
        XCTAssertEqual(json["focus"] as? String, "locked")
        XCTAssertEqual(json["orientation"] as? String, "sensor_native")
        XCTAssertNotNil(json["lens_position"])
    }
    func testQueueSurvivesRestartAndAcknowledgesOnlyMatchingID() throws {
        let store = CaptureRepository(root: directory)
        let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile(), physical: false, squareMM: nil, calibrationID: nil)
        try store.create(creation)
        try store.append(id: creation.id, image: Data([1,2,3]), timestamp: 1)
        let reopened = CaptureRepository(root: directory)
        let capture = try reopened.get(creation.id)
        XCTAssertEqual(capture.pending.count, 1)
        let frame = capture.pending[0]
        XCTAssertThrowsError(try reopened.acknowledge(session: creation.id, frame: frame.id, receipt: ["id": "wrong"]))
        XCTAssertEqual(try reopened.get(creation.id).pending.count, 1)
        try reopened.acknowledge(session: creation.id, frame: frame.id, receipt: ["id": frame.id, "count": 1])
        XCTAssertTrue(try reopened.get(creation.id).pending.isEmpty)
        XCTAssertEqual(try reopened.image(session: creation.id, frame: frame.id), Data([1,2,3]))
    }
    func testRejectsTraversalAndOversizeFrames() throws {
        let store = CaptureRepository(root: directory)
        XCTAssertThrowsError(try store.get("../../elsewhere"))
        let creation = CaptureCreation(mode: "trial", markerCount: 4, profile: profile(), physical: false, squareMM: nil, calibrationID: nil)
        try store.create(creation)
        XCTAssertThrowsError(try store.append(id: creation.id, image: Data(count: 8*1024*1024+1), timestamp: 1))
        XCTAssertEqual(try store.get(creation.id).frameCount, 0)
    }
    func testBridgeAcceptsOnlyLocalHostsAndNoCredentialsOrQuery() throws {
        XCTAssertNoThrow(try BridgeClient(address: "http://192.168.1.2:8765", token: "test"))
        XCTAssertNoThrow(try BridgeClient(address: "https://lab.local:8765", token: "test"))
        XCTAssertThrowsError(try BridgeClient(address: "https://example.com", token: "test"))
        XCTAssertThrowsError(try BridgeClient(address: "https://192.168.1.2.evil.example", token: "test"))
        XCTAssertThrowsError(try BridgeClient(address: "http://user:pass@192.168.1.2", token: "test"))
        XCTAssertThrowsError(try BridgeClient(address: "http://192.168.1.2?key=test", token: "test"))
    }
}
