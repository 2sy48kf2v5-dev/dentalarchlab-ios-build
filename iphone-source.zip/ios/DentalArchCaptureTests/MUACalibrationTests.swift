import Foundation
import XCTest
@testable import DentalArchCapture

final class MUACalibrationTests: XCTestCase {
    private var identity: [[Double]] { [[1,0,0,0], [0,1,0,0], [0,0,1,0], [0,0,0,1]] }
    private func flag(_ id: Int = 0, transform: [[Double]]? = nil) -> MUACalibrationFlag {
        MUACalibrationFlag(markerID: id, physicalSerial: "TEST-ONLY-D4V-\(id)", transform: transform ?? identity,
                           fitRMSMM: 0.02, uncertaintyMM: 0.04, uncertaintyDegrees: 0.3)
    }
    private func fixture(_ flags: [MUACalibrationFlag]? = nil) -> MUACalibration {
        MUACalibration(referenceDevice: "TEST SYNTHETIC REFERENCE", referenceReport: "Test fixture; no physical measurement",
                       measuredAt: "2026-09-27T10:00:00Z", flags: flags ?? [flag()])
    }
    private func result(_ transforms: [[[Double]]]) -> [String: Any] {
        ["units": "mm", "rig": ["units": "mm", "dictionary": "DAL_DOTS4_V1"],
         "warnings": [String](), "physical_accuracy_um": NSNull(),
         "markers": transforms.enumerated().map { index, transform -> [String: Any] in
             ["id": index, "T_world_marker": transform, "T_world_mua": NSNull()]
         }]
    }

    func testCanonicalRoundTripRetainsReferenceProvenanceAndHash() throws {
        let original = fixture([flag(0), flag(3)])
        let encoded = try original.canonicalData()
        let decoded = try MUACalibration.load(encoded)
        XCTAssertEqual(original, decoded)
        XCTAssertEqual(try decoded.canonicalData(), encoded)
        XCTAssertEqual(try decoded.contentHash(), try original.contentHash())
        XCTAssertEqual(try decoded.contentHash().count, 64)
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
        XCTAssertEqual(object["geometry_revision"] as? String, "DAL_N48_D4_VERTICAL_V1")
        XCTAssertEqual(object["component_reference"] as? String, "MG-MUASB9")
    }

    func testWrongSchemaUnitsFamilyComponentGeometryAndSourceAreRejected() {
        let changes: [(inout MUACalibration) -> Void] = [
            { $0.schema = 2 }, { $0.units = "m" }, { $0.dictionary = "other" },
            { $0.componentReference = "OTHER-MUA" }, { $0.geometryRevision = "DAL_N48_HORIZONTAL" },
            { $0.source = "nominal_cad" }
        ]
        for change in changes { var value = fixture(); change(&value); XCTAssertThrowsError(try value.validated()) }
    }

    func testEmptyAndOutOfRangeRepeatedFlagIDsOrSerialsAreRejected() {
        XCTAssertThrowsError(try fixture([]).validated())
        XCTAssertThrowsError(try fixture([flag(-1)]).validated())
        XCTAssertThrowsError(try fixture([flag(6)]).validated())
        XCTAssertThrowsError(try fixture([flag(0), flag(0)]).validated())
        var repeated = flag(1); repeated.physicalSerial = flag(0).physicalSerial
        XCTAssertThrowsError(try fixture([flag(0), repeated]).validated())
        var empty = flag(); empty.physicalSerial = " "
        XCTAssertThrowsError(try fixture([empty]).validated())
    }

    func testMeasurementMetadataDateAndUncertaintyMustBeValid() {
        var missing = fixture(); missing.referenceDevice = ""
        XCTAssertThrowsError(try missing.validated())
        missing = fixture(); missing.referenceReport = " "
        XCTAssertThrowsError(try missing.validated())
        missing = fixture(); missing.measuredAt = "not a date"
        XCTAssertThrowsError(try missing.validated())
        let changes: [(inout MUACalibrationFlag) -> Void] = [
            { $0.fitRMSMM = -1 }, { $0.uncertaintyMM = -.infinity },
            { $0.uncertaintyDegrees = .nan }, { $0.uncertaintyDegrees = -0.1 }
        ]
        for change in changes { var item = flag(); change(&item); XCTAssertThrowsError(try fixture([item]).validated()) }
    }

    func testMalformedScaledShearedReflectedAndNonfiniteTransformsAreRejected() {
        var scaled = identity; scaled[0][0] = 1.1
        var sheared = identity; sheared[0][1] = 0.1
        var reflected = identity; reflected[2][2] = -1
        var nonfinite = identity; nonfinite[1][3] = .infinity
        var badRow = identity; badRow[3][0] = 0.01
        for matrix in [scaled, sheared, reflected, nonfinite, badRow, [[1.0, 2.0]]] {
            XCTAssertThrowsError(try fixture([flag(transform: matrix)]).validated())
        }
    }

    func testTranslationIsRotatedBeforeWorldTranslationIsAdded() throws {
        // World marker is +90° around Z at (10,20,30); local MUA offset (2,0,3)
        // must become (10,22,33), not (12,20,33).
        let world: [[Double]] = [[0,-1,0,10], [1,0,0,20], [0,0,1,30], [0,0,0,1]]
        var local = identity; local[0][3] = 2; local[2][3] = 3
        let output = try fixture([flag(transform: local)]).apply(to: result([world]))
        let marker = try XCTUnwrap((output["markers"] as? [[String: Any]])?.first)
        XCTAssertEqual(marker["center_mm"] as? [Double], [10,22,33])
        XCTAssertEqual(marker["axis"] as? [Double], [0,0,1])
        XCTAssertEqual(marker["T_world_marker"] as? [[Double]], world)
        XCTAssertEqual(marker["calibration_status"] as? String, "imported_reference_metrology_unverified")
    }

    func testMUAPositiveZAxisUsesBothRotations() throws {
        let world: [[Double]] = [[0,-1,0,0], [1,0,0,0], [0,0,1,0], [0,0,0,1]]
        let local: [[Double]] = [[1,0,0,0], [0,0,-1,0], [0,1,0,0], [0,0,0,1]]
        let output = try fixture([flag(transform: local)]).apply(to: result([world]))
        let marker = try XCTUnwrap((output["markers"] as? [[String: Any]])?.first)
        XCTAssertEqual(marker["axis"] as? [Double], [1,0,0])
    }

    func testMissingMappingStaysNullAndNeverClaimsPhysicalAccuracy() throws {
        var original = result([identity, identity])
        var old = try XCTUnwrap(original["markers"] as? [[String: Any]])
        old[1]["T_world_mua"] = identity; old[1]["center_mm"] = [0,0,0]
        original["markers"] = old
        let output = try fixture().apply(to: original)
        let markers = try XCTUnwrap(output["markers"] as? [[String: Any]])
        XCTAssertTrue(markers[1]["T_world_mua"] is NSNull)
        XCTAssertTrue(markers[1]["center_mm"] is NSNull)
        XCTAssertTrue(markers[1]["axis"] is NSNull)
        XCTAssertTrue(output["physical_accuracy_um"] is NSNull)
        XCTAssertEqual(output["all_mua_calibrated"] as? Bool, false)
        XCTAssertEqual(output["mua_calibrated_marker_ids"] as? [Int], [0])
        XCTAssertEqual(output["mua_missing_marker_ids"] as? [Int], [1])
        XCTAssertEqual(output["clinically_validated"] as? Bool, false)
        XCTAssertEqual(output["measurement_source_verified"] as? Bool, false)
    }

    func testProvenanceIsFrozenAndChangesProduceDifferentHash() throws {
        var imported = fixture()
        let output = try imported.apply(to: result([identity]))
        let frozen = try XCTUnwrap(output["mua_calibration_import"] as? [String: Any])
        let firstHash = try imported.contentHash()
        imported.flags[0].transform[0][3] = 1
        XCTAssertNotEqual(try imported.contentHash(), firstHash)
        XCTAssertEqual(output["mua_calibration_sha256"] as? String, firstHash)
        let restored = try MUACalibration.load(JSONSerialization.data(withJSONObject: frozen))
        XCTAssertEqual(restored.flags[0].transform, identity)
    }

    func testApplyRejectsWrongResultUnitsFamilyDuplicateIDsAndInvalidWorldPose() throws {
        let calibration = fixture()
        var wrong = result([identity]); wrong["units"] = "m"
        XCTAssertThrowsError(try calibration.apply(to: wrong))
        wrong = result([identity]); wrong["rig"] = ["units": "mm", "dictionary": "OTHER"]
        XCTAssertThrowsError(try calibration.apply(to: wrong))
        wrong = result([identity]); let markers = wrong["markers"] as! [[String: Any]]; wrong["markers"] = markers + markers
        XCTAssertThrowsError(try calibration.apply(to: wrong))
        var invalid = identity; invalid[0][0] = 2
        XCTAssertThrowsError(try calibration.apply(to: result([invalid])))
    }

    func testImportRejectsOversizeMalformedAndMissingRequiredFields() throws {
        XCTAssertThrowsError(try MUACalibration.load(Data(count: 512 * 1024 + 1)))
        XCTAssertThrowsError(try MUACalibration.load(Data("[]".utf8)))
        XCTAssertThrowsError(try MUACalibration.load(Data("{".utf8)))
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: fixture().canonicalData()) as? [String: Any])
        object.removeValue(forKey: "reference_report")
        XCTAssertThrowsError(try MUACalibration.load(JSONSerialization.data(withJSONObject: object)))
    }

    func testPartialImportClearsMissingMUAOnlyOnMappedFlagAndKeepsQualityFailures() throws {
        let unmeasured = "MUA transforms are unmeasured; only independent optical flag geometry is available."
        var source = result([identity, identity])
        source["warnings"] = [unmeasured, "Insufficient parallax remains."]
        var markers = try XCTUnwrap(source["markers"] as? [[String: Any]])
        for index in markers.indices { markers[index]["issues"] = ["missing_mua_calibration", "insufficient_parallax"] }
        source["markers"] = markers
        let output = try fixture([flag(0)]).apply(to: source)
        let updated = try XCTUnwrap(output["markers"] as? [[String: Any]])
        XCTAssertEqual(updated[0]["issues"] as? [String], ["insufficient_parallax"])
        XCTAssertEqual(updated[1]["issues"] as? [String], ["missing_mua_calibration", "insufficient_parallax"])
        let warnings = try XCTUnwrap(output["warnings"] as? [String])
        XCTAssertTrue(warnings.contains(unmeasured))
        XCTAssertTrue(warnings.contains("Insufficient parallax remains."))
        XCTAssertTrue(warnings.contains { $0.contains("ölçüm kaynağı ve klinik doğruluk uygulama tarafından doğrulanmadı") })
        XCTAssertEqual(output["all_mua_calibrated"] as? Bool, false)
        XCTAssertEqual(output["measurement_source_verified"] as? Bool, false)
    }

    func testCompleteImportReplacesOnlyObsoleteUnmeasuredWarning() throws {
        let unmeasured = "MUA transforms are unmeasured; only independent optical flag geometry is available."
        var source = result([identity, identity])
        source["warnings"] = [unmeasured, "Physical measurement accuracy remains unvalidated."]
        var markers = try XCTUnwrap(source["markers"] as? [[String: Any]])
        for index in markers.indices { markers[index]["issues"] = ["few_views", "missing_mua_calibration", "high_reprojection_error"] }
        source["markers"] = markers
        let output = try fixture([flag(0), flag(1)]).apply(to: source)
        let warnings = try XCTUnwrap(output["warnings"] as? [String])
        XCTAssertFalse(warnings.contains(unmeasured))
        XCTAssertTrue(warnings.contains("Physical measurement accuracy remains unvalidated."))
        XCTAssertTrue(warnings.contains { $0.contains("ölçüm kaynağı ve klinik doğruluk uygulama tarafından doğrulanmadı") })
        let updated = try XCTUnwrap(output["markers"] as? [[String: Any]])
        for marker in updated { XCTAssertEqual(marker["issues"] as? [String], ["few_views", "high_reprojection_error"]) }
        XCTAssertEqual(output["all_mua_calibrated"] as? Bool, true)
        XCTAssertEqual(output["measurement_source_verified"] as? Bool, false)
        XCTAssertEqual(output["clinically_validated"] as? Bool, false)
        XCTAssertTrue(output["physical_accuracy_um"] is NSNull)
    }
}
