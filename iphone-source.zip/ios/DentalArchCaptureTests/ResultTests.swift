import XCTest
@testable import DentalArchCapture

final class ResultTests: XCTestCase {
    func envelope() -> [String: Any] {
        let t: [[Double]] = [[1,0,0,12], [0,1,0,23], [0,0,1,34], [0,0,0,1]]
        return ["id": String(repeating: "a", count: 32), "state": "complete", "mode": "scan", "message": "Tamam",
                "result": ["units": "mm", "reprojection_rms_px": 0.25,
                           "markers": [["id": 2, "T_world_marker": t, "T_world_mua": NSNull()]]]]
    }
    func testReadsRowMajorTranslationAndPositiveZWithoutInventingMUA() throws {
        let result = try ResultSnapshot.decode(envelope())
        XCTAssertEqual(result.landmarks.first?.center, LabPoint(x: 12, y: 23, z: 34))
        XCTAssertEqual(result.landmarks.first?.axis, LabPoint(x: 0, y: 0, z: 1))
        XCTAssertFalse(result.hasMUA)
        XCTAssertEqual(result.rmsPX, 0.25)
        XCTAssertFalse(result.isSynthetic)
    }
    func testUsesCalibratedMUATransformWhenPresent() throws {
        var value = envelope(), result = value["result"] as! [String: Any]
        var markers = result["markers"] as! [[String: Any]]
        markers[0]["T_world_mua"] = [[1.0,0,0,1], [0,1,0,2], [0,0,1,3], [0,0,0,1]]
        result["markers"] = markers; value["result"] = result
        let parsed = try ResultSnapshot.decode(value)
        XCTAssertTrue(parsed.hasMUA)
        XCTAssertEqual(parsed.landmarks.first?.center, LabPoint(x: 1, y: 2, z: 3))
    }
    func testRefusesUnfinishedNonfiniteAndWrongUnits() throws {
        var value = envelope(); value["state"] = "processing"
        XCTAssertThrowsError(try ResultSnapshot.decode(value))
        value = envelope(); var result = value["result"] as! [String: Any]
        result["units"] = "m"; value["result"] = result
        XCTAssertThrowsError(try ResultSnapshot.decode(value))
        result["units"] = "mm"; result["reprojection_rms_px"] = Double.infinity; value["result"] = result
        XCTAssertThrowsError(try ResultSnapshot.decode(value))
    }
    func testMalformedTransformAndDuplicateIDsAreRejected() throws {
        var value = envelope(), result = value["result"] as! [String: Any]
        let markers = result["markers"] as! [[String: Any]]
        result["markers"] = markers + markers; value["result"] = result
        XCTAssertThrowsError(try ResultSnapshot.decode(value))
        result["markers"] = [["id": 0, "T_world_marker": [[1.0,2,3]]]]; value["result"] = result
        XCTAssertThrowsError(try ResultSnapshot.decode(value))
    }
    func testIllustrationNeverReportsAnAccuracyMetricOrMUA() {
        for count in [4,6] {
            let result = ResultSnapshot.illustration(count: count)
            XCTAssertEqual(result.landmarks.count, count)
            XCTAssertTrue(result.isIllustration); XCTAssertTrue(result.isSynthetic)
            XCTAssertNil(result.rmsPX); XCTAssertFalse(result.hasMUA)
        }
    }
    func testPairingParsesServerQRAndRejectsRemoteOrMalformedLinks() throws {
        let token = String(repeating: "a", count: 32)
        let pairing = try PairingDetails(link: "http://192.168.1.2:8765/#key=" + token)
        XCTAssertEqual(pairing.address, "http://192.168.1.2:8765/"); XCTAssertEqual(pairing.token, token)
        for address in ["https://example.com/#key=", "http://192.168.1.2/path#key=", "http://192.168.1.2/?x=1#key=", "http://192.168.001.2/#key="] {
            XCTAssertThrowsError(try PairingDetails(link: address + token))
        }
        XCTAssertThrowsError(try PairingDetails(link: "http://192.168.1.2/#key=short"))
        XCTAssertThrowsError(try PairingDetails(link: "http://192.168.1.2/#key=" + token + "&extra=value"))
    }
    func testCachedResultsSurviveRestartAndDisappearWhenReopened() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: folder) }
        let store = CaptureRepository(root: folder)
        let profile = CaptureProfile(device: "test", lensPosition: 0.5, width: 1920, height: 1080, format: "test")
        let creation = CaptureCreation(mode: "scan", markerCount: 4, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        try store.create(creation); try store.update(session: creation.id, state: "complete", message: "Tamam")
        XCTAssertThrowsError(try store.cacheResult(session: creation.id, response: envelope()))
        var response = envelope(); response["id"] = creation.id
        _ = try store.cacheResult(session: creation.id, response: response)
        let reopened = CaptureRepository(root: folder)
        XCTAssertEqual(try reopened.cachedResult(session: creation.id)?.landmarks.count, 1)
        try reopened.update(session: creation.id, state: "collecting", message: "Yeni çekim")
        XCTAssertNil(try reopened.cachedResult(session: creation.id))
    }
    func testCalibrationAndTrialDoNotProduceFlagCoordinates() throws {
        let calibration: [String: Any] = ["mode": "calibration", "state": "complete", "calibration": ["metadata": ["rms_px": 0.543]]]
        XCTAssertTrue(try ResultSnapshot.decode(calibration).landmarks.isEmpty)
        XCTAssertEqual(try ResultSnapshot.decode(calibration).rmsPX, 0.543)
        XCTAssertTrue(try ResultSnapshot.decode(["mode": "trial", "state": "complete", "marker_count": 6]).landmarks.isEmpty)
    }
    func testTrialRejectsEmbeddedValid3DResultWhileScanStillDecodes() throws {
        let scan = envelope()
        XCTAssertEqual(try ResultSnapshot.decode(scan).landmarks.count, 1)
        var trial = scan; trial["mode"] = "trial"; trial["marker_count"] = 6
        XCTAssertThrowsError(try ResultSnapshot.decode(trial)) { error in
            XCTAssertTrue(error.localizedDescription.contains("2B bayrak deneyi 3B sonuç içeremez"))
        }
    }
    func testTrialWithNullSpatialPayloadKeepsIdentitySummaryWithoutCoordinates() throws {
        let trial: [String: Any] = ["mode": "trial", "state": "complete", "marker_count": 6, "result": NSNull(),
            "trial_summary": ["expected_count": 6, "recognized_ids": [0,2,4], "accepted_frames": 2,
                "metric": "identity_only_no_3d", "physical_accuracy_um": NSNull()]]
        let decoded = try ResultSnapshot.decode(trial)
        XCTAssertEqual(decoded.trial?.recognizedIDs, [0,2,4])
        XCTAssertEqual(decoded.trial?.missingIDs, [1,3,5])
        XCTAssertTrue(decoded.landmarks.isEmpty); XCTAssertNil(decoded.rmsPX); XCTAssertFalse(decoded.hasMUA)
    }
    func testTrialRejectsMalformedSpatialPayloadInsteadOfSilentlyIgnoringIt() {
        let payloads: [Any] = ["unexpected", [1,2,3], ["units": "mm"]]
        for payload in payloads {
            let trial: [String: Any] = ["mode": "trial", "state": "complete", "marker_count": 6, "result": payload]
            XCTAssertThrowsError(try ResultSnapshot.decode(trial))
        }
    }
}
