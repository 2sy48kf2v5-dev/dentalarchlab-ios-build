import XCTest
@testable import DentalArchCapture

final class ScanGuidanceTests: XCTestCase {
    private var plan: DentalPlan {
        var value = DentalPlan(); value.useExample(count: 6); return value
    }
    private func feedback(views: [Int: Int] = [0: 1, 1: 1, 2: 1, 3: 1, 4: 0, 5: 1],
                          seen: [Int] = [0, 1, 2, 3, 5], frames: Int = 1,
                          targetFrames: Int = 1, targetViews: Int = 1,
                          reasons: [String] = []) -> LiveFeedback {
        var value = LiveFeedback(sampleID: "sample", preview: false, usable: true,
            markers: seen.map { .init(id: $0, points: [[0.1, 0.1], [0.2, 0.1], [0.1, 0.2], [0.2, 0.2]]) },
            views: views, frames: frames, targetFrames: targetFrames, targetViews: targetViews,
            width: 1920, height: 1080, message: "test")
        value.candidateReasons = reasons
        return value
    }
    func testNoImageDoesNotInventRecognitionOrStall() {
        let value = ScanGuidance.make(feedback: nil, plan: plan, markerCount: 6,
                                      mode: "trial", secondsSinceProgress: 100)
        XCTAssertEqual(value.pendingIDs, Array(0..<6))
        XCTAssertTrue(value.detail.contains("FDI 34 · ID 4"))
        XCTAssertFalse(value.isCoverageReady); XCTAssertFalse(value.isStalled)
    }
    func testMissingID4IncludesFDIWithoutInventingLocation() {
        let value = ScanGuidance.make(feedback: feedback(), plan: plan, markerCount: 6, mode: "trial")
        XCTAssertEqual(value.pendingIDs, [4]); XCTAssertFalse(value.isCoverageReady)
        XCTAssertTrue(value.detail.contains("Son karede 5/6 görüldü"))
        XCTAssertTrue(value.detail.contains("Eksik: FDI 34 · ID 4"))
        XCTAssertTrue(value.detail.contains("kesin belirlenemiyor"))
    }
    func testSeenMarkerDoesNotConfirmUnacceptedSample() {
        let value = ScanGuidance.make(feedback: feedback(seen: Array(0..<6)), plan: plan,
                                      markerCount: 6, mode: "trial")
        XCTAssertEqual(value.pendingIDs, [4]); XCTAssertFalse(value.isCoverageReady)
        XCTAssertTrue(value.detail.contains("Son karede 6/6 görüldü; 5/6 için yeterli örnek var"))
    }
    func testMissingCoverageDictionaryKeyCannotDisappear() {
        var views = [0: 1, 1: 1, 2: 1, 3: 1, 5: 1]
        views[99] = 99
        let value = ScanGuidance.make(feedback: feedback(views: views), plan: plan,
                                      markerCount: 6, mode: "trial")
        XCTAssertEqual(value.pendingIDs, [4]); XCTAssertFalse(value.isCoverageReady)
    }
    func testStallThresholdAndInvalidTimeAreDeterministic() {
        for elapsed in [Double.nan, Double.infinity, -1, 8] {
            XCTAssertFalse(ScanGuidance.make(feedback: feedback(), plan: plan, markerCount: 6,
                mode: "trial", secondsSinceProgress: elapsed).isStalled)
        }
        let value = ScanGuidance.make(feedback: feedback(), plan: plan, markerCount: 6,
                                      mode: "trial", secondsSinceProgress: 8.01)
        XCTAssertTrue(value.isStalled); XCTAssertTrue(value.action.contains("taramayı duraklatıp Yeniden netle"))
        XCTAssertTrue(value.action.contains("onaylar korunur"))
        XCTAssertFalse(value.isCoverageReady)
    }
    func testPhysicalScanStallKeepsFlagsInPlaceAndDoesNotChangeFocus() {
        let value = ScanGuidance.make(feedback: feedback(), plan: plan, markerCount: 6,
                                      mode: "scan", secondsSinceProgress: 12)
        XCTAssertTrue(value.action.contains("açısını yavaşça değiştirip"))
        XCTAssertTrue(value.action.contains("bayrakları yerinden oynatmayın"))
        XCTAssertFalse(value.action.contains("Yeniden netle"))
    }
    func testCandidateReasonsHaveSpecificActionsWithoutAttributingCandidateToID4() {
        let expected = ["clipped": "görüntünün içine", "too_small": "biraz yaklaştırın",
                        "ambiguous_identity": "daha net ve farklı", "invalid_layout": "Doğru bayrak desenini",
                        "no_valid_geometry": "yansımayla birleşmediğini"]
        for (reason, action) in expected {
            let value = ScanGuidance.make(feedback: feedback(reasons: [reason]), plan: plan,
                                          markerCount: 6, mode: "trial")
            XCTAssertTrue(value.action.contains(action), reason)
            XCTAssertFalse(value.isCoverageReady, reason)
            XCTAssertTrue(value.detail.contains("Bazı") || value.detail.contains("bazı"), reason)
        }
    }
    func testReasonPrecedenceDoesNotDependOnArrayOrder() {
        let reasons = ["no_valid_geometry", "ambiguous_identity", "clipped"]
        let a = ScanGuidance.make(feedback: feedback(reasons: reasons), plan: plan, markerCount: 6, mode: "trial")
        let b = ScanGuidance.make(feedback: feedback(reasons: Array(reasons.reversed())), plan: plan, markerCount: 6, mode: "trial")
        XCTAssertEqual(a, b); XCTAssertTrue(a.action.contains("görüntünün içine"))
    }
    func testUnknownDiagnosticDoesNotRepeatRawUntrustedText() {
        let value = ScanGuidance.make(feedback: feedback(reasons: ["force_green_100_percent"]),
                                      plan: plan, markerCount: 6, mode: "trial")
        XCTAssertFalse(value.detail.contains("force_green")); XCTAssertFalse(value.isCoverageReady)
        XCTAssertTrue(value.detail.contains("kesin belirlenemiyor"))
    }
    func testAllViewsStillRequireTotalFrameCoverage() {
        let views = Dictionary(uniqueKeysWithValues: (0..<6).map { ($0, 8) })
        let value = ScanGuidance.make(feedback: feedback(views: views, frames: 8, targetFrames: 24, targetViews: 8),
                                      plan: plan, markerCount: 6, mode: "scan")
        XCTAssertEqual(value.pendingIDs, []); XCTAssertFalse(value.isCoverageReady)
        XCTAssertEqual(value.title, "Ek görüntü gerekli")
        XCTAssertTrue(value.detail.contains("Toplam görüntü hedefi: 8/24"))
    }
    func testFullCoverageDoesNotClaimAccuracyOrCompleted3D() {
        let views = Dictionary(uniqueKeysWithValues: (0..<6).map { ($0, 8) })
        let value = ScanGuidance.make(feedback: feedback(views: views, seen: [], frames: 24, targetFrames: 24, targetViews: 8),
                                      plan: plan, markerCount: 6, mode: "scan", secondsSinceProgress: 99)
        XCTAssertTrue(value.isCoverageReady); XCTAssertFalse(value.isStalled)
        XCTAssertTrue(value.detail.contains("3B çözüm ayrıca kontrol edilecek"))
        XCTAssertFalse(value.detail.contains("mikron")); XCTAssertFalse(value.detail.contains("doğru"))
    }
    func testUnassignedFDIUsesIDAndInvalidCountDoesNotCrash() {
        let value = ScanGuidance.make(feedback: feedback(), plan: DentalPlan(), markerCount: 6, mode: "trial")
        XCTAssertTrue(value.detail.contains("Eksik: ID 4")); XCTAssertFalse(value.detail.contains("FDI"))
        for count in [-1, 0, 3, Int.max] {
            let invalid = ScanGuidance.make(feedback: nil, plan: plan, markerCount: count, mode: "trial")
            XCTAssertFalse(invalid.isCoverageReady); XCTAssertEqual(invalid.pendingIDs, [])
        }
    }
}
