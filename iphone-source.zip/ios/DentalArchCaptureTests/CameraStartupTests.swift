import AVFoundation
import Combine
import UIKit
import XCTest
@testable import DentalArchCapture

private final class StartupCamera: CameraControlling {
    typealias StartCompletion = (Result<CaptureProfile, Error>) -> Void
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    private(set) var starts: [StartCompletion] = []
    private(set) var focusRequests: [CameraFocusRequest] = []
    private(set) var stopCount = 0

    func start(focus: CameraFocusRequest, completion: @escaping StartCompletion) {
        focusRequests.append(focus)
        starts.append(completion)
    }

    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        XCTFail("Startup tests must not request a camera frame")
        completion(.failure(StartupFailure.test))
    }

    func stop() { stopCount += 1 }
    func complete(_ index: Int, with result: Result<CaptureProfile, Error>) { starts[index](result) }
}

private enum StartupFailure: LocalizedError {
    case test
    var errorDescription: String? { "Test kamera açılış hatası" }
}

@MainActor final class CameraStartupTests: XCTestCase {
    private func fixture(timeout: UInt64 = 2_000_000_000) -> (CaptureModel, StartupCamera, URL) {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let camera = StartupCamera()
        let model = CaptureModel(repository: CaptureRepository(root: directory), camera: camera,
                                 cameraStartTimeoutNanoseconds: timeout)
        return (model, camera, directory)
    }

    private func cleanup(_ model: CaptureModel, _ directory: URL) {
        model.stopCamera()
        try? FileManager.default.removeItem(at: directory)
    }

    private var profile: CaptureProfile {
        CaptureProfile(device: "fake-wide", lensPosition: 0.55, width: 1920, height: 1080, format: "test")
    }

    func testNewCalibrationAndFlagTrialChooseAutomaticFocusAndKeepActualPosition() async {
        for mode in ["calibration", "trial"] {
            let (model, camera, directory) = fixture()
            defer { cleanup(model, directory) }
            model.mode = mode
            model.openCamera()
            XCTAssertEqual(camera.focusRequests, [.automatic])
            var actual = profile; actual.lensPosition = 0.71342
            await completeAndWait(camera, model: model, index: 0, result: .success(actual))
            XCTAssertTrue(model.ready)
            XCTAssertEqual(model.focus, actual.lensPosition)
            XCTAssertTrue(model.canRefocus)
        }
    }

    func testRefocusBeforeFirstFrameUsesAutomaticAndIgnoresOldCompletion() async {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        XCTAssertFalse(model.canRefocus)
        model.refocusCamera()
        XCTAssertTrue(camera.starts.isEmpty)
        model.openCamera()
        await completeAndWait(camera, model: model, index: 0, result: .success(profile))
        model.refocusCamera()
        XCTAssertEqual(camera.focusRequests, [.automatic, .automatic])
        XCTAssertTrue(model.cameraStarting)
        XCTAssertFalse(model.canRefocus)
        camera.complete(0, with: .failure(StartupFailure.test))
        var actual = profile; actual.lensPosition = 0.6841
        await completeAndWait(camera, model: model, index: 1, result: .success(actual))
        XCTAssertTrue(model.ready)
        XCTAssertEqual(model.focus, actual.lensPosition)
    }

    func testResumingSavedRecordRestoresFocusAndRejectsDifferentProfile() async throws {
        for mode in ["calibration", "trial"] {
            let (model, camera, directory) = fixture()
            defer { cleanup(model, directory) }
            var original = profile; original.lensPosition = 0.70251
            let creation = CaptureCreation(mode: mode, markerCount: 6, profile: original,
                                           physical: false, squareMM: nil, calibrationID: nil)
            try model.repository.create(creation)
            // Rehydrate a model with this saved record, as after an app restart.
            let resumed = CaptureModel(repository: model.repository, camera: camera)
            defer { resumed.stopCamera() }
            resumed.select(try model.repository.get(creation.id))
            resumed.openCamera()
            XCTAssertEqual(camera.focusRequests, [.locked(original.lensPosition)])
            await completeAndWait(camera, model: resumed, index: 0, result: .success(profile))
            XCTAssertFalse(resumed.ready)
            XCTAssertFalse(resumed.canRefocus)
            XCTAssertEqual(try model.repository.get(creation.id).creation.profile, original)
            resumed.openCamera()
            await completeAndWait(camera, model: resumed, index: 1, result: .success(original))
            XCTAssertTrue(resumed.ready)
            XCTAssertEqual(resumed.canRefocus, mode == "trial")
            resumed.refocusCamera()
            XCTAssertEqual(camera.starts.count, mode == "trial" ? 3 : 2)
            if mode == "trial" { XCTAssertEqual(camera.focusRequests.last, .automatic) }
        }
    }

    func testResearchScanWithoutEligibleCalibrationDoesNotAutofocus() {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        model.mode = "scan"
        model.openCamera()
        XCTAssertTrue(camera.starts.isEmpty)
        XCTAssertFalse(model.ready)
        XCTAssertFalse(model.canRefocus)
        XCTAssertTrue(model.status.contains("kalibrasyonu seçin"))
    }

    func testNewResearchScanRestoresSelectedCalibrationInsteadOfAutofocusing() async throws {
        let (initial, camera, directory) = fixture()
        defer { cleanup(initial, directory) }
        var calibrated = profile; calibrated.lensPosition = 0.72613
        let calibration = CaptureCreation(mode: "calibration", markerCount: 6, profile: calibrated,
                                          physical: true, squareMM: 6, calibrationID: nil)
        try initial.repository.create(calibration)
        try initial.repository.update(session: calibration.id, state: "complete", message: "test")
        let result: [String: Any] = ["calibration": ["metadata": [
            "status": "measured_research", "warnings": [String](), "rms_px": 0.2, "views": 20]]]
        try JSONSerialization.data(withJSONObject: result).write(to: initial.repository.resultURL(calibration.id))
        let model = CaptureModel(repository: initial.repository, camera: camera)
        defer { model.stopCamera() }
        model.mode = "scan"
        model.chooseCalibration(try XCTUnwrap(model.availableCalibrations.first))
        model.openCamera()
        XCTAssertEqual(camera.focusRequests, [.locked(calibrated.lensPosition)])
        var wrongCamera = calibrated; wrongCamera.device = "different-camera"
        await completeAndWait(camera, model: model, index: 0, result: .success(wrongCamera))
        XCTAssertFalse(model.ready)
        model.openCamera()
        await completeAndWait(camera, model: model, index: 1, result: .success(calibrated))
        XCTAssertTrue(model.ready)
        XCTAssertFalse(model.canRefocus)
        model.refocusCamera()
        XCTAssertEqual(camera.starts.count, 2)
    }

    func testInvalidActualFocusCannotMakeCameraReady() async {
        for invalid in [Float.nan, Float.infinity, -0.1, 1.1] {
            let (model, camera, directory) = fixture()
            defer { cleanup(model, directory) }
            model.openCamera()
            var actual = profile; actual.lensPosition = invalid
            await completeAndWait(camera, model: model, index: 0, result: .success(actual))
            XCTAssertFalse(model.ready)
            XCTAssertFalse(model.canRefocus)
        }
    }

    func testPendingFramesFollowSelectedSessionAndDoNotBlockNewCapture() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let repository = CaptureRepository(root: directory)
        let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        try repository.create(creation)
        _ = try repository.append(id: creation.id, image: Data([1,2,3]), timestamp: 1)
        let model = CaptureModel(repository: repository, camera: StartupCamera())
        defer { cleanup(model, directory) }
        XCTAssertEqual(model.pendingCount, 0)
        let saved = try XCTUnwrap(model.sessions.first)
        model.select(saved)
        XCTAssertEqual(model.pendingCount, 1)
        model.newSession()
        XCTAssertEqual(model.pendingCount, 0)
        model.select(saved)
        XCTAssertEqual(model.pendingCount, 1)
        model.showIllustration()
        XCTAssertEqual(model.pendingCount, 0)
        XCTAssertEqual(try repository.list().first?.pending.count, 1)
    }

    private func completeAndWait(_ camera: StartupCamera, model: CaptureModel, index: Int,
                                 result: Result<CaptureProfile, Error>) async {
        let finished = expectation(description: "Camera startup completes")
        let observation = model.$cameraStarting.dropFirst().filter { !$0 }.prefix(1).sink { _ in finished.fulfill() }
        defer { observation.cancel() }
        camera.complete(index, with: result)
        await fulfillment(of: [finished], timeout: 1)
    }

    func testMissingCameraCompletionTimesOutAndAllowsRetry() async {
        let (model, camera, directory) = fixture(timeout: 30_000_000)
        defer { cleanup(model, directory) }
        let finished = expectation(description: "Missing camera callback has a bounded timeout")
        let observation = model.$cameraStarting.dropFirst().filter { !$0 }.prefix(1).sink { _ in finished.fulfill() }
        defer { observation.cancel() }

        model.openCamera()
        XCTAssertTrue(model.cameraStarting)
        XCTAssertTrue(model.busy)
        let preparing = model.status
        await fulfillment(of: [finished], timeout: 1)

        XCTAssertFalse(model.cameraStarting)
        XCTAssertFalse(model.busy)
        XCTAssertFalse(model.ready)
        XCTAssertNotEqual(model.status, preparing)
        XCTAssertGreaterThanOrEqual(camera.stopCount, 1)
        model.openCamera()
        XCTAssertEqual(camera.starts.count, 2)
        XCTAssertTrue(model.cameraStarting)
    }

    func testStopReleasesStartupAndIgnoresLateSuccess() async throws {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        model.openCamera()
        let preparing = model.status
        model.stopCamera()
        let stopped = model.status

        XCTAssertFalse(model.cameraStarting)
        XCTAssertFalse(model.busy)
        XCTAssertFalse(model.ready)
        XCTAssertFalse(UIApplication.shared.isIdleTimerDisabled)
        XCTAssertNotEqual(stopped, preparing)
        camera.complete(0, with: .success(profile))
        // Give the callback's MainActor task a bounded turn before asserting it was ignored.
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertFalse(model.ready)
        XCTAssertFalse(model.busy)
        XCTAssertFalse(UIApplication.shared.isIdleTimerDisabled)
        XCTAssertEqual(model.status, stopped)
    }

    func testOldAttemptCannotCompleteOrFailNewAttempt() async throws {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        model.openCamera()
        model.stopCamera()
        model.openCamera()
        let preparing = model.status

        camera.complete(0, with: .success(profile))
        camera.complete(0, with: .failure(StartupFailure.test))
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertTrue(model.cameraStarting)
        XCTAssertTrue(model.busy)
        XCTAssertFalse(model.ready)
        XCTAssertEqual(model.status, preparing)

        await completeAndWait(camera, model: model, index: 1, result: .success(profile))
        XCTAssertTrue(model.ready)
        XCTAssertFalse(model.busy)
        let readyStatus = model.status
        camera.complete(0, with: .failure(StartupFailure.test))
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertTrue(model.ready)
        XCTAssertEqual(model.status, readyStatus)
    }

    func testSuccessfulStartupCancelsWatchdogAndDuplicateCompletion() async throws {
        let (model, camera, directory) = fixture(timeout: 100_000_000)
        defer { cleanup(model, directory) }
        model.mode = "calibration"
        model.openCamera()
        await completeAndWait(camera, model: model, index: 0, result: .success(profile))

        XCTAssertTrue(model.ready)
        XCTAssertFalse(model.cameraStarting)
        XCTAssertFalse(model.busy)
        XCTAssertTrue(model.status.contains("Kalibrasyon taramasını başlat"))
        XCTAssertTrue(UIApplication.shared.isIdleTimerDisabled)
        let readyStatus = model.status
        let stopCount = camera.stopCount
        camera.complete(0, with: .failure(StartupFailure.test))
        camera.complete(0, with: .success(profile))
        // Cross the watchdog's original deadline: a stale timer must not stop a ready camera.
        try await Task.sleep(nanoseconds: 160_000_000)
        XCTAssertTrue(model.ready)
        XCTAssertFalse(model.cameraStarting)
        XCTAssertFalse(model.busy)
        XCTAssertEqual(model.status, readyStatus)
        XCTAssertEqual(camera.stopCount, stopCount)
    }

    func testStartupFailureIsRetryable() async {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        model.openCamera()
        await completeAndWait(camera, model: model, index: 0, result: .failure(StartupFailure.test))
        XCTAssertFalse(model.cameraStarting)
        XCTAssertFalse(model.busy)
        XCTAssertFalse(model.ready)
        XCTAssertTrue(model.status.contains("Test kamera açılış hatası"))

        model.openCamera()
        XCTAssertEqual(camera.starts.count, 2)
        await completeAndWait(camera, model: model, index: 1, result: .success(profile))
        XCTAssertTrue(model.ready)
        XCTAssertFalse(model.busy)
    }

    func testStructuredStartupDetailsAreExposedAndClearedOnRetry() async throws {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        let failure = CameraStartupFailure(message: "Kamera görüntü boyutu doğrulanamadı.",
                                           details: "Kare: 1280 × 720\nBeklenen: 1920 × 1080\nOdak: locked")
        model.openCamera()
        XCTAssertNil(model.cameraDiagnostic)
        await completeAndWait(camera, model: model, index: 0, result: .failure(failure))
        XCTAssertEqual(model.status, failure.message)
        XCTAssertEqual(model.cameraDiagnostic, failure.details)
        XCTAssertFalse(model.ready)

        model.openCamera()
        XCTAssertNil(model.cameraDiagnostic)
        camera.complete(0, with: .failure(failure))
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertNil(model.cameraDiagnostic)
        XCTAssertTrue(model.cameraStarting)
        await completeAndWait(camera, model: model, index: 1, result: .failure(StartupFailure.test))
        XCTAssertNil(model.cameraDiagnostic)
        XCTAssertEqual(model.status, StartupFailure.test.localizedDescription)
    }

    func testInterruptionDuringStartupReleasesControlsAndRejectsLateResult() async throws {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        model.openCamera()
        let stopped = expectation(description: "Interruption cancels startup")
        let observation = model.$cameraStarting.dropFirst().filter { !$0 }.prefix(1).sink { _ in stopped.fulfill() }
        defer { observation.cancel() }
        camera.onInterruption?("Test kamera kesintisi")
        await fulfillment(of: [stopped], timeout: 1)
        XCTAssertFalse(model.busy)
        XCTAssertFalse(model.ready)
        XCTAssertEqual(model.status, "Test kamera kesintisi")

        camera.complete(0, with: .success(profile))
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertFalse(model.ready)
        XCTAssertEqual(model.status, "Test kamera kesintisi")
    }

    func testOldInterruptionCannotStopReplacementCameraRun() async throws {
        let (model, camera, directory) = fixture()
        defer { cleanup(model, directory) }
        model.openCamera()
        let oldInterruption = try XCTUnwrap(camera.onInterruption)
        model.stopCamera()
        model.openCamera()
        let preparing = model.status

        oldInterruption("Eski kamera kesintisi")
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertTrue(model.cameraStarting)
        XCTAssertTrue(model.busy)
        XCTAssertEqual(model.status, preparing)

        await completeAndWait(camera, model: model, index: 1, result: .success(profile))
        let readyStatus = model.status
        oldInterruption("Eski kamera kesintisi")
        try await Task.sleep(nanoseconds: 30_000_000)
        XCTAssertTrue(model.ready)
        XCTAssertEqual(model.status, readyStatus)

        let stopped = expectation(description: "The current run still responds to interruptions after startup")
        let observation = model.$ready.dropFirst().filter { !$0 }.prefix(1).sink { _ in stopped.fulfill() }
        defer { observation.cancel() }
        camera.onInterruption?("Yeni kamera kesintisi")
        await fulfillment(of: [stopped], timeout: 1)
        XCTAssertFalse(model.ready)
        XCTAssertFalse(model.busy)
        XCTAssertEqual(model.status, "Yeni kamera kesintisi")
    }
}

final class CameraStartupReadinessTests: XCTestCase {
    private struct Frame {
        var now = 11.0
        var running = true
        var interrupted = false
        var focusLocked = true
        var adjustingFocus = false
        var lensPosition: Float = 0.55
        var width = 1920
        var height = 1080
        var timestamp = 1.0
    }

    private func observe(_ check: inout CameraStartupCheck, timestamp: Double,
                         change: (inout Frame) -> Void = { _ in }) -> Bool {
        var frame = Frame()
        frame.timestamp = timestamp
        change(&frame)
        return check.observe(now: frame.now, running: frame.running, interrupted: frame.interrupted,
                             focusLocked: frame.focusLocked, adjustingFocus: frame.adjustingFocus,
                             lensPosition: frame.lensPosition, width: frame.width, height: frame.height,
                             timestamp: frame.timestamp)
    }

    func testReadinessNeedsThreeFreshFramesAfterSettling() {
        var check = CameraStartupCheck(requestedLens: 0.55, earliestFrameTime: 10)
        XCTAssertFalse(observe(&check, timestamp: 1) { $0.now = 9.99 })
        XCTAssertFalse(observe(&check, timestamp: 2) { $0.now = 10 })
        XCTAssertFalse(observe(&check, timestamp: 3))
        XCTAssertTrue(observe(&check, timestamp: 4))
    }

    func testPreviewSizedFramesCannotSubstituteForFullResolutionLockedFrames() {
        var check = CameraStartupCheck(requestedLens: 0.55, earliestFrameTime: 10)
        for timestamp in [1.0, 2.0, 3.0, 4.0] {
            XCTAssertFalse(observe(&check, timestamp: timestamp) {
                $0.width = 1280; $0.height = 720
            })
        }
        // Correct output dimensions still cannot bypass the requested focus position.
        for timestamp in [5.0, 6.0, 7.0] {
            XCTAssertFalse(observe(&check, timestamp: timestamp) { $0.lensPosition = 0.56 })
        }
        XCTAssertFalse(observe(&check, timestamp: 8))
        XCTAssertFalse(observe(&check, timestamp: 9))
        XCTAssertTrue(observe(&check, timestamp: 10))
    }

    func testEachInvalidCameraFactResetsConsecutiveFrameRequirement() {
        let invalidFacts: [(String, (inout Frame) -> Void)] = [
            ("session stopped", { $0.running = false }),
            ("session interrupted", { $0.interrupted = true }),
            ("focus unlocked", { $0.focusLocked = false }),
            ("focus still moving", { $0.adjustingFocus = true }),
            ("wrong lens position", { $0.lensPosition = 0.56 }),
            ("nonfinite lens position", { $0.lensPosition = .nan }),
            ("wrong width", { $0.width = 1280 }),
            ("wrong height", { $0.height = 720 }),
            ("settling not complete", { $0.now = 9.99 }),
            ("nonfinite clock", { $0.now = .nan })
        ]
        for (reason, invalidate) in invalidFacts {
            var check = CameraStartupCheck(requestedLens: 0.55, earliestFrameTime: 10)
            XCTAssertFalse(observe(&check, timestamp: 1), reason)
            XCTAssertFalse(observe(&check, timestamp: 2), reason)
            XCTAssertFalse(observe(&check, timestamp: 3, change: invalidate), reason)
            XCTAssertFalse(observe(&check, timestamp: 4), reason)
            XCTAssertFalse(observe(&check, timestamp: 5), reason)
            XCTAssertTrue(observe(&check, timestamp: 6), reason)
        }
    }

    func testDuplicateOlderNegativeAndNonfiniteTimestampsCannotCountAsFreshFrames() {
        for invalid in [2.0, 1.5, -0.1, Double.nan, Double.infinity, -Double.infinity] {
            var check = CameraStartupCheck(requestedLens: 0.55, earliestFrameTime: 10)
            XCTAssertFalse(observe(&check, timestamp: 1))
            XCTAssertFalse(observe(&check, timestamp: 2))
            XCTAssertFalse(observe(&check, timestamp: invalid))
            XCTAssertFalse(observe(&check, timestamp: 3))
            XCTAssertFalse(observe(&check, timestamp: 4))
            XCTAssertTrue(observe(&check, timestamp: 5))
        }
    }

    func testSmallLensRoundingErrorIsAcceptedButLargerErrorIsRejected() {
        var near = CameraStartupCheck(requestedLens: 0.55, earliestFrameTime: 10)
        XCTAssertFalse(observe(&near, timestamp: 1) { $0.lensPosition = 0.5519 })
        XCTAssertFalse(observe(&near, timestamp: 2) { $0.lensPosition = 0.5481 })
        XCTAssertTrue(observe(&near, timestamp: 3) { $0.lensPosition = 0.5519 })

        var far = CameraStartupCheck(requestedLens: 0.55, earliestFrameTime: 10)
        for timestamp in [1.0, 2.0, 3.0, 4.0] {
            XCTAssertFalse(observe(&far, timestamp: timestamp) { $0.lensPosition = 0.5521 })
        }
    }
}
