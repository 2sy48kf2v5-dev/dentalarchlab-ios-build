import Foundation
import XCTest
@testable import DentalArchCapture

final class TissueWorkspaceTests: XCTestCase {
    private let identity: [[Double]] = [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
    private struct Fixture {
        let root: URL
        let repository: CaptureRepository
        let session: String
        let workspace: TissueWorkspace
    }
    private func fixture(calibrated: Bool = false, mode: String = "scan", duplicateFDI: Bool = false) throws -> Fixture {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent("tissue-" + UUID().uuidString)
        let repository = CaptureRepository(root: root)
        let profile = CaptureProfile(device: "SYNTHETIC TEST", lensPosition: 0.55, width: 1920, height: 1080, format: "test")
        let creation = CaptureCreation(mode: mode, markerCount: 4, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        try repository.create(creation)
        try repository.update(session: creation.id, state: "complete", message: "SYNTHETIC SOFTWARE TEST")
        let fdis = duplicateFDI ? [46,46,33,36] : [46,43,33,36]
        let points: [[Double]] = [[-3,2.4,0],[3.3,2,0],[-1.7,-2.8,0],[-1.38,1.376,0]]
        let markers: [[String: Any]] = (0..<4).map { index in
            var matrix = identity; matrix[0][3] = Double(index % 2)*20; matrix[1][3] = Double(index / 2)*20
            return ["id": index, "fdi": fdis[index], "component_reference": "MG-MUASB9", "T_world_marker": matrix, "T_world_mua": NSNull(), "issues": [String]()]
        }
        var result: [String: Any] = ["units": "mm", "status": "research_result", "markers": markers, "missing_markers": [Int](),
            "rig": ["units": "mm", "dictionary": "DAL_DOTS4_V1", "markers": (0..<4).map { ["id": $0, "points_mm": points] as [String: Any] }],
            "warnings": [String](), "reprojection_rms_px": 0.1, "bundle_adjustment": [["converged": true]]]
        if calibrated {
            let calibration = MUACalibration(referenceDevice: "TEST DEVICE", referenceReport: "SYNTHETIC ONLY",
                measuredAt: "2026-09-29T10:00:00Z", flags: (0..<4).map {
                    MUACalibrationFlag(markerID: $0, physicalSerial: "TEST-\($0)", transform: identity,
                        fitRMSMM: 0.01, uncertaintyMM: 0.02, uncertaintyDegrees: 0.1)
                })
            result = try calibration.apply(to: result)
        }
        let envelope: [String: Any] = ["id": creation.id, "state": "complete", "mode": mode, "marker_count": 4,
            "message": "SYNTHETIC SOFTWARE TEST", "result": result]
        _ = try repository.cacheResult(session: creation.id, response: envelope)
        return Fixture(root: root, repository: repository, session: creation.id,
            workspace: TissueWorkspace(repository: repository, session: creation.id))
    }
    private func mesh() throws -> Data {
        try TissueMesh(vertices: [LabPoint(x: -5,y: -5,z: 0), LabPoint(x: 30,y: -5,z: 0), LabPoint(x: -5,y: 30,z: 0)],
            triangles: [[0,1,2]]).stlData()
    }
    private func prepare(_ f: Fixture, checkError: Double = 0, withCheck: Bool = true) async throws -> TissueWorkspaceState {
        let initial = try await f.workspace.importMesh(data: mesh(), name: "ios-test.stl")
        for id in ["0:0", "0:1", "1:2", "2:1"] {
            let target = try XCTUnwrap(initial.targets.first { $0.id == id })
            let source = target.point - LabPoint(x: 2,y: -4,z: 5)
            _ = try await f.workspace.setPair(targetID: id, source: source, checkOnly: false)
        }
        if withCheck {
            let target = try XCTUnwrap(initial.targets.first { $0.id == "3:3" })
            let source = target.point - LabPoint(x: 2,y: -4,z: 5) + LabPoint(x: checkError,y: 0,z: 0)
            _ = try await f.workspace.setPair(targetID: target.id, source: source, checkOnly: true)
        }
        return try await f.workspace.align()
    }
    private func library() throws -> Data {
        let profile = ExocadLibraryProfile(schema: 1, manufacturer: "MegaGen", implantSystem: "TEST ONLY",
            connectionLevel: "mua", componentReference: "MG-MUASB9", library: "TEST_LIBRARY", type: "TEST_TYPE",
            subtype: nil, configSHA256: String(repeating: "b", count: 64), libraryVersion: "TEST", exocadVersion: "TEST",
            referenceReport: "SYNTHETIC TEST", source: "reference_metrology", transform: identity,
            maxAlignmentRMSMM: 0.1, maxCheckpointErrorMM: 0.2)
        return try JSONEncoder().encode(profile)
    }

    func testFitTransformsRealMeshAndHeldOutPointIsNotUsed() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        let state = try await prepare(f, checkError: 2)
        let registration = try XCTUnwrap(state.registration)
        XCTAssertEqual(registration.rmsMM, 0, accuracy: 1e-8)
        XCTAssertEqual(state.checkRMSMM ?? -1, 2, accuracy: 1e-8)
        XCTAssertEqual(registration.transform[0][3], 2, accuracy: 1e-8)
        XCTAssertEqual(registration.transform[1][3], -4, accuracy: 1e-8)
        XCTAssertEqual(registration.transform[2][3], 5, accuracy: 1e-8)
        let vertex = try XCTUnwrap(state.alignedMesh?.vertices.first)
        XCTAssertEqual(vertex.x, -3, accuracy: 1e-8); XCTAssertEqual(vertex.y, -9, accuracy: 1e-8)
        XCTAssertEqual(vertex.z, 5, accuracy: 1e-8)
    }

    func testUncalibratedSurfaceExportWorksWithoutInventedImplantFiles() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f)
        let files = try await f.workspace.export(projectName: "MODEL")
        XCTAssertEqual(files.count, 4)
        XCTAssertTrue(files.contains { $0.lastPathComponent == "MODEL-tissue-aligned.stl" })
        XCTAssertFalse(files.contains { $0.pathExtension == "implantPosition" })
        let report = try report(files)
        XCTAssertEqual(report["clinically_validated"] as? Bool, false)
        XCTAssertTrue(report["physical_accuracy_um"] is NSNull)
        XCTAssertEqual(report["exocad_import_tested"] as? Bool, false)
        XCTAssertFalse((report["implant_export_blockers"] as? [String] ?? []).isEmpty)
    }

    func testCompleteResearchPrerequisitesProduceExactlyOneXMLPerFDI() async throws {
        let f = try fixture(calibrated: true); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f)
        let state = try await f.workspace.importLibrary(data: library())
        XCTAssertEqual(state.blockers, [])
        let files = try await f.workspace.export(projectName: "MODEL")
        XCTAssertEqual(Set(files.filter { $0.pathExtension == "implantPosition" }.map(\.lastPathComponent)),
            Set(["MODEL-46.implantPosition", "MODEL-43.implantPosition", "MODEL-33.implantPosition", "MODEL-36.implantPosition"]))
        XCTAssertEqual(try report(files)["exocad_library_match_verified"] as? Bool, false)
    }

    func testIndependentCheckpointBlocksIncorrectCADButKeepsResearchSurface() async throws {
        let f = try fixture(calibrated: true); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f, checkError: 1)
        let state = try await f.workspace.importLibrary(data: library())
        XCTAssertTrue(state.blockers.contains { $0.contains("Kontrol noktası") })
        let files = try await f.workspace.export(projectName: "MODEL")
        XCTAssertFalse(files.contains { $0.pathExtension == "implantPosition" })
    }

    func testMissingCheckpointAndDuplicateFDIBlockImplantExport() async throws {
        let f = try fixture(calibrated: true, duplicateFDI: true); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f, withCheck: false)
        let state = try await f.workspace.importLibrary(data: library())
        XCTAssertTrue(state.blockers.contains { $0.contains("kontrol noktası") })
        XCTAssertTrue(state.blockers.contains { $0.contains("FDI") })
    }

    func testReopenPreservesAlignmentAndLastExportWithoutReusingOldResults() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f)
        let files = try await f.workspace.export(projectName: "MODEL")
        let reopened = TissueWorkspace(repository: f.repository, session: f.session)
        let state = try await reopened.load()
        XCTAssertEqual(state.files, files); XCTAssertEqual(state.pairs.count, 5)
        XCTAssertNotNil(state.registration)
        let url = try f.repository.resultURL(f.session)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        object["message"] = "Updated result"
        try JSONSerialization.data(withJSONObject: object).write(to: url)
        do { _ = try await reopened.load(); XCTFail("Changed result must invalidate alignment") } catch { }
    }

    func testPairChangeInvalidatesPreviousTransformAndExportList() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f); _ = try await f.workspace.export(projectName: "MODEL")
        let changed = try await f.workspace.removePair(targetID: "0:0")
        XCTAssertNil(changed.registration); XCTAssertEqual(changed.files, [])
        do { _ = try await f.workspace.export(projectName: "MODEL"); XCTFail("Recompute required") } catch { }
    }

    func testNewMeshResetsCorrespondenceAndNoScaleIsGuessed() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f)
        let fresh = try await f.workspace.importMesh(data: mesh(), name: "second.stl")
        XCTAssertEqual(fresh.pairs.count, 0); XCTAssertNil(fresh.registration)
        XCTAssertEqual(fresh.mesh?.vertices.first?.x, -5)
    }

    func testChangedSourceCannotHideBehindSameActorCache() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        _ = try await prepare(f)
        let source = try f.repository.resultURL(f.session).deletingLastPathComponent().appendingPathComponent("TissueAlignment/source.stl")
        try Data("changed".utf8).write(to: source)
        do { _ = try await f.workspace.load(); XCTFail("Cached source changed") } catch { }
        do { _ = try await f.workspace.export(projectName: "MODEL"); XCTFail("Cached export must revalidate source") } catch { }
    }

    func testMarkerQualityIssuesAndNonconvergenceBlockImplantPositionFiles() async throws {
        let f = try fixture(calibrated: true); defer { try? FileManager.default.removeItem(at: f.root) }
        let url = try f.repository.resultURL(f.session)
        var response = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        var result = response["result"] as! [String: Any]
        var markers = result["markers"] as! [[String: Any]]
        markers[0]["issues"] = ["high_reprojection_error"]
        result["markers"] = markers; result["bundle_adjustment"] = [["converged": false]]
        response["result"] = result
        try JSONSerialization.data(withJSONObject: response).write(to: url)
        _ = try await prepare(f)
        let state = try await f.workspace.importLibrary(data: library())
        XCTAssertTrue(state.blockers.contains { $0.contains("kalite kontrolleri") })
        let files = try await f.workspace.export(projectName: "MODEL")
        XCTAssertFalse(files.contains { $0.pathExtension == "implantPosition" })
    }

    func testOneFlagAndUnknownTargetsCannotDriveWholeArchAlignment() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        let state = try await f.workspace.importMesh(data: mesh(), name: "model.stl")
        for target in state.targets.filter({ $0.markerID == 0 }) {
            _ = try await f.workspace.setPair(targetID: target.id, source: target.point, checkOnly: false)
        }
        do { _ = try await f.workspace.align(); XCTFail("Need distributed references") } catch { }
        do { _ = try await f.workspace.setPair(targetID: "99:0", source: .zero, checkOnly: false); XCTFail("Unknown target") } catch { }
    }

    func testDemoCannotMasqueradeAsPhysicalTissueWorkspace() async throws {
        let f = try fixture(mode: "demo"); defer { try? FileManager.default.removeItem(at: f.root) }
        do { _ = try await f.workspace.load(); XCTFail("Demo is not a physical scan") } catch { }
    }

    private func report(_ files: [URL]) throws -> [String: Any] {
        let file = try XCTUnwrap(files.first { $0.lastPathComponent == "alignment-report.json" })
        return try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: file)) as? [String: Any])
    }
}
