import AVFoundation
import UIKit
import XCTest
@testable import DentalArchCapture

private final class CalibrationCamera: CameraControlling {
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    var starts: [(Result<CaptureProfile, Error>) -> Void] = []
    var pending: ((Result<(Data, CaptureProfile, Double), Error>) -> Void)?
    var compactRequests: [Bool] = []
    var overlaps = 0
    let profile = CaptureProfile(device: "calibration-test", lensPosition: 0.55,
                                 width: 1920, height: 1080, format: "BGRA")
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) { starts.append(completion) }
    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        if pending != nil { overlaps += 1 }
        compactRequests.append(compactTrial); pending = completion
    }
    func stop() {
        let old = pending; pending = nil
        old?(.failure(LabError.message("Test kamerası durduruldu.")))
    }
    func deliver(_ image: Data) {
        let callback = pending; pending = nil
        callback?(.success((image, profile, ProcessInfo.processInfo.systemUptime)))
    }
}

@MainActor final class CalibrationScanTests: XCTestCase {
    private func fixture() -> (CaptureModel, CalibrationCamera, URL) {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("calibration-scan-" + UUID().uuidString)
        let camera = CalibrationCamera()
        let model = CaptureModel(repository: CaptureRepository(root: directory), camera: camera)
        model.mode = "calibration"
        return (model, camera, directory)
    }
    private func waitUntil(_ condition: () -> Bool, timeout: Double = 5,
                           file: StaticString = #filePath, line: UInt = #line) async throws {
        let deadline = Date().addingTimeInterval(timeout)
        while !condition(), Date() < deadline { try await Task.sleep(nanoseconds: 10_000_000) }
        XCTAssertTrue(condition(), file: file, line: line)
    }
    private func cleanup(_ model: CaptureModel, _ directory: URL) async throws {
        model.stopCamera()
        try await waitUntil({ !model.analyzing && !model.uploading }, timeout: 20)
        try? FileManager.default.removeItem(at: directory)
    }
    private func blankImage() -> Data {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        return UIGraphicsImageRenderer(size: CGSize(width: 1920, height: 1080), format: format).pngData { context in
            UIColor.white.setFill(); context.fill(CGRect(x: 0, y: 0, width: 1920, height: 1080))
        }
    }

    func testOneTapWaitsForCameraReadinessAndThenRequestsLosslessFrameWithoutFDI() async throws {
        let (model, camera, directory) = fixture()
        model.beginCalibrationScan()
        XCTAssertTrue(model.cameraStarting)
        XCTAssertFalse(model.autoRunning)
        XCTAssertEqual(camera.starts.count, 1)
        XCTAssertTrue(camera.compactRequests.isEmpty)
        camera.starts[0](.success(camera.profile))
        try await waitUntil({ camera.pending != nil })
        XCTAssertTrue(model.autoRunning)
        XCTAssertEqual(camera.compactRequests, [false])
        XCTAssertEqual(camera.overlaps, 0)
        try await cleanup(model, directory)
    }

    func testCancelledStartupCannotStartCalibrationFromLateCallback() async throws {
        let (model, camera, directory) = fixture()
        model.beginCalibrationScan(); model.stopCamera()
        camera.starts[0](.success(camera.profile))
        try await Task.sleep(nanoseconds: 50_000_000)
        XCTAssertFalse(model.ready); XCTAssertFalse(model.autoRunning)
        XCTAssertTrue(camera.compactRequests.isEmpty)
        try await cleanup(model, directory)
    }

    func testPauseDiscardsOutstandingSampleAndResumeNeverOverlapsCapture() async throws {
        let (model, camera, directory) = fixture()
        model.beginCalibrationScan(); camera.starts[0](.success(camera.profile))
        try await waitUntil({ camera.pending != nil })
        model.pauseAutomatic(); model.beginCalibrationScan()
        XCTAssertEqual(camera.compactRequests.count, 1)
        camera.deliver(Data([0, 1])) // Cancellation must discard this before native decoding.
        try await waitUntil({ !model.analyzing })
        XCTAssertNil(model.currentID); XCTAssertNil(model.calibrationFeedback)
        model.beginCalibrationScan()
        try await waitUntil({ camera.pending != nil })
        XCTAssertEqual(camera.compactRequests.count, 2)
        XCTAssertEqual(camera.overlaps, 0)
        try await cleanup(model, directory)
    }

    func testMissingBoardKeepsAutomaticCalibrationOpenWithoutSavingRejectedImages() async throws {
        let (model, camera, directory) = fixture()
        model.physicalBoard = true; model.squareMM = "6,5"
        model.beginCalibrationScan(); camera.starts[0](.success(camera.profile))
        try await waitUntil({ camera.pending != nil })
        camera.deliver(blankImage())
        try await waitUntil({ model.calibrationFeedback != nil }, timeout: 20)
        XCTAssertTrue(model.autoRunning)
        XCTAssertEqual(model.calibrationFeedback?.reason, "not_found")
        XCTAssertEqual(model.calibrationFeedback?.cornerCount, 0)
        XCTAssertEqual(model.calibrationFeedback?.acceptedFrames, 0)
        let capture = try XCTUnwrap(model.current)
        XCTAssertTrue(capture.creation.board.physicalMeasured)
        XCTAssertEqual(capture.creation.board.squareMM, 6.5)
        XCTAssertNil(capture.creation.dentalPlan)
        XCTAssertEqual(capture.acceptedCount, 0)
        XCTAssertEqual(capture.frameCount, 0)
        XCTAssertEqual(model.pendingCount, 0)
        try await cleanup(model, directory)
    }

    func testInvalidPhysicalBoardSizeDoesNotOpenCamera() async throws {
        let (model, camera, directory) = fixture()
        model.physicalBoard = true; model.squareMM = "0"
        model.beginCalibrationScan()
        XCTAssertTrue(camera.starts.isEmpty)
        XCTAssertTrue(model.status.contains("Kare boyutunu"))
        XCTAssertFalse(model.cameraStarting)
        try await cleanup(model, directory)
    }

    private func receipt(preview: Bool = true, reason: String = "accepted") -> [String: Any] {
        let points = (0..<54).map { [0.2 + Double($0 % 9) * 0.05, 0.2 + Double($0 / 9) * 0.07] }
        return ["id": "frame", "accepted": reason == "accepted", "count": 4,
                "timing": ["detection_ms": 25.0],
                "calibration_feedback": ["schema": 1, "session_id": "session", "sample_id": "frame",
                    "preview": preview, "sample_usable": reason == "accepted", "image_size": [1920, 1080],
                    "coordinates": "sensor_normalized", "corners": points, "detected_count": 54,
                    "expected_corners": 54, "target_frames": 20, "accepted_frames": 4,
                    "blur_laplacian": 120.0, "reason": reason, "message": "Tahta algılandı.",
                    "metric": "accepted_calibration_views_not_accuracy", "physical_accuracy_um": NSNull()]]
    }

    func testCalibrationFeedbackDistinguishesDetectedDuplicateFromSavedFrame() throws {
        let feedback = try CalibrationFeedback.decode(receipt(reason: "duplicate"), session: "session", sample: "frame")
        XCTAssertTrue(feedback.preview); XCTAssertFalse(feedback.usable)
        XCTAssertEqual(feedback.cornerCount, 54); XCTAssertEqual(feedback.acceptedFrames, 4)
        XCTAssertEqual(feedback.fraction, 0.2, accuracy: 0.0001)
        XCTAssertEqual(feedback.detectionMilliseconds, 25)
        let committed = try CalibrationFeedback.decode(receipt(preview: false), session: "session", sample: "frame")
        XCTAssertFalse(committed.preview); XCTAssertTrue(committed.usable)
    }

    func testCalibrationFeedbackRejectsMismatchedOrFabricatedGeometry() throws {
        XCTAssertThrowsError(try CalibrationFeedback.decode(receipt(), session: "other", sample: "frame"))
        XCTAssertThrowsError(try CalibrationFeedback.decode(receipt(), session: "session", sample: "other"))
        for (field, value) in [("corners", [[Double.nan, 0.5]] as Any), ("detected_count", 53),
                               ("physical_accuracy_um", 0), ("target_frames", 0), ("accepted_frames", 120),
                               ("reason", "not_found"), ("blur_laplacian", Double.infinity)] {
            var r = receipt(); var f = try XCTUnwrap(r["calibration_feedback"] as? [String: Any])
            f[field] = value; r["calibration_feedback"] = f
            XCTAssertThrowsError(try CalibrationFeedback.decode(r, session: "session", sample: "frame"))
        }
    }

    func testCalibrationCadenceDoesNotQueueFasterThanAnalysis() {
        XCTAssertEqual(CalibrationCadence.delayNanoseconds(elapsed: 0), 650_000_000)
        XCTAssertEqual(CalibrationCadence.delayNanoseconds(elapsed: 2), 100_000_000)
        XCTAssertEqual(CalibrationCadence.delayNanoseconds(elapsed: .infinity), 650_000_000)
    }
}
