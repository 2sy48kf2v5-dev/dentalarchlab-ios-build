import Foundation
import XCTest
@testable import DentalArchCapture

final class TissueGeometryTests: XCTestCase {
    private let identity: [[Double]] = [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]]
    // Independent proper rotation from quaternion (2,-3,4,1)/sqrt(30), plus translation.
    private let known: [[Double]] = [[-2.0/15,-14.0/15,1.0/3,17],
                                    [-2.0/3,1.0/3,2.0/3,-23],
                                    [-11.0/15,-2.0/15,-2.0/3,8], [0,0,0,1]]
    private let points = [LabPoint(x:1,y:2,z:3), LabPoint(x:13,y:-4,z:2),
                          LabPoint(x:-7,y:11,z:-1), LabPoint(x:2,y:-3,z:17),
                          LabPoint(x:6,y:8,z:9)]
    private func expected(_ p: LabPoint) -> LabPoint {
        LabPoint(x:(-2*p.x-14*p.y+5*p.z)/15+17,
                 y:(-2*p.x+p.y+2*p.z)/3-23,
                 z:(-11*p.x-2*p.y-10*p.z)/15+8)
    }
    private func assertPoint(_ actual: LabPoint, _ wanted: LabPoint, accuracy: Double = 1e-9,
                             file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(actual.x,wanted.x,accuracy:accuracy,file:file,line:line)
        XCTAssertEqual(actual.y,wanted.y,accuracy:accuracy,file:file,line:line)
        XCTAssertEqual(actual.z,wanted.z,accuracy:accuracy,file:file,line:line)
    }
    private var triangle: TissueMesh {
        TissueMesh(vertices:[.zero,LabPoint(x:2,y:0,z:0),LabPoint(x:0,y:3,z:0)],
                   triangles:[[0,1,2]], colors:[[255,0,0],[0,255,0],[0,0,255]])
    }
    private func appendLE(_ value: UInt64, bytes: Int, to data: inout Data) {
        for shift in 0..<bytes { data.append(UInt8(truncatingIfNeeded: value >> (8*shift))) }
    }
    private func parse(_ text: String, _ ext: String) throws -> TissueMesh {
        try TissueMesh.parse(data:Data(text.utf8),fileExtension:ext)
    }
    private var asciiSTL: String {
        """
        solid example mesh
          facet normal 0 0 1
            outer loop
              vertex 0 0 0
              vertex 2 0 0
              vertex 0 3 0
            endloop
          endfacet
        endsolid example mesh
        """
    }
    private var asciiPLY: String {
        """
        ply
        format ascii 1.0
        comment coordinates are mm
        element vertex 3
        property float x
        property float y
        property float z
        property float nx
        property uchar red
        property uchar green
        property uchar blue
        element face 1
        property list uchar int vertex_indices
        end_header
        0 0 0 0 255 0 0
        2 0 0 0 0 255 0
        0 3 0 0 0 0 255
        3 0 1 2
        """
    }

    func testKnownArbitraryProperRotationAndTranslationRecoveredWithoutScale() throws {
        let fit=try TissueRegistration.fit(points.map { TissuePair(source:$0,target:expected($0)) })
        for row in 0..<4 { for column in 0..<4 {
            XCTAssertEqual(fit.transform[row][column],known[row][column],accuracy:1e-10)
        } }
        XCTAssertLessThan(fit.rmsMM,1e-10)
        XCTAssertLessThan(fit.maxMM,1e-10)
        XCTAssertEqual(fit.residualsMM.count,points.count)
        try TissueRegistration.validateRigid(fit.transform)
        assertPoint(try TissueRegistration.apply(points[0],matrix:fit.transform),expected(points[0]))
    }

    func testExactlyThreeNoncollinearPlanarPairsRecoverRigidPose() throws {
        let chosen=Array(points.prefix(3))
        let fit=try TissueRegistration.fit(chosen.map { TissuePair(source:$0,target:expected($0)) })
        XCTAssertLessThan(fit.maxMM,1e-9)
        assertPoint(try TissueRegistration.apply(points[3],matrix:fit.transform),expected(points[3]))
    }

    func testNoisyFitReportsEuclideanResidualsInMillimetres() throws {
        let noise=[LabPoint(x:0.01,y:0,z:0),LabPoint(x:0,y:-0.01,z:0.005),
                   LabPoint(x:-0.007,y:0.003,z:0),LabPoint(x:0.002,y:0,z:-0.01),
                   LabPoint(x:0,y:0.006,z:0.003)]
        let pairs=points.indices.map { TissuePair(source:points[$0],target:expected(points[$0])+noise[$0]) }
        let fit=try TissueRegistration.fit(pairs)
        XCTAssertGreaterThan(fit.rmsMM,0.001)
        XCTAssertLessThan(fit.rmsMM,0.02)
        var sum=0.0
        for index in pairs.indices {
            let measured=try TissueRegistration.apply(pairs[index].source,matrix:fit.transform)
            let residual=(measured-pairs[index].target).length
            XCTAssertEqual(fit.residualsMM[index],residual,accuracy:1e-12)
            sum += residual*residual
        }
        XCTAssertEqual(fit.rmsMM,sqrt(sum/Double(pairs.count)),accuracy:1e-12)
        XCTAssertEqual(fit.maxMM,try XCTUnwrap(fit.residualsMM.max()))
    }

    func testScaleMismatchAndMirrorCannotBeAbsorbedIntoRigidTransform() throws {
        let scaled=try TissueRegistration.fit(points.map { TissuePair(source:$0,target:$0*2) })
        XCTAssertGreaterThan(scaled.rmsMM,1)
        try TissueRegistration.validateRigid(scaled.transform)
        let mirrored=try TissueRegistration.fit(points.map { TissuePair(source:$0,target:LabPoint(x:-$0.x,y:$0.y,z:$0.z)) })
        XCTAssertGreaterThan(mirrored.rmsMM,1)
        try TissueRegistration.validateRigid(mirrored.transform)
    }

    func testDuplicateCollinearNonfiniteAndHugeLandmarksAreRejected() throws {
        let good=points.map { TissuePair(source:$0,target:expected($0)) }
        XCTAssertThrowsError(try TissueRegistration.fit(Array(good.prefix(2))))
        XCTAssertThrowsError(try TissueRegistration.fit(good+[good[0]]))
        var duplicateTarget=good
        duplicateTarget[1]=TissuePair(source:points[1],target:good[0].target)
        XCTAssertThrowsError(try TissueRegistration.fit(duplicateTarget))
        let line=(0..<4).map { LabPoint(x:Double($0),y:0,z:0) }
        XCTAssertThrowsError(try TissueRegistration.fit(line.map { TissuePair(source:$0,target:expected($0)) }))
        XCTAssertThrowsError(try TissueRegistration.fit(points.prefix(4).enumerated().map { TissuePair(source:$0.element,target:line[$0.offset]) }))
        for bad in [Double.nan,Double.infinity,100_001] {
            var pairs=good; pairs[0]=TissuePair(source:LabPoint(x:bad,y:0,z:0),target:good[0].target)
            XCTAssertThrowsError(try TissueRegistration.fit(pairs))
        }
    }

    func testRigidValidationRejectsReflectionScaleMalformedAndProjectiveMatrices() throws {
        try TissueRegistration.validateRigid(identity)
        try TissueRegistration.validateRigid(known)
        var reflected=identity; reflected[0][0] = -1
        var scaled=identity; scaled[1][1] = 2
        var projective=identity; projective[3][0] = 0.01
        var invalid=identity; invalid[0][3] = .nan
        for matrix in [reflected,scaled,projective,invalid,[[1,0],[0,1]]] {
            XCTAssertThrowsError(try TissueRegistration.validateRigid(matrix))
        }
    }

    func testMeshTransformPreservesTopologyRGBAndActualCoordinates() throws {
        let transformed=try triangle.transformed(known)
        XCTAssertEqual(transformed.triangles,triangle.triangles)
        XCTAssertEqual(transformed.colors,triangle.colors)
        for index in triangle.vertices.indices { assertPoint(transformed.vertices[index],expected(triangle.vertices[index])) }
        var scale=identity; scale[0][0]=2
        XCTAssertThrowsError(try triangle.transformed(scale))
    }

    func testBinarySTLRoundtripAndSolidBinaryHeaderAreHandled() throws {
        let data=try triangle.stlData()
        XCTAssertEqual(data.count,134)
        let parsed=try TissueMesh.parse(data:data,fileExtension:"STL")
        XCTAssertEqual(parsed.vertices,triangle.vertices)
        XCTAssertEqual(parsed.triangles,triangle.triangles)
        XCTAssertNil(parsed.colors)
        var startsSolid=data
        startsSolid.replaceSubrange(0..<5,with:Data("solid".utf8))
        XCTAssertEqual(try TissueMesh.parse(data:startsSolid,fileExtension:"stl").vertices,triangle.vertices)
    }

    func testASCIISTLReadsAndDeduplicatesSharedVertices() throws {
        let facet=asciiSTL.components(separatedBy:"facet normal")[1].components(separatedBy:"endsolid")[0]
        let two="solid test\nfacet normal"+facet+"facet normal"+facet+"endsolid test\n"
        let mesh=try parse(two,"stl")
        XCTAssertEqual(mesh.vertices,triangle.vertices)
        XCTAssertEqual(mesh.triangles,[[0,1,2],[0,1,2]])
    }

    func testSTLTruncationInvalidCoordinatesAndDeclaredCountLimitAreRejected() throws {
        var binary=try triangle.stlData(); binary.removeLast()
        XCTAssertThrowsError(try TissueMesh.parse(data:binary,fileExtension:"stl"))
        XCTAssertThrowsError(try parse(asciiSTL.replacingOccurrences(of:"vertex 2",with:"vertex nan"),"stl"))
        XCTAssertThrowsError(try parse(asciiSTL.replacingOccurrences(of:"endsolid example mesh",with:""),"stl"))
        var huge=Data(repeating:0,count:80); appendLE(1_000_001,bytes:4,to:&huge)
        XCTAssertThrowsError(try TissueMesh.parse(data:huge,fileExtension:"stl"))
    }

    func testASCIIPLYImportsRGBAndSkipsDeclaredNormals() throws {
        let mesh=try parse(asciiPLY,"ply")
        XCTAssertEqual(mesh.vertices,triangle.vertices)
        XCTAssertEqual(mesh.triangles,triangle.triangles)
        XCTAssertEqual(mesh.colors,triangle.colors)
    }

    func testBinaryLittleEndianPLYSupportsMixedScalarTypesAndRGB() throws {
        let header="""
        ply
        format binary_little_endian 1.0
        element vertex 3
        property double x
        property float y
        property short z
        property uchar red
        property uchar green
        property uchar blue
        element face 1
        property list uchar uint vertex_indices
        end_header

        """
        var data=Data(header.utf8)
        for (index,point) in triangle.vertices.enumerated() {
            appendLE(point.x.bitPattern,bytes:8,to:&data)
            appendLE(UInt64(Float(point.y).bitPattern),bytes:4,to:&data)
            appendLE(0,bytes:2,to:&data)
            data.append(contentsOf:try XCTUnwrap(triangle.colors)[index])
        }
        data.append(3)
        for index in 0..<3 { appendLE(UInt64(index),bytes:4,to:&data) }
        let mesh=try TissueMesh.parse(data:data,fileExtension:"ply")
        XCTAssertEqual(mesh.vertices,triangle.vertices)
        XCTAssertEqual(mesh.colors,triangle.colors)
        data.removeLast()
        XCTAssertThrowsError(try TissueMesh.parse(data:data,fileExtension:"ply"))
    }

    func testPLYRejectsPolygonsInvalidIndicesCountsAndColorChannels() throws {
        for text in [asciiPLY.replacingOccurrences(of:"3 0 1 2",with:"4 0 1 2 0"),
                     asciiPLY.replacingOccurrences(of:"3 0 1 2",with:"3 0 1 3"),
                     asciiPLY.replacingOccurrences(of:"3 0 1 2",with:"3 0 -1 2"),
                     asciiPLY.replacingOccurrences(of:"element vertex 3",with:"element vertex 1000001"),
                     asciiPLY.replacingOccurrences(of:"255 0 0",with:"256 0 0"),
                     asciiPLY.replacingOccurrences(of:"property uchar blue\n",with:""),
                     asciiPLY.replacingOccurrences(of:"format ascii",with:"format binary_big_endian")] {
            XCTAssertThrowsError(try parse(text,"ply"))
        }
    }

    func testOBJPositiveNegativeAndSlashIndicesWithoutExternalMaterials() throws {
        let mesh=try parse("""
        # External material is intentionally not loaded.
        mtllib does-not-exist.mtl
        v 0 0 0
        v 2 0 0
        v 0 3 0 1
        vt 0 0
        vn 0 0 1
        usemtl example
        f 1/1/1 2/1/1 3/1/1
        f -3//1 -2//1 -1//1 # same face
        ""","obj")
        XCTAssertEqual(mesh.vertices,triangle.vertices)
        XCTAssertEqual(mesh.triangles,[[0,1,2],[0,1,2]])
        XCTAssertNil(mesh.colors)
    }

    func testOBJRejectsPolygonsZeroAndOutOfRangeIndicesAndUnknownUnits() throws {
        let base="v 0 0 0\nv 2 0 0\nv 0 3 0\n"
        for face in ["f 0 1 2","f -4 -2 -1","f 1 2 4","f 1 2 3 1","f 1 1 2"] {
            XCTAssertThrowsError(try parse(base+face,"obj"))
        }
        XCTAssertThrowsError(try parse(base.replacingOccurrences(of:"v 2 0 0",with:"v 2 0 0 2")+"f 1 2 3","obj"))
        XCTAssertThrowsError(try parse(base+"f 1 2 3","unknown"))
    }

    func testEmptyDegenerateNonfiniteMeshAndInvalidRGBFailWithoutIndexingCrash() throws {
        let invalid=[TissueMesh(vertices:[],triangles:[]),
                     TissueMesh(vertices:triangle.vertices,triangles:[[0,1,99]]),
                     TissueMesh(vertices:triangle.vertices,triangles:[[0,1]]),
                     TissueMesh(vertices:[.zero,LabPoint(x:1,y:0,z:0),LabPoint(x:2,y:0,z:0)],triangles:[[0,1,2]]),
                     TissueMesh(vertices:triangle.vertices,triangles:[[0,1,2]],colors:[[255]])]
        for mesh in invalid {
            XCTAssertThrowsError(try mesh.validate())
            XCTAssertThrowsError(try mesh.stlData())
        }
        let floatCollapse=TissueMesh(vertices:[LabPoint(x:99999,y:0,z:0),LabPoint(x:99999.0001,y:0,z:0),LabPoint(x:99999,y:1,z:0)],triangles:[[0,1,2]])
        try floatCollapse.validate()
        XCTAssertThrowsError(try floatCollapse.stlData())
        XCTAssertThrowsError(try TissueMesh.parse(data:Data(),fileExtension:"stl"))
    }
}
