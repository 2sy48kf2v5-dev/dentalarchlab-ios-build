import XCTest
@testable import DentalArchCapture

final class FastScanTests: XCTestCase {
    func testCadenceIncludesWorkInsteadOfAddingLongPause() {
        XCTAssertEqual(ScanCadence.delayNanoseconds(elapsed: 0), 200_000_000)
        XCTAssertEqual(Double(ScanCadence.delayNanoseconds(elapsed: 0.12)), 80_000_000, accuracy: 1)
        XCTAssertEqual(ScanCadence.delayNanoseconds(elapsed: 0.9), 20_000_000)
        XCTAssertEqual(ScanCadence.delayNanoseconds(elapsed: .nan), 200_000_000)
    }
    func testCommitContainsIdentityButNoImageBytes() throws {
        let profile = CaptureProfile(device: "test", lensPosition: 0.55, width: 1920, height: 1080, format: "JPEG")
        let hash = PreviewCommit.digest(Data("abc".utf8))
        XCTAssertEqual(hash, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
        let commit = PreviewCommit(session: "local", id: "frame", sha256: hash, profile: profile, timestamp: 1.5)
        let bytes = try JSONEncoder().encode(commit)
        let body = try XCTUnwrap(JSONSerialization.jsonObject(with: bytes) as? [String: Any])
        XCTAssertNil(body["image"]); XCTAssertNil(body["session"])
        XCTAssertEqual(body["timestamp_s"] as? Double, 1.5)
        XCTAssertEqual(body["sha256"] as? String, hash)
        XCTAssertLessThan(bytes.count, 1000)
    }
    func testWrongReceiptNeverAcknowledgesSavedImage() throws {
        let valid: [String: Any] = ["id": "a", "sha256": "hash", "count": 1, "accepted": true]
        XCTAssertNoThrow(try PreviewCommit.verify(valid, frame: "a", digest: "hash"))
        XCTAssertThrowsError(try PreviewCommit.verify(valid, frame: "b", digest: "hash"))
        XCTAssertThrowsError(try PreviewCommit.verify(valid, frame: "a", digest: "different"))
        var preview = valid; preview.removeValue(forKey: "count")
        XCTAssertThrowsError(try PreviewCommit.verify(preview, frame: "a", digest: "hash"))
    }
    func testOnlyCacheMissOrOlderEndpointFallsBackToImage() {
        for code in [404, 409] { XCTAssertTrue(BridgeHTTPError(status: code, message: "test").retryWithOriginal) }
        for code in [401, 403, 500, 507] { XCTAssertFalse(BridgeHTTPError(status: code, message: "test").retryWithOriginal) }
    }
    func testRegistrationCacheCannotCrossPairingOrSession() throws {
        let base = try XCTUnwrap(URL(string: "http://192.168.1.2:8765"))
        let key = RegistrationKey(base: base, token: "one", session: "s")
        let cache: Set<RegistrationKey> = [key]
        XCTAssertTrue(cache.contains(key))
        XCTAssertFalse(cache.contains(RegistrationKey(base: base, token: "two", session: "s")))
        XCTAssertFalse(cache.contains(RegistrationKey(base: base, token: "one", session: "next")))
    }
    func testMissingFlagsMeanCurrentSampleNotAccumulatedCoverage() throws {
        let feedback = LiveFeedback(sampleID: "sample", preview: false, usable: true,
            markers: [.init(id: 0, points: [[0.1, 0.2], [0.2, 0.2], [0.1, 0.3], [0.15, 0.25]])],
            views: [0: 4, 1: 4, 2: 4, 3: 4], frames: 12, targetFrames: 12, targetViews: 4,
            width: 1920, height: 1080, message: "test")
        XCTAssertTrue(feedback.coverageReached)
        XCTAssertEqual(feedback.missingInSample, [1, 2, 3])
    }
}
