import XCTest
@testable import DentalArchCapture

final class SelectedDentalPlanTests: XCTestCase {
    private func selectedPlan() throws -> DentalPlan {
        var plan = DentalPlan.vidaMUA9
        try plan.reset(markerIDs: [0, 3, 4, 5])
        for (id, tooth) in zip([0, 3, 4, 5], [46, 43, 33, 36]) { plan.assign(tooth, to: id) }
        return plan
    }
    func testFourActualIDsValidateAndFDIAssignmentUsesIDNotArrayIndex() throws {
        var plan = try selectedPlan()
        try plan.validate(count: 4)
        XCTAssertEqual(plan.markerIDs, [0, 3, 4, 5])
        XCTAssertEqual(plan.tooth(for: 5), 36)
        XCTAssertEqual(plan.tooth(for: 3), 43)
        plan.assign(46, to: 5)
        XCTAssertNil(plan.tooth(for: 0))
        XCTAssertEqual(plan.tooth(for: 5), 46)
        XCTAssertEqual(plan.tooth(for: 3), 43)
        let unchanged = plan
        plan.assign(36, to: 1)
        XCTAssertEqual(plan, unchanged, "An absent physical ID cannot mutate an array slot.")
    }
    func testReplacingPhysicalIDPreservesRetainedAssignmentsAndClearsNewID() throws {
        var plan = try selectedPlan()
        try plan.setMarkerIDs([0, 2, 4, 5])
        XCTAssertEqual(plan.tooth(for: 0), 46)
        XCTAssertNil(plan.tooth(for: 2))
        XCTAssertNil(plan.tooth(for: 3))
        XCTAssertEqual(plan.tooth(for: 4), 33)
        XCTAssertEqual(plan.tooth(for: 5), 36)
        XCTAssertTrue(plan.assignments.allSatisfy { $0.componentCode == "MG-MUASBU" })
        XCTAssertThrowsError(try plan.validate(count: 4), "The new ID must be assigned before scanning.")
    }
    func testReorderingPhysicalSlotsKeepsFDIAttachedToIDAndCanonicalIDsSorted() throws {
        var plan = try selectedPlan()
        try plan.setMarkerIDs([5, 0, 4, 3])
        XCTAssertEqual(plan.assignments.map(\.markerID), [5, 0, 4, 3])
        XCTAssertEqual(plan.markerIDs, [0, 3, 4, 5])
        XCTAssertEqual(plan.tooth(for: 5), 36)
        XCTAssertEqual(plan.tooth(for: 3), 43)
        try plan.validate(count: 4)
    }
    func testInvalidSelectionsDoNotPartiallyMutatePlan() throws {
        var plan = try selectedPlan()
        let original = plan
        for ids in [[0, 3, 4, 4], [0, 3, 4, 6], [-1, 3, 4, 5], [0, 3, 4], [], [0, 1, 2, 3, 4]] {
            XCTAssertThrowsError(try plan.setMarkerIDs(ids))
            XCTAssertEqual(plan, original)
            XCTAssertThrowsError(try plan.reset(markerIDs: ids, arch: "upper"))
            XCTAssertEqual(plan, original)
        }
        XCTAssertThrowsError(try plan.reset(markerIDs: [0, 3, 4, 5], arch: "unknown"))
        XCTAssertEqual(plan, original)
        var duplicate = plan; duplicate.assignments[1].markerID = 0
        XCTAssertThrowsError(try duplicate.validate(count: 4))
        XCTAssertThrowsError(try plan.validate(count: 6))
    }
    func testArchResetKeepsPhysicalIDsAndLegacyCountResetRemainsSequential() throws {
        var plan = try selectedPlan()
        try plan.reset(markerIDs: plan.markerIDs, arch: "upper")
        XCTAssertEqual(plan.markerIDs, [0, 3, 4, 5])
        XCTAssertTrue(plan.assignments.allSatisfy { $0.fdi == nil && $0.componentCode == "MG-MUASBU" })
        plan.reset(count: 6)
        XCTAssertEqual(plan.markerIDs, [0, 1, 2, 3, 4, 5])
        plan.reset(count: 4)
        XCTAssertEqual(plan.markerIDs, [0, 1, 2, 3])
    }
    func testSelectedPlanRoundTripAndExampleKeepActualIDs() throws {
        var plan = try selectedPlan()
        plan.useExample(count: 4)
        XCTAssertEqual(plan.markerIDs, [0, 3, 4, 5])
        try plan.validate(count: 4)
        let restored = try JSONDecoder().decode(DentalPlan.self, from: JSONEncoder().encode(plan))
        XCTAssertEqual(restored, plan)
        XCTAssertEqual(restored.tooth(for: 5), 36)
    }
    private func feedback() -> LiveFeedback {
        LiveFeedback(sampleID: "selected", preview: false, usable: false, markers: [],
            views: [0: 1, 3: 0, 4: 0, 5: 0], frames: 1, targetFrames: 1, targetViews: 1,
            width: 1920, height: 1080, message: "test")
    }
    func testGuidanceUsesOnlySelectedIDsAndNeverInfersMissingCoverage() throws {
        let plan = try selectedPlan()
        let initial = ScanGuidance.make(feedback: nil, plan: plan, markerCount: 4, mode: "trial")
        XCTAssertEqual(initial.pendingIDs, [0, 3, 4, 5])
        var sample = feedback()
        sample.unselectedIDs = [1, 2]
        let guidance = ScanGuidance.make(feedback: sample, plan: plan, markerCount: 4, mode: "trial")
        XCTAssertEqual(guidance.pendingIDs, [3, 4, 5])
        XCTAssertTrue(guidance.detail.contains("ID 1, 2"))
        XCTAssertTrue(guidance.action.contains("FDI planındaki seçili bayrak numaralarını kontrol edin"))
        XCTAssertFalse(guidance.isCoverageReady)
        var invalid = plan; invalid.assignments[3].markerID = 4
        XCTAssertEqual(ScanGuidance.make(feedback: sample, plan: invalid, markerCount: 4, mode: "scan").pendingIDs, [])
    }
    func testSmallFourDotGroupsExplainResolutionBeforeGenericGeometryFailure() throws {
        var sample = feedback()
        sample.candidateReasons = ["no_valid_geometry"]
        sample.candidates = [.init(id: 0, points: [[0.2, 0.2], [0.216, 0.2], [0.2, 0.213], [0.216, 0.213]],
                                   reason: "no_valid_geometry", accepted: false)]
        let guidance = ScanGuidance.make(feedback: sample, plan: try selectedPlan(), markerCount: 4, mode: "scan")
        XCTAssertTrue(guidance.action.contains("biraz yaklaştırın"))
        XCTAssertTrue(guidance.action.contains("Önizlemeyi büyütmek analiz edilen görüntüyü büyütmez"))
        XCTAssertFalse(guidance.isCoverageReady)
        XCTAssertEqual(sample.views[5], 0)
    }
    func testLargeOrIncompleteOrInvalidLayoutGroupsDoNotInventSizeDiagnosis() throws {
        for candidate in [
            LiveFeedback.Candidate(id: 0, points: [[0.2, 0.2], [0.3, 0.2], [0.2, 0.3], [0.3, 0.3]], reason: "no_valid_geometry", accepted: false),
            .init(id: 0, points: [[0.2, 0.2], [0.201, 0.2], [0.2, 0.201]], reason: "no_valid_geometry", accepted: false),
            .init(id: 0, points: [[0.2, 0.2], [0.201, 0.2], [0.2, 0.201], [0.201, 0.201]], reason: "invalid_layout", accepted: false)
        ] {
            var sample = feedback(); sample.candidates = [candidate]; sample.candidateReasons = [candidate.reason]
            let guidance = ScanGuidance.make(feedback: sample, plan: try selectedPlan(), markerCount: 4, mode: "scan")
            XCTAssertFalse(guidance.action.contains("biraz yaklaştırın"))
            XCTAssertFalse(guidance.isCoverageReady)
        }
    }
    func testUnselectedIDsAdvicePrecedesSmallCandidateWithoutInventingFDI() throws {
        var sample = feedback(); sample.unselectedIDs = [2]
        sample.candidateReasons = ["too_small"]
        let guidance = ScanGuidance.make(feedback: sample, plan: try selectedPlan(), markerCount: 4, mode: "trial")
        XCTAssertTrue(guidance.detail.contains("Seçili olmayan bayrak kimlikleri görüldü: ID 2"))
        XCTAssertTrue(guidance.action.contains("Yeni kayıt hazırla"))
        XCTAssertFalse(guidance.action.contains("biraz yaklaştırın"))
    }
}
