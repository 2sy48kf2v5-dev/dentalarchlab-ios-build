import Foundation
import XCTest
@testable import DentalArchCapture

/// Public synthetic fixtures only. These checks preserve physical IDs across
/// dictionary matching, multi-view geometry and the serialized optical rig.
final class NativeMarkerSelectionTests: XCTestCase {
    private let selection = [0, 3, 4, 5]
    private func boxed(_ ids: [Int]) -> [NSNumber] { ids.map { NSNumber(value: $0) } }
    private func fixture(_ name: String = "shadowed_vertical_arch") throws -> Data {
        try Data(contentsOf: XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "dat")))
    }
    private func camera(_ focal: Double = 1920) -> [String: Any] {
        ["schema_version": 1, "model": "opencv_pinhole", "K": [[focal,0,960],[0,focal,540],[0,0,1]],
         "image_size": [1920,1080], "distortion": [0.0,0,0,0,0]]
    }
    private func intrinsics(_ focal: Double = 1920) -> [String: Any] {
        ["K": [[focal,0,960],[0,focal,540],[0,0,1]], "width": 1920, "height": 1080,
         "source": "avfoundation_sample_buffer"]
    }
    private func observedIDs(_ result: [String: Any]) throws -> [Int] {
        try XCTUnwrap(result["observations"] as? [[String: Any]]).map { try XCTUnwrap($0["marker"] as? Int) }.sorted()
    }
    func testFourSelectedFromSixKeepActualIDsAndReportUnselectedIdentities() throws {
        let result = try DALNativeEngine.detect(image: fixture(), camera: camera(), markerIDs: boxed([5,0,4,3]))
        XCTAssertEqual(try observedIDs(result), selection)
        let quality = try XCTUnwrap(result["quality"] as? [String: Any])
        XCTAssertEqual(quality["selected_marker_ids"] as? [Int], selection)
        XCTAssertEqual(quality["unselected_marker_ids"] as? [Int], [1,2])
        let candidates = try XCTUnwrap(quality["candidate_diagnostics"] as? [[String: Any]])
        let unselected = candidates.filter { $0["reason"] as? String == "unselected_identity" }
        XCTAssertEqual(unselected.compactMap { $0["best_id"] as? Int }.sorted(), [1,2])
        XCTAssertTrue(unselected.allSatisfy { $0["accepted"] as? Bool == false })
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, true)
    }
    func testUnselectedFourIsNeverRelabelledAsZeroToThree() throws {
        let result = try DALNativeEngine.detect(image: fixture("macro_oblique_id4"), camera: camera(600), markerIDs: boxed([0,1,2,3]))
        XCTAssertEqual(try observedIDs(result), [])
        let quality = try XCTUnwrap(result["quality"] as? [String: Any])
        XCTAssertEqual(quality["unselected_marker_ids"] as? [Int], [4])
    }
    func testTrialAcceptsSelectedFourAndFiveWithoutBecomingMetric() throws {
        let result = try DALNativeEngine.detectTrial(image: fixture(), intrinsics: intrinsics(), markerIDs: boxed(selection))
        XCTAssertEqual(try observedIDs(result), selection)
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, false)
        XCTAssertThrowsError(try DALNativeEngine.detectTrial(image: fixture(), intrinsics: nil, markerIDs: boxed(selection)))
    }
    func testSelectionOrderCannotChangeDetectedGeometryOrQuality() throws {
        let data = try fixture()
        let first = try DALNativeEngine.detect(image: data, camera: camera(), markerIDs: boxed(selection))
        let reversed = try DALNativeEngine.detect(image: data, camera: camera(), markerIDs: boxed(Array(selection.reversed())))
        XCTAssertTrue(NSDictionary(dictionary: first).isEqual(to: reversed))
    }
    func testDuplicateAndInvalidSelectionsRejectAcrossAllThreeNativeEntryPoints() throws {
        let image = try fixture()
        let invalid: [[NSNumber]] = [boxed([0,1,2]), boxed([0,1,2,3,4]), boxed([0,0,4,5]), boxed([-1,3,4,5]),
            boxed([0,3,4,6]), [NSNumber(value: false),3,4,5], [0,NSNumber(value: 3.5),4,5],
            [0,NSNumber(value: Double.nan),4,5], [0,NSNumber(value: Double.infinity),4,5]]
        for ids in invalid {
            XCTAssertThrowsError(try DALNativeEngine.detect(image: image, camera: camera(), markerIDs: ids))
            XCTAssertThrowsError(try DALNativeEngine.detectTrial(image: image, intrinsics: intrinsics(), markerIDs: ids))
            XCTAssertThrowsError(try DALNativeEngine.reconstruct(observations: [], camera: camera(), markerIDs: ids))
        }
    }
    func testSelectedDuplicatePhysicalFlagRemainsRejected() throws {
        let result = try DALNativeEngine.detect(image: fixture("macro_duplicate_id4"), camera: camera(600), markerIDs: boxed(selection))
        XCTAssertEqual(try observedIDs(result), [])
        let q = try XCTUnwrap(result["quality"] as? [String: Any])
        XCTAssertTrue(try XCTUnwrap(q["rejected"] as? [String]).contains { $0.contains("Yinelenen") })
    }
    // Analytic points are independent of native project/reconstruction code.
    private func points(_ id: Int) -> [[Double]] {
        let outer = [[-3.0,2.4,0], [3.3,2,0], [-1.7,-2.8,0]]
        let weights = [[0.60,0.22,0.18],[0.20,0.60,0.20],[0.20,0.20,0.60],
                       [0.43,0.41,0.16],[0.43,0.16,0.41],[0.16,0.42,0.42]][id]
        let inner = (0..<3).map { axis in (0..<3).reduce(0.0) { $0 + outer[$1][axis]*weights[$1] } }
        return outer + [inner]
    }
    private func center(_ id: Int) -> [Double] { [Double(id)*9-22.5, 3*sin(Double(id)), Double(id)*0.7] }
    private func observations(_ ids: [Int]) -> [[String: Any]] {
        var rows: [[String: Any]] = []
        for frame in 0..<14 {
            let phase = Double(frame)*2*Double.pi/14
            let ax = Double.pi + 0.10*sin(phase), ay = 0.16*cos(phase)
            let tx = 24*cos(phase), ty = 16*sin(phase), tz = 175 + 10*sin(2*phase)
            for id in ids {
                let c = center(id)
                let projected = points(id).map { p -> [Double] in
                    let x = p[0]+c[0], y = p[1]+c[1], z = p[2]+c[2]
                    let xx = cos(ay)*x + sin(ay)*sin(ax)*y + sin(ay)*cos(ax)*z
                    let yy = cos(ax)*y - sin(ax)*z
                    let zz = -sin(ay)*x + cos(ay)*sin(ax)*y + cos(ay)*cos(ax)*z
                    return [1600*(xx+tx)/(zz+tz)+960,1600*(yy+ty)/(zz+tz)+540]
                }
                var span = 0.0
                for a in projected { for b in projected { span = max(span,hypot(a[0]-b[0],a[1]-b[1])) } }
                rows.append(["frame": String(format: "selection_%02d", frame), "marker": id,
                             "corners": projected, "min_side_px": span, "ambiguity_ratio": 0.0])
            }
        }
        return rows
    }
    private func verifyReconstruction(_ selected: [Int]) throws {
        let input = observations(Array(selected.reversed()))
        let result = try DALNativeEngine.reconstruct(observations: input, camera: camera(1600), markerIDs: boxed(Array(selected.reversed())))
        let anchor = try XCTUnwrap(selected.min())
        XCTAssertEqual(result["world_anchor_marker_id"] as? Int, anchor)
        XCTAssertEqual(result["missing_markers"] as? [Int], [])
        XCTAssertEqual(result["status"] as? String, "research_result")
        let markers = try XCTUnwrap(result["markers"] as? [[String: Any]])
        XCTAssertEqual(markers.compactMap { $0["id"] as? Int }.sorted(), selected)
        let rig = try XCTUnwrap(result["rig"] as? [String: Any])
        let templates = try XCTUnwrap(rig["markers"] as? [[String: Any]])
        XCTAssertEqual(templates.compactMap { $0["id"] as? Int }, selected)
        for template in templates {
            let id = try XCTUnwrap(template["id"] as? Int)
            let geometry = try XCTUnwrap(template["points_mm"] as? [[Double]])
            for corner in 0..<4 { for axis in 0..<3 { XCTAssertEqual(geometry[corner][axis],points(id)[corner][axis],accuracy: 1e-12) } }
            XCTAssertEqual(template["serial"] as? String, String(format: "DAL-D4-%02d",id))
        }
        for marker in markers {
            let id = try XCTUnwrap(marker["id"] as? Int)
            let transform = try XCTUnwrap(marker["T_world_marker"] as? [[Double]])
            for axis in 0..<3 { XCTAssertEqual(transform[axis][3],center(id)[axis]-center(anchor)[axis],accuracy: 0.05) }
            XCTAssertTrue(marker["T_world_mua"] is NSNull)
        }
        XCTAssertLessThan(try XCTUnwrap(result["reprojection_rms_px"] as? Double),0.1)
    }
    func testCustomSubsetReconstructionPreservesZeroThreeFourFiveGeometry() throws { try verifyReconstruction(selection) }
    func testCustomSubsetWithoutZeroUsesActualIDOneAsStableAnchor() throws { try verifyReconstruction([1,3,4,5]) }
    func testMissingAndUnselectedObservationsUsePhysicalMembership() throws {
        let result = try DALNativeEngine.reconstruct(observations: observations([3,4,5]), camera: camera(1600), markerIDs: boxed(selection))
        XCTAssertEqual(result["missing_markers"] as? [Int], [0])
        XCTAssertEqual(result["world_anchor_marker_id"] as? Int, 3)
        XCTAssertThrowsError(try DALNativeEngine.reconstruct(observations: observations([1,3,4,5]), camera: camera(1600), markerIDs: boxed(selection)))
    }
    func testAllSixAndLegacyCountRemainCompatible() throws {
        let data = try fixture()
        let old = try DALNativeEngine.detect(image: data, camera: camera(), markerCount: 6)
        let new = try DALNativeEngine.detect(image: data, camera: camera(), markerIDs: boxed(Array(0..<6)))
        XCTAssertEqual(try observedIDs(old), try observedIDs(new))
        XCTAssertTrue(NSArray(array: try XCTUnwrap(old["observations"] as? [Any])).isEqual(to: try XCTUnwrap(new["observations"] as? [Any])))
        let input = observations([0,1,2,3])
        let legacy = try DALNativeEngine.reconstruct(observations: input, camera: camera(1600), markerCount: 4)
        let selected = try DALNativeEngine.reconstruct(observations: input, camera: camera(1600), markerIDs: boxed([0,1,2,3]))
        XCTAssertTrue(NSDictionary(dictionary: legacy).isEqual(to: selected))
    }
}
