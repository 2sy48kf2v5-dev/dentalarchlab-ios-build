import AVFoundation
import Combine
import Foundation
import XCTest
@testable import DentalArchCapture

private final class ExperienceCamera: CameraControlling {
    typealias StartReply = (Result<CaptureProfile, Error>) -> Void
    typealias FrameReply = (Result<(Data, CaptureProfile, Double), Error>) -> Void
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    var onIlluminationChanged: ((TorchStatus) -> Void)?
    var starts: [StartReply] = []
    var focusRequests: [CameraFocusRequest] = []
    var lightRequests: [Bool] = []
    var compactRequests: [Bool] = []
    var pending: FrameReply?
    var cancelPendingOnStop = true
    var stopCount = 0
    var didStart: (() -> Void)?
    var didCapture: (() -> Void)?

    func configureIllumination(enabled: Bool) { lightRequests.append(enabled) }
    func start(focus: CameraFocusRequest, completion: @escaping StartReply) {
        focusRequests.append(focus); starts.append(completion); didStart?()
    }
    func capture(compactTrial: Bool, completion: @escaping FrameReply) {
        XCTAssertNil(pending, "Automatic scanning must never overlap capture requests")
        compactRequests.append(compactTrial); pending = completion; didCapture?()
    }
    func stop() {
        stopCount += 1
        if cancelPendingOnStop {
            let callback = pending; pending = nil
            callback?(.failure(LabError.message("Test camera stopped")))
        }
    }
    func deliver(_ data: Data, profile: CaptureProfile, timestamp: Double = 1) {
        let callback = pending; pending = nil
        callback?(.success((data, profile, timestamp)))
    }
}

@MainActor private final class ExperienceAudio: ScanAudioFeedbackControlling {
    var events: [ScanSoundEvent] = []
    var stopCount = 0
    var warning: String?
    var didPlay: ((ScanSoundEvent) -> Void)?
    func play(_ event: ScanSoundEvent) -> String? {
        events.append(event); didPlay?(event); return warning
    }
    func stop() { stopCount += 1 }
}

@MainActor final class ScanExperienceTests: XCTestCase {
    private struct Fixture {
        let model: CaptureModel
        let camera: ExperienceCamera
        let audio: ExperienceAudio
        let directory: URL
    }
    private var profile: CaptureProfile {
        CaptureProfile(device: "scan-experience-wide", lensPosition: 0.71342,
                       width: 1920, height: 1080, format: "fixture")
    }
    private func fixture(mode: String = "trial",
                         prepare: ((CaptureRepository) throws -> Void)? = nil) throws -> Fixture {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("scan-experience-" + UUID().uuidString)
        let repository = CaptureRepository(root: directory)
        try prepare?(repository)
        let camera = ExperienceCamera(), audio = ExperienceAudio()
        let model = CaptureModel(repository: repository, camera: camera, scanAudio: audio)
        model.mode = mode
        model.plan.useExample(count: 6)
        return Fixture(model: model, camera: camera, audio: audio, directory: directory)
    }
    private func cleanup(_ fixture: Fixture) {
        fixture.camera.cancelPendingOnStop = true
        fixture.model.stopCamera()
        try? FileManager.default.removeItem(at: fixture.directory)
    }
    private func calibration(_ repository: CaptureRepository, physical: Bool = true,
                             rms: Double = 0.2) throws {
        let creation = CaptureCreation(mode: "calibration", markerCount: 6, profile: profile,
                                       physical: physical, squareMM: physical ? 16.4 : nil, calibrationID: nil)
        try repository.create(creation)
        try repository.update(session: creation.id, state: "complete", message: "Fixture calibration")
        let envelope: [String: Any] = ["calibration": ["metadata": [
            "status": physical ? "measured_research" : "screen_only", "warnings": [String](),
            "rms_px": rms, "views": 20]]]
        try JSONSerialization.data(withJSONObject: envelope).write(to: repository.resultURL(creation.id))
    }
    private func completeAndAwaitCapture(_ fixture: Fixture, index: Int,
                                         profile actual: CaptureProfile? = nil) async {
        let captured = expectation(description: "A ready camera requests the next scan frame")
        fixture.camera.didCapture = { captured.fulfill() }
        fixture.camera.starts[index](.success(actual ?? profile))
        await fulfillment(of: [captured], timeout: 3)
        fixture.camera.didCapture = nil
    }
    private func completeAndAwaitStartup(_ fixture: Fixture, index: Int,
                                         profile actual: CaptureProfile? = nil) async {
        let settled = expectation(description: "Camera startup has finished")
        let observer = fixture.model.$cameraStarting.dropFirst().filter { !$0 }.prefix(1).sink { _ in settled.fulfill() }
        defer { observer.cancel() }
        fixture.camera.starts[index](.success(actual ?? profile))
        await fulfillment(of: [settled], timeout: 3)
    }
    private func pixels() throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "vertical_arch", withExtension: "dat"))
        return try Data(contentsOf: url)
    }

    func testGuidedTrialRequestsNoFrameBeforeReadinessThenStartsWithDefaultLight() async throws {
        let fixture = try fixture()
        defer { cleanup(fixture) }
        fixture.model.startGuidedScan()
        XCTAssertEqual(fixture.camera.focusRequests, [.automatic])
        XCTAssertEqual(fixture.camera.lightRequests, [true])
        XCTAssertTrue(fixture.model.cameraStarting)
        XCTAssertFalse(fixture.model.autoRunning)
        XCTAssertTrue(fixture.camera.compactRequests.isEmpty)
        await completeAndAwaitCapture(fixture, index: 0)
        XCTAssertTrue(fixture.model.ready)
        XCTAssertTrue(fixture.model.autoRunning)
        XCTAssertEqual(fixture.camera.compactRequests, [true])
        XCTAssertTrue(fixture.audio.events.isEmpty, "Starting capture is not marker acceptance")
    }

    func testGuidedStartRejectsIncompleteFDIAndMissingPhysicalCalibration() throws {
        let incomplete = try fixture()
        defer { cleanup(incomplete) }
        incomplete.model.plan.reset(count: 6)
        incomplete.model.startGuidedScan()
        XCTAssertTrue(incomplete.camera.starts.isEmpty)
        XCTAssertTrue(incomplete.model.status.contains("FDI"))
        for preparation in 0..<3 {
            let scan = try fixture(mode: "scan") { repository in
                if preparation == 1 { try self.calibration(repository, physical: false) }
                if preparation == 2 { try self.calibration(repository, rms: 0.9) }
            }
            defer { cleanup(scan) }
            XCTAssertTrue(scan.model.availableCalibrations.isEmpty)
            scan.model.startGuidedScan()
            XCTAssertTrue(scan.camera.starts.isEmpty)
            XCTAssertTrue(scan.camera.lightRequests.isEmpty)
            XCTAssertFalse(scan.model.autoRunning)
            XCTAssertTrue(scan.model.status.contains("fiziksel kalibrasyonu"))
        }
    }

    func testGuidedPhysicalScanRestoresSelectedCalibrationBeforeLosslessCapture() async throws {
        let fixture = try fixture(mode: "scan") { try self.calibration($0) }
        defer { cleanup(fixture) }
        fixture.model.chooseCalibration(try XCTUnwrap(fixture.model.availableCalibrations.first))
        fixture.model.startGuidedScan()
        XCTAssertEqual(fixture.camera.focusRequests, [.locked(profile.lensPosition)])
        XCTAssertTrue(fixture.camera.compactRequests.isEmpty)
        await completeAndAwaitCapture(fixture, index: 0)
        XCTAssertTrue(fixture.model.autoRunning)
        XCTAssertEqual(fixture.camera.compactRequests, [false])
        XCTAssertEqual(fixture.model.focus, profile.lensPosition)
    }

    func testTorchRestartRetainsRefocusedTrialRecordAndResumesOnlyAfterReadiness() async throws {
        var refocused = profile; refocused.lensPosition = 0.79123
        let fixture = try fixture { repository in
            let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: self.profile,
                                           physical: false, squareMM: nil, calibrationID: nil)
            try repository.create(creation)
            try repository.updateTrialProfile(session: creation.id, profile: refocused)
            try repository.acknowledge(session: creation.id, frame: "fixture",
                                       receipt: ["id": "fixture", "count": 5, "message": "5 accepted views"])
        }
        defer { cleanup(fixture) }
        let saved = try XCTUnwrap(fixture.model.sessions.first)
        fixture.model.select(saved); fixture.model.plan.useExample(count: 6)
        fixture.model.startGuidedScan()
        await completeAndAwaitCapture(fixture, index: 0, profile: refocused)
        let restarted = expectation(description: "Light change reopens the same camera after its pending frame stops")
        fixture.camera.didStart = { restarted.fulfill() }
        fixture.model.toggleTorch()
        XCTAssertFalse(fixture.model.ready)
        XCTAssertFalse(fixture.model.autoRunning)
        await fulfillment(of: [restarted], timeout: 3)
        fixture.camera.didStart = nil
        XCTAssertEqual(fixture.camera.lightRequests, [true, false])
        XCTAssertEqual(fixture.camera.focusRequests, [.locked(refocused.lensPosition), .locked(refocused.lensPosition)])
        XCTAssertEqual(fixture.camera.compactRequests.count, 1, "Readiness is required again after changing illumination")
        await completeAndAwaitCapture(fixture, index: 1, profile: refocused)
        XCTAssertTrue(fixture.model.autoRunning)
        XCTAssertEqual(fixture.model.currentID, saved.id)
        let retained = try fixture.model.repository.get(saved.id)
        XCTAssertEqual(retained.acceptedCount, 5)
        XCTAssertEqual(retained.creation.profile, profile)
        XCTAssertEqual(retained.activeProfile, refocused)
        XCTAssertFalse(fixture.model.torchEnabled)
    }

    func testTorchRestartCannotReplaceTheCanonicalCalibrationProfile() async throws {
        let fixture = try fixture(mode: "calibration") { repository in
            let creation = CaptureCreation(mode: "calibration", markerCount: 6, profile: self.profile,
                                           physical: true, squareMM: 16.4, calibrationID: nil)
            try repository.create(creation)
        }
        defer { cleanup(fixture) }
        let saved = try XCTUnwrap(fixture.model.sessions.first)
        fixture.model.select(saved); fixture.model.openCamera()
        await completeAndAwaitStartup(fixture, index: 0)
        let restarted = expectation(description: "Calibration light changes use a fresh camera startup")
        fixture.camera.didStart = { restarted.fulfill() }
        fixture.model.toggleTorch()
        await fulfillment(of: [restarted], timeout: 3)
        fixture.camera.didStart = nil
        XCTAssertEqual(fixture.camera.focusRequests, [.locked(profile.lensPosition), .locked(profile.lensPosition)])
        var wrong = profile; wrong.lensPosition = 0.52
        await completeAndAwaitStartup(fixture, index: 1, profile: wrong)
        XCTAssertFalse(fixture.model.ready)
        XCTAssertFalse(fixture.model.autoRunning)
        XCTAssertTrue(fixture.camera.compactRequests.isEmpty)
        XCTAssertEqual(try fixture.model.repository.get(saved.id).creation.profile, profile)
        XCTAssertTrue(fixture.model.status.contains("kayıtlı kalibrasyon profiline"))
    }

    func testCancelledTorchRestartDiscardsLateFrameWithoutCaptureOrSound() async throws {
        let fixture = try fixture()
        defer { cleanup(fixture) }
        fixture.model.startGuidedScan()
        await completeAndAwaitCapture(fixture, index: 0)
        fixture.camera.cancelPendingOnStop = false
        fixture.model.toggleTorch()
        fixture.model.stopCamera()
        let settled = expectation(description: "The cancelled scan discards its late camera frame")
        let observer = fixture.model.$analyzing.dropFirst().filter { !$0 }.prefix(1).sink { _ in settled.fulfill() }
        defer { observer.cancel() }
        fixture.camera.deliver(try pixels(), profile: profile)
        await fulfillment(of: [settled], timeout: 3)
        XCTAssertFalse(fixture.model.illuminationChanging)
        XCTAssertFalse(fixture.model.cameraStarting)
        XCTAssertFalse(fixture.model.ready)
        XCTAssertFalse(fixture.model.autoRunning)
        XCTAssertEqual(fixture.camera.starts.count, 1)
        XCTAssertEqual(fixture.camera.compactRequests.count, 1)
        XCTAssertNil(fixture.model.currentID)
        XCTAssertTrue(fixture.audio.events.isEmpty)
    }

    func testTorchPreferenceWhileStoppedIsDeferredAndSurvivesAnotherStop() async throws {
        let fixture = try fixture()
        defer { cleanup(fixture) }
        fixture.model.toggleTorch()
        fixture.model.stopCamera()
        XCTAssertFalse(fixture.model.torchEnabled)
        XCTAssertTrue(fixture.camera.lightRequests.isEmpty)
        fixture.model.startGuidedScan()
        XCTAssertEqual(fixture.camera.lightRequests, [false])
        await completeAndAwaitCapture(fixture, index: 0)
        XCTAssertFalse(fixture.model.torchEnabled)
        XCTAssertTrue(fixture.model.autoRunning)
    }

    func testSoundTestExposesPlaybackWarningAndRespectsMute() throws {
        let fixture = try fixture()
        defer { cleanup(fixture) }
        fixture.audio.warning = "Test output is muted"
        fixture.model.testScanSound()
        XCTAssertEqual(fixture.audio.events, [.test])
        XCTAssertEqual(fixture.model.soundStatus, fixture.audio.warning)
        fixture.model.toggleSound()
        XCTAssertFalse(fixture.model.soundEnabled)
        XCTAssertNil(fixture.model.soundStatus)
        XCTAssertEqual(fixture.audio.stopCount, 1)
        fixture.model.testScanSound()
        XCTAssertEqual(fixture.audio.events, [.test])
        XCTAssertTrue(fixture.model.soundStatus?.contains("sesini açın") == true)
        fixture.audio.warning = nil
        fixture.model.toggleSound(); fixture.model.testScanSound()
        XCTAssertEqual(fixture.audio.events, [.test, .test])
        XCTAssertNil(fixture.model.soundStatus)
    }

    func testRealNativeFlagCommitPlaysConfirmationThenCompletionOnce() async throws {
        let fixture = try fixture()
        defer { cleanup(fixture) }
        fixture.model.startGuidedScan()
        await completeAndAwaitCapture(fixture, index: 0)
        let finished = expectation(description: "Native six-flag identity result produces the completion cue")
        fixture.audio.didPlay = { event in if event == .completed { finished.fulfill() } }
        fixture.camera.deliver(try pixels(), profile: profile)
        await fulfillment(of: [finished], timeout: 20)
        fixture.audio.didPlay = nil
        XCTAssertEqual(fixture.audio.events, [.flagConfirmed, .completed])
        XCTAssertEqual(fixture.camera.compactRequests.count, 1)
        XCTAssertEqual(fixture.model.current?.acceptedCount, 1)
        XCTAssertEqual(fixture.model.resultSnapshot?.trial?.recognizedIDs, Array(0..<6))
        XCTAssertFalse(fixture.model.ready)
        XCTAssertFalse(fixture.model.autoRunning)
        XCTAssertEqual(fixture.model.pendingCount, 0)
        let stopsAfterCompletion = fixture.audio.stopCount
        fixture.model.leaveCaptureScreen(showingCompletedResult: true)
        XCTAssertEqual(fixture.audio.stopCount, stopsAfterCompletion,
                       "Automatic result navigation must not cut off its completion chime")
        fixture.model.stopCamera()
        XCTAssertGreaterThan(fixture.audio.stopCount, stopsAfterCompletion,
                             "Background/explicit stop must still silence all sound")
    }

    func testPausingDuringNativeCommitPreservesAcceptedFrameWithoutLateSound() async throws {
        let fixture = try fixture()
        defer { cleanup(fixture) }
        fixture.model.startGuidedScan()
        await completeAndAwaitCapture(fixture, index: 0)
        let committing = expectation(description: "Pause while the accepted frame is being committed")
        let settled = expectation(description: "In-flight native commit finishes after pause")
        let uploadObserver = fixture.model.$uploading.dropFirst().filter { $0 }.prefix(1).sink { _ in
            fixture.model.pauseAutomatic(); committing.fulfill()
        }
        let analysisObserver = fixture.model.$analyzing.dropFirst().filter { !$0 }.prefix(1).sink { _ in settled.fulfill() }
        defer { uploadObserver.cancel(); analysisObserver.cancel() }
        fixture.camera.deliver(try pixels(), profile: profile)
        await fulfillment(of: [committing, settled], timeout: 20, enforceOrder: true)
        XCTAssertTrue(fixture.model.ready, "Pausing keeps preview available")
        XCTAssertFalse(fixture.model.autoRunning)
        XCTAssertEqual(fixture.model.current?.acceptedCount, 1, "The real committed frame must remain saved")
        XCTAssertEqual(fixture.model.pendingCount, 0)
        XCTAssertNil(fixture.model.resultSnapshot)
        XCTAssertTrue(fixture.audio.events.isEmpty, "An in-flight acceptance must not restart audio after Pause")
    }
}
