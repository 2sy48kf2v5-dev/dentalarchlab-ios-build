import Foundation
import XCTest
@testable import DentalArchCapture

final class ResearchExportTests: XCTestCase {
    private struct Fixture {
        let directory: URL
        let repository: CaptureRepository
        let session: String
        let response: [String: Any]
    }
    private let world0: [[Double]] = [[0,0,1,1.25], [0,1,0,-2.5], [-1,0,0,3.75], [0,0,0,1]]
    private let world1: [[Double]] = [[1,0,0,-4.125], [0,1,0,5.0625], [0,0,1,6.5], [0,0,0,1]]
    private let mua0: [[Double]] = [[1,0,0,10.25], [0,0,-1,-20.5], [0,1,0,30.75], [0,0,0,1]]

    private func fixture(calibrated: Set<Int> = []) throws -> Fixture {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("research-export-" + UUID().uuidString)
        let repository = CaptureRepository(root: directory)
        let profile = CaptureProfile(device: "test-wide", lensPosition: 0.55, width: 1920, height: 1080, format: "test")
        var creation = CaptureCreation(mode: "scan", markerCount: 4, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        var plan = DentalPlan(); plan.useExample(count: 4); creation.dentalPlan = plan
        try repository.create(creation)
        try repository.update(session: creation.id, state: "complete", message: "Synthetic export fixture")
        let planJSON = try JSONSerialization.jsonObject(with: JSONEncoder().encode(plan))
        let markers: [[String: Any]] = [
            ["id": 0, "fdi": 46, "component_reference": "MG-MUASB9", "T_world_marker": world0,
             "T_world_mua": calibrated.contains(0) ? mua0 as Any : NSNull()],
            ["id": 1, "fdi": 43, "component_reference": "MG-MUASB9", "T_world_marker": world1,
             "T_world_mua": calibrated.contains(1) ? world1 as Any : NSNull()]
        ]
        let response: [String: Any] = [
            "id": creation.id, "state": "complete", "mode": "scan", "message": "Synthetic export fixture",
            "dental_plan": planJSON,
            "result": ["units": "mm", "markers": markers, "reprojection_rms_px": 0.125,
                       "physical_accuracy_um": NSNull(), "warnings": [String]()]
        ]
        _ = try repository.cacheResult(session: creation.id, response: response)
        return Fixture(directory: directory, repository: repository, session: creation.id, response: response)
    }
    private func export(_ fixture: Fixture) throws -> [URL] {
        try ResearchExport.write(response: fixture.response, repository: fixture.repository, session: fixture.session)
    }
    private func contents(_ name: String, files: [URL]) throws -> String {
        try String(contentsOf: XCTUnwrap(files.first { $0.lastPathComponent == name }), encoding: .utf8)
    }
    private func handoff(_ files: [URL]) throws -> [String: Any] {
        let url = try XCTUnwrap(files.first { $0.lastPathComponent == "cad_handoff.json" })
        return try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
    }

    func testCSVUsesPortableDecimalsFDIReferenceAndPositiveAxis() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.directory) }
        let files = try export(f)
        let csv = try contents("research_coordinates.csv", files: files)
        let lines = csv.split(separator: "\n").map(String.init)
        XCTAssertEqual(lines.count, 3)
        XCTAssertEqual(lines[0], "marker_id,fdi,component_reference,coordinate_type,x_mm,y_mm,z_mm,axis_x,axis_y,axis_z,physical_accuracy_um")
        XCTAssertEqual(lines[1], "0,46,\"MG-MUASB9\",MARKER,1.250000000,-2.500000000,3.750000000,1.000000000,0.000000000,0.000000000,")
        XCTAssertEqual(lines[2], "1,43,\"MG-MUASB9\",MARKER,-4.125000000,5.062500000,6.500000000,0.000000000,0.000000000,1.000000000,")
        for line in lines.dropFirst() {
            let columns = line.split(separator: ",", omittingEmptySubsequences: false)
            XCTAssertEqual(columns.count, 11)
            for cell in columns[4...9] { XCTAssertNotNil(Double(cell)) }
            XCTAssertEqual(columns[10], "")
        }
    }

    func testPLYContainsMillimetreCentresFiveMillimetreAxesAndMatchingEdges() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.directory) }
        let files = try export(f)
        let lines = try contents("research_marker_axes.ply", files: files).split(separator: "\n").map(String.init)
        XCTAssertEqual(lines.first, "ply")
        XCTAssertTrue(lines.contains("format ascii 1.0"))
        XCTAssertTrue(lines.contains("element vertex 4"))
        XCTAssertTrue(lines.contains("element edge 2"))
        let header = try XCTUnwrap(lines.firstIndex(of: "end_header"))
        let records = Array(lines.dropFirst(header + 1))
        XCTAssertEqual(records, [
            "1.250000000 -2.500000000 3.750000000 0 170 150",
            "6.250000000 -2.500000000 3.750000000 255 170 0",
            "-4.125000000 5.062500000 6.500000000 0 170 150",
            "-4.125000000 5.062500000 11.500000000 255 170 0",
            "0 1", "2 3"
        ])
        XCTAssertFalse(lines.contains(where: { $0.hasPrefix("element face") }))
    }

    func testPartialMUAUsesCalibratedCoordinateOnlyForItsMatchingID() throws {
        let f = try fixture(calibrated: [0]); defer { try? FileManager.default.removeItem(at: f.directory) }
        let files = try export(f)
        let csv = try contents("research_coordinates.csv", files: files)
        XCTAssertTrue(csv.contains("0,46,\"MG-MUASB9\",MUA,10.250000000,-20.500000000,30.750000000,0.000000000,-1.000000000,0.000000000,"))
        XCTAssertTrue(csv.contains("1,43,\"MG-MUASB9\",MARKER,-4.125000000,5.062500000,6.500000000,"))
        let metadata = try handoff(files)
        XCTAssertEqual(metadata["mua_calibration_available"] as? Bool, true)
        XCTAssertEqual(metadata["all_mua_calibrated"] as? Bool, false)
        XCTAssertEqual(metadata["mua_calibrated_marker_ids"] as? [Int], [0])
        XCTAssertTrue(metadata["physical_accuracy_um"] is NSNull)
        XCTAssertEqual(metadata["exocad_library_match_verified"] as? Bool, false)
        let ply = try contents("research_marker_axes.ply", files: files)
        XCTAssertTrue(ply.contains("10.250000000 -25.500000000 30.750000000 255 170 0"))
    }

    func testUncalibratedHandoffNeverInventsMUAOrExocadCompatibility() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.directory) }
        let files = try export(f)
        let metadata = try handoff(files)
        XCTAssertEqual(metadata["units"] as? String, "mm")
        XCTAssertEqual(metadata["research_only"] as? Bool, true)
        XCTAssertEqual(metadata["mua_calibration_available"] as? Bool, false)
        XCTAssertEqual(metadata["all_mua_calibrated"] as? Bool, false)
        XCTAssertEqual(metadata["mua_calibrated_marker_ids"] as? [Int], [])
        XCTAssertEqual(metadata["exocad_library_match_verified"] as? Bool, false)
        XCTAssertTrue(metadata["physical_accuracy_um"] is NSNull)
        let plan = try XCTUnwrap(metadata["dental_plan"] as? [String: Any])
        let assignments = try XCTUnwrap(plan["assignments"] as? [[String: Any]])
        XCTAssertEqual(assignments.first?["fdi"] as? Int, 46)
        XCTAssertFalse(try contents("research_coordinates.csv", files: files).contains(",MUA,"))
    }

    func testEveryReturnedMarkerMappedSetsAllFlagButAccuracyRemainsUnknown() throws {
        let f = try fixture(calibrated: [0, 1]); defer { try? FileManager.default.removeItem(at: f.directory) }
        let files = try export(f)
        let metadata = try handoff(files)
        XCTAssertEqual(metadata["all_mua_calibrated"] as? Bool, true)
        XCTAssertEqual(metadata["mua_calibrated_marker_ids"] as? [Int], [0, 1])
        XCTAssertTrue(metadata["physical_accuracy_um"] is NSNull)
        XCTAssertEqual(metadata["exocad_library_match_verified"] as? Bool, false)
    }

    func testExistingExportsSurviveRepositoryReopenAndKeepOriginalJSON() throws {
        let f = try fixture(calibrated: [0]); defer { try? FileManager.default.removeItem(at: f.directory) }
        let original = try Data(contentsOf: f.repository.resultURL(f.session))
        let written = try export(f)
        let reopened = CaptureRepository(root: f.directory)
        let listed = try ResearchExport.existing(repository: reopened, session: f.session)
        XCTAssertEqual(Set(written.map(\.lastPathComponent)), Set(["result.json", "research_coordinates.csv", "research_marker_axes.ply", "cad_handoff.json", "OKU.txt"]))
        XCTAssertEqual(Set(listed), Set(written))
        XCTAssertEqual(try Data(contentsOf: reopened.resultURL(f.session)), original)
        XCTAssertTrue(try contents("OKU.txt", files: listed).contains("PLY bir diş/abutment yüzey taraması değildir"))
    }
}
