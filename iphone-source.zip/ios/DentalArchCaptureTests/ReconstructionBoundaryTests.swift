import Foundation
import XCTest
@testable import DentalArchCapture

/// Exercises persisted Swift dictionaries -> Objective-C++ -> real solver.
/// Analytic image points isolate this boundary; these are not physical scans.
final class ReconstructionBoundaryTests: XCTestCase {
    private typealias Matrix = [[Double]]
    private let identity: Matrix = [[1,0,0,0], [0,1,0,0], [0,0,1,0], [0,0,0,1]]

    private func multiply(_ a: Matrix, _ b: Matrix) -> Matrix {
        (0..<4).map { row in (0..<4).map { column in
            (0..<4).reduce(0.0) { $0 + a[row][$1] * b[$1][column] }
        } }
    }
    private func pose(_ rotation: [Double], _ translation: [Double]) -> Matrix {
        var result = identity
        let angle = sqrt(rotation.reduce(0) { $0 + $1*$1 })
        if angle > 0 {
            let axis = rotation.map { $0 / angle }, c = cos(angle), s = sin(angle)
            let cross: Matrix = [[0,-axis[2],axis[1]], [axis[2],0,-axis[0]], [-axis[1],axis[0],0]]
            for row in 0..<3 { for column in 0..<3 {
                result[row][column] = (row == column ? c : 0) + (1-c)*axis[row]*axis[column] + s*cross[row][column]
            } }
        }
        for row in 0..<3 { result[row][3] = translation[row] }
        return result
    }
    private func inverse(_ matrix: Matrix) -> Matrix {
        var result = identity
        for row in 0..<3 {
            for column in 0..<3 { result[row][column] = matrix[column][row] }
            result[row][3] = -(0..<3).reduce(0.0) { $0 + result[row][$1] * matrix[$1][3] }
        }
        return result
    }
    private func point(_ matrix: Matrix, _ point: [Double]) -> [Double] {
        var result: [Double] = []
        for row in 0..<3 {
            var rotated: Double = 0.0
            for axis in 0..<3 {
                let component: Double = matrix[row][axis] * point[axis]
                rotated += component
            }
            let translated: Double = matrix[row][3] + rotated
            result.append(translated)
        }
        return result
    }
    private func encoded(_ object: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
    }
    private func seed(mode: String = "scan", state: String = "collecting") -> (state: [String: Any], truth: [Matrix]) {
        let outer = [[-3.0,2.4,0], [3.3,2.0,0], [-1.7,-2.8,0]]
        let weights = [[0.60,0.22,0.18], [0.20,0.60,0.20], [0.20,0.20,0.60],
                       [0.43,0.41,0.16], [0.43,0.16,0.41], [0.16,0.42,0.42]]
        var truth: [Matrix] = (0..<6).map { id in
            let a = Double.pi * Double(id) / 5
            return pose([0.025*sin(a),0.02*cos(a),0.08*cos(a)], [25*cos(a),28*sin(a),1.5*sin(2*a)])
        }
        let anchor = truth[0]
        truth = truth.map { multiply(inverse(anchor), $0) }
        var frames: [[String: Any]] = []
        for index in 0..<14 {
            let phase = 2 * Double.pi * Double(index) / 14
            let camera = multiply(multiply(pose([0.13*sin(phase),0.16*cos(phase),0.015*sin(2*phase)],
                [12*cos(phase),10+8*sin(phase),165+10*sin(2*phase)]), pose([Double.pi,0,0], [0,0,0])), anchor)
            let frameID = String(format: "%032x", index+1)
            var rows: [[String: Any]] = []
            for id in 0..<6 {
                let inner = (0..<3).map { axis in (0..<3).reduce(0.0) { $0 + outer[$1][axis]*weights[id][$1] } }
                let transform = multiply(camera, truth[id])
                let corners: [[Double]] = (outer + [inner]).map { landmark in
                    let p = point(transform, landmark)
                    return [1600*p[0]/p[2]+960,1585*p[1]/p[2]+540]
                }
                var span = 0.0
                for a in corners { for b in corners { span = max(span, hypot(a[0]-b[0],a[1]-b[1])) } }
                rows.append(["frame": frameID, "marker": id, "corners": corners,
                             "min_side_px": span, "ambiguity_ratio": 0.0, "blur_laplacian": 100.0])
            }
            frames.append(["id": frameID, "timestamp_s": Double(index), "observations": rows])
        }
        let camera: [String: Any] = ["schema_version": 1, "model": "opencv_pinhole",
            "K": [[1600.0,0,960], [0,1585.0,540], [0,0,1]], "distortion": [0.0,0,0,0,0], "image_size": [1920,1080]]
        return (["id": captureID(), "engine": "iphone_native_v1", "mode": mode,
            "state": state, "marker_count": 6, "camera": camera, "accepted": frames,
            "count": frames.count, "research_only": true, "physical_accuracy_um": NSNull(),
            "message": state == "error" ? "Hesap tamamlanamadı: Veri sözlüğü bekleniyor." : "Synthetic boundary fixture"], truth)
    }
    private func write(_ state: [String: Any], folder: URL) throws -> String {
        let id = try XCTUnwrap(state["id"] as? String)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try encoded(state).write(to: folder.appendingPathComponent(id + ".json"))
        return id
    }
    private func folder() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("reconstruction-boundary-" + UUID().uuidString)
    }
    private func assertGeometry(_ response: [String: Any], truth: [Matrix], file: StaticString = #filePath, line: UInt = #line) throws {
        XCTAssertEqual(response["state"] as? String, "complete", file: file, line: line)
        let result = try XCTUnwrap(response["result"] as? [String: Any], file: file, line: line)
        XCTAssertEqual(result["observations_used"] as? Int, 84, file: file, line: line)
        XCTAssertEqual(result["frame_count"] as? Int, 14, file: file, line: line)
        XCTAssertEqual(result["status"] as? String, "research_result", file: file, line: line)
        XCTAssertTrue(result["physical_accuracy_um"] is NSNull, file: file, line: line)
        let markers = try XCTUnwrap(result["markers"] as? [[String: Any]], file: file, line: line)
        XCTAssertEqual(markers.compactMap { $0["id"] as? Int }.sorted(), [0,1,2,3,4,5], file: file, line: line)
        for marker in markers {
            let id = try XCTUnwrap(marker["id"] as? Int, file: file, line: line)
            let actual = try XCTUnwrap(marker["T_world_marker"] as? Matrix, file: file, line: line)
            XCTAssertEqual(actual.count, 4, file: file, line: line)
            for row in actual { XCTAssertEqual(row.count, 4, file: file, line: line); XCTAssertTrue(row.allSatisfy(\.isFinite), file: file, line: line) }
            let distance = sqrt((0..<3).reduce(0.0) { $0 + pow(actual[$1][3]-truth[id][$1][3], 2) })
            XCTAssertLessThan(distance, 0.05, "Synthetic marker \(id) centre", file: file, line: line)
            let cosine = (0..<3).reduce(0.0) { $0 + actual[$1][2]*truth[id][$1][2] }
            XCTAssertLessThan(acos(min(1,max(-1,cosine)))*180/Double.pi, 0.2, file: file, line: line)
            XCTAssertTrue(marker["T_world_mua"] is NSNull, file: file, line: line)
        }
    }

    func testPersistedSixMarkerScanCrossesSwiftNativeBoundaryAndSurvivesReopen() async throws {
        let fixture = seed(), location = folder(); defer { try? FileManager.default.removeItem(at: location) }
        let id = try write(fixture.state, folder: location)
        let result = try await OfflineEngine(root: location).request("sessions/\(id)/process", body: nil)
        try assertGeometry(result, truth: fixture.truth)
        let reopened = OfflineEngine(root: location)
        let saved = try await reopened.request("sessions/\(id)", body: nil)
        let repeated = try await reopened.request("sessions/\(id)/process", body: nil)
        XCTAssertEqual(try encoded(saved), try encoded(result))
        XCTAssertEqual(try encoded(repeated), try encoded(result))
    }

    func testPriorDictionaryErrorRetriesSameSavedFramesWithoutRecapture() async throws {
        let fixture = seed(state: "error"), location = folder(); defer { try? FileManager.default.removeItem(at: location) }
        let id = try write(fixture.state, folder: location)
        let result = try await OfflineEngine(root: location).request("sessions/\(id)/process", body: nil)
        try assertGeometry(result, truth: fixture.truth)
        XCTAssertTrue(NSDictionary(dictionary: ["accepted": result["accepted"]!]).isEqual(to: ["accepted": fixture.state["accepted"]!]))
    }

    func testMalformedSavedObservationArrayFailsClearlyAndPreservesEveryFrame() async throws {
        var fixture = seed().state
        var frames = try XCTUnwrap(fixture["accepted"] as? [[String: Any]])
        frames[2]["observations"] = [["nested-array-is-not-a-dictionary"]]
        fixture["accepted"] = frames
        let location = folder(); defer { try? FileManager.default.removeItem(at: location) }
        let id = try write(fixture, folder: location), engine = OfflineEngine(root: location)
        for _ in 0..<2 {
            do { _ = try await engine.request("sessions/\(id)/process", body: nil); XCTFail("Malformed observations were silently discarded") }
            catch { XCTAssertTrue(error.localizedDescription.contains("3. karenin bayrak verisi geçersiz")) }
            let saved = try await engine.request("sessions/\(id)", body: nil)
            XCTAssertEqual(saved["state"] as? String, "error")
            XCTAssertNil(saved["result"])
            XCTAssertTrue(NSDictionary(dictionary: ["accepted": saved["accepted"]!]).isEqual(to: ["accepted": frames]))
        }
    }

    func testObservationExtractionFlattensDictionariesAndRejectsBrokenFrameLinks() throws {
        let state = seed().state
        let frames = try XCTUnwrap(state["accepted"] as? [[String: Any]])
        let rows = try OfflineEngine.reconstructionObservations(frames)
        XCTAssertEqual(rows.count, 84)
        XCTAssertTrue(rows.allSatisfy { $0["marker"] is Int && $0["frame"] is String })
        var broken = frames
        var first = try XCTUnwrap(broken[0]["observations"] as? [[String: Any]])
        first[0]["frame"] = "wrong-frame"; broken[0]["observations"] = first
        XCTAssertThrowsError(try OfflineEngine.reconstructionObservations(broken))
        broken = frames; broken[0]["observations"] = NSNull()
        XCTAssertThrowsError(try OfflineEngine.reconstructionObservations(broken))
        broken = frames; broken[0]["observations"] = [] as [Any]
        XCTAssertThrowsError(try OfflineEngine.reconstructionObservations(broken))
    }

    func testTwoDimensionalTrialDoesNotEnterReconstructionOrInventCoordinates() async throws {
        var fixture = seed(mode: "trial").state
        fixture["camera"] = NSNull()
        let location = folder(); defer { try? FileManager.default.removeItem(at: location) }
        let id = try write(fixture, folder: location)
        let result = try await OfflineEngine(root: location).request("sessions/\(id)/process", body: nil)
        XCTAssertEqual(result["state"] as? String, "complete")
        XCTAssertNil(result["result"])
        let summary = try XCTUnwrap(result["trial_summary"] as? [String: Any])
        XCTAssertEqual(summary["recognized_ids"] as? [Int], [0,1,2,3,4,5])
        XCTAssertEqual(summary["metric"] as? String, "identity_only_no_3d")
        XCTAssertTrue(summary["physical_accuracy_um"] is NSNull)
    }
}
