import Foundation
import XCTest
@testable import DentalArchCapture

final class ExocadHandoffTests: XCTestCase {
    private var identity: [[Double]] { [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]] }
    private func profile() -> ExocadLibraryProfile {
        ExocadLibraryProfile(schema: 1, manufacturer: "MegaGen", implantSystem: "TEST ST", connectionLevel: "mua",
            componentReference: "MG-MUASB9", library: "TEST_LIBRARY", type: "TYPE<&", subtype: "SUB",
            configSHA256: String(repeating: "a", count: 64), libraryVersion: "TEST", exocadVersion: "TEST",
            referenceReport: "SYNTHETIC SOFTWARE TEST ONLY", source: "reference_metrology", transform: identity,
            maxAlignmentRMSMM: 0.1, maxCheckpointErrorMM: 0.2)
    }

    func testMatrixCompositionAndTransposeKeepTranslationAndRotation() throws {
        var p = profile(); p.transform = [[1,0,0,2],[0,0,-1,3],[0,1,0,4],[0,0,0,1]]
        let world: [[Double]] = [[0,-1,0,10],[1,0,0,20],[0,0,1,30],[0,0,0,1]]
        let xml = try XCTUnwrap(String(data: ExocadHandoff.xml(worldMUA: world, profile: p), encoding: .utf8))
        // Rz90 * (2,3,4) + (10,20,30) = (7,22,34).
        XCTAssertTrue(xml.contains("<_30>7.000000000000</_30>"))
        XCTAssertTrue(xml.contains("<_31>22.000000000000</_31>"))
        XCTAssertTrue(xml.contains("<_32>34.000000000000</_32>"))
        XCTAssertTrue(xml.contains("<_03>0.000000000000</_03>"))
        XCTAssertTrue(xml.contains("<_01>1.000000000000</_01>"))
        XCTAssertTrue(xml.contains("<_20>1.000000000000</_20>"))
        XCTAssertTrue(xml.contains("<Type>TYPE&lt;&amp;</Type>"))
        XCTAssertFalse(xml.contains("<Position>")); XCTAssertFalse(xml.contains("<Axis>"))
    }

    func testXMLIsWellFormedAndOnlyOnePoseRepresentation() throws {
        let data = try ExocadHandoff.xml(worldMUA: identity, profile: profile())
        let parser = XMLParser(data: data)
        XCTAssertTrue(parser.parse(), parser.parserError?.localizedDescription ?? "")
        var p = profile(); p.subtype = nil
        let text = String(decoding: try ExocadHandoff.xml(worldMUA: identity, profile: p), as: UTF8.self)
        XCTAssertFalse(text.contains("<Subtype>"))
        XCTAssertTrue(text.contains("OpticalModelScan"))
    }

    func testCannotSubstituteNineMillimetreLabelForLibraryMapping() throws {
        let mutations: [(inout ExocadLibraryProfile)->Void] = [
            { $0.library = "" }, { $0.configSHA256 = "" }, { $0.referenceReport = "" },
            { $0.connectionLevel = "implant" }, { $0.source = "nominal_cad" },
            { $0.transform![0][0] = 1.01 }, { $0.transform![2][2] = -1 },
            { $0.maxAlignmentRMSMM = 0 }, { $0.maxCheckpointErrorMM = .nan },
            { $0.library = "../wrong" }, { $0.componentReference = "9mm" }
        ]
        for mutate in mutations { var p = profile(); mutate(&p); XCTAssertThrowsError(try p.validate()) }
    }

    func testTraceabilityRoundTripAndCurrentUploadedComponentCode() throws {
        var p = profile(); p.componentReference = "MG-MUASBU"
        let loaded = try ExocadLibraryProfile.load(JSONEncoder().encode(p))
        XCTAssertEqual(loaded.componentReference, "MG-MUASBU")
        XCTAssertEqual(loaded.transform, identity)
    }

    func testVerifiedLibraryIdentityDoesNotInventPhysicalPose() throws {
        let profile = ExocadLibraryProfile.vidaMUA9
        try profile.validate()
        XCTAssertEqual(profile.library, "MegaGen_N_Type_MUA_Direkt_9mm")
        XCTAssertEqual(profile.type, "VidaTrkiye")
        XCTAssertEqual(profile.subtype, "48Direkt")
        XCTAssertNil(profile.transform)
        XCTAssertThrowsError(try ExocadHandoff.xml(worldMUA: identity, profile: profile))
    }

    func testUnsafeProjectNamesNeverBecomeFilePaths() throws {
        for name in ["", "../escape", "x/y", "x\\y", "C:case", "A.dentalProject", "CON", "NUL.txt", "trailing.", "x\nq"] {
            XCTAssertThrowsError(try ExocadHandoff.projectName(name))
        }
        XCTAssertEqual(try ExocadHandoff.projectName("Model 29-09"), "Model 29-09")
    }
}
