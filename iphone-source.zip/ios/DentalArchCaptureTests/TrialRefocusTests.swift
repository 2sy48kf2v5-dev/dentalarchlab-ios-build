import AVFoundation
import XCTest
@testable import DentalArchCapture

private final class RefocusCamera: CameraControlling {
    let session = AVCaptureSession()
    var onInterruption: ((String) -> Void)?
    var requests: [CameraFocusRequest] = []
    var completions: [(Result<CaptureProfile, Error>) -> Void] = []
    func start(focus: CameraFocusRequest, completion: @escaping (Result<CaptureProfile, Error>) -> Void) {
        requests.append(focus); completions.append(completion)
    }
    func stop() {}
    func capture(compactTrial: Bool, completion: @escaping (Result<(Data, CaptureProfile, Double), Error>) -> Void) {
        XCTFail("The refocus state test must not invent camera pixels")
        completion(.failure(LabError.message("Unexpected capture")))
    }
}

@MainActor final class TrialRefocusTests: XCTestCase {
    private var profile: CaptureProfile {
        CaptureProfile(device: "focus-test-wide", lensPosition: 0.55, width: 1920, height: 1080, format: "test")
    }
    private func settled(_ model: CaptureModel) async {
        for _ in 0..<100 where model.cameraStarting { try? await Task.sleep(nanoseconds: 10_000_000) }
    }
    func testOnlyIdentityTrialMayChangeFocusAndAllOtherOpticalFieldsStayExact() {
        var focused = profile; focused.lensPosition = 0.73
        XCTAssertTrue(profile.accepts(focused, mode: "trial"))
        XCTAssertFalse(profile.accepts(focused, mode: "scan"))
        XCTAssertFalse(profile.accepts(focused, mode: "calibration"))
        XCTAssertTrue(profile.accepts(profile, mode: "scan"))
        var changedDevice = focused; changedDevice.device = "different-wide"
        var changedFormat = focused; changedFormat.format = "other-format"
        var changedZoom = focused; changedZoom.zoom = 2
        var changedSize = focused; changedSize.width = 1280
        var changedOrientation = focused; changedOrientation.orientation = "portrait"
        var invalidFocus = focused; invalidFocus.lensPosition = .nan
        for wrong in [changedDevice, changedFormat, changedZoom, changedSize, changedOrientation, invalidFocus] {
            XCTAssertFalse(profile.accepts(wrong, mode: "trial"))
        }
    }
    func testMidTrialRefocusRetainsFiveAcceptedViewsAndOriginalCreationThenRestoresNewFocus() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let repo = CaptureRepository(root: directory), camera = RefocusCamera()
        let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        try repo.create(creation)
        try repo.acknowledge(session: creation.id, frame: "test", receipt: ["id": "test", "count": 5, "message": "5/6"])
        let model = CaptureModel(repository: repo, camera: camera)
        defer { model.stopCamera() }
        model.select(try repo.get(creation.id)); model.openCamera()
        XCTAssertEqual(camera.requests, [.locked(profile.lensPosition)])
        camera.completions[0](.success(profile)); await settled(model)
        XCTAssertTrue(model.canRefocus)
        model.refocusCamera()
        XCTAssertEqual(camera.requests.last, .automatic)
        var focused = profile; focused.lensPosition = 0.73123
        camera.completions[1](.success(focused)); await settled(model)
        XCTAssertTrue(model.ready); XCTAssertFalse(model.autoRunning)
        XCTAssertEqual(model.currentID, creation.id)
        XCTAssertEqual(model.current?.acceptedCount, 5)
        XCTAssertEqual(model.current?.creation.profile, profile)
        XCTAssertEqual(model.current?.activeProfile, focused)
        model.stopCamera()
        let restored = CaptureModel(repository: repo, camera: camera)
        defer { restored.stopCamera() }
        restored.select(try repo.get(creation.id)); restored.openCamera()
        XCTAssertEqual(camera.requests.last, .locked(focused.lensPosition))
        camera.completions[2](.success(focused)); await settled(restored)
        XCTAssertTrue(restored.ready)
    }
    func testRefocusRejectsDifferentDeviceAndDoesNotRewriteSavedProfile() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let repo = CaptureRepository(root: directory), camera = RefocusCamera()
        let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        try repo.create(creation)
        let model = CaptureModel(repository: repo, camera: camera)
        defer { model.stopCamera() }
        model.select(try repo.get(creation.id)); model.openCamera()
        camera.completions[0](.success(profile)); await settled(model)
        model.refocusCamera()
        var wrong = profile; wrong.device = "telephoto"; wrong.lensPosition = 0.72
        camera.completions[1](.success(wrong)); await settled(model)
        XCTAssertFalse(model.ready)
        XCTAssertEqual(try repo.get(creation.id).activeProfile, profile)
    }
    func testEachPendingFrameKeepsActualProfileAndTrialProfileCannotChangeDuringUpload() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let repo = CaptureRepository(root: directory)
        let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        try repo.create(creation)
        var focused = profile; focused.lensPosition = 0.72
        try repo.updateTrialProfile(session: creation.id, profile: focused)
        let id = try repo.append(id: creation.id, image: Data([0xff,0xd8,0xff,0xd9]), timestamp: 1, profile: focused)
        let pending = try XCTUnwrap(repo.get(creation.id).pending.first)
        XCTAssertEqual(pending.id, id); XCTAssertEqual(pending.profile, focused)
        XCTAssertThrowsError(try repo.updateTrialProfile(session: creation.id, profile: profile))
        let legacy = try JSONDecoder().decode(PendingFrame.self, from: Data("{\"id\":\"old\",\"timestamp\":1}".utf8))
        XCTAssertNil(legacy.profile)
        let calibration = CaptureCreation(mode: "calibration", markerCount: 6, profile: profile, physical: true, squareMM: 16.4, calibrationID: nil)
        try repo.create(calibration)
        XCTAssertThrowsError(try repo.updateTrialProfile(session: calibration.id, profile: focused))
        XCTAssertThrowsError(try repo.append(id: calibration.id, image: Data([1,2]), timestamp: 1, profile: focused))
    }
    func testNativeTrialUsesNewActualFocusAndKeepsPreviouslyAcceptedIdentities() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let engine = OfflineEngine(root: directory)
        let creation = CaptureCreation(mode: "trial", markerCount: 6, profile: profile, physical: false, squareMM: nil, calibrationID: nil)
        _ = try await engine.request("sessions", body: JSONEncoder().encode(creation))
        let file = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "vertical_arch", withExtension: "dat"))
        let data = try Data(contentsOf: file)
        let first = FrameUpload(id: captureID(), image: data.base64EncodedString(), profile: profile, timestamp: 1)
        let firstReceipt = try await engine.request("sessions/\(creation.id)/frames", body: JSONEncoder().encode(first))
        XCTAssertEqual(firstReceipt["accepted"] as? Bool, true)
        var focused = profile; focused.lensPosition = 0.713
        let duplicate = FrameUpload(id: captureID(), image: data.base64EncodedString(), profile: focused, timestamp: 2)
        let second = try await engine.request("sessions/\(creation.id)/frames", body: JSONEncoder().encode(duplicate))
        XCTAssertEqual(second["accepted"] as? Bool, false)
        XCTAssertEqual(second["count"] as? Int, 1)
        let feedback = try LiveFeedback.decode(second, session: creation.id, sample: duplicate.id, count: 6)
        XCTAssertEqual(feedback.completedIDs, Array(0..<6))
        let state = try await engine.request("sessions/\(creation.id)", body: nil)
        let history = try XCTUnwrap(state["accepted"] as? [[String: Any]])
        XCTAssertEqual(history.count, 1)
        let storedFocus = try XCTUnwrap((history[0]["capture_profile"] as? [String: Any])?["lens_position"] as? Double)
        XCTAssertEqual(storedFocus, Double(profile.lensPosition), accuracy: 0.00001)
    }
    func testRecognitionReportExportsExactRejectedImageAndMatchingNativeDiagnostics() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let id = captureID(), bytes = Data([0xff,0xd8,3,5,7,11,0xff,0xd9])
        let response: [String: Any] = ["id": id, "sha256": PreviewCommit.digest(bytes), "accepted": false,
            "feedback": ["diagnostics": ["rejected": ["ID uncertain"], "dot_groups": 1]]]
        let sample = RecognitionSample(session: captureID(), sample: id, image: bytes, profile: profile,
            timestamp: 123.456, mode: "trial", markerCount: 6, response: response)
        let url = try sample.write(to: directory)
        let decoded = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [String: Any])
        XCTAssertEqual(Data(base64Encoded: try XCTUnwrap(decoded["image_base64"] as? String)), bytes)
        XCTAssertEqual(decoded["image_sha256"] as? String, PreviewCommit.digest(bytes))
        XCTAssertEqual(decoded["response"] as? NSDictionary, response as NSDictionary)
        XCTAssertEqual(decoded["image_encoding"] as? String, "jpeg")
        XCTAssertTrue(decoded["physical_accuracy_um"] is NSNull)
        let mismatched = RecognitionSample(session: sample.session, sample: id, image: Data([1,2]), profile: profile,
            timestamp: 123.456, mode: "trial", markerCount: 6, response: response)
        XCTAssertThrowsError(try mismatched.write(to: directory))
    }
}
