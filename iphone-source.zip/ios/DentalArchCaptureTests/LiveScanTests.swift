import XCTest
@testable import DentalArchCapture

final class LiveScanTests: XCTestCase {
    func testOneSampleInFlightAndNoRestartUntilRelease() {
        var gate = SamplingGate()
        XCTAssertTrue(gate.start())
        let ticket = gate.reserve()!
        XCTAssertNil(gate.reserve())
        XCTAssertFalse(gate.start())
        gate.stop()
        XCTAssertFalse(gate.owns(ticket))
        XCTAssertFalse(gate.start())
        gate.release(ticket)
        XCTAssertTrue(gate.start())
        let new = gate.reserve()!
        XCTAssertNotEqual(new, ticket)
        gate.release(ticket)
        XCTAssertTrue(gate.owns(new))
    }
    func testNormalBackpressureCycleAndPausedState() {
        var gate = SamplingGate()
        XCTAssertNil(gate.reserve())
        XCTAssertTrue(gate.start())
        for _ in 0..<25 {
            let t = gate.reserve()!
            XCTAssertTrue(gate.owns(t)); XCTAssertNil(gate.reserve())
            gate.release(t)
        }
        gate.stop(); XCTAssertNil(gate.reserve())
    }
    func receipt(frames: Int = 12, weakest: Int = 4) -> [String: Any] {
        ["id": "sample", "message": "Uygun", "feedback": [
            "schema": 1, "session_id": "session", "sample_id": "sample",
            "coordinates": "sensor_normalized", "metric": "accepted_image_coverage_not_accuracy",
            "physical_accuracy_um": NSNull(), "preview": false, "sample_usable": true,
            "image_size": [1920, 1080], "frames": frames, "target_frames": 12, "target_views": 4,
            "views": ["0": weakest, "1": frames, "2": frames, "3": frames],
            "markers": [["id": 0, "points": [[0.1, 0.2], [0.2, 0.2], [0.1, 0.3], [0.15, 0.25]]]]
        ]]
    }
    func decode(_ r: [String: Any]) throws -> LiveFeedback {
        try LiveFeedback.decode(r, session: "session", sample: "sample", count: 4)
    }
    func testCoverageNeedsAllFlagsAndFrames() throws {
        XCTAssertTrue(try decode(receipt()).coverageReached)
        XCTAssertFalse(try decode(receipt(weakest: 0)).coverageReached)
        XCTAssertEqual(try decode(receipt(weakest: 2)).fraction, 0.5)
        XCTAssertFalse(try decode(receipt(frames: 4)).coverageReached)
    }
    func testWrongSampleAndSessionNeverReachOverlay() {
        XCTAssertThrowsError(try LiveFeedback.decode(receipt(), session: "another", sample: "sample", count: 4))
        XCTAssertThrowsError(try LiveFeedback.decode(receipt(), session: "session", sample: "newer", count: 4))
    }
    func testMalformedCoordinatesAndInventedAccuracyAreRejected() {
        for invalid in [Double.nan, Double.infinity, -0.1, 1.01] {
            var r = receipt(); var f = r["feedback"] as! [String: Any]
            f["markers"] = [["id": 0, "points": [[invalid, 0.2], [0.2, 0.2], [0.1, 0.3], [0.15, 0.25]]]]
            r["feedback"] = f; XCTAssertThrowsError(try decode(r))
        }
        var r = receipt(); var f = r["feedback"] as! [String: Any]
        f["physical_accuracy_um"] = 0; r["feedback"] = f
        XCTAssertThrowsError(try decode(r))
    }
    func testOverlayLetterboxingUsesExactSensorImage() {
        let p = FeedbackViewport(imageWidth: 1920, imageHeight: 1080, viewWidth: 400, viewHeight: 300)
        XCTAssertEqual(p.width, 400); XCTAssertEqual(p.height, 225)
        let top = p.point([0, 0]); XCTAssertEqual(top.0, 0); XCTAssertEqual(top.1, 37.5)
        let bottom = p.point([1, 1]); XCTAssertEqual(bottom.0, 400); XCTAssertEqual(bottom.1, 262.5)
        let middle = p.point([0.5, 0.5]); XCTAssertEqual(middle.0, 200); XCTAssertEqual(middle.1, 150)
    }
    func testDuplicateMarkerIDsCannotInflateFeedback() {
        var r = receipt(); var f = r["feedback"] as! [String: Any]
        let marker = (f["markers"] as! [[String: Any]])[0]
        f["markers"] = [marker, marker]; r["feedback"] = f
        XCTAssertThrowsError(try decode(r))
    }
}
