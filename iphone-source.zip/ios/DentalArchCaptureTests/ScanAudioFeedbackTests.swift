import Foundation
import XCTest
@testable import DentalArchCapture

@MainActor private final class FakeScanAudioOutput: ScanAudioOutput {
    var outputVolume: Float = 0.5
    var activationError: Error?
    var preparationError: Error?
    var deactivationError: Error?
    var prepareResult = true
    var playResult = true
    var activations = 0
    var plays = 0
    var stops = 0
    var deactivations = 0
    var styles: [ScanSoundStyle] = []
    func activate() throws {
        activations += 1
        if let activationError { throw activationError }
    }
    func prepare(style: ScanSoundStyle) throws -> Bool {
        styles.append(style)
        if let preparationError { throw preparationError }
        return prepareResult
    }
    func play() -> Bool { plays += 1; return playResult }
    func stop() { stops += 1 }
    func deactivate() throws {
        deactivations += 1
        if let deactivationError { throw deactivationError }
    }
}

@MainActor final class ScanAudioFeedbackTests: XCTestCase {
    private let failure = NSError(domain: "ScanAudioTest", code: 1,
        userInfo: [NSLocalizedDescriptionKey: "test audio failure"])

    func testAcceptedSampleCadenceDoesNotActivateOrPlayEveryFrame() {
        let output = FakeScanAudioOutput()
        var clock = 100.0
        let audio = ScanAudioFeedback(output: output, now: { clock })
        XCTAssertNil(audio.play(.sampleAccepted))
        clock += 0.1
        XCTAssertNil(audio.play(.sampleAccepted))
        clock += 0.64
        XCTAssertNil(audio.play(.sampleAccepted))
        XCTAssertEqual(output.plays, 1)
        clock = 100.75
        XCTAssertNil(audio.play(.sampleAccepted))
        XCTAssertEqual(output.plays, 2)
        XCTAssertEqual(output.activations, 1)
    }

    func testConfirmationOverridesTickAndFollowingTickDoesNotCutItOff() {
        let output = FakeScanAudioOutput()
        var clock = 10.0
        let audio = ScanAudioFeedback(output: output, now: { clock })
        XCTAssertNil(audio.play(.sampleAccepted))
        clock += 0.01
        XCTAssertNil(audio.play(.flagConfirmed))
        XCTAssertEqual(output.plays, 2)
        clock += 0.01
        XCTAssertNil(audio.play(.sampleAccepted))
        XCTAssertEqual(output.plays, 2)
        XCTAssertLessThan(output.styles[0].volume, output.styles[1].volume)
        XCTAssertNil(audio.play(.completed))
        XCTAssertEqual(output.plays, 3)
        XCTAssertEqual(output.styles.last?.repetitions, 1)
        XCTAssertNil(audio.play(.test))
        XCTAssertEqual(output.plays, 4)
        XCTAssertEqual(output.styles.last?.repetitions, 0)
    }

    func testZeroMediaVolumeExplainsHowToRecoverWithoutChangingVolume() {
        let output = FakeScanAudioOutput()
        output.outputVolume = 0
        let audio = ScanAudioFeedback(output: output, now: { 0 })
        let warning = audio.play(.test)
        XCTAssertTrue(warning?.contains("medya sesi kapalı") == true)
        XCTAssertEqual(output.outputVolume, 0)
        XCTAssertEqual(output.plays, 0)
        XCTAssertTrue(output.styles.isEmpty)
        XCTAssertEqual(output.deactivations, 1)
        output.outputVolume = 0.5
        XCTAssertNil(audio.play(.test))
        XCTAssertEqual(output.activations, 2)
        XCTAssertEqual(output.plays, 1)
        XCTAssertNil(audio.lastWarning)
    }

    func testActivationErrorIsVisibleAndNextAcceptedSampleCanRetryImmediately() {
        let output = FakeScanAudioOutput()
        output.activationError = failure
        let audio = ScanAudioFeedback(output: output, now: { 5 })
        XCTAssertTrue(audio.play(.sampleAccepted)?.contains("test audio failure") == true)
        XCTAssertEqual(output.plays, 0)
        output.activationError = nil
        XCTAssertNil(audio.play(.sampleAccepted))
        XCTAssertEqual(output.plays, 1)
        XCTAssertEqual(output.activations, 2)
    }

    func testPrepareAndPlayFailuresAreReportedAndReleaseTheSession() {
        let output = FakeScanAudioOutput()
        let audio = ScanAudioFeedback(output: output, now: { 1 })
        output.preparationError = failure
        XCTAssertTrue(audio.play(.flagConfirmed)?.contains("test audio failure") == true)
        XCTAssertEqual(output.deactivations, 1)
        output.preparationError = nil
        output.prepareResult = false
        XCTAssertTrue(audio.play(.flagConfirmed)?.contains("hazırlanamadı") == true)
        XCTAssertEqual(output.plays, 0)
        XCTAssertEqual(output.deactivations, 2)
        output.prepareResult = true
        output.playResult = false
        XCTAssertTrue(audio.play(.flagConfirmed)?.contains("başlatılamadı") == true)
        XCTAssertEqual(output.deactivations, 3)
        output.playResult = true
        XCTAssertNil(audio.play(.flagConfirmed))
        XCTAssertEqual(output.activations, 4)
        XCTAssertNil(audio.lastWarning)
    }

    func testStopCancelsPlaybackReleasesSessionAndResetsSampleCadence() {
        let output = FakeScanAudioOutput()
        let audio = ScanAudioFeedback(output: output, now: { 100 })
        XCTAssertNil(audio.play(.sampleAccepted))
        audio.stop()
        XCTAssertEqual(output.stops, 1)
        XCTAssertEqual(output.deactivations, 1)
        audio.stop()
        XCTAssertEqual(output.deactivations, 1)
        XCTAssertNil(audio.play(.sampleAccepted))
        XCTAssertEqual(output.plays, 2)
        XCTAssertEqual(output.activations, 2)
    }

    func testFailedDeactivationStopsPlayerAndRetriesCleanup() {
        let output = FakeScanAudioOutput()
        let audio = ScanAudioFeedback(output: output)
        XCTAssertNil(audio.play(.test))
        output.deactivationError = failure
        audio.stop()
        XCTAssertEqual(output.stops, 1)
        XCTAssertEqual(output.deactivations, 1)
        XCTAssertTrue(audio.lastWarning?.contains("kapatılamadı") == true)
        output.deactivationError = nil
        audio.stop()
        XCTAssertEqual(output.stops, 2)
        XCTAssertEqual(output.deactivations, 2)
    }
}
