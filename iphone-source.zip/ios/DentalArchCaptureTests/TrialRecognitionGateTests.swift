import XCTest
@testable import DentalArchCapture

final class TrialRecognitionGateTests: XCTestCase {
    private func observation(_ id: Int, span: Double = 80, blur: Double = 100) -> [String: Any] {
        let x = 100.0 + Double(id) * 180
        return ["marker": id, "corners": [[x,100], [x+80,100], [x+20,170], [x+30,130]],
                "min_side_px": span, "blur_laplacian": blur]
    }
    private var history: [[String: Any]] { [["observations": [0,1,2,3,5].map { observation($0) }]] }
    func testSmallOrBlurredPreviouslyConfirmedFlagsCannotVetoNewSharpID4() throws {
        let observations = [observation(0, span: 36, blur: 3), observation(4)]
        let quality: [String: Any] = ["blur_laplacian": 20.0]
        XCTAssertTrue(try OfflineEngine.assess(observations, quality: quality, history: history, markerCount: 6, identityOnly: true).0)
        XCTAssertEqual(OfflineEngine.eligibleTrialObservations(observations, quality: quality, history: history).compactMap { $0["marker"] as? Int }, [4])
        XCTAssertFalse(try OfflineEngine.assess(observations, quality: quality, history: history, markerCount: 6).0)
    }
    func testSharpKnownFlagCannotHideBlurredMissingFlag() throws {
        let observations = [observation(0), observation(4, blur: 8)]
        XCTAssertFalse(try OfflineEngine.assess(observations, quality: ["blur_laplacian": 100.0], history: history, markerCount: 6, identityOnly: true).0)
        XCTAssertTrue(OfflineEngine.eligibleTrialObservations(observations, quality: ["blur_laplacian": 100.0], history: history).isEmpty)
    }
    func testOnlyNewEligibleIDsArePersistedWhenAnotherNewFlagIsSmall() throws {
        let observations = [observation(0), observation(1, span: 36)]
        let eligible = OfflineEngine.eligibleTrialObservations(observations, quality: ["blur_laplacian": 100.0], history: [])
        XCTAssertTrue(try OfflineEngine.assess(observations, quality: ["blur_laplacian": 100.0], history: [], markerCount: 6, identityOnly: true).0)
        XCTAssertEqual(eligible.compactMap { $0["marker"] as? Int }, [0])
    }
    func testNonfiniteTrialSharpnessNeverConfirmsAnIdentity() throws {
        for invalid in [Double.nan, Double.infinity, -1] {
            XCTAssertFalse(try OfflineEngine.assess([observation(4, blur: invalid)], quality: ["blur_laplacian": 100.0], history: history, markerCount: 6, identityOnly: true).0)
        }
    }
    private func receipt() -> [String: Any] {
        ["id": "frame", "message": "Eksik bayrak", "feedback": [
            "schema": 1, "session_id": "session", "sample_id": "frame", "coordinates": "sensor_normalized",
            "metric": "accepted_image_coverage_not_accuracy", "physical_accuracy_um": NSNull(),
            "preview": true, "sample_usable": false, "image_size": [1920,1080], "frames": 1,
            "target_frames": 1, "target_views": 1, "views": ["0":1,"1":1,"2":1,"3":1,"4":0,"5":1],
            "markers": [], "diagnostics": ["dot_groups": 1, "candidate_diagnostics": [
                ["candidate_index": 0, "centers_px": [[100.0,100.0],[180.0,100.0],[120.0,170.0],[130.0,130.0]],
                 "accepted": false, "reason": "ambiguous_identity", "best_id": 4]
            ]]
        ]]
    }
    func testAmbiguousCandidateRemainsUnconfirmedAndFiveOfSixProgressIsVisible() throws {
        let feedback = try LiveFeedback.decode(receipt(), session: "session", sample: "frame", count: 6)
        XCTAssertEqual(feedback.fraction, 5.0/6.0, accuracy: 0.0001)
        XCTAssertEqual(feedback.pendingIDs, [4]); XCTAssertFalse(feedback.coverageReached)
        XCTAssertTrue(feedback.markers.isEmpty); XCTAssertEqual(feedback.candidateReasons, ["ambiguous_identity"])
        XCTAssertFalse(feedback.candidates[0].accepted)
        XCTAssertEqual(feedback.candidates[0].points[0][0], 100.0/1920, accuracy: 0.0001)
    }
    func testMalformedCandidateCannotReachTheImageOverlay() {
        var r = receipt(); var f = r["feedback"] as! [String: Any]
        f["diagnostics"] = ["candidate_diagnostics": [["candidate_index": 0,
            "centers_px": [[Double.infinity,100.0]], "accepted": false, "reason": "ambiguous_identity"]]]
        r["feedback"] = f
        XCTAssertThrowsError(try LiveFeedback.decode(r, session: "session", sample: "frame", count: 6))
    }
}
