import XCTest
@testable import DentalArchCapture

final class ScanDetectionOverlayTests: XCTestCase {
    private func feedback(usable: Bool = true, preview: Bool = false, views: Int = 1,
                          points: [[Double]] = [[0.1, 0.2], [0.8, 0.2], [0.1, 0.9], [0.3, 0.4]]) -> LiveFeedback {
        LiveFeedback(sampleID: "actual-sample", preview: preview, usable: usable,
                     markers: [.init(id: 4, points: points)], views: [0: 0, 1: 0, 2: 0, 3: 0, 4: views, 5: 0],
                     frames: 8, targetFrames: 24, targetViews: 8, width: 1920, height: 1080, message: "fixture")
    }
    func testOnlyFreshMatchingImageCanCoverLivePreview() {
        let sampled = Date(timeIntervalSince1970: 1000)
        let actual = feedback()
        func visible(age: Double, ready: Bool = true, width: Int? = 1920, height: Int? = 1080) -> Bool {
            ScanDetectionOverlay.isVisible(ready: ready, feedback: actual, sampledAt: sampled,
                now: sampled.addingTimeInterval(age), imageWidth: width, imageHeight: height)
        }
        XCTAssertTrue(visible(age: 0))
        XCTAssertTrue(visible(age: 0.349))
        XCTAssertFalse(visible(age: 0.351), "Old coordinates must not remain on the moving preview.")
        XCTAssertFalse(visible(age: -0.01))
        XCTAssertFalse(visible(age: 0.1, ready: false))
        XCTAssertFalse(visible(age: 0.1, width: nil, height: nil))
        XCTAssertFalse(visible(age: 0.1, width: 1080, height: 1920))
    }
    func testPortraitRotationAndLetterboxPreserveActualFourCenters() throws {
        // 1080x1920 rotated image fits at 300x533.333 in a 300x600 view.
        let outlines = ScanDetectionOverlay.outlines(feedback: feedback(), viewWidth: 300,
                                                     viewHeight: 600, rotatedClockwise: true)
        let marker = try XCTUnwrap(outlines.first)
        XCTAssertEqual(marker.id, 4)
        XCTAssertEqual(marker.centers.count, 4)
        XCTAssertEqual(marker.centers[0].x, 240, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[0].y, 86.6666667, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[1].x, 240, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[1].y, 460, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[2].x, 30, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[3].x, 180, accuracy: 0.0001)
        XCTAssertEqual(marker.bounds.minX, 21, accuracy: 0.0001)
        XCTAssertEqual(marker.bounds.maxX, 249, accuracy: 0.0001)
        XCTAssertTrue(marker.centers.allSatisfy { marker.bounds.contains($0) })
    }
    func testAcceptedDetectionDoesNotInventCompletionOrExpectedFlags() throws {
        let outlines = ScanDetectionOverlay.outlines(feedback: feedback(), viewWidth: 400,
                                                     viewHeight: 300, rotatedClockwise: false)
        XCTAssertEqual(outlines.map(\.id), [4], "Only actual detections get outlines, not all six planned IDs.")
        let marker = try XCTUnwrap(outlines.first)
        XCTAssertTrue(marker.accepted)
        XCTAssertFalse(feedback().completedIDs.contains(4), "Green dot detection does not mean eight views completed.")
        XCTAssertEqual(marker.centers[0].x, 40, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[0].y, 82.5, accuracy: 0.0001)
    }
    func testPreviewAndRejectedSampleRemainAmberEvenForPreviouslyCompletedID() throws {
        for candidate in [feedback(usable: false, views: 8), feedback(preview: true, views: 8)] {
            let marker = try XCTUnwrap(ScanDetectionOverlay.outlines(feedback: candidate,
                viewWidth: 400, viewHeight: 300, rotatedClockwise: false).first)
            XCTAssertFalse(marker.accepted)
            XCTAssertTrue(candidate.completedIDs.contains(4), "Historical completion is independent from this sample's quality.")
        }
    }
    func testInvalidCoordinatesAndMissingDetectionsCreateNoGreenGeometry() {
        for invalid in [Double.nan, Double.infinity, -0.01, 1.01] {
            let candidate = feedback(points: [[invalid, 0.2], [0.8, 0.2], [0.1, 0.9], [0.3, 0.4]])
            XCTAssertTrue(ScanDetectionOverlay.outlines(feedback: candidate, viewWidth: 400,
                                                       viewHeight: 300, rotatedClockwise: false).isEmpty)
        }
        let empty = feedback(points: [])
        XCTAssertTrue(ScanDetectionOverlay.outlines(feedback: empty, viewWidth: 400,
                                                   viewHeight: 300, rotatedClockwise: false).isEmpty)
        let now = Date(timeIntervalSince1970: 1000)
        XCTAssertFalse(ScanDetectionOverlay.isVisible(ready: true, feedback: empty, sampledAt: now, now: now,
                                                      imageWidth: 1920, imageHeight: 1080))
        XCTAssertTrue(ScanDetectionOverlay.outlines(feedback: feedback(), viewWidth: 0,
                                                   viewHeight: 300, rotatedClockwise: false).isEmpty)
    }
    func testOnlyRejectedCandidateCentersGetAmberCandidateRings() {
        var actual = feedback()
        actual.candidates = [
            .init(id: 0, points: [[0.5, 0.5]], reason: "ambiguous_identity", accepted: false),
            .init(id: 1, points: [[0.1, 0.2]], reason: "accepted", accepted: true)
        ]
        let centers = ScanDetectionOverlay.rejectedCenters(feedback: actual, viewWidth: 400,
                                                           viewHeight: 300, rotatedClockwise: false)
        XCTAssertEqual(centers.count, 1)
        XCTAssertEqual(centers.first?.x, 200)
        XCTAssertEqual(centers.first?.y, 150)
    }
}
