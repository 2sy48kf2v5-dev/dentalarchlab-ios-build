import XCTest
@testable import DentalArchCapture

final class ScanDetectionOverlayTests: XCTestCase {
    private func feedback(usable: Bool = true, preview: Bool = false, views: Int = 1,
                          points: [[Double]] = [[0.1, 0.2], [0.8, 0.2], [0.1, 0.9], [0.3, 0.4]]) -> LiveFeedback {
        LiveFeedback(sampleID: "actual-sample", preview: preview, usable: usable,
                     markers: [.init(id: 4, points: points)], views: [0: 0, 1: 0, 2: 0, 3: 0, 4: views, 5: 0],
                     frames: 8, targetFrames: 24, targetViews: 8, width: 1920, height: 1080, message: "fixture")
    }
    func testOnlyFreshMatchingImageCanEmitConfirmationCue() {
        let sampled = Date(timeIntervalSince1970: 1000)
        let actual = feedback()
        func visible(age: Double, ready: Bool = true, width: Int? = 1920, height: Int? = 1080) -> Bool {
            ScanDetectionOverlay.isVisible(ready: ready, feedback: actual, sampledAt: sampled,
                now: sampled.addingTimeInterval(age), imageWidth: width, imageHeight: height)
        }
        XCTAssertTrue(visible(age: 0))
        XCTAssertTrue(visible(age: 0.349))
        XCTAssertFalse(visible(age: 0.351), "An old result must not repeat the confirmation pulse.")
        XCTAssertFalse(visible(age: -0.01))
        XCTAssertFalse(visible(age: 0.1, ready: false))
        XCTAssertFalse(visible(age: 0.1, width: nil, height: nil))
        XCTAssertFalse(visible(age: 0.1, width: 1080, height: 1920))
    }
    func testPortraitRotationAndLetterboxPreserveActualFourCenters() throws {
        // 1080x1920 rotated image fits at 300x533.333 in a 300x600 view.
        let outlines = ScanDetectionOverlay.outlines(feedback: feedback(), viewWidth: 300,
                                                     viewHeight: 600, rotatedClockwise: true)
        let marker = try XCTUnwrap(outlines.first)
        XCTAssertEqual(marker.id, 4)
        XCTAssertEqual(marker.centers.count, 4)
        XCTAssertEqual(marker.centers[0].x, 240, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[0].y, 86.6666667, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[1].x, 240, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[1].y, 460, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[2].x, 30, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[3].x, 180, accuracy: 0.0001)
        XCTAssertEqual(marker.bounds.minX, 21, accuracy: 0.0001)
        XCTAssertEqual(marker.bounds.maxX, 249, accuracy: 0.0001)
        XCTAssertTrue(marker.centers.allSatisfy { marker.bounds.contains($0) })
    }
    func testAcceptedDetectionDoesNotInventCompletionOrExpectedFlags() throws {
        let outlines = ScanDetectionOverlay.outlines(feedback: feedback(), viewWidth: 400,
                                                     viewHeight: 300, rotatedClockwise: false)
        XCTAssertEqual(outlines.map(\.id), [4], "Only actual detections get outlines, not all six planned IDs.")
        let marker = try XCTUnwrap(outlines.first)
        XCTAssertTrue(marker.accepted)
        XCTAssertFalse(feedback().completedIDs.contains(4), "Green dot detection does not mean eight views completed.")
        XCTAssertEqual(marker.centers[0].x, 40, accuracy: 0.0001)
        XCTAssertEqual(marker.centers[0].y, 82.5, accuracy: 0.0001)
    }
    func testPreviewAndRejectedSampleRemainAmberEvenForPreviouslyCompletedID() throws {
        for candidate in [feedback(usable: false, views: 8), feedback(preview: true, views: 8)] {
            let marker = try XCTUnwrap(ScanDetectionOverlay.outlines(feedback: candidate,
                viewWidth: 400, viewHeight: 300, rotatedClockwise: false).first)
            XCTAssertFalse(marker.accepted)
            XCTAssertTrue(candidate.completedIDs.contains(4), "Historical completion is independent from this sample's quality.")
        }
    }
    func testInvalidCoordinatesAndMissingDetectionsCreateNoGreenGeometry() {
        for invalid in [Double.nan, Double.infinity, -0.01, 1.01] {
            let candidate = feedback(points: [[invalid, 0.2], [0.8, 0.2], [0.1, 0.9], [0.3, 0.4]])
            XCTAssertTrue(ScanDetectionOverlay.outlines(feedback: candidate, viewWidth: 400,
                                                       viewHeight: 300, rotatedClockwise: false).isEmpty)
        }
        let empty = feedback(points: [])
        XCTAssertTrue(ScanDetectionOverlay.outlines(feedback: empty, viewWidth: 400,
                                                   viewHeight: 300, rotatedClockwise: false).isEmpty)
        let now = Date(timeIntervalSince1970: 1000)
        XCTAssertFalse(ScanDetectionOverlay.isVisible(ready: true, feedback: empty, sampledAt: now, now: now,
                                                      imageWidth: 1920, imageHeight: 1080))
        XCTAssertTrue(ScanDetectionOverlay.outlines(feedback: feedback(), viewWidth: 0,
                                                   viewHeight: 300, rotatedClockwise: false).isEmpty)
    }
    func testOnlyRejectedCandidateCentersGetAmberCandidateRings() {
        var actual = feedback()
        actual.candidates = [
            .init(id: 0, points: [[0.5, 0.5]], reason: "ambiguous_identity", accepted: false),
            .init(id: 1, points: [[0.1, 0.2]], reason: "accepted", accepted: true)
        ]
        let centers = ScanDetectionOverlay.rejectedCenters(feedback: actual, viewWidth: 400,
                                                           viewHeight: 300, rotatedClockwise: false)
        XCTAssertEqual(centers.count, 1)
        XCTAssertEqual(centers.first?.x, 200)
        XCTAssertEqual(centers.first?.y, 150)
    }
    func testLiveHintExpiryUsesCaptureUptimeNotFreshReceiptTime() {
        let actual = feedback()
        let receipt = Date(timeIntervalSince1970: 1000)
        XCTAssertTrue(ScanDetectionOverlay.isVisible(ready: true, feedback: actual, sampledAt: receipt,
            now: receipt, imageWidth: 1920, imageHeight: 1080))
        XCTAssertEqual(ScanDetectionOverlay.remainingLiveTime(ready: true, feedback: actual, captureUptime: 40,
            nowUptime: 41, imageWidth: 1920, imageHeight: 1080), 0,
            "A just-arrived result from a slow analysis must not appear over the current live frame.")
        XCTAssertEqual(ScanDetectionOverlay.remainingLiveTime(ready: true, feedback: actual, captureUptime: 40,
            nowUptime: 40.1, imageWidth: 1920, imageHeight: 1080), 0.15, accuracy: 0.00001)
        for time in [39.9, 40.25, 40.5, Double.infinity, Double.nan] {
            XCTAssertEqual(ScanDetectionOverlay.remainingLiveTime(ready: true, feedback: actual, captureUptime: 40,
                nowUptime: time, imageWidth: 1920, imageHeight: 1080), 0)
        }
        XCTAssertEqual(ScanDetectionOverlay.remainingLiveTime(ready: false, feedback: actual, captureUptime: 40,
            nowUptime: 40.1, imageWidth: 1920, imageHeight: 1080), 0)
        XCTAssertEqual(ScanDetectionOverlay.remainingLiveTime(ready: true, feedback: actual, captureUptime: nil,
            nowUptime: 40.1, imageWidth: 1920, imageHeight: 1080), 0)
        XCTAssertEqual(ScanDetectionOverlay.remainingLiveTime(ready: true, feedback: actual, captureUptime: 40,
            nowUptime: 40.1, imageWidth: 1080, imageHeight: 1920), 0)
    }
    func testLivePortraitAspectFillUsesCropInsteadOfThumbnailLetterbox() throws {
        let actual = feedback(points: [[0.4, 0.4], [0.6, 0.4], [0.4, 0.6], [0.5, 0.5]])
        let centers = ScanDetectionOverlay.liveCenters(feedback: actual, viewWidth: 400, viewHeight: 300, previewZoom: 1)
        XCTAssertEqual(centers.count, 4)
        XCTAssertEqual(centers[0].x, 240, accuracy: 0.0001)
        XCTAssertEqual(centers[0].y, 78.8888889, accuracy: 0.0001)
        XCTAssertEqual(centers[1].y, 221.1111111, accuracy: 0.0001)
        XCTAssertEqual(centers[2].x, 160, accuracy: 0.0001)
        XCTAssertEqual(centers[3], CGPoint(x: 200, y: 150))
        let thumbnail = try XCTUnwrap(ScanDetectionOverlay.outlines(feedback: actual, viewWidth: 400,
            viewHeight: 300, rotatedClockwise: true).first)
        XCTAssertEqual(thumbnail.centers[0].x, 216.875, accuracy: 0.0001)
        XCTAssertNotEqual(centers[0].x, thumbnail.centers[0].x,
            "The fit thumbnail and fill preview must not share a mismatched coordinate transform.")
    }
    func testLiveHintZoomIsCenteredAndCroppedPointsStayOffscreen() {
        let actual = feedback(points: [[0.4, 0.4], [0.6, 0.4], [0.4, 0.6], [0.5, 0.5]])
        let centers = ScanDetectionOverlay.liveCenters(feedback: actual, viewWidth: 400, viewHeight: 300, previewZoom: 2)
        XCTAssertEqual(centers.count, 4)
        XCTAssertEqual(centers[0].x, 280, accuracy: 0.0001)
        XCTAssertEqual(centers[0].y, 7.7777778, accuracy: 0.0001)
        XCTAssertEqual(centers[1].y, 292.2222222, accuracy: 0.0001)
        XCTAssertEqual(centers[3], CGPoint(x: 200, y: 150))
        let edges = feedback(points: [[0, 0], [1, 1], [0, 1], [0.5, 0.5]])
        XCTAssertEqual(ScanDetectionOverlay.liveCenters(feedback: edges, viewWidth: 400,
            viewHeight: 300, previewZoom: 2), [CGPoint(x: 200, y: 150)])
        XCTAssertTrue(ScanDetectionOverlay.liveCenters(feedback: actual, viewWidth: 400,
            viewHeight: 300, previewZoom: .nan).isEmpty)
    }
    func testRejectedCandidatesCanStayInThumbnailButNeverCreateLiveHints() {
        var actual = feedback(points: [])
        actual.candidates = [.init(id: 0, points: [[0.5, 0.5]], reason: "ambiguous_identity", accepted: false)]
        XCTAssertTrue(ScanDetectionOverlay.matchesImage(feedback: actual, imageWidth: 1920, imageHeight: 1080))
        XCTAssertEqual(ScanDetectionOverlay.remainingLiveTime(ready: true, feedback: actual, captureUptime: 40,
            nowUptime: 40.1, imageWidth: 1920, imageHeight: 1080), 0)
        XCTAssertTrue(ScanDetectionOverlay.liveCenters(feedback: actual, viewWidth: 400,
            viewHeight: 300, previewZoom: 1).isEmpty)
    }

    func testBothLandscapeLivePreviewsUseAspectFillWithCorrectHalfTurn() {
        // 1920x1080 fills 400x300 at 533.333x300, cropping 66.667 per side.
        let actual = feedback(points: [[0.25, 0.2], [0.75, 0.3], [0.6, 0.8], [0.5, 0.5]])
        let cases: [(CameraDisplayOrientation, [CGPoint])] = [
            (.landscapeRight, [CGPoint(x: 66.6666667, y: 60), CGPoint(x: 333.3333333, y: 90),
                               CGPoint(x: 253.3333333, y: 240), CGPoint(x: 200, y: 150)]),
            (.landscapeLeft, [CGPoint(x: 333.3333333, y: 240), CGPoint(x: 66.6666667, y: 210),
                              CGPoint(x: 146.6666667, y: 60), CGPoint(x: 200, y: 150)])
        ]
        for (orientation, expected) in cases {
            let centers = ScanDetectionOverlay.liveCenters(feedback: actual, viewWidth: 400,
                viewHeight: 300, previewZoom: 1, orientation: orientation)
            assertCenters(centers, equal: expected)
        }
        XCTAssertEqual(actual.width, 1920)
        XCTAssertEqual(actual.height, 1080)
        XCTAssertEqual(actual.markers[0].points[0], [0.25, 0.2], "Display rotation cannot rewrite sensor coordinates.")
    }

    func testLandscapeLiveCropRejectsHiddenSensorEdgesInsteadOfClampingThem() {
        let horizontalEdges = feedback(points: [[0, 0.5], [1, 0.5], [0.5, 0.25], [0.5, 0.75]])
        let verticalEdges = feedback(points: [[0.5, 0], [0.5, 1], [0.25, 0.5], [0.75, 0.5]])
        for orientation in [CameraDisplayOrientation.landscapeRight, .landscapeLeft] {
            let tall = ScanDetectionOverlay.liveCenters(feedback: horizontalEdges, viewWidth: 400,
                viewHeight: 300, previewZoom: 1, orientation: orientation)
            let wide = ScanDetectionOverlay.liveCenters(feedback: verticalEdges, viewWidth: 800,
                viewHeight: 300, previewZoom: 1, orientation: orientation)
            let expectedTall = [CGPoint(x: 200, y: 75), CGPoint(x: 200, y: 225)]
            let expectedWide = [CGPoint(x: 200, y: 150), CGPoint(x: 600, y: 150)]
            assertCenters(tall, equal: orientation == .landscapeRight ? expectedTall : Array(expectedTall.reversed()))
            assertCenters(wide, equal: orientation == .landscapeRight ? expectedWide : Array(expectedWide.reversed()))
        }
    }

    func testBothLandscapePreviewZoomStaysCenteredAfterRotationAndCropping() {
        let actual = feedback(points: [[0.4, 0.4], [0.65, 0.35], [0.6, 0.6], [0.5, 0.5]])
        let cases: [(CameraDisplayOrientation, [CGPoint])] = [
            (.landscapeRight, [CGPoint(x: 93.3333333, y: 90), CGPoint(x: 360, y: 60),
                               CGPoint(x: 306.6666667, y: 210), CGPoint(x: 200, y: 150)]),
            (.landscapeLeft, [CGPoint(x: 306.6666667, y: 210), CGPoint(x: 40, y: 240),
                              CGPoint(x: 93.3333333, y: 90), CGPoint(x: 200, y: 150)])
        ]
        for (orientation, expected) in cases {
            let centers = ScanDetectionOverlay.liveCenters(feedback: actual, viewWidth: 400,
                viewHeight: 300, previewZoom: 2, orientation: orientation)
            assertCenters(centers, equal: expected)
        }
    }

    func testBothLandscapeThumbnailsRotateAcceptedAndRejectedPointsTogether() throws {
        var actual = feedback()
        actual.candidates = [
            .init(id: 0, points: [[0.1, 0.2]], reason: "ambiguous_identity", accepted: false),
            .init(id: 1, points: [[0.8, 0.2]], reason: "accepted", accepted: true)
        ]
        for (orientation, expected) in [
            (CameraDisplayOrientation.landscapeRight, CGPoint(x: 60, y: 98.75)),
            (CameraDisplayOrientation.landscapeLeft, CGPoint(x: 540, y: 301.25))
        ] {
            let marker = try XCTUnwrap(ScanDetectionOverlay.outlines(feedback: actual, viewWidth: 600,
                viewHeight: 400, orientation: orientation).first)
            XCTAssertEqual(marker.id, 4)
            XCTAssertTrue(marker.accepted)
            XCTAssertEqual(marker.centers.count, 4)
            assertCenters([marker.centers[0]], equal: [expected])
            XCTAssertTrue(marker.centers.allSatisfy { marker.bounds.contains($0) })
            let rejected = ScanDetectionOverlay.rejectedCenters(feedback: actual, viewWidth: 600,
                viewHeight: 400, orientation: orientation)
            assertCenters(rejected, equal: [expected])
        }
    }

    private func assertCenters(_ actual: [CGPoint], equal expected: [CGPoint],
                               file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(actual.count, expected.count, file: file, line: line)
        for (point, reference) in zip(actual, expected) {
            XCTAssertEqual(point.x, reference.x, accuracy: 0.00001, file: file, line: line)
            XCTAssertEqual(point.y, reference.y, accuracy: 0.00001, file: file, line: line)
        }
    }
}
