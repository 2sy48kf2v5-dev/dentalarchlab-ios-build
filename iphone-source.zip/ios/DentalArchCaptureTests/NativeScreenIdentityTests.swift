import UIKit
import XCTest
@testable import DentalArchCapture

/// Runs the production Objective-C++ detector on the exact mouth shown to the
/// user. These are image/software checks, never physical accuracy validation.
final class NativeScreenIdentityTests: XCTestCase {
    private func fixture(_ name: String, sha256: String) throws -> Data {
        let url = try XCTUnwrap(Bundle(for: Self.self).url(forResource: name, withExtension: "dat"))
        let data = try Data(contentsOf: url)
        XCTAssertEqual(PreviewCommit.digest(data), sha256, "Keep reviewed encoded pixels; do not PNG-crush test resources")
        return data
    }

    private func mouth() throws -> Data {
        try fixture("mouth_front", sha256: "c63b724a97ae2ddf7829f83d9f8b10392d9d342cf3e347be984d7e1f1c69e50e")
    }

    private func observations(_ result: [String: Any]) throws -> [[String: Any]] {
        try XCTUnwrap(result["observations"] as? [[String: Any]])
    }

    private func ids(_ result: [String: Any]) throws -> [Int] {
        try observations(result).map { try XCTUnwrap($0["marker"] as? Int) }.sorted()
    }

    private func evidence(_ result: [String: Any], name: String) throws {
        let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        let attachment = XCTAttachment(data: data, uniformTypeIdentifier: "public.json")
        attachment.name = name; attachment.lifetime = .keepAlways; add(attachment)
    }

    private func render(size: CGSize, draw: (UIGraphicsImageRendererContext) -> Void) throws -> Data {
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        return try XCTUnwrap(UIGraphicsImageRenderer(size: size, format: format).image(actions: draw).pngData())
    }

    func testDisplayedMouthContainsSixNativeIDsAndPerMarkerSharpness() throws {
        let result = try DALNativeEngine.detect(image: mouth(), camera: nil, markerCount: 6)
        try evidence(result, name: "native-displayed-mouth.json")
        XCTAssertEqual(try ids(result), [0, 1, 2, 3, 4, 5])
        let rows = try observations(result)
        for row in rows {
            let sharpness = try XCTUnwrap(row["blur_laplacian"] as? Double)
            XCTAssertTrue(sharpness.isFinite); XCTAssertGreaterThan(sharpness, 35)
        }
        let quality = try XCTUnwrap(result["quality"] as? [String: Any])
        XCTAssertEqual(quality["detector_mode"] as? String, "assumed_camera_pose_2d")
        let candidates = try XCTUnwrap(quality["candidate_diagnostics"] as? [[String: Any]])
        XCTAssertEqual(candidates.filter { $0["accepted"] as? Bool == true }.count, 6)
        let fourth = try XCTUnwrap(candidates.first { $0["best_id"] as? Int == 4 })
        XCTAssertEqual(fourth["reason"] as? String, "accepted")
        XCTAssertEqual((fourth["centers_px"] as? [[Double]])?.count, 4)
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, false)
    }

    func testObliqueJPEGScreenSimulationPreservesSixIDsIncludingFour() throws {
        let data = try fixture("mouth_oblique", sha256: "1d1776bac96771a25eb7a35b48b65dc2a45e2204fb625807510b86c94d971741")
        let result = try DALNativeEngine.detect(image: data, camera: nil, markerCount: 6)
        try evidence(result, name: "native-oblique-screen-jpeg.json")
        XCTAssertEqual(try ids(result), [0, 1, 2, 3, 4, 5])
        XCTAssertEqual(result["metric_intrinsics"] as? Bool, false)
    }

    func testCoveredFourthDotCannotBeInferredFromFiveOtherRecognizedIDs() throws {
        let source = try XCTUnwrap(UIImage(data: mouth()))
        let data = try render(size: source.size) { context in
            source.draw(at: .zero)
            UIColor.black.setFill()
            // Ground-truth inner circle of ID 4: (1658.48, 1020.63), radius ~11 px.
            context.fill(CGRect(x: 1641, y: 1003, width: 36, height: 35))
        }
        let result = try DALNativeEngine.detect(image: data, camera: nil, markerCount: 6)
        try evidence(result, name: "native-missing-dot-four.json")
        XCTAssertEqual(try ids(result), [0, 1, 2, 3, 5])
    }

    func testDuplicateFourthIdentityIsRejectedAndDiagnosticDoesNotClaimAcceptance() throws {
        let source = try XCTUnwrap(UIImage(data: mouth()))
        let cropped = try XCTUnwrap(source.cgImage?.cropping(to: CGRect(x: 1500, y: 850, width: 400, height: 400)))
        let flag = UIImage(cgImage: cropped)
        let data = try render(size: CGSize(width: 800, height: 400)) { _ in
            flag.draw(at: .zero); flag.draw(at: CGPoint(x: 400, y: 0))
        }
        let result = try DALNativeEngine.detect(image: data, camera: nil, markerCount: 6)
        try evidence(result, name: "native-duplicate-four.json")
        XCTAssertEqual(try ids(result), [])
        let quality = try XCTUnwrap(result["quality"] as? [String: Any])
        let candidates = try XCTUnwrap(quality["candidate_diagnostics"] as? [[String: Any]])
        XCTAssertEqual(candidates.count, 2)
        for candidate in candidates {
            XCTAssertEqual(candidate["best_id"] as? Int, 4)
            XCTAssertEqual(candidate["reason"] as? String, "duplicate_identity")
            XCTAssertEqual(candidate["accepted"] as? Bool, false)
        }
    }

    func testNoFourDotCandidateHasExplicitDiagnosticAndNoInventedID() throws {
        let data = try render(size: CGSize(width: 640, height: 480)) { context in
            UIColor.gray.setFill(); context.fill(CGRect(x: 0, y: 0, width: 640, height: 480))
        }
        let result = try DALNativeEngine.detect(image: data, camera: nil, markerCount: 6)
        XCTAssertEqual(try ids(result), [])
        let quality = try XCTUnwrap(result["quality"] as? [String: Any])
        XCTAssertEqual(quality["dot_groups"] as? Int, 0)
        XCTAssertEqual((quality["candidate_diagnostics"] as? [Any])?.count, 0)
        XCTAssertFalse(try XCTUnwrap(quality["rejected"] as? [String]).isEmpty)
        XCTAssertTrue(JSONSerialization.isValidJSONObject(result))
    }
}
