import UIKit
import XCTest
@testable import DentalArchCapture

final class CameraDisplayOrientationTests: XCTestCase {
    func testInterfaceOrientationControlsPreviewStillAndSensorPointTogether() throws {
        // This off-axis sensor point catches swapped axes and accidental mirroring.
        let cases: [(UIInterfaceOrientation, CameraDisplayOrientation, CGFloat, UIImage.Orientation, Bool, [Double])] = [
            (.portrait, .portrait, 90, .right, true, [0.7, 0.2]),
            (.landscapeRight, .landscapeRight, 0, .up, false, [0.2, 0.3]),
            (.landscapeLeft, .landscapeLeft, 180, .down, false, [0.8, 0.7]),
            (.portraitUpsideDown, .portraitUpsideDown, 270, .left, true, [0.3, 0.8])
        ]
        for (interface, expected, angle, image, swaps, point) in cases {
            let orientation = try XCTUnwrap(CameraDisplayOrientation(interfaceOrientation: interface))
            XCTAssertEqual(orientation, expected)
            XCTAssertEqual(orientation.previewRotationAngle, angle)
            XCTAssertEqual(orientation.imageOrientation, image)
            XCTAssertEqual(orientation.swapsDimensions, swaps)
            let mapped = orientation.normalizedPoint([0.2, 0.3])
            XCTAssertEqual(mapped[0], point[0], accuracy: 0.00001)
            XCTAssertEqual(mapped[1], point[1], accuracy: 0.00001)
        }
    }

    func testUnknownInterfaceOrientationDoesNotResetALandscapePreview() {
        XCTAssertNil(CameraDisplayOrientation(interfaceOrientation: .unknown))
        let previous = CameraDisplayOrientation.landscapeLeft
        let resolved = CameraDisplayOrientation(interfaceOrientation: .unknown) ?? previous
        XCTAssertEqual(resolved, .landscapeLeft)
    }

    func testCalibrationAndImageLetterboxUseUnswappedLandscapeSensorDimensions() {
        // A 1920x1080 image fits a 600x400 thumbnail at 600x337.5, y=31.25.
        // Expected points are calculated from these physical dimensions.
        for (orientation, expectedX, expectedY) in [
            (CameraDisplayOrientation.landscapeRight, 120.0, 132.5),
            (CameraDisplayOrientation.landscapeLeft, 480.0, 267.5)
        ] {
            let viewport = orientation.viewport(imageWidth: 1920, imageHeight: 1080,
                                                viewWidth: 600, viewHeight: 400)
            XCTAssertEqual(viewport.width, 600, accuracy: 0.00001)
            XCTAssertEqual(viewport.height, 337.5, accuracy: 0.00001)
            XCTAssertEqual(viewport.y, 31.25, accuracy: 0.00001)
            let point = viewport.point(orientation.normalizedPoint([0.2, 0.3]))
            XCTAssertEqual(point.0, expectedX, accuracy: 0.00001)
            XCTAssertEqual(point.1, expectedY, accuracy: 0.00001)
        }
    }
}
