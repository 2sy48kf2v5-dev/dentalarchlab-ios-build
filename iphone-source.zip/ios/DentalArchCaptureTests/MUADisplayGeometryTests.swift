import Foundation
import XCTest
@testable import DentalArchCapture

final class MUADisplayGeometryTests: XCTestCase {
    private let identity: [[Double]] = [[1,0,0,0], [0,1,0,0], [0,0,1,0], [0,0,0,1]]
    private func result(_ markers: [[String: Any]]) -> [String: Any] {
        ["units": "mm", "rig": ["units": "mm", "dictionary": "DAL_DOTS4_V1"], "markers": markers]
    }
    private func snapshot(_ result: [String: Any]) throws -> ResultSnapshot {
        try ResultSnapshot.decode(["state": "complete", "mode": "scan", "result": result])
    }
    private func assertPoint(_ actual: LabPoint, _ expected: LabPoint, file: StaticString = #filePath, line: UInt = #line) {
        XCTAssertEqual(actual.x, expected.x, accuracy: 1e-9, file: file, line: line)
        XCTAssertEqual(actual.y, expected.y, accuracy: 1e-9, file: file, line: line)
        XCTAssertEqual(actual.z, expected.z, accuracy: 1e-9, file: file, line: line)
    }

    func testMeasuredCompositionControlsBodyOriginWithoutInventedOffset() throws {
        // Marker rotates 90 degrees around Z. Imported MUA offset rotates into
        // world Y before translation; the viewer must not apply it a second time.
        let world: [[Double]] = [[0,-1,0,10], [1,0,0,20], [0,0,1,30], [0,0,0,1]]
        var local = identity; local[0][3] = 2; local[2][3] = 3
        let flag = MUACalibrationFlag(markerID: 0, physicalSerial: "SYNTHETIC-ONLY-0", transform: local,
            fitRMSMM: 0, uncertaintyMM: 0, uncertaintyDegrees: 0)
        let calibration = MUACalibration(referenceDevice: "Synthetic fixture", referenceReport: "No physical measurement",
            measuredAt: "2026-09-29T01:00:00Z", flags: [flag])
        let output = try calibration.apply(to: result([["id": 0, "T_world_marker": world, "T_world_mua": NSNull()]]))
        let decoded = try snapshot(output)
        let landmark = try XCTUnwrap(decoded.landmarks.first)
        let geometry = MUADisplayGeometry(landmark: landmark)
        XCTAssertEqual(geometry.kind, .calibratedMUA)
        assertPoint(geometry.origin, LabPoint(x: 10, y: 22, z: 33))
        assertPoint(MUADisplayGeometry.worldPoint(.zero, landmark: landmark), geometry.origin)
        assertPoint(MUADisplayGeometry.worldPoint(LabPoint(x: 1, y: 0, z: 0), landmark: landmark),
            LabPoint(x: 10, y: 23, z: 33))
        XCTAssertTrue(output["physical_accuracy_um"] is NSNull)
    }

    func testTiltedMUAHasBoreAlongMeasuredPositiveZAndPreservesFullRotation() throws {
        // +90 degrees around X makes local +Z point toward world -Y.
        let mua: [[Double]] = [[1,0,0,3], [0,0,-1,4], [0,1,0,5], [0,0,0,1]]
        let decoded = try snapshot(result([["id": 0, "T_world_marker": identity, "T_world_mua": mua]]))
        let landmark = try XCTUnwrap(decoded.landmarks.first)
        XCTAssertEqual(landmark.worldTransform, mua)
        let geometry = MUADisplayGeometry(landmark: landmark)
        assertPoint(geometry.axis, LabPoint(x: 0, y: -1, z: 0))
        let bore = geometry.surfaces.filter { $0.material == .bore }
        XCTAssertFalse(bore.isEmpty)
        let vertices = bore.flatMap { $0.vertices }
        XCTAssertTrue(vertices.allSatisfy { $0.y < geometry.origin.y })
        assertPoint(MUADisplayGeometry.worldPoint(LabPoint(x: 0, y: 1, z: 0), landmark: landmark),
            LabPoint(x: 3, y: 4, z: 6))
    }

    func testMissingCalibrationCreatesOnlyCompactMarkerAtMeasuredOpticalOrigin() throws {
        var world = identity; world[0][3] = 12; world[1][3] = -7; world[2][3] = 9
        let decoded = try snapshot(result([["id": 4, "T_world_marker": world, "T_world_mua": NSNull()]]))
        let landmark = try XCTUnwrap(decoded.landmarks.first)
        let geometry = MUADisplayGeometry(landmark: landmark)
        XCTAssertFalse(decoded.hasMUA)
        XCTAssertFalse(geometry.isSchematicMUA)
        XCTAssertEqual(geometry.kind, .uncalibratedMarker)
        assertPoint(geometry.origin, LabPoint(x: 12, y: -7, z: 9))
        XCTAssertTrue(geometry.surfaces.allSatisfy { $0.material == .marker })
        XCTAssertTrue(geometry.surfaces.flatMap { $0.vertices }.allSatisfy { ($0 - geometry.origin).length < 1.5 })
    }

    func testIllustrationCanShowExampleBodiesWithoutClaimingMeasuredMUAs() {
        let example = ResultSnapshot.illustration(count: 6)
        XCTAssertTrue(example.isIllustration)
        XCTAssertFalse(example.hasMUA)
        XCTAssertNil(example.rmsPX)
        for landmark in example.landmarks {
            let geometry = MUADisplayGeometry(landmark: landmark, illustration: true)
            XCTAssertEqual(geometry.kind, .exampleMUA)
            XCTAssertTrue(geometry.isSchematicMUA)
            assertPoint(geometry.origin, landmark.center)
            XCTAssertFalse(landmark.isMUA)
        }
    }

    func testMixedResultDoesNotPromoteUnknownMarkersToMUA() throws {
        let decoded = try snapshot(result([
            ["id": 0, "T_world_marker": identity, "T_world_mua": identity],
            ["id": 1, "T_world_marker": identity, "T_world_mua": NSNull()]
        ]))
        let kinds = decoded.landmarks.map { MUADisplayGeometry(landmark: $0).kind }
        XCTAssertEqual(kinds, [.calibratedMUA, .uncalibratedMarker])
    }

    func testAxisOnlyLegacyLandmarkKeepsOriginAndAxisWithFiniteDisplayVertices() {
        let axes = [LabPoint(x: 0, y: 0, z: 1), LabPoint(x: 1, y: 0, z: 0), LabPoint(x: 0, y: -1, z: 0)]
        for axis in axes {
            let landmark = ResultLandmark(id: 0, center: LabPoint(x: 2, y: 3, z: 4), axis: axis, isMUA: true)
            let geometry = MUADisplayGeometry(landmark: landmark)
            XCTAssertNil(landmark.worldTransform)
            assertPoint(MUADisplayGeometry.worldPoint(LabPoint(x: 0, y: 0, z: 2), landmark: landmark), landmark.center + axis * 2)
            XCTAssertTrue(geometry.surfaces.flatMap { $0.vertices }.allSatisfy { $0.x.isFinite && $0.y.isFinite && $0.z.isFinite })
        }
    }

    func testDecodeRejectsReflectedAndShearedRotationEvenWhenZAxisIsUnitLength() {
        var reflected = identity; reflected[0][0] = -1
        var sheared = identity; sheared[0][1] = 0.5
        for matrix in [reflected, sheared] {
            XCTAssertThrowsError(try snapshot(result([["id": 0, "T_world_marker": identity, "T_world_mua": matrix]])))
        }
    }
}
