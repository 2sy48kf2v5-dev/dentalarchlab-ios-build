import XCTest
@testable import DentalArchCapture

private enum TorchFixtureError: LocalizedError {
    case denied
    var errorDescription: String? { "Donanım ayarı reddedildi" }
}

private final class TorchFixture: CameraTorchDevice {
    var hasTorch = true
    var isTorchAvailable = true
    var isTorchActive = false
    var supportsTorchOn = true
    var failOn = false
    var failOff = false
    var lightOnAfterRequest = true
    var partlyActivateBeforeFailure = false
    var levels: [Float] = []
    var offCalls = 0

    func setTorchLevel(_ level: Float) throws {
        levels.append(level)
        if failOn {
            if partlyActivateBeforeFailure { isTorchActive = true }
            throw TorchFixtureError.denied
        }
        isTorchActive = lightOnAfterRequest
    }

    func switchTorchOff() throws {
        offCalls += 1
        if failOff { throw TorchFixtureError.denied }
        isTorchActive = false
    }
}

final class CameraIlluminationTests: XCTestCase {
    func testPreferenceChangesNeverTouchHardwareUntilNextStartup() {
        let device = TorchFixture()
        var illumination = CameraIllumination()
        illumination.configure(enabled: false)
        illumination.configure(enabled: true)
        XCTAssertTrue(device.levels.isEmpty)
        XCTAssertEqual(device.offCalls, 0)
        XCTAssertFalse(illumination.status(device: device).isOn)
        illumination.start(device: device, sessionRunning: true)
        XCTAssertEqual(device.levels, [0.25])
        XCTAssertTrue(illumination.status(device: device).isOn)
        illumination.configure(enabled: false)
        XCTAssertTrue(device.isTorchActive, "Changing a preference must not disturb locked exposure during capture")
        XCTAssertEqual(device.offCalls, 0)
        illumination.stop(device: device)
        illumination.start(device: device, sessionRunning: true)
        XCTAssertEqual(device.levels, [0.25])
        XCTAssertFalse(illumination.status(device: device).isOn)
    }

    func testStoppedSessionCannotTurnOnTorch() {
        let device = TorchFixture()
        device.isTorchActive = true
        var illumination = CameraIllumination()
        illumination.start(device: device, sessionRunning: false)
        XCTAssertTrue(device.levels.isEmpty)
        XCTAssertEqual(device.offCalls, 1)
        XCTAssertFalse(illumination.sessionStarted)
        XCTAssertFalse(illumination.status(device: device).isOn)
    }

    func testDisabledPreferenceClearsAnAlreadyActiveTorch() {
        let device = TorchFixture()
        device.isTorchActive = true
        var illumination = CameraIllumination()
        illumination.configure(enabled: false)
        illumination.start(device: device, sessionRunning: true)
        XCTAssertTrue(device.levels.isEmpty)
        XCTAssertEqual(device.offCalls, 1)
        XCTAssertFalse(illumination.status(device: device).isOn)
    }

    func testUnsupportedAndTemporarilyUnavailableDevicesNeverReceiveOnRequest() {
        for unavailableReason in 0..<3 {
            let device = TorchFixture()
            if unavailableReason == 0 { device.hasTorch = false }
            if unavailableReason == 1 { device.supportsTorchOn = false }
            if unavailableReason == 2 { device.isTorchAvailable = false }
            var illumination = CameraIllumination()
            illumination.start(device: device, sessionRunning: true)
            XCTAssertTrue(device.levels.isEmpty)
            XCTAssertFalse(illumination.status(device: device).available)
            XCTAssertFalse(illumination.status(device: device).isOn)
        }
    }

    func testSuccessfulRequestDoesNotInventLightBeforeHardwareReadback() {
        let device = TorchFixture()
        device.lightOnAfterRequest = false
        var illumination = CameraIllumination()
        illumination.start(device: device, sessionRunning: true)
        XCTAssertEqual(device.levels, [0.25])
        XCTAssertFalse(illumination.status(device: device).isOn)
        XCTAssertTrue(illumination.status(device: device).message.contains("henüz ışık vermiyor"))
        device.isTorchActive = true
        XCTAssertTrue(illumination.status(device: device).isOn)
    }

    func testFailedActivationSwitchesOffPartiallyActivatedLightAndReportsError() {
        let device = TorchFixture()
        device.failOn = true
        device.partlyActivateBeforeFailure = true
        var illumination = CameraIllumination()
        illumination.start(device: device, sessionRunning: true)
        XCTAssertEqual(device.offCalls, 1)
        XCTAssertFalse(illumination.status(device: device).isOn)
        XCTAssertTrue(illumination.status(device: device).message.contains("ayarı uygulanamadı"))
    }

    func testStopPreservesPreferenceForRestartButExtinguishesActualLight() {
        let device = TorchFixture()
        var illumination = CameraIllumination()
        illumination.start(device: device, sessionRunning: true)
        illumination.stop(device: device)
        XCTAssertFalse(illumination.status(device: device).isOn)
        XCTAssertFalse(illumination.sessionStarted)
        XCTAssertTrue(illumination.requestedEnabled)
        illumination.start(device: device, sessionRunning: true)
        XCTAssertEqual(device.levels, [0.25, 0.25])
        XCTAssertTrue(illumination.status(device: device).isOn)
    }

    func testFailedShutdownDoesNotFalselyReportOff() {
        let device = TorchFixture()
        var illumination = CameraIllumination()
        illumination.start(device: device, sessionRunning: true)
        device.failOff = true
        illumination.stop(device: device)
        XCTAssertTrue(illumination.status(device: device).isOn)
        XCTAssertTrue(illumination.status(device: device).message.contains("kapatılamadı"))
        // AVFoundation session stop/KVO can later confirm the actual off state.
        device.isTorchActive = false
        XCTAssertFalse(illumination.status(device: device).isOn)
    }

    func testThermalShutdownReadbackRemovesOnStateWithoutRetryingHardware() {
        let device = TorchFixture()
        var illumination = CameraIllumination()
        illumination.start(device: device, sessionRunning: true)
        device.isTorchAvailable = false
        device.isTorchActive = false
        let state = illumination.status(device: device)
        XCTAssertFalse(state.available)
        XCTAssertFalse(state.isOn)
        XCTAssertTrue(state.message.contains("kullanılamıyor"))
        XCTAssertEqual(device.levels.count, 1, "A thermal shutdown must not cause repeated torch activation attempts")
        XCTAssertTrue(illumination.requestedEnabled)
    }

    func testMissingDeviceIsUnavailableAcrossStartAndStop() {
        var illumination = CameraIllumination()
        illumination.start(device: nil, sessionRunning: true)
        XCTAssertEqual(illumination.status(device: nil), .unavailable)
        illumination.stop(device: nil)
        XCTAssertEqual(illumination.status(device: nil), .unavailable)
        XCTAssertTrue(illumination.requestedEnabled)
    }
}
