# DentalArchLab · iPhone 0.13.0

Yeni: [yakın çekimden XYZ sonucuna tam akış](MACRO_XYZ_V013.md). Önizleme otomatik netler; taramayı başlatınca ölçüm odağı kilitlenir. Yakın çekim XYZ kendi fiziksel lens kalibrasyonunu kullanır.

Önceki sürüm: [doku birleştirme ve Exocad araştırma aktarımı](TISSUE_EXOCAD.md), doğrulanmış
Vida Dental 9 mm kütüphane kimliği ve [yakın çekim kamera seçimi](CAMERA_CLOSEUP.md).
Üretici dosyası eşleşmesi fiziksel parça kalibrasyonu veya klinik doğruluk değildir.

Tarama ekranı kameraya ağırlık verir: üstte ses, sürekli ışık ve ayrıntılar; bayrak/FDI başına
ilerleme halkası; altta tek başlat/duraklat düğmesi. Canlı kamera sürekli aynı ölçekte kalır;
analiz fotoğrafı kameranın yerine geçmez. 250 ms'den yeni örnek noktaları kısa, şeffaf
geri bildirim olarak gösterilebilir; bunlar AR takibi değildir. Daha eski analiz, kendi
etiketli küçük görüntüsünde gösterilir. Görüntünün canlıya uyarlanması aynı kırpma ve
elle seçilen odak yardım ölçeğini kullanır; otomatik yakınlaştırma yapılmaz.
Yeşil algılama işareti veri kabulünü, tamamlanan halka yeterli görünüm kapsamını belirtir;
ikisi de fiziksel doğruluk ölçümü değildir.

Ölçüm karesi 1920×1080, sabit 1× ve 30 FPS hedefini korur. Yeni yakın çekim/standart
seçimi fiziksel ultra geniş/geniş lens kullanır; uygun 4K sensör biçimi önizleme için
tercih edilir. Kalibrasyon lensi ve sürümlü optik imza aynen geri çağrılır. PNG/JPEG
sıkıştırması kamera geri çağrı kuyruğundan ayrıdır; aynı anda yalnız bir kodlama işi vardır.
Gerçek kare geliş hızı, düşen kareler ve son kodlama süresi cihazda ölçülür. Gösterilen
kamera FPS'i analiz sayısı değildir. Bayrak analiz döngüsü en fazla 5 Hz hedefler ve
işlem bitmeden yenisini başlatmaz; kalibrasyonun açı çeşitliliği/kabul kuralları korunur.
Yerel motora görüntü doğrudan Data olarak gider; base64/JSON resim dönüşümü yapılmaz.
Görüntü çözme, hash ve kalıcı kare I/O arayüzden ayrıdır. Bu değişiklikler cihazda belirli
bir FPS veya fiziksel doğruluk garantisi vermez; gerçek ölçümler cihaz deneyiyle kaydedilir.

Kabul edilen yeni kare hafif ses, yeni tamamlanan bayrak belirgin onay sesi üretir. Tekrarlanan
kayıt onayları yeniden ötmez. Ses oturumu sessiz anahtarında da çalışacak şekilde yapılandırılır;
medya sesi sıfırsa açıklama gösterilir. Ayrıntılar'daki Ses dene ile cihazda kontrol edin.
Işık varsayılan olarak kamera açılışında %25 güçte istenir; gerçek donanım durumu gösterilir.
Işık değişirse kayıtlı optik profil korunarak pozlama yeniden hazırlanır. Kamera kapanınca,
kesintiye uğrayınca veya uygulama arka plana geçince ışık ve tarama sesi durdurulur.

3B görünüm çubuk yerine şematik MUA gövdesi kullanır. Gerçek kayıtta yalnız ölçülmüş
`T_world_mua` bulunan bağlantı MUA olarak gösterilir; eksik dönüşüm bayrak işareti olarak
kalır. Yeni Vida Dental referansı MG-MUASBU'dur; eski MG-MUASB9 kayıtları korunur.
Çizilen şematik gövde üretici CAD'i değildir.
Görünüm geometri hesabını değiştirmez ve üretime hazır Exocad dosyası oluşturmaz.
Apple derleme/test kanıtı sürümün teslim paketinde ayrıca doğrulanmalıdır; Windows sözdizimi
kontrolü Apple testi ya da fiziksel iPhone ses/ışık doğrulaması sayılmaz.

3B hesap aktarımındaki iç içe liste hatası açık tipli gözlem birleştirmesiyle düzeltilir.
Hesap hatası veren fiziksel tarama, sonuç ekranından korunmuş karelerle yeniden hesaplanabilir.
Bilgisayardaki sanal ağız için 2B deney kullanılmalıdır; ekran resmi fiziksel XYZ ölçümü değildir.

2B bayrak deneyinde her kimlik yalnız bir kez kaydedilir. Tamamlanan kimlikler yeşil kalır;
aynı kimlik yeniden ses üretmez. Tüm kimlikler kaydedilince deney özeti otomatik açılır.
Özet, tanınan ve eksik bayrakları gösterir; ekrandaki modelden XYZ veya Exocad geometrisi üretmez.
3B taramada çoklu görünüm geometrisi korunur; 24 uygun kare ve bayrak başına 8 görünümde
hesap otomatik başlar. Hesap hatası varsa sonuç ekranında açıklama görünür.

ScanCompletionTests içindeki dik CAD resmi, Xcode'un PNG dönüşümünü engellemek için
`.dat` kaynağı olarak paketlenir; SHA-256 ile özgün PNG baytları doğrulanır.
Doğrudan motor testi PNG'yi, otomatik kamera akışı testi iPhone deneyiyle aynı JPEG 0.94
kodlamasını kullanır. Bunlar fiziksel iPhone optik doğrulaması değildir.

Yeni kalibrasyon ve bayrak deneyinde odak otomatik bulunur ve sabitlenir; manuel odak sayısı seçilmez. Tahtayı/bayrakları başlamadan kameranın ortasında tutun. Kayıtlı kalibrasyonla 3B tarama ve yarım kalan kayıtlar kendi sabit odaklarını korur. Ana kamera ekranı büyütülmüştür; uygun kare kaydında kısa yeşil geri bildirim verilir. Ayrıntılar ikincil paneldedir. 2B deneyinde Yeniden netle onayları korur. Fiziksel 3B tarama aynı kalibrasyon odağını korur.

Yerel SwiftUI / AVFoundation / OpenCV araştırma prototipi. Kalibrasyon, bağımsız DAL bayrak algılama, çoklu kare 3B fotogrametri, ölçülmüş MUA dönüşümü, sonuç görüntüleme ve CSV/JSON/PLY paylaşımı iPhone içinde çalışır. Tarama sırasında PC, USB veya internet gerekmez. AltStore imzalama/yenileme süreci uygulamanın hesaplamasından ayrıdır.

## İlk cihaz testi

1. Mevcut uygulamayı silmeden yeni IPA ile güncelleyin. Eski PC kayıtları salt okunur korunur; yeni kayıtlar yerel motoru kullanır.
2. USB kablosunu çıkarın, uçak modunu açın. Başlangıç → **Hesap motorunu test et**. Gerçek yerel algoritmalar sentetik görüntü ve bilinen geometriyle çalışır. Başarı fiziksel doğruluk kanıtı değildir.
3. **Bayrak deneyi (2B)** → Çekim → Kamerayı aç. DAL N48 D4 dik v1 bayraklarda dört beyaz nokta görünmeli. Otomatik tarama uygun kareyi yeşil çerçeve ve sesle kaydeder. Yeşil = görüntü kabulü; mikron doğruluğu değildir.
4. Kamera açılamazsa **Kamera hata ayrıntıları** metnini kopyalayın. KAM-02 çözünürlük, KAM-03–05 odak durumu; bunlar gözlenen hata nedenini ayırır. Sabit odak kalite koşulları gevşetilmez.
5. **Kamera kalibrasyonu → Kalibrasyon taramasını başlat**: kamera hazırlanır ve net, farklı açılı kareler otomatik seçilir. Tek tek fotoğraf çekmeniz gerekmez. Ekrandaki `54/54 iç köşe` algılamayı, `…/20 uygun kare` kaydı gösterir. Tahtanın tamamını gösterin; telefonu sağa/sola, yukarı/aşağı ve hafif eğimli açılara taşıyıp kısa süre sabit tutun. Uygun karede ses gelir. İlk 20 karede hesap kendiliğinden başlar; açı/uyum yetersizse beşer ek kare ister, 60 karede hâlâ yetersizse durur. **Duraklat / Devam et** kayıtları korur.
6. Fiziksel tarama için 9×6 iç köşeli düz fiziksel tahtanın gerçek kare kenarını ölçün ve başlamadan **Fiziksel tahta boyutunu ölçtüm** seçeneğini açın. Ekrandaki tahtayı deniyorsanız bu seçenek kapalı kalsın; ekran deneyi 3B ölçüm kalibrasyonu sayılmaz. Hesap tamamlanınca **Yeni kayıt hazırla**, uygun kalibrasyonu seçip 4/6 bayrak için FDI planını hazırlayın. Modeli sabit tutup telefonu hareket ettirin; her yeni karede önceki karelerle en az iki ortak bayrak gerekir.
7. Kapsam hedefi 24 kare / bayrak başına 8 görünüm. **Hesapla**: en az 12 uygun kare ve bayrak başına 4 görünüm gerektirir; geometri/algoritma kontrolleri ayrıca başarısız olabilir. Sonuçta uyarıları ve piksel uyum hatasını inceleyin.
8. Sonuç → **Araştırma dosyalarını paylaş**. Veriler Dosyalar → iPhone’umda → DentalArchLab altında korunur.

## Ölçüm sınırları

- Tescilli PIC/iMetric kodu, marker geometrisi veya doğruluk iddiası kullanılmaz.
- Nominal CAD bayrak geometrisi fiziksel baskı doğruluğunun yerine geçmez. Referans cihazla tekrar yerleştirme, eksen/merkez ve full-arch doğrulaması gerekir.
- MG-MUASB9 kullanıcı tarafından bildirilen parça referansıdır. Exocad kütüphane eşleşmesi doğrulanmadı. PLY merkez/eksen çizgileridir; diş yüzey ağı veya üretime hazır protez dosyası değildir.
- Ölçülmüş bayrak–MUA dönüşümü yoksa yalnız bayrak merkezleri gösterilir. [MUA dosya modeli](MUA_CALIBRATION.md).
- Fiziksel doğruluk ve sıfır hata garantisi yoktur. Piksel artık hatası mikrona çevrilmez; sentetik hata raporu ayrı tutulur.

## Mimari ve geliştirme

`DentalArchCapture/OfflineEngine.swift` seri CPU actor üzerinde dosya destekli kayıt ve kabul kararlarını yönetir. `NativeEngine` özgün C++ algılama, kalibrasyon, poz, DLT ve sınırlı robust bundle adjustment uygular. Objective-C++ köprüsü görüntü boyutlarını ImageIO ile kontrol eder ve pikselleri OpenCV ile çözer; HTTP servisi kullanılmaz. Eski BridgeClient yalnız geriye dönük kaynak/test desteğidir; yeni çekim yolu çağırmaz ve uygulamada yerel ağ izni yoktur.

Kalibrasyon, video önizlemesi sürerken yalnız bir kayıpsız sensör karesini analiz eder; işlemler üst üste birikmez. Bulunamayan/bulanık/yinelenen önizlemeler diske fotoğraf olarak kaydedilmez veya kare sınırını tüketmez. Önizleme ve kalıcı kayıt aynı görüntü özetiyle eşleşir. Köşe işaretleri analiz edilen görüntüde gösterilir; yeni canlı kareye eski konumlar taşınmaz. Otomatik hesapta yetersiz eğim veya yüksek artık hata başarı sayılmaz; ek görüntüler istenir. Ekran/ölçülmüş fiziksel tahta ayrımı korunur.

Kamera: arka wide, 1920×1080 sensör koordinatları, sabitleme kapalı. Yeni kayıtta merkezde tek seferlik otomatik netleme, gözlenen sabit lens konumu ve currentLensPosition kilidi kullanılır. Yüz odak önceliği kapalıdır. Hazır olma kararı ayrı üç ardışık uygun kareye dayanır. Kayıtlı profillerde lens konumu toleransı genişletilmez; her kaydedilen karede kilit ve lens konumu yeniden kontrol edilir. Lens konumu 0–1 arası boyutsuz değerdir, mesafe veya mikron doğruluğu değildir.

Mac / Apple derlemesi:

```sh
python3 prepare_opencv.py
python3 generate_project.py
python3 run_mac_checks.py
python3 build_ipa.py --output IPA-output
```

Resmi OpenCV 4.12.0 statik iOS dağıtımı SHA-256 ile sabitlenir. Dağıtım x86_64 simülatör ve arm64 cihaz içerdiği için GitHub Actions `macos-15-intel` kullanır. Framework IPA’ya dinamik olarak gömülmez. Lisans ve üçüncü taraf bildirimleri uygulama kaynaklarına eklenir.

`check_sources.py` Windows’ta yalnız sözdizimi/yapı denetimidir. Apple XCTest sonuçları ve ARM64 IPA doğrulaması ayrı raporlanır. Simülatör testleri fiziksel iPhone kamerasını sınamaz; uçak modu, kamera, basılı bayrak ve fiziksel referans testleri cihazda yapılmalıdır.
