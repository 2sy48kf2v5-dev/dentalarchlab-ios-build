"""Build and actually execute XCTest on an available iPhone simulator on a Mac.
No signing credentials, uploads, third-party packages, or account login required.
"""
import datetime
import base64
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent


def simulator_id(payload, available_ids=None, preferred_sdk=None):
    candidates = []
    for runtime, devices in payload.get("devices", {}).items():
        if ".iOS-" not in runtime:
            continue
        for device in devices:
            if device.get("isAvailable") and device.get("name", "").startswith("iPhone"):
                if available_ids is not None and device.get("udid") not in available_ids:
                    continue
                runtime_version = tuple(int(part) for part in runtime.split(".iOS-")[-1].split("-") if part.isdigit())
                version = tuple(-part for part in runtime_version)
                sdk_mismatch = preferred_sdk is not None and runtime_version[:2] != tuple(preferred_sdk)[:2]
                candidates.append((sdk_mismatch, device.get("state") != "Booted", device["name"] != "iPhone 16 Pro Max", "Pro Max" not in device["name"], version, device["udid"]))
    if not candidates:
        raise RuntimeError("Xcode > Settings > Components/Platforms bölümünden bir iOS Simulator indirin.")
    return sorted(candidates)[0][-1]


def available_simulator_ids(output):
    """Parse only concrete iOS Simulator destinations in Xcode's available section."""
    available = False
    result = set()
    for line in output.splitlines():
        line = line.strip()
        if line.startswith("Available destinations for "):
            available = True
        elif line.startswith("Ineligible destinations for "):
            available = False
        elif available and line.startswith("{") and line.endswith("}"):
            fields = dict(part.strip().split(":", 1) for part in line[1:-1].split(",") if ":" in part)
            fields = {key.strip(): value.strip() for key, value in fields.items()}
            identifier = fields.get("id", "")
            if (fields.get("platform") == "iOS Simulator" and identifier
                    and "placeholder" not in identifier.lower() and "error" not in fields):
                result.add(identifier)
    return result


def main():
    if platform.system() != "Darwin":
        print("Bu test Apple iOS SDK gerektirir. Mac üzerinde Xcode kurulduktan sonra çalıştırın.")
        return 2
    env = os.environ.copy()
    conventional = Path("/Applications/Xcode.app/Contents/Developer")
    if "DEVELOPER_DIR" not in env and conventional.exists():
        env["DEVELOPER_DIR"] = str(conventional)
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    out = ROOT / "Validation-Mac" / stamp
    out.mkdir(parents=True)
    report = {"created": stamp, "swift_compiled": False, "xctest_executed": False,
              "real_iphone_tested": False, "physical_accuracy_validated": False, "steps": []}

    def run(name, command, timeout=1200):
        print(name + "…", flush=True)
        log = out / (name + ".log")
        with log.open("w", encoding="utf-8") as stream:
            process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                                       stderr=subprocess.STDOUT, text=True, errors="replace", bufsize=1)
            def copy_output():
                for line in process.stdout:
                    stream.write(line)
                    if "Test Case " in line or "error:" in line or "DAL_NATIVE_VALIDATION_JSON " in line:
                        stream.flush()
                        print(line.rstrip(), flush=True)
                stream.flush()
            reader = threading.Thread(target=copy_output, daemon=True)
            reader.start()
            try:
                exit_code = process.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(); reader.join(timeout=10)
                raise
            reader.join(timeout=10)
        report["steps"].append({"name": name, "exit_code": exit_code, "log": str(log)})
        if exit_code:
            print(log.read_text(encoding="utf-8", errors="replace")[-12000:])
            raise RuntimeError(name + " başarısız. Log: " + str(log))
        return log

    try:
        from prepare_opencv import prepare
        prepare()
        import generate_project
        generate_project.main()
        run("Xcode", ["xcodebuild", "-version"], timeout=60)
        sdk_log = run("SimulatorSDK", ["xcrun", "--sdk", "iphonesimulator", "--show-sdk-version"], timeout=60)
        sdk_version = sdk_log.read_text(encoding="utf-8").strip().splitlines()[-1]
        preferred_sdk = tuple(int(part) for part in sdk_version.split(".")[:2])
        report["simulator_sdk_version"] = sdk_version
        # A fresh hosted Mac may start CoreSimulator during its first query.
        print("Waiting for Apple's available simulator inventory…", flush=True)
        payload = json.loads(subprocess.check_output(["xcrun", "simctl", "list", "devices", "available", "--json"], env=env, timeout=180))
        project = ["xcodebuild", "-project", "DentalArchCapture.xcodeproj", "-scheme", "DentalArchCapture",
                   "-destination-timeout", "180"]
        inventory_ids = {device["udid"] for runtime, devices in payload.get("devices", {}).items()
                         if ".iOS-" in runtime for device in devices
                         if device.get("isAvailable") and device.get("name", "").startswith("iPhone")}

        def discover_destinations(name, expected_ids):
            # simctl inventory alone does not prove this Xcode process can
            # resolve a concrete destination. Retry discovery only, never tests.
            # A cold hosted Mac can temporarily expose only placeholders even
            # after bootstatus succeeds. Wait for a concrete ID, never bypass it.
            for attempt in range(1, 7):
                log = run(name + str(attempt), project + ["-showdestinations"], timeout=240)
                found = available_simulator_ids(log.read_text(encoding="utf-8", errors="replace"))
                if found.intersection(expected_ids):
                    return found
                if attempt < 6:
                    print("Xcode has not listed the requested simulator yet; checking destination discovery once more…", flush=True)
                    time.sleep(20)
            raise RuntimeError("Xcode henüz uygun iPhone Simulator hedefini listelemiyor. Hedef keşif loglarını kontrol edin.")

        if not inventory_ids:
            simulator_id(payload)  # Preserve the explicit missing-runtime explanation.
        discovered = discover_destinations("SimulatorDestinations", inventory_ids)
        sid = simulator_id(payload, available_ids=discovered, preferred_sdk=preferred_sdk)
        report["simulator_id"] = sid
        selected = next((runtime, device) for runtime, devices in payload["devices"].items()
                        for device in devices if device["udid"] == sid)
        report["simulator_runtime"] = selected[0]
        report["simulator_name"] = selected[1]["name"]
        if selected[1].get("state") != "Booted":
            run("SimulatorBoot", ["xcrun", "simctl", "boot", sid], timeout=60)
        run("SimulatorReady", ["xcrun", "simctl", "bootstatus", sid, "-b"], timeout=600)
        discover_destinations("SimulatorReadyDestinations", {sid})
        report["simulator_destination_verified"] = True
        base = project + ["-destination", "platform=iOS Simulator,id="+sid+",arch=x86_64",
                "-derivedDataPath", str(out/"DerivedData"), "CODE_SIGNING_ALLOWED=NO",
                "-jobs", "2", "-parallel-testing-enabled", "NO"]
        run("Build", base + ["build-for-testing"])
        report["swift_compiled"] = True
        result_bundle = out/"Tests.xcresult"
        report["xctest_attempted"] = True
        report["xctest_executed"] = None  # Unknown until xcodebuild confirms completion.
        # Run the physical-ID UI regression first so a menu/selection defect
        # fails before spending time on the complete suite. This is an extra
        # check, not a substitute: every test still runs below on success.
        run("MarkerSelectionSmoke", base + [
            "-only-testing:DentalArchCaptureUITests/SelectedMarkerUITests/testFourPhysicalIDsDrivePlanAndCaptureRings",
            "-resultBundlePath", str(out/"MarkerSelectionSmoke.xcresult"),
            "test-without-building"], timeout=600)
        run("Tests", base + ["-resultBundlePath", str(result_bundle), "test-without-building"])
        report["xctest_executed"] = True
        report["tests_passed"] = True
        # Keep Apple's original result bundle, which includes actual test counts.
        report["xcresult"] = str(result_bundle)
        # Export Apple's actual test attachments, using this Xcode's own help
        # to verify the supported command. The existing report artifact carries
        # PNG bytes so the Windows reviewer can inspect the native UI as well.
        help_text = subprocess.check_output(["xcrun", "xcresulttool", "help", "export", "attachments"], env=env, text=True, timeout=60)
        if "--output-path" in help_text and "--path" in help_text:
            screenshots = out/"Screenshots"
            run("ExportAttachments", ["xcrun", "xcresulttool", "export", "attachments", "--path", str(result_bundle), "--output-path", str(screenshots)], timeout=60)
            report["screenshots"] = [dict(filename=p.name, png_base64=base64.b64encode(p.read_bytes()).decode())
                for p in screenshots.rglob("*.png") if p.stat().st_size < 5_000_000]
        print("Derleme ve simülatör testleri başarılı. Sıradaki adım: iPhone cihaz testi.")
        return 0
    except (OSError, subprocess.SubprocessError, ValueError, RuntimeError) as error:
        report["error"] = str(error)
        print(str(error), file=sys.stderr)
        return 1
    finally:
        (out/"report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print("Test raporu: " + str(out/"report.json"))


if __name__ == "__main__":
    raise SystemExit(main())
