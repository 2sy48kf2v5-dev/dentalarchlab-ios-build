"""Syntax/structure checks on Windows; NOT Swift compilation or XCTest execution."""
import json
from pathlib import Path
import plistlib
import re
import xml.etree.ElementTree as ET
from tree_sitter import Language, Parser
import tree_sitter_swift

root=Path(__file__).resolve().parent
parser=Parser(Language(tree_sitter_swift.language()))
records=[]
for source in sorted(p for folder in ('DentalArchCapture','DentalArchCaptureTests','DentalArchCaptureUITests') for p in (root/folder).glob('*.swift')):
    tree=parser.parse(source.read_bytes())
    def errors(node):
        if node.type=='ERROR' or node.is_missing:
            return [dict(line=node.start_point.row+1,column=node.start_point.column+1,type=node.type,text=node.text.decode())]
        return [error for child in node.children for error in errors(child)]
    records.append(dict(file=str(source.relative_to(root)),errors=errors(tree.root_node)))
with (root/'DentalArchCapture/Info.plist').open('rb') as stream:
    info=plistlib.load(stream)
assert info['NSCameraUsageDescription']
assert 'NSLocalNetworkUsageDescription' not in info and 'NSAppTransportSecurity' not in info
project=(root/'DentalArchCapture.xcodeproj/project.pbxproj').read_text()
for record in records:
    assert Path(record['file']).name in project
ET.parse(root/'DentalArchCapture.xcodeproj/xcshareddata/xcschemes/DentalArchCapture.xcscheme')
report=dict(swift_compiled=False,xctest_executed=False,scope='Tree-sitter syntax + plist/XML/source references only; iOS SDK unavailable on Windows',sources=records,passed=not any(r['errors'] for r in records))
(root.parent/'validation/ios-v0120-source-check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['passed'] else 1)

