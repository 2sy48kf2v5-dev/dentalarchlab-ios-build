# iPhone'da ölçülmüş bayrak–MUA dönüşümü

Bu içe aktarma, her fiziksel bayrağın optik koordinat sistemi ile MUA referans
koordinat sistemi arasındaki **ölçülmüş rijit dönüşümü** saklar. Kalibrasyon
dosyası telefonda tutulur. Yeni 3B tarama başladığında dosyanın içeriği o kaydın
ayarlarına kopyalanır; daha sonra farklı dosya seçmek önceki kaydı değiştirmez.

Bu depoda içe aktarılmaya hazır gerçek bir ölçüm matrisi yoktur. CAD'deki nominal
dönüşüm, parçanın MUA'ya oturduğunun gözlenmesi veya telefonun Ölçüm uygulaması
bu veri yerine kullanılamaz. Testlerdeki matrisler yalnız yazılım test verisidir.

## Ölçümün hazırlanması

1. Basılmış her bayrağa benzersiz fiziksel seri numarası verin. Optik kimlik
   `0…5`, fiziksel seri numarasının yerine geçmez; aynı kimliğin yeniden basılan
   parçası farklı ölçüm gerektirebilir.
2. Basılmış bayrağı uygun referans MUA/fikstüre oturtun. Kullanılacak oturma,
   sıkma ve tekrarlı montaj koşullarını ölçüm raporunda belirtin.
3. Kalibre referans ölçüm cihazıyla dört optik noktanın merkezlerini ve MUA
   referansını aynı koordinat sisteminde ölçün. Tekrarlı ölçüm/oturtma ile uyum
   artığını ve belirsizlikleri raporlayın. Uygulama bu değerleri kendiliğinden
   üretmez veya doğrulamaz.
4. MUA başlangıç noktasını ve eksen yönünü raporda açıkça tanımlayın. Örneğin
   oturma düzleminin merkezini başlangıç, vida/abutment ekseninin koronal yönünü
   `+Z` olarak kullanıyorsanız bu tanımı bütün parçalar için koruyun. X/Y
   yönlerini sağ elli olacak şekilde ayrıca tanımlayın.
5. Ölçümden hesaplanan dönüşümleri, rapor ve cihaz kimliğiyle birlikte aşağıdaki
   şemaya yazın. Kaynağı olmayan sayılarla alanları doldurmayın.

## Koordinat sözleşmesi

- Birim **mm**, matris düzeni **satır esaslı 4 × 4**'tür.
- Sütun vektör kullanılır: `p_marker = T_marker_mua × p_mua`.
- Optik bayrak sistemi, `DAL_DOTS4_V1` nokta koordinatlarıdır: optik yüze
  bakarken `+X` sağa, `+Y` yukarı; `+Z` optik yüzün önüne doğrudur.
- iPhone sonucu `T_world_mua = T_world_marker × T_marker_mua` ile hesaplar.
  Merkez, sonuç matrisinin son sütununun ilk üç değeri; MUA `+Z` ekseni üçüncü
  sütunun ilk üç değeridir.
- Son satır `[0, 0, 0, 1]` olmalıdır. Sol üst 3 × 3 blok ortonormal olmalı ve
  determinantı `+1` olmalıdır. Ölçekleme, kaydırmalı şekil bozma ve yansıma
  matrisi kabul edilmez.

## JSON alanları

| Alan | Zorunlu değer veya anlam |
| --- | --- |
| `schema` | Tam sayı `1` |
| `units` | `mm` |
| `dictionary` | `DAL_DOTS4_V1` |
| `component_reference` | `MG-MUASB9`; kullanıcı tarafından bildirilen parça referansı |
| `geometry_revision` | `DAL_N48_D4_VERTICAL_V1` |
| `source` | `reference_metrology` |
| `reference_device` | Referans ölçüm cihazının izlenebilir kimliği |
| `reference_report` | Ölçüm raporunun izlenebilir kimliği/açıklaması |
| `measured_at` | Saat dilimi içeren ISO 8601 ölçüm tarihi ve saati |
| `flags` | Bir ile altı fiziksel bayrak kaydı |

Her `flags` elemanında şu alanlar bulunur:

| Alan | Tür ve anlam |
| --- | --- |
| `marker_id` | `0…5` arasında benzersiz tam sayı |
| `physical_serial` | Boş olmayan, dosyada benzersiz fiziksel seri numarası |
| `T_marker_mua` | Ölçümden elde edilmiş 4 × 4 rijit dönüşüm; sonlu sayılar |
| `fit_rms_mm` | Referans ölçümüne uyum RMS artığı, mm; sonlu ve negatif olmayan |
| `uncertainty_mm` | Raporlanan konumsal belirsizlik, mm; sonlu ve negatif olmayan |
| `uncertainty_deg` | Raporlanan açısal belirsizlik, derece; sonlu ve negatif olmayan |

Metin alanları başında/sonunda boşluk veya kontrol karakteri içermemelidir.
Belirsizliğin kapsamı, kapsama katsayısı ve hesaplama yöntemi referans raporunda
belirtilmelidir. Bu belirsizlikler bütün tarama sisteminin doğruluğu değildir.

## Telefon üzerinde kullanma

**Başlangıç → Bayrak–MUA kalibrasyonu → Ölçüm JSON dosyasını içe aktar** yoluyla
dosyayı seçin. Arayüz en fazla 256.000 baytlık JSON kabul eder. İçe aktarma
sonucunu durum mesajında kontrol edin; fiziksel seri numaralarıyla kullanılan
parçaları eşleştirin. Değişiklik yeni bir tarama başlatılmadan önce yapılır.

Sonuç JSON'unda kullanılan dosyanın içerik kopyası, SHA-256 özeti ve her bayrak
için kaynak bilgisi korunur. Eşleşmeyen kimliklerin MUA dönüşümü, merkezi ve
ekseni `null` kalır; uygulama onların yerine bayrak merkezini MUA merkezi saymaz.
CSV'de `coordinate_type`, satırın `MUA` veya `MARKER` koordinatı olduğunu belirtir.

Dosyanın yapısal kontrolü, referans ölçümün gerçekten yapıldığını veya seri
numarasının kameradaki parçaya ait olduğunu doğrulamaz. Bu nedenle sonuçta
`measurement_source_verified=false`, `clinically_validated=false` ve
`physical_accuracy_um=null` korunur. MG-MUASB9 referansı tek başına doğrulanmış
Exocad kütüphane eşleşmesi veya üretim çıktısı sağlamaz.
