"""Deterministically generate an Xcode project using only Python's standard library.
This writes project structure; it does not compile or validate against the iOS SDK.
"""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
objects = {}


def ident(name):
    return hashlib.sha256(name.encode()).hexdigest()[:24].upper()


def add(object_key, isa, **values):
    key = ident(object_key)
    objects[key] = dict(isa=isa, **values)
    return key


def configurations(name, settings):
    configs = []
    for mode in ('Debug', 'Release'):
        value = dict(settings)
        if mode == 'Debug':
            value.update(SWIFT_OPTIMIZATION_LEVEL='-Onone', GCC_OPTIMIZATION_LEVEL='0', DEBUG_INFORMATION_FORMAT='dwarf', SWIFT_ACTIVE_COMPILATION_CONDITIONS='DEBUG')
        else:
            value.update(SWIFT_OPTIMIZATION_LEVEL='-O', GCC_OPTIMIZATION_LEVEL='3', DEBUG_INFORMATION_FORMAT='dwarf-with-dsym')
        configs.append(add(name+mode, 'XCBuildConfiguration', name=mode, buildSettings=value))
    return add(name+'Configs', 'XCConfigurationList', buildConfigurations=configs, defaultConfigurationIsVisible=0, defaultConfigurationName='Release')


def serialize(value, indent=0):
    tab = '\t'*indent
    if isinstance(value, dict):
        return '{\n'+''.join(tab+'\t'+json.dumps(k)+' = '+serialize(v, indent+1)+';\n' for k,v in value.items())+tab+'}'
    if isinstance(value, list):
        return '(\n'+''.join(tab+'\t'+serialize(v,indent+1)+',\n' for v in value)+tab+')'
    return json.dumps(str(value))


def main():
    sources=[]; files=[]
    for filename in sorted(p.name for p in (ROOT/'DentalArchCapture').glob('*.swift')):
        f=add(filename, 'PBXFileReference', lastKnownFileType='sourcecode.swift', path='DentalArchCapture/'+filename, sourceTree='<group>')
        files.append(f); sources.append(add(filename+'Build','PBXBuildFile',fileRef=f))
    for path in sorted((ROOT/'NativeEngine').glob('*')):
        if path.suffix not in ('.cpp', '.mm', '.h', '.hpp'):
            continue
        kind = 'sourcecode.cpp.objcpp' if path.suffix == '.mm' else 'sourcecode.cpp.cpp' if path.suffix == '.cpp' else 'sourcecode.c.h'
        f=add(path.name, 'PBXFileReference', lastKnownFileType=kind, path='NativeEngine/'+path.name, sourceTree='<group>')
        files.append(f)
        if path.suffix in ('.cpp', '.mm'):
            sources.append(add(path.name+'Build','PBXBuildFile',fileRef=f))
    opencv=add('OpenCV','PBXFileReference',lastKnownFileType='wrapper.framework',path='vendor/opencv2.framework',sourceTree='<group>')
    files.append(opencv)
    frameworks=add('Frameworks','PBXFrameworksBuildPhase',buildActionMask=2147483647,files=[add('OpenCVLink','PBXBuildFile',fileRef=opencv)],runOnlyForDeploymentPostprocessing=0)
    info=add('Info' ,'PBXFileReference',lastKnownFileType='text.plist.xml',path='DentalArchCapture/Info.plist',sourceTree='<group>')
    testFiles=[]; testBuild=[]
    for path in sorted((ROOT/'DentalArchCaptureTests').glob('*.swift')):
        f=add('Test'+path.name,'PBXFileReference',lastKnownFileType='sourcecode.swift',path='DentalArchCaptureTests/'+path.name,sourceTree='<group>')
        testFiles.append(f); testBuild.append(add('TestBuild'+path.name,'PBXBuildFile',fileRef=f))
    assets=add('Assets','PBXFileReference',lastKnownFileType='folder.assetcatalog',path='DentalArchCapture/Assets.xcassets',sourceTree='<group>')
    sound=add('Sound','PBXFileReference',lastKnownFileType='audio.wav',path='DentalArchCapture/ScanAccepted.wav',sourceTree='<group>')
    files.append(sound)
    resourceBuild=[add('AssetsBuild','PBXBuildFile',fileRef=assets),add('SoundBuild','PBXBuildFile',fileRef=sound)]
    for name in ('OPENCV-LICENSE.txt', 'THIRD-PARTY-NOTICES.txt'):
        licenseFile=add(name,'PBXFileReference',lastKnownFileType='text',path='NativeEngine/'+name,sourceTree='<group>')
        files.append(licenseFile); resourceBuild.append(add(name+'Build','PBXBuildFile',fileRef=licenseFile))
    resources=add('Resources','PBXResourcesBuildPhase',buildActionMask=2147483647,files=resourceBuild,runOnlyForDeploymentPostprocessing=0)
    uiFiles=[]; uiBuild=[]
    for path in sorted((ROOT/'DentalArchCaptureUITests').glob('*.swift')):
        ref=add('UIFile'+path.name,'PBXFileReference',lastKnownFileType='sourcecode.swift',path='DentalArchCaptureUITests/'+path.name,sourceTree='<group>')
        uiFiles.append(ref); uiBuild.append(add('UIBuild'+path.name,'PBXBuildFile',fileRef=ref))
    uiSources=add('UISources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=uiBuild,runOnlyForDeploymentPostprocessing=0)
    uiProduct=add('UIProduct','PBXFileReference',explicitFileType='wrapper.cfbundle',path='DentalArchCaptureUITests.xctest',sourceTree='BUILT_PRODUCTS_DIR')
    appProduct=add('AppProduct','PBXFileReference',explicitFileType='wrapper.application',path='DentalArchCapture.app',sourceTree='BUILT_PRODUCTS_DIR')
    testProduct=add('TestProduct','PBXFileReference',explicitFileType='wrapper.cfbundle',path='DentalArchCaptureTests.xctest',sourceTree='BUILT_PRODUCTS_DIR')
    products=add('Products','PBXGroup',children=[appProduct,testProduct,uiProduct],name='Products',sourceTree='<group>')
    group=add('Root','PBXGroup',children=files+[info,assets]+uiFiles+testFiles+[products],sourceTree='<group>')
    appSources=add('AppSources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=sources,runOnlyForDeploymentPostprocessing=0)
    testSources=add('TestSources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=testBuild,runOnlyForDeploymentPostprocessing=0)
    # Opaque test data preserves original PNG bytes; Xcode must not pngcrush it
    # into its private CgBI format, which camera uploads never use.
    fixtureBuild=[]
    for name in sorted(p.name for p in (ROOT/'DentalArchCaptureTests/Fixtures').glob('*.dat')):
        fixture=add('TrialFixture'+name,'PBXFileReference',lastKnownFileType='file',path='DentalArchCaptureTests/Fixtures/'+name,sourceTree='<group>')
        objects[group]['children'].append(fixture)
        fixtureBuild.append(add('TrialFixtureBuild'+name,'PBXBuildFile',fileRef=fixture))
    testResources=add('TestResources','PBXResourcesBuildPhase',buildActionMask=2147483647,files=fixtureBuild,runOnlyForDeploymentPostprocessing=0)
    common=dict(CLANG_CXX_LANGUAGE_STANDARD='c++17', CLANG_CXX_LIBRARY='libc++', CLANG_ENABLE_OBJC_ARC='YES', SWIFT_VERSION='5.0',IPHONEOS_DEPLOYMENT_TARGET='17.0',TARGETED_DEVICE_FAMILY='1',CODE_SIGN_STYLE='Automatic',SDKROOT='iphoneos',SUPPORTED_PLATFORMS='iphoneos iphonesimulator',SWIFT_STRICT_CONCURRENCY='minimal',CLANG_ENABLE_MODULES='YES')
    common['EXCLUDED_ARCHS[sdk=iphonesimulator*]'] = 'arm64'
    projectConfig=configurations('Project',dict(common,ENABLE_TESTABILITY='YES'))
    appConfig=configurations('App',dict(common,PRODUCT_BUNDLE_IDENTIFIER='org.dentalarchlab.capture',PRODUCT_NAME='$(TARGET_NAME)',INFOPLIST_FILE='DentalArchCapture/Info.plist',LD_RUNPATH_SEARCH_PATHS='$(inherited) @executable_path/Frameworks',GENERATE_INFOPLIST_FILE='NO',ASSETCATALOG_COMPILER_APPICON_NAME='AppIcon', SWIFT_OBJC_BRIDGING_HEADER='NativeEngine/DALBridge.h', FRAMEWORK_SEARCH_PATHS=['$(inherited)','$(SRCROOT)/vendor'], HEADER_SEARCH_PATHS=['$(inherited)','$(SRCROOT)/NativeEngine'], OTHER_LDFLAGS=['$(inherited)','-lc++','-lz','-framework','Accelerate','-framework','AVFoundation','-framework','CoreMedia','-framework','CoreVideo','-framework','CoreGraphics','-framework','UIKit','-framework','ImageIO']))
    testConfig=configurations('Tests',dict(common,PRODUCT_BUNDLE_IDENTIFIER='org.dentalarchlab.capture.tests',PRODUCT_NAME='$(TARGET_NAME)',GENERATE_INFOPLIST_FILE='YES',BUNDLE_LOADER='$(TEST_HOST)',TEST_HOST='$(BUILT_PRODUCTS_DIR)/DentalArchCapture.app/DentalArchCapture'))
    uiConfig=configurations('UITests',dict(common,PRODUCT_BUNDLE_IDENTIFIER='org.dentalarchlab.capture.uitests',PRODUCT_NAME='$(TARGET_NAME)',GENERATE_INFOPLIST_FILE='YES',TEST_TARGET_NAME='DentalArchCapture'))
    app=add('AppTarget','PBXNativeTarget',name='DentalArchCapture',buildConfigurationList=appConfig,buildPhases=[appSources,resources,frameworks],buildRules=[],dependencies=[],productName='DentalArchCapture',productReference=appProduct,productType='com.apple.product-type.application')
    proxy=add('AppProxy','PBXContainerItemProxy',containerPortal=ident('Project'),proxyType=1,remoteGlobalIDString=app,remoteInfo='DentalArchCapture')
    dep=add('AppDep','PBXTargetDependency',target=app,targetProxy=proxy)
    tests=add('TestTarget','PBXNativeTarget',name='DentalArchCaptureTests',buildConfigurationList=testConfig,buildPhases=[testSources,testResources],buildRules=[],dependencies=[dep],productName='DentalArchCaptureTests',productReference=testProduct,productType='com.apple.product-type.bundle.unit-test')
    uiDep=add('UIAppDep','PBXTargetDependency',target=app,targetProxy=proxy)
    uiTests=add('UITarget','PBXNativeTarget',name='DentalArchCaptureUITests',buildConfigurationList=uiConfig,buildPhases=[uiSources],buildRules=[],dependencies=[uiDep],productName='DentalArchCaptureUITests',productReference=uiProduct,productType='com.apple.product-type.bundle.ui-testing')
    project=add('Project','PBXProject',attributes=dict(LastUpgradeCheck='1600',TargetAttributes={app:dict(CreatedOnToolsVersion='16.0'),tests:dict(CreatedOnToolsVersion='16.0',TestTargetID=app),uiTests:dict(CreatedOnToolsVersion='16.0',TestTargetID=app)}),buildConfigurationList=projectConfig,compatibilityVersion='Xcode 14.0',developmentRegion='tr',hasScannedForEncodings=0,knownRegions=['tr','en','Base'],mainGroup=group,productRefGroup=products,projectDirPath='',projectRoot='',targets=[app,tests,uiTests])
    target=ROOT/'DentalArchCapture.xcodeproj';target.mkdir(exist_ok=True)
    (target/'project.pbxproj').write_text('// !$*UTF8*$!\n'+serialize(dict(archiveVersion=1,classes={},objectVersion=56,objects=objects,rootObject=project))+'\n',encoding='utf-8')
    scheme=target/'xcshareddata/xcschemes';scheme.mkdir(parents=True,exist_ok=True)
    ref=lambda uid,name,product:f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{uid}" BuildableName="{product}" BlueprintName="{name}" ReferencedContainer="container:DentalArchCapture.xcodeproj"/>'
    appref=ref(app,'DentalArchCapture','DentalArchCapture.app'); testref=ref(tests,'DentalArchCaptureTests','DentalArchCaptureTests.xctest')
    testref += '</TestableReference><TestableReference skipped="NO">'+ref(uiTests,'DentalArchCaptureUITests','DentalArchCaptureUITests.xctest')
    (scheme/'DentalArchCapture.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1600" version="1.3"><BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES">{appref}</BuildActionEntry></BuildActionEntries></BuildAction><TestAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" shouldUseLaunchSchemeArgsEnv="YES"><Testables><TestableReference skipped="NO">{testref}</TestableReference></Testables></TestAction><LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" debugServiceExtension="internal" allowLocationSimulation="NO"><BuildableProductRunnable runnableDebuggingMode="0">{appref}</BuildableProductRunnable></LaunchAction><ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0">{appref}</BuildableProductRunnable></ProfileAction><AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/></Scheme>''',encoding='utf-8')
    print(target)


if __name__=='__main__':
    main()
