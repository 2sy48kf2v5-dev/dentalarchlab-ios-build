"""Compile an unsigned iPhone app on macOS, verify its executable, then package it.

No Apple credentials are used. The IPA needs personal signing (e.g. AltStore)
before installation. An IPA is never emitted from source or simulator files.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import plistlib
import struct
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent


def device_binary(binary):
    if len(binary) < 32 or binary[:4] != b'\xcf\xfa\xed\xfe':
        raise ValueError('A thin 64-bit Mach-O executable is required.')
    _, cpu, _, file_type, count, command_bytes, _, _ = struct.unpack_from('<8I', binary)
    if cpu != 0x0100000C or file_type != 2:
        raise ValueError('Executable must target ARM64 iPhone, not a simulator/host.')
    end = 32 + command_bytes
    if end > len(binary) or count > 10000:
        raise ValueError('Malformed Mach-O load commands.')
    offset = 32
    platforms = []
    encrypted = False
    for _ in range(count):
        if offset + 8 > end:
            raise ValueError('Truncated Mach-O load command.')
        command, size = struct.unpack_from('<II', binary, offset)
        if size < 8 or offset + size > end:
            raise ValueError('Invalid Mach-O command size.')
        if command == 0x32:  # LC_BUILD_VERSION: PLATFORM_IOS = 2, SIMULATOR = 7
            if size < 24:
                raise ValueError('Invalid build-version command.')
            platforms.append(struct.unpack_from('<I', binary, offset + 8)[0])
        if command in (0x21, 0x2C):  # LC_ENCRYPTION_INFO(_64)
            if size < 20:
                raise ValueError('Invalid encryption command.')
            encrypted |= struct.unpack_from('<I', binary, offset + 16)[0] != 0
        offset += size
    if offset != end or platforms != [2] or encrypted:
        raise ValueError('Not an unencrypted iPhone device build.')
    return dict(architecture='arm64', platform='iPhoneOS', macho_executable=True, encrypted=False)


def verify_app(app):
    app = Path(app).resolve()
    with (app/'Info.plist').open('rb') as f:
        info = plistlib.load(f)
    executable = info.get('CFBundleExecutable', '')
    if not executable or Path(executable).name != executable:
        raise ValueError('Invalid executable name.')
    if info.get('CFBundlePackageType') != 'APPL' or info.get('CFBundleSupportedPlatforms') != ['iPhoneOS']:
        raise ValueError('Info.plist does not identify a real iPhone app.')
    if not info.get('NSCameraUsageDescription'):
        raise ValueError('Camera permission description is missing.')
    binary = (app/executable).read_bytes()
    result = device_binary(binary)
    result.update(bundle_id=info['CFBundleIdentifier'], version=info['CFBundleShortVersionString'],
                  build=info['CFBundleVersion'], minimum_ios=info['MinimumOSVersion'],
                  executable_sha256=hashlib.sha256(binary).hexdigest())
    return result


def package_app(app, ipa):
    app, ipa = Path(app).resolve(), Path(ipa).resolve()
    result = verify_app(app)
    if ipa.exists():
        raise ValueError('Refusing to replace an existing IPA. Use a new output directory.')
    ipa.parent.mkdir(parents=True, exist_ok=True)
    temporary = ipa.with_suffix('.ipa.tmp')
    entries = [p for p in sorted(app.rglob('*')) if p.is_file() or p.is_symlink()]
    try:
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
            for file in entries:
                if file.is_symlink():
                    raise ValueError('Unexpected symlink in iPhone app bundle.')
                z.write(file, 'Payload/' + app.name + '/' + file.relative_to(app).as_posix())
        with zipfile.ZipFile(temporary) as z:
            if z.testzip() is not None:
                raise ValueError('IPA integrity verification failed.')
            if not all(n.startswith('Payload/'+app.name+'/') for n in z.namelist()):
                raise ValueError('Invalid IPA archive structure.')
        temporary.replace(ipa)
    finally:
        if temporary.exists():
            temporary.unlink()
    result.update(ipa_sha256=hashlib.sha256(ipa.read_bytes()).hexdigest(), bytes=ipa.stat().st_size,
                  apple_development_signed=False, requires_personal_signing=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT/'IPA-output')
    args = parser.parse_args()
    if platform.system() != 'Darwin':
        parser.exit(2, 'Apple iOS SDK is required: run this on a macOS build runner. No IPA was created.\n')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out/'build-report.json').exists():
        parser.exit(2, 'Use a fresh output directory for each build.\n')
    env = os.environ.copy()
    if 'DEVELOPER_DIR' not in env and Path('/Applications/Xcode.app/Contents/Developer').exists():
        env['DEVELOPER_DIR'] = '/Applications/Xcode.app/Contents/Developer'
    report = dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  device_build_passed=False, ipa_created=False, real_iphone_tested=False,
                  physical_accuracy_validated=False, source_commit=env.get('GITHUB_SHA'),
                  github_run_id=env.get('GITHUB_RUN_ID'), apple_credentials_used=False)
    try:
        from prepare_opencv import prepare
        prepare()
        report['opencv'] = json.loads((ROOT/'vendor/opencv-version.json').read_text())
        source_archive = ROOT.parent/'iphone-source.zip'
        if source_archive.exists():
            report['source_archive_sha256'] = hashlib.sha256(source_archive.read_bytes()).hexdigest()
        import generate_project
        generate_project.main()
        report['xcode'] = subprocess.check_output(['xcodebuild','-version'],env=env,text=True,timeout=30).strip()
        derived = out/'DerivedData'
        command = ['xcodebuild','-project',str(ROOT/'DentalArchCapture.xcodeproj'),'-scheme','DentalArchCapture',
                   '-configuration','Release','-sdk','iphoneos','-destination','generic/platform=iOS',
                   '-derivedDataPath',str(derived),'CODE_SIGNING_ALLOWED=NO','CODE_SIGNING_REQUIRED=NO',
                   'CODE_SIGN_IDENTITY=','DEVELOPMENT_TEAM=','-jobs','2','build']
        print('Compiling an unsigned iPhone device build...',flush=True)
        with (out/'device-build.log').open('w',encoding='utf-8') as log:
            completed = subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1200)
        if completed.returncode:
            print((out/'device-build.log').read_text(errors='replace')[-18000:])
            raise RuntimeError('Device build failed. No IPA was produced.')
        report['device_build_passed'] = True
        app = derived/'Build/Products/Release-iphoneos/DentalArchCapture.app'
        version = plistlib.loads((app/'Info.plist').read_bytes())['CFBundleShortVersionString']
        ipa = out/f'DentalArchLab-{version}-unsigned.ipa'
        report.update(package_app(app,ipa))
        report['ipa_created'] = True
        (out/(ipa.name+'.sha256.txt')).write_text(report['ipa_sha256']+'  '+ipa.name+'\n',encoding='utf-8')
        (out/'KURULUM.txt').write_text('Bu gerçek iPhone için derlenmiş, imzasız IPA dosyasıdır.\n'
            'AltStore Classic ile kendi Apple hesabınızla imzalanıp kurulmalıdır.\n'
            'Safari/Dosyalar uygulamasında dosyaya dokunmak kurulumu başlatmaz.\n'
            'Kamera ve gerçek cihaz testleri henüz yapılmadı; klinik kullanım için doğrulanmadı.\n',encoding='utf-8')
        print(json.dumps(report,ensure_ascii=False,indent=2))
        return 0
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        report['error'] = str(error)
        print(str(error))
        return 1
    finally:
        (out/'build-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')


if __name__ == '__main__':
    raise SystemExit(main())
