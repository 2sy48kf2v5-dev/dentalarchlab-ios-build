"""Fetch pinned official static OpenCV iOS library for device/Intel simulator.
No image, patient, pairing or user data is uploaded. macOS build time only.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import platform
import plistlib
import subprocess
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
URL = 'https://github.com/opencv/opencv/releases/download/4.12.0/opencv-4.12.0-ios-framework.zip'
SHA256 = '86b42c9f141cd9169b91be2fc380b0e556a88a95c98ccc8e7aef8349ab74cf70'


def prepare():
    vendor = ROOT/'vendor'
    receipt = vendor/'opencv-version.json'
    framework = vendor/'opencv2.framework'
    if receipt.exists() and (framework/'opencv2').exists():
        if json.loads(receipt.read_text()).get('archive_sha256') == SHA256:
            return
    vendor.mkdir(exist_ok=True)
    archive = vendor/'opencv-4.12.0-ios-framework.zip'
    if not archive.exists():
        print('Downloading official OpenCV 4.12.0 iOS static framework', flush=True)
        urllib.request.urlretrieve(URL, archive)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    if digest != SHA256:
        raise RuntimeError('OpenCV checksum mismatch; refusing to build')
    framework.mkdir(exist_ok=True)
    # Official zip has a versioned macOS-style layout and symlinks. iOS tooling
    # expects flat framework Info.plist/Headers/binary. Copy verified real files;
    # do not extract symlinks or untrusted paths.
    prefix = 'opencv2.framework/Versions/A/'
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            if not item.filename.startswith(prefix) or item.is_dir():
                continue
            relative = PurePosixPath(item.filename[len(prefix):])
            if relative.is_absolute() or '..' in relative.parts or (item.external_attr >> 16) & 0o170000 == 0o120000:
                raise RuntimeError('Unsafe OpenCV package path')
            if str(relative) == 'Resources/Info.plist':
                relative = PurePosixPath('Info.plist')
            if relative.parts[0] not in ('Headers', 'Modules') and str(relative) not in ('opencv2', 'Info.plist'):
                continue
            out = framework.joinpath(*relative.parts)
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(z.read(item))
    if platform.system() != 'Darwin':
        raise RuntimeError('OpenCV architecture verification requires macOS/Xcode')
    archs = subprocess.check_output(['xcrun','lipo','-archs',str(framework/'opencv2')], text=True).strip()
    if 'arm64' not in archs.split() or 'x86_64' not in archs.split():
        raise RuntimeError('OpenCV device/simulator architectures missing')
    plist = plistlib.loads((framework/'Info.plist').read_bytes())
    receipt.write_text(json.dumps(dict(version=plist['CFBundleShortVersionString'], archive_sha256=digest,
        source=URL, architectures=archs, linkage='static; do not embed framework',
        simulator='x86_64 only; use macos-15-intel runner'), indent=2))


if __name__ == '__main__':
    prepare()
