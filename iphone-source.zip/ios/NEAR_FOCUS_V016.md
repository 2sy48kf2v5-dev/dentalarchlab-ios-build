# 0.16.0 - Aynı odakta yakın çekim kalibrasyonu

3B tarama, seçili fiziksel kamera kalibrasyonunun odağını geri yükler. Uzakta bir tahta üzerinde kilitlenen odak, yakın bayraklarda net görüntü vermeyebilir. Lens konumu tek başına milimetre cinsinden çalışma mesafesi değildir. Yeni akış, bayraklarda seçilen yakın odağı fiziksel tahta kalibrasyonuna taşır.

## Kullanım

1. Modeli sabitleyin. Kalibrasyon veya duraklatılmış 3B tarama ekranında **Yakın netlik kurulumu** düğmesini açın.
2. Bayrakları çalışacağınız mesafede kameranın ortasına alın. **Bayraklara netle ve sabitle** düğmesine basın. Fiziksel ultra geniş kamera otomatik netler ve odağı kilitler; bu adım kare toplamaz.
3. Noktalar net değilse **Yakın odağı yeniden kur** ile yeniden hazırlayın. Net olduğunu görmeden ilerlemeyin.
4. Telefonun mesafesini koruyup model yerine düz, ölçülmüş kalibrasyon tahtasını aynı netlik düzlemine yerleştirin. Tahtanın 10 x 7 karesinin (9 x 6 iç köşe) tamamı görünmelidir.
5. **Tahta ölçüsünü onayla** bölümüne gerçek kare kenarını mm olarak girin. Önceki tahtanın ölçü onayı yeni kuruluma aktarılmaz. Yakın mesafede sığması için daha küçük kareli fiziksel tahta gerekebilir. Ekran görüntüsü fiziksel tahta yerine geçmez.
6. **Kalibrasyon taramasını başlat**. Hazırlanan odak değişmez. Tahtayı farklı açılarda gösterirken bütün köşeleri net tutun; her yeni açıda kısaca durun. İlerleme ve kalite sınırları korunur.
7. Kalibrasyon başarıyla bittikten sonra başlangıçta yeni 3B kayıt hazırlayın ve bu yeni kalibrasyonu seçin. Bayrakları yine aynı net çalışma aralığında tarayın.

Hazırlık iptal edilirse önceki kayıtlar silinmez. Kamera kapanırsa hazırlanan odak ancak tam aynı kamera profili geri yüklenerek sürdürülür. Odağı yeniden değiştirmek yeni kalibrasyon gerektirir. Yeni ve eski odaklı görüntüler tek 3B kayıtta karıştırılmaz.

## Tanı bilgileri

Yeni rapor, görüntüdeki daire adaylarının neden elendiğini sayar: küçük kontur, geçersiz elips, yetersiz kenar kontrastı, eksik kenar örnekleri. Bu sayaçlar arka planı da içerir; belirli bir fiziksel bayrağa ait oldukları varsayılmaz. `target_blur_available=false` hedef netliğinin ölçülemediğini belirtir; sıfır değerini bayrağın ölçülmüş bulanıklığı olarak yorumlamayın.

Tanıma, kimlik ayrımı, piksel boyutu, poz ve 3B kalite eşikleri değiştirilmemiştir. Bulanık noktaları zorla kabul eden bir yol eklenmemiştir. Kamera akışı, simülatör testleri ve gerçek model performansı ayrı doğrulamalardır. Klinik kullanım veya mikron doğruluğu doğrulanmış değildir.
