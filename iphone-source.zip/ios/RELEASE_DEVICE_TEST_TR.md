# DentalArchLab 0.16.0 / yapı 24 - Modelde cihaz deneyi

Bu sürüm yakın odağı fiziksel kalibrasyondan önce hazırlamayı sağlar. Yazılım testleri tek başına gerçek modelde tanıma ya da konum doğruluğunu kanıtlamaz.

## Kurulum ve netlik

- Mevcut uygulamayı silmeden yeni IPA'yı AltStore ile güncelleyin. Başlangıçta 0.16.0 / 24 yazdığını kontrol edin.
- Model ve ışık sabitken duraklatılmış 3B taramada veya yeni kalibrasyonda **Yakın netlik kurulumu** açın.
- Bayraklar kadrajdayken **Bayraklara netle ve sabitle** seçin. Dört beyaz noktanın ayrı ve net göründüğünü kontrol edin. Bu aşamada kare sayısı artmamalıdır.
- Bu netliği koruyarak ölçülmüş, düz kalibrasyon tahtasını aynı mesafeye yerleştirin. Bütün 9 x 6 iç köşe görünmelidir. Tahta büyük olduğu için bu mesafede sığmıyorsa küçük kareli fiziksel baskı kullanın; rastgele uzaklaştırıp farklı bir odağı kalibre etmeyin.
- **Tahta ölçüsünü onayla** ile gerçek kare kenarını girin, sonra kalibrasyonu başlatın. Başlatma sırasında görüntü bulanıklaşırsa duraklatın ve kamera hata ayrıntılarını kaydedin.

## Baskı kontrolü

Paket içindeki 6 mm SVG hedefinin nominal kare boyu 6 mm, 10 x 7 desen boyu 60 x 42 mm'dir. Yazdırmada yüzde 100 / gerçek boyut kullanın. Beş kareyi yatay ve dikey ölçün; nominal toplam 30 mm'dir. Uygulamaya baskının gerçekten ölçülen toplamını beşe bölerek girin. Yatay ve dikey ölçek farklıysa o baskıyı kullanmayın. Beyaz çerçeveyi ölçüye katmayın. Kağıdı düz, sert bir yüzeye sabitleyin.

## 3B model taraması

- Yeni başarılı kalibrasyonu seçip yeni 3B kayıt oluşturun. Gerçek fiziksel bayrak ID'lerini ve FDI eşleşmelerini seçin.
- Model yerinden oynamadan telefonu yavaşça farklı açılara taşıyın. Başlangıçta en az iki bayrak; sonraki karelerde önceden kaydedilen en az iki ortak bayrak görünmelidir. Eksik yeni bayrağı eklerken önceki iki bayrak da görüntüde kalmalıdır.
- Tanınmış nokta, kabul edilmiş kare, yeterli örnek ve tamamlanmış 3B sonuç farklı aşamalardır. Yeşil bir nokta tek başına fiziksel doğruluk anlamına gelmez.
- Sorun sürerse bayraklar kadrajdayken **Duraklat > ... > Tanıma raporu hazırla > Paylaş** yoluyla son gerçek sensör karesini içeren raporu paylaşın. Görüntü kişisel veri içerebilir; herkese açık kaynak deposuna koymayın.

## Kaydedilecek sonuçlar

| Kontrol | Cihazda gözlenen sonuç |
|---|---|
| Bayraklarda ilk netleme sonrası dört nokta ayrı mı? | |
| Kalibrasyon başlatılınca netlik korunuyor mu? | |
| Kalibrasyon bitiyor mu, RMS ve kullanılan kare sayısı? | |
| 3B taramada gerçek ID'ler ve kabul edilen görüntü sayıları? | |
| 3B sonuç oluşuyor mu, kalite uyarısı var mı? | |
| Uygulama arka plana gidip gelince aynı profil geri yükleniyor mu? | |

Fiziksel konum ve açı hatası, boyutları bilinen referans model/ölçümle ayrıca sınanmalıdır. Kalibrasyon RMS'si piksel cinsindedir; mikron doğruluğu olarak okunmaz.
