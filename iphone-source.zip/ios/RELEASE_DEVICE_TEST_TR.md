# DentalArchLab 0.16.1 / yapı 25 — Kalibrasyon ve 3B geçişi

Bu sürüm kalibrasyonun neden reddedildiğini açıklar ve tamamlanan uygun fiziksel kalibrasyondan 3B taramaya doğrudan geçiş ekler. Hesaplama eşikleri, bayrak tanıyıcı ve kamera geometrisi değişmedi. Son fiziksel kalibrasyonun neden başarısız olduğu henüz yeni bir cihaz kaydıyla doğrulanmadı.

## Tamamlanan kalibrasyonu kullanma

1. Mevcut uygulamayı silmeden IPA'yı AltStore ile güncelleyin; başlangıçta **0.16.1 / yapı 25** yazmalı. Silmek kayıtları kaybettirebilir.
2. Kayıtlar bölümünden tamamlanan fiziksel kalibrasyonu açın. Sonuç ekranındaki **Bu kalibrasyonla 3B tara** düğmesi bu kaydı seçer ve Çekim ekranına geçirir.
3. Kamera kendiliğinden başlamaz. Gerçek fiziksel bayrak ID'lerini ve FDI eşleşmelerini kontrol edip **Taramayı başlat** seçin. Aynı lens ve sabit odak geri yüklenir.
4. Düğme yerine uyarı varsa o neden çözülmelidir. Ekran deneyi, ölçüsü onaylanmamış tahta, geniş lens kaydı, kalite eşiğini geçmeyen sonuç veya uyuşmayan kamera profili yakın çekim 3B için kabul edilmez. Eski kayıtlar korunur.

## Kalibrasyon tamamlanmazsa

- Sonucun gerçek ret nedeni görüntülenir: yetersiz eğim, kadraj dağılımı, yüksek piksel uyum hatası veya hesaplama/veri hatası. Bir hesaplama hatası otomatik olarak eğim eksikliği sayılmaz.
- 60 görüntüde yeterli sonuç elde edilemezse otomatik çekim durur; kabul edilmiş görüntüler silinmez. Aynı çekimi nedenini öğrenmeden tekrar etmeyin. Tam ret mesajının ekran görüntüsünü ve kullanılan uygulama sürümünü paylaşın.
- Başarılı ekran kalibrasyonu fiziksel 3B kalibrasyonuyla aynı değildir. Gerçek tahta ölçüsünü onaylamak gerekir.

## Fiziksel hedef ve yakın odak

Önceki yakın netlik kurulumu korunur: gerçek bayraklara netleyip odağı sabitleyin, ardından aynı mesafeye düz ve ölçülmüş kalibrasyon tahtasını koyun. **Tahta ölçüsünü onayla** işleminden sonra farklı açılar ve kadraj bölgeleriyle tarayın. Tüm 9 × 6 iç köşe görünür olmalıdır. Kırışık veya kat izi taşıyan kağıt düz referans değildir.

Paket içindeki 6 mm hedefi A4'te **%100 / gerçek boyut**, sayfaya sığdır kapalı yazdırın. Beş karenin yatay ve dikey toplamını ölçüp beşe bölün; nominal toplam 30 mm olsa da uygulamaya gerçek baskı ölçüsü girilir. Beyaz dış çerçeveyi dahil etmeyin. Yatay ve dikey ölçek uyuşmuyorsa yeni baskı gerekir.

## Model deneyi

3B araştırmada model sabit kalırken telefonu farklı açılara taşıyın. Başlangıçta ve komşu görüşlerde en az iki ortak bayrak görünmelidir. Tanınan nokta, kabul edilen kare ve tamamlanan 3B sonuç farklı aşamalardır. Yeşil işaret fiziksel doğruluğu kanıtlamaz.

Tanıma sorunu sürerse duraklatıp **Tanıma raporu hazırla > Paylaş** kullanın. Rapor gerçek sensör karesi içerebilir; herkese açık kaynak deposuna yüklemeyin.

Yazılım ve simülatör testleri gerçek iPhone'da odak, baskı doğruluğu veya fiziksel konum doğruluğu yerine geçmez. Kalibrasyon RMS değeri piksel cinsindedir; mikron hata değildir. Klinik kullanım doğrulanmadı.
