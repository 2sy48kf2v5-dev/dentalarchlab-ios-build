# Başlangıç ve yatay çekim · 0.15.0

Başlangıç, beyaz zeminli bir vaka ekranıdır. DentalArchLab adı ve uygulamanın kendi DAL işareti korunur. İsteğe bağlı model/vaka referansı, görsel üst/alt çene seçimi, 4/6 bayrak seçimi ve **Takılı bayraklar ve FDI** bağlantısı aynı karttadır. **Taramayı başlat** ana eylemdir; **Kalibrasyon** ve **2B deneme** ikincil eylemlerdir.

Sağ üstteki **Ayarlar ve araçlar** düğmesi lens tercihini, kayıtlı kalibrasyon seçimini, bayrak–MUA JSON içe aktarımını, çalışma seçimini, yerel motor testini ve bağlantısız 3B örneğini açar. Bu kontroller başlangıç ekranını uzun bir ayar formuna dönüştürmez. Seçili bir kayıt varsa **Kayda devam et** veya **Sonucu aç** ile **Yeni vaka başlat** eylemleri görünür. Yeni vaka açmak vaka referansını temizler; kayıtlı oturumları silmez.

## Çekim düzeni

Çekim ekranına girildiğinde uygulama iOS'tan yatay yön ister. İki yatay yön de desteklenir. Solda kamera alanı ve seçili bayrakların ilerlemesi, sağda sabit çekim kontrolleri bulunur. Uzun durum ve yönlendirme metinleri sağdaki ayrı alanda kaydırılır; ana çekim düğmesi bu metinlerle birlikte kaybolmaz. Yatay ekranda alt sekme çubuğu gizlenir. Sol üstteki geri düğmesi başlangıca çıkar ve dikey yön ister. Sistem yön isteğini reddederse dikey yerleşim kullanılabilir.

Ekran yönü ve nokta çizimi, görüntünün gösterilme biçimiyle ilgilidir. Kaydedilen ölçüm görüntüsü ve kamera kalibrasyonunun sensör koordinatları bu arayüz dönüşü için değiştirilmez. Kamera kapalıyken **KAMERA KAPALI** gösterilir; çekim ekranına geçmek tek başına kamerayı açmaz.

Çekime girip başlangıca dönmek seçili gerçek bayrak ID'lerini ve FDI planını değiştirmez. Dört bayrakta seçili dört gerçek ID, altı bayrakta DAL 0–5 ailesi kullanılır. Çene veya bayrak adedini değiştirdikten sonra FDI atamalarını yeniden kontrol et.

## XYZ ve fiziksel tahta

**Taramayı başlat**, yakın çekim XYZ hazırlığını kullanır. Uygun fiziksel ultra geniş lens kalibrasyonu yoksa önce kalibrasyon ekranı açılır. Ekrandaki örnek veya kalibrasyonsuz 2B tanıma, fiziksel XYZ kalibrasyonu yerine geçmez.

Kalibrasyon tahtası düz ve sabit olmalıdır: 10 × 7 kare, 9 × 6 iç köşe. Katlanmış tahtayı düz bir baskı ve düz taşıyıcıyla değiştir. Yeni baskının ölçeğini yeniden ölç. **16,4 mm**, ancak kullanılacak düz tahtada beş karenin toplamı yeniden **82,0 mm** ölçülürse girilecek tek kare kenarıdır. İki yöndeki ölçüyü ve düzlüğü kontrol et; önceki baskının değerini otomatik olarak kullanma.

## Doğrulama sınırı

Simülatör; ekran yerleşimi, düğmelere erişim, yön geçişi ve durumun korunması için kullanılabilir. Gerçek iPhone netliğini, kamera FPS değerini, ışığı, fiziksel ölçüm doğruluğunu veya klinik uygunluğu doğrulamaz. Cihaz kontrol adımları: [0.15.0 cihaz deneyi](../docs/V0150_CIHAZ_DENEYI_TR.md).
