#!/bin/zsh
cd -- "$(dirname -- "$0")" || exit 1
python3 run_mac_checks.py
result=$?
printf '\nTest bitti. Kapatmak icin Enter.\n'
read -r answer
exit "$result"
