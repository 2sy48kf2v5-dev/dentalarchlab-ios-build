# Yakın çekim netliği · 0.13.0

Yeni kayıt hazırlarken **Yakın çekim** seçeneği fiziksel ultra geniş kamerayı açar. Sabit lens konumunu destekleyen bu kamera yoksa uygulama başka bir lense sessizce geçmez; Standart seçeneği gerekir. **Standart** fiziksel geniş kamerayı kullanır. iPhone 16 Pro Max'te yakın çekim lensinin gerçek netliği ayrıca cihaz üzerinde kontrol edilmelidir.

Önceki sürüm yalnız geniş kamerayı ve ilk 1920×1080 biçimini seçiyordu. Yeni kayıtlarda uygun biçimler arasından 30 fps destekleyen 3840×2160 sensör biçimi tercih edilir; bulunamazsa 1920×1080 seçimi ekranda gösterilir. Canlı önizleme doğrudan kamera katmanından gelir. Analiz ve kalibrasyon kareleri aynı görüş alanında 1920×1080 kalır; Apple'ın video çıkışı boyutlandırması kullanılır. **4K sensör tercihi, 4K ölçüm yapıldığı veya 4K ekran bulunduğu anlamına gelmez.** Analiz PNG'sinde sonradan yapay keskinleştirme/ayrıntı üretme uygulanmaz.

## İlk fiziksel deneme

1. Güncellemeden sonra **Yeni kayıt → Kalibrasyon → Yakın çekim** seçin. Eski geniş kamera kalibrasyonu ultra geniş kamera için kullanılamaz.
2. Tahtayı kullanmayı planladığınız çalışma mesafesinde, görüntünün ortasında tutup kamerayı açın. Önizleme otomatik netlemeye devam eder. Görüntü net olduğunda **Kalibrasyon taramasını başlat** ile ölçüm odağını kilitleyin. Tam akış: [yakın çekim XYZ](MACRO_XYZ_V013.md).
3. Net bir görüntüyle fiziksel tahta kalibrasyonunu tamamlayın. Sonrasında 3B tarama bu kalibrasyonun lensini, sensör biçimini ve odak konumunu aynen geri çağırır.
4. Çekim ayrıntılarında gerçek lensi, sensör/analiz çözünürlüğünü, cihazın bildirdiği minimum odak mesafesini ve kamera FPS'ini okuyun. Minimum mesafe kesin netlik garantisi veya canlı mesafe ölçümü değildir.
5. Basılı bayrağı birkaç farklı çalışma mesafesinde 1× önizlemeyle kontrol edin; tanıma raporundaki gerçek analiz karesini de inceleyin. Netliği artırmak için telefonun fiziksel odak sınırının içine girmeyin.

Ekrandaki 1×/2× düğmesi **ekran büyütmesidir**. Sensör zoom'unu değiştirmez veya yeni ayrıntı oluşturmaz; yeni mod/kayıtta 1×'e döner. Sadece bu düğmeye basarak yakındaki optik bulanıklık giderilemez.

Tarama sürerken sürekli otomatik odak veya otomatik lens atlaması açılmadı. Bunlar kamera geometrisini değiştirebilir. Sabit kalibrasyonla her mesafede aynı netlik vaat edilemez; netleme mesafesi değiştirilirse uygun yeni kalibrasyon gerekir. Yakın çekim lensinin daha geniş netlik alanı bu sorunu azaltabilir ama cihazda doğrulanmadan garanti sayılmaz.

## Profil korunması

Yeni optik imza, fiziksel cihaz/lens, sensör çözünürlüğü, format, görüş açısı, binning, geometrik düzeltme durumu ve format indeksini ayırt eder. Kayıtlı biçim bulunamazsa başka bir biçimle ölçüm devam etmez. Eski yalnız sayısal formatlı geniş kamera profili eski 1080p seçimine geri döner. Bu eski profilin netlik iyileştirmelerini kendiliğinden kazanması beklenmemelidir.

## Doğrulama sınırı

Sentetik birim testleri profil seçimini, eski profile dönüşü, eşleşmeyen lens/formatın reddini ve çıktı boyutunu sınar. iPhone Simulator fiziksel kamera odağını, 4K önizleme akıcılığını veya minimum netleme mesafesini test etmez. Gerçek telefon denemesinde lens, görüntü, FPS, analiz hızı, ısınma ve düşen kareler birlikte kaydedilmelidir. T-Marker ile eşit optik performans gösterildiği iddia edilmez.

Apple kaynakları: [Video çıkışı boyutları](https://developer.apple.com/documentation/avfoundation/avcapturevideodataoutput/videosettings), [minimum odak mesafesi](https://developer.apple.com/documentation/avfoundation/avcapturedevice/minimumfocusdistance).
